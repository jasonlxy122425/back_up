from Default.DefaultConfigInterface import *

class PredictorConfig:
    def __init__(self):
        self.quoter_symbol = ""
        self.model_path = ""
        self.model_type = "lgb"
        self.factors = []
        self.main_signal_weight = 1.0
        self.assist_signal_weight = 0.0

class OrderLogicConfig:
    def __init__(self):
        self.improve_ticks = 0
        self.custom_max_notional = 10000
        pass

@add_default_config
class KronosConfig():
    def __init__(self, tag):
        self.tag = tag
        self.sub_tag = f"{self.tag}"
        self.predictorConfig = PredictorConfig()
        self.assistPredictorConfig = PredictorConfig()
        self.orderLogicConfig = OrderLogicConfig()
        self.order_logic = "Kronos"
        self.predictor = ""
        self.assist_predictor = ""
    
    def setSymbol(self, quoter_symbol):
        self.predictorConfig.quoter_symbol = quoter_symbol
        self.assistPredictorConfig.quoter_symbol = quoter_symbol

        factor_symbols = [ factor['symbol'] for factor in self.predictorConfig.factors] + [factor['asst_symbol'] for factor in self.predictorConfig.factors if "asst_symbol" in factor.keys()]

        self.reference_symbols = [quoter_symbol]
        self.reference_symbols.extend(factor_symbols)
        self.reference_symbols = list(set(self.reference_symbols))


        assist_factor_symbols = [ factor['symbol'] for factor in self.assistPredictorConfig.factors] + [factor['asst_symbol'] for factor in self.assistPredictorConfig.factors if "asst_symbol" in factor.keys()]
        self.assist_reference_symbols = list(set(assist_factor_symbols))

