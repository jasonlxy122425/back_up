#pragma once
#include <memory>
#include "SystemDefine.h"
#include "DemeterDataManager.h"
#include "GaiaOrderbook.h"
#include "Predictor.h"
#include "StrategyFields.h"

class DataWriteSampler {
public:
    DataWriteSampler(){};
    void init(uint64_t sample_count) { sample_count_ = sample_count; }

    bool sample(SymId sid) {
        if(sample_count_ <= 0) {
            return true;
        }
        if(sid_count_.find(sid) == sid_count_.end()) sid_count_[sid] = 0;

        if(++sid_count_[sid] >= sample_count_) {
            sid_count_[sid] = 0;
            return true;
        }
        return false;
    }

private:
    std::unordered_map<SymId, uint64_t> sid_count_;
    uint64_t sample_count_ = 0;
};


struct DataWriter {
    static std::shared_ptr<DataWriter> CreateDataWriter(const Config &config, StrategyFields*, Predictor *, std::shared_ptr<demeter::DemeterDataManager>);

    DataWriter() {}
    virtual ~DataWriter() {}
    void Initialize(const Config config, StrategyFields *st, Predictor *pred) {
        strategy_fields_ = st;
        predictor_ = pred;

        write_factors = config.Get<bool>("write_factors", false);
        write_orderbook = config.Get<bool>("write_orderbook", true);
        write_demeter = config.Get<bool>("write_demeter", true);
        write_origin_quote = config.Get<bool>("write_origin_quote", true);
        write_latency = config.Get<bool>("write_latency", true);
        write_ob_l1 = config.Get<bool>("write_ob_l1", true);
        write_kline = config.Get<bool>("write_kline", true);

        uint64_t sample_count = 0;
        try {
            sample_count = config.Get<uint64_t>("sample_count");
        } catch(...) {
            sample_count = 0;
        }


        sampler_.init(sample_count);
        this->Initialize(config);
    }
    void setUnCappedNumLevels(size_t num_bids, size_t num_asks) {num_bids_ = num_bids; num_asks_ = num_asks;}
    void setLatency(StrategyLatency *strategy_latency) { latency_ = strategy_latency; }
    virtual void Initialize(const Config config) = 0;
    virtual void WriteData(const GaiaOrderbook&, SymId sid, double price, double qty,
                   Side side, std::string trade_id,
                   double bid_price, double bid_qty,
                   double ask_price, double ask_qty,
                   const md::Kline &kline,
                   md::Message *msg, int64_t seq_id) = 0;

    void setDemeterDatas(std::shared_ptr<demeter::DemeterDataManager> &demeter_manager) { demeter_data_manager_ = demeter_manager; }
    void saveOb(const GaiaOrderbook &gaia_ob, SymId sid) { last_ob_[sid] = gaia_ob; }

    void OnTrade(const md::Trade &trade) {
        last_trade_[trade.sid] = trade;
        // WriteData(gaia_ob, (Message *)&trade, 0);
        last_msg_[trade.sid] = *(md::Message*)&trade;
        last_seq_id_[trade.sid] = 0;
    }

    void OnBestQuote(const md::BestQuote &bbo) {
        last_bbo_[bbo.sid] = bbo;
        // WriteData(gaia_ob, (Message *)&bbo, bbo.seq_id);
        last_msg_[bbo.sid] = *(md::Message*)&bbo;
        last_seq_id_[bbo.sid] = bbo.seq_id;
    }

    void OnOrderbook(const md::FlatOrderbook &ob) {
        // Implementation for handling orderbook data
        // WriteData(gaia_ob, (Message *)&ob, ob.seq_id);
        last_msg_[ob.sid] = *(md::Message*)&ob;
        last_seq_id_[ob.sid] = ob.seq_id;
    }

    void OnLiquidation(const md::Liquidation &liquidation) {
        // Implementation for handling liquidation data
        last_trade_[liquidation.sid].cb_start_ts = liquidation.cb_start_ts;
        last_trade_[liquidation.sid].parser_end_ts = liquidation.parser_end_ts;
        last_trade_[liquidation.sid].exch_ts = liquidation.exch_ts;
        last_trade_[liquidation.sid].recv_ts = liquidation.recv_ts;
        last_trade_[liquidation.sid].qs_send_ts = liquidation.qs_send_ts;
        last_trade_[liquidation.sid].side = liquidation.side;
        last_trade_[liquidation.sid].price = liquidation.price;
        last_trade_[liquidation.sid].qty = liquidation.qty;
        strcpy(last_trade_[liquidation.sid].trade_id, "liquidation");

        last_msg_[liquidation.sid] = *(md::Message*)&liquidation;
        last_seq_id_[liquidation.sid] = 0;
        // WriteData(gaia_ob, (Message *)&liquidation, 0);
    }

    void OnKline(const md::Kline &kline) {
        last_kline_[kline.sid] = kline;
        last_msg_[kline.sid] = *(md::Message*)&kline;
        last_seq_id_[kline.sid] = 0;
    }

    void WriteData(const GaiaOrderbook &gaia_ob, SymId sid) {
        if(!sampler_.sample(sid)) return;
        CheckLastData(sid);
        std::string write_trade_id;
        if (last_trade_[sid].trade_id_as_seq)  write_trade_id = std::to_string(last_trade_[sid].trade_id_as_int());
        else write_trade_id = last_trade_[sid].trade_id;
        WriteData(gaia_ob, sid, last_trade_[sid].price, last_trade_[sid].qty, last_trade_[sid].side,
                  write_trade_id,
                  last_bbo_[sid].best_bid.price, last_bbo_[sid].best_bid.qty,
                  last_bbo_[sid].best_ask.price, last_bbo_[sid].best_ask.qty,
                  last_kline_[sid],
                  &last_msg_[sid], last_seq_id_[sid]);
    }

    void WriteData(SymId sid) {
        if(!sampler_.sample(sid)) return;
        CheckLastData(sid);
        std::string write_trade_id;
        if (last_trade_[sid].trade_id_as_seq)  write_trade_id = std::to_string(last_trade_[sid].trade_id_as_int());
        else write_trade_id = last_trade_[sid].trade_id;
        WriteData(last_ob_[sid], sid, last_trade_[sid].price, last_trade_[sid].qty, last_trade_[sid].side,
                  write_trade_id,
                  last_bbo_[sid].best_bid.price, last_bbo_[sid].best_bid.qty,
                  last_bbo_[sid].best_ask.price, last_bbo_[sid].best_ask.qty,
                  last_kline_[sid],
                  &last_msg_[sid], last_seq_id_[sid]);
    }

    void CheckLastData(SymId sid) {
        if(last_trade_.find(sid) == last_trade_.end()) {
            last_trade_[sid].price = 0;
            last_trade_[sid].qty = 0;
            last_trade_[sid].side = Side::UNKNOWN;
	        last_trade_[sid].trade_id[0] = '\0';
        }
    }


protected:
    std::unordered_map<SymId, md::Message> last_msg_;
    std::unordered_map<SymId, int64_t> last_seq_id_;
    std::unordered_map<SymId, GaiaOrderbook> last_ob_;
    Config config_;
    std::string zone_;
    Predictor *predictor_ = nullptr;
    StrategyFields *strategy_fields_ = nullptr;
    FactorOutputType factors_;

    StrategyLatency *latency_;

    DataWriteSampler sampler_;

    bool write_factors = false;
    bool write_orderbook = true;
    bool write_demeter = true;
    bool write_origin_quote = false;
    bool write_latency = false;
    bool write_ob_l1 = false;
    bool write_kline = false;

    std::unordered_map<SymId, md::Trade> last_trade_;
    std::unordered_map<SymId, md::BestQuote> last_bbo_;
    std::unordered_map<SymId, md::Kline> last_kline_;
    std::shared_ptr<demeter::DemeterDataManager> demeter_data_manager_;
    size_t num_bids_;
    size_t num_asks_;
};
