#include "Factor.h"
#include "Ema.h"
#include <cmath>
#include "GaiaCircularBuffer.h"

class TradeASellJumpFactor : public FactorInterface
{
public:
    TradeASellJumpFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
        threshold = config.Get<int64_t>("threshold");
        lookback = config.Get<double>("lookback");
        last_prc_buffer.setSize(lookback, 0.0);
        prev_exch_ts = 0;

    };

    virtual std::string gen_name() {;
        return std::string("TradeASellJumpFactor") + "@threshold=" + std::to_string(threshold) + "@lookback=" + std::to_string(lookback);
    }

    virtual void calculate(const FactorInput& input_data) {
        factor_value = 0.0;
        auto &trade = input_data.cur_contract->trade;
        int64_t exch_ts = trade.exch_ts;
        if (trade.side == Side::BUY){
            if (std::abs(exch_ts - prev_exch_ts) > MinErr){
                last_prc_buffer.push(trade.price);
            }
            else {
                last_prc_buffer[-1] = trade.price;
            }
        }
        if(last_prc_buffer.isFull() != false){
            double prc_diff_bps = 1e4*(last_prc_buffer[-1] - last_prc_buffer[0])/last_prc_buffer[0]; 
            if (prc_diff_bps >= threshold){
                factor_value = 1.0;
            }
        }
        prev_exch_ts = exch_ts;
        
    };

private:
    int64_t lookback;
    GaiaCircularBuffer<double> last_prc_buffer;
    int64_t prev_exch_ts;
    int64_t threshold;
    double last_price = 0.0;
    
};
                              
