#include "Factor.h"
#include "Ema.h"
#include <cmath>
#include "GaiaCircularBuffer.h"

class TradeALastSigmaFactor : public FactorInterface
{
public:
    TradeALastSigmaFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
        lookback = config.Get<int64_t>("lookback");
        var_ewma = config.Get<int64_t>("var_ewma");
        last_prc_buffer.setSize(lookback, 0.0);

    };

    virtual std::string gen_name() {;
        return std::string("TradeALastSigmaFactor") + "@lookback=" + std::to_string(lookback) + "@var_ewma=" + std::to_string(var_ewma);
    }

    virtual void calculate(const FactorInput& input_data) {
        factor_value = 0.0;
        var_ewma = var_ewma/100.0;
        auto &trade = input_data.cur_contract->trade;
        int64_t exch_ts = trade.exch_ts;
        double prc_tick_size = input_data.cur_contract->symbol_info->prc_tick_size;
        if (exch_ts != prev_exch_ts) {
            last_prc_buffer.push(trade.price);
        }
        else {
            last_prc_buffer[-1] = trade.price;
        }
        if(last_prc_buffer.isFull() != false){
            double last_diff = last_prc_buffer[-1] - last_prc_buffer[0];
            ewma_var = var_ewma*ewma_var + (1.0 - var_ewma)*std::pow(last_diff, 2);
            factor_value = std::sqrt(ewma_var/lookback/prc_tick_size);
        }
        prev_exch_ts = exch_ts;
        
    };

private:
    int64_t lookback;
    GaiaCircularBuffer<double> last_prc_buffer;
    int64_t prev_exch_ts = 0;
    int64_t var_ewma = 0.0;
    double ewma_var = 0.0;
    
};
                              
