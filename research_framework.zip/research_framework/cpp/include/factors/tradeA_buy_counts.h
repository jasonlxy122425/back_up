#include "Factor.h"
#include "Ema.h"
#include <cmath>
#include "GaiaCircularBuffer.h"

class TradeABuyCountsFactor : public FactorInterface
{
public:
    TradeABuyCountsFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
        lookback = config.Get<int64_t>("lookback");
        threshold = config.Get<int64_t>("threshold");
        d_threshold = 1e3 * static_cast<double>(threshold);
        qty_buffer.setSize(lookback, 0.0);
        prev_exch_ts = 0;

    };

    virtual std::string gen_name() {;
        return std::string("TradeABuyCountsFactor") + "@threshold=" + std::to_string(threshold) + "@lookback=" + std::to_string(lookback);
    }

    virtual void calculate(const FactorInput& input_data) {
        factor_value = 0.0;
        auto &trade = input_data.cur_contract->trade;
        exch_ts = trade.exch_ts;
        
        double this_amt = trade.price * trade.qty;
        if (trade.side == Side::SELL) {
            this_amt = -trade.price * trade.qty;
        }
        
        if (exch_ts != prev_exch_ts) {
            if (qty_buffer.isFull()) {
                if (qty_buffer[0] >= d_threshold) {
                    buy_count -= 1;
                }
            }

            if (this_amt >= d_threshold) {
                buy_count += 1;
            }

            qty_buffer.push(this_amt);
        } else {
            double old_amt = qty_buffer[-1];
            double new_amt = old_amt + this_amt;
            
            bool old_need_count = (old_amt >= d_threshold);
            bool new_need_count = (new_amt >= d_threshold);
            
            if (old_need_count && !new_need_count) {
                buy_count -= 1;
            } else if (!old_need_count && new_need_count) {
                buy_count += 1;
            }

            qty_buffer[-1] += this_amt;
        }

        if (qty_buffer.isFull()) {
            factor_value = buy_count;
        }
        
        prev_exch_ts = exch_ts;
    };

    // virtual void calculate(const FactorInput& input_data) {
    //     factor_value = 0.0;
    //     auto &trade = input_data.cur_contract->trade;
    //     int64_t exch_ts = trade.exch_ts;
    //     if (trade.side == Side::BUY){
    //         this_amt = trade.price*trade.qty;
    //     }
    //     else if (trade.side == Side::SELL){
    //         this_amt = -trade.price*trade.qty;
    //     }
    //     if (std::abs(exch_ts - prev_exch_ts) > MinErr){
    //         qty_buffer.push(this_amt);
    //     }
    //     else {
    //         qty_buffer[-1] += this_amt;
    //     }

    //     if(qty_buffer.isFull() != false){
    //         for (int i=0; i < lookback; i++){
    //             if (qty_buffer[i] >= 1e3*threshold){
    //                 factor_value += 1;
    //             }
    //         }
    //     }
    //     prev_exch_ts = exch_ts;
        
    // };

private:
    int64_t lookback;
    GaiaCircularBuffer<double> qty_buffer;
    int64_t prev_exch_ts;
    double this_amt = 0.0;
    int64_t threshold;
    double d_threshold;

    int64_t exch_ts;
    int32_t buy_count = 0;
    
};
