#include "Factor.h"
#include "Ema.h"
#include <cmath>
#include "GaiaCircularBuffer.h"

class TradeTsIntervalFactor : public FactorInterface
{
public:
    TradeTsIntervalFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
    };

    virtual std::string gen_name() {;
        return std::string("TradeTsIntervalFactor");
    }

    virtual void calculate(const FactorInput& input_data) {
        factor_value = 0.0;
        auto &trade = input_data.cur_contract->trade;
        if (prev_exch_ts > MinErr){
            factor_value = (trade.exch_ts - prev_exch_ts)/1e6;
        }
        prev_exch_ts = trade.exch_ts;
        
    };

private:
    double this_qty = 0.0;
    int64_t prev_exch_ts = 0;
    
};
                              
