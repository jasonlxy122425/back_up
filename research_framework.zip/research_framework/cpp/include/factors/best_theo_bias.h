#include "Factor.h"
#include "Ema.h"
#include <cmath>

class BestTheoBiasFactor : public FactorInterface
{
public:
    BestTheoBiasFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
        theo_gamma = config.Get<double>("theo_gamma");
    };

    virtual std::string gen_name() {
        return std::string("BestTheoBiasFactor") + "@theo_gamma=" + std::to_string(theo_gamma);
    }

    virtual void calculate(const FactorInput& input_data) {
        auto &ob = input_data.cur_contract->alphaBook;
        double adj_bz = std::pow(ob->bid(0).qty, theo_gamma);
        double adj_az = std::pow(ob->ask(0).qty, theo_gamma);
        double w_bid = adj_az/(adj_bz + adj_az);
        double theo = w_bid*ob->bid(0).price + (1.0 - w_bid)*ob->ask(0).price; 
        double mid_price = (ob->bid(0).price + ob->ask(0).price)/2.0;
        factor_value = theo - mid_price;
    };


private:
    double theo_gamma;
};
                              
