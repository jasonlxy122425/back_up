#include "Factor.h"
#include "Ema.h"
#include <cmath>

class TradePxChgFactor : public FactorInterface
{
public:
    TradePxChgFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
        ema_int = config.Get<int16_t>("ema_int");
        ema_bid_chg.init(ema_int);
        ema_ask_chg.init(ema_int);
        ema_bid_match.init(ema_int);
        ema_ask_match.init(ema_int);
        prev_bid_price = 0.0;
        prev_ask_price = 0.0;

    };

    virtual std::string gen_name() {;
        return std::string("TradePxChgFactor") + '@' + std::to_string(ema_int);
    }

    virtual void calculate(const FactorInput& input_data) {
        auto &gob = input_data.cur_contract->alphaBook;
        auto &demeter_data = input_data.cur_contract->demeter_data;
        double bid_match = std::log(demeter_data->GetGobUpdateSum(Side::BUY, demeter::BookOrderType::Match)+1.0);
        double ask_match = std::log(demeter_data->GetGobUpdateSum(Side::SELL, demeter::BookOrderType::Match)+1.0);
        ema_bid_match.update(bid_match);
        ema_ask_match.update(ask_match);
        double bid_price = gob->bid(0).price;
        double ask_price = gob->ask(0).price;
        double bid_chg = 0.0;
        double ask_chg = 0.0;
        if (prev_bid_price > MinErr){
            if (prev_bid_price > bid_price + MinErr){
                bid_chg = prev_bid_price - bid_price;
            }
            if (ask_price > prev_ask_price + MinErr){
                ask_chg = ask_price - prev_ask_price;
            }
        }
        ema_bid_chg.update(bid_chg);
        ema_ask_chg.update(ask_chg);
        factor_value = ema_bid_chg.get()*ema_bid_match.get() - ema_ask_chg.get()*ema_ask_match.get();
        prev_bid_price = bid_price;
        prev_ask_price = ask_price;
    };

private:
    int64_t ema_int;
    Ema ema_bid_chg;
    Ema ema_ask_chg;
    Ema ema_bid_match;
    Ema ema_ask_match;
    double prev_bid_price;
    double prev_ask_price;
};
                              
