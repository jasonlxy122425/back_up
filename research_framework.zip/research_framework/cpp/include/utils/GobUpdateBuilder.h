#pragma once

#include "ContractInfo.h"
#include "GaiaCircularBuffer.h"

namespace demeter {

template<typename GobUpdateT>
class GobUpdateBuilder {
public:
    void Update(GaiaCircularBuffer<GaiaOrderbook> &order_book_buf, ContractInfo *contract, GobUpdateT &gob_update) {
        if(contract->update_tick_type == TickEventType::TICK_BBO
            || contract->update_tick_type == TickEventType::TICK_OB
            || contract->update_tick_type == TickEventType::TICK_TRADE) {
            OnBookChange(order_book_buf, gob_update);
        } else if (contract->update_tick_type == TickEventType::TICK_LIQUIDATION) {
            OnLiquidation(contract->liquidation, gob_update);
        } else {
            // unhandled tick type
            return;
        }
    }

private:
    void OnBookChange(GaiaCircularBuffer<GaiaOrderbook> &order_book_buf, GobUpdateT &gob_update) {
        if(order_book_buf.size() < 2) {
            return;
        }
        GaiaOrderbook &order_book = order_book_buf[-1];
        GaiaOrderbook &last_order_book = order_book_buf[-2];

        auto book_updater = [this](const std::vector<PriceLevel> &levels, const std::vector<PriceLevel> &last_levels, GobUpdateT &gob_update,
                                    auto compare, Side side) {
            const PriceLevel &best_level = levels[0];
            const PriceLevel &last_best_level = last_levels[0];

            int side_int = side == Side::BUY ? 1 : -1;

            if (compare(best_level.price, last_best_level.price + side_int * eps)) { // if cur level better than last level
                double insert_qty = get_insert_qty(last_best_level, levels, compare, side_int);
                gob_update.get(side, BookOrderType::Insert).push_back(insert_qty);
            } else if (compare(last_best_level.price, best_level.price + side_int * eps)) { // if cur level worse than last level
                double match_qty = get_match_qty(best_level, last_levels, compare, side_int);
                Side match_side = side == Side::BUY ? Side::SELL : Side::BUY;
                gob_update.get(match_side, BookOrderType::Match).push_back(match_qty);
            } else { // if cur level equal to last level
                if (best_level.qty > last_best_level.qty + eps) {
                    gob_update.get(side, BookOrderType::Insert).push_back(best_level.qty - last_best_level.qty);
                } else if (best_level.qty < last_best_level.qty - eps) {
                    gob_update.get(side, BookOrderType::Cancel).push_back(last_best_level.qty - best_level.qty);
                }
            }
        };

        book_updater(order_book.bids(), last_order_book.bids(), gob_update, std::greater<double>(), Side::BUY);

        book_updater(order_book.asks(), last_order_book.asks(), gob_update, std::less<double>(), Side::SELL);
    }

    double get_insert_qty(const PriceLevel &last_level, const std::vector<PriceLevel> &levels, auto compare, int side_int) {
        double insert_qty = 0;
        for (const auto &level : levels) {
            if (compare(level.price, last_level.price + side_int * eps)) {
                insert_qty += level.qty;
            } else if (Double::Equal(level.price, last_level.price)) {
                if (level.qty > last_level.qty + eps) {
                    insert_qty += level.qty - last_level.qty;
                }
                break;
            } else {
                break;
            }
        }
        return insert_qty;
    }

    double get_match_qty(const PriceLevel &best_level, const std::vector<PriceLevel> &last_levels, auto compare, int side_int) {
        double match_qty = 0;
        for (const auto &last_level : last_levels) {
            if (compare(last_level.price, best_level.price + side_int * eps)) {
                match_qty += last_level.qty;
            } else if (Double::Equal(best_level.price, last_level.price)) {
                if(last_level.qty > best_level.qty + eps) {
                    match_qty += last_level.qty - best_level.qty;
                }
                break;
            } else {
                break;
            }
        }
        return match_qty;
    }

    void OnBook(GaiaCircularBuffer<GaiaOrderbook> &order_book_buf, GobUpdateT &gob_update) {
        GaiaOrderbook &order_book = order_book_buf[-1];
        GaiaOrderbook &last_order_book = order_book_buf[-2];
        auto bbo_updater = [this](const PriceLevel &level, const PriceLevel &last_level, GobUpdateT &gob_update,
                                    auto compare, Side side) {
            int side_int = side == Side::BUY ? 1 : -1;
            if (compare(level.price, last_level.price + side_int * eps)) {
                gob_update.get(side, BookOrderType::Insert).push_back(level.qty);
            } else if (compare(last_level.price, level.price + side_int * eps)) {
                gob_update.get(side, BookOrderType::Cancel).push_back(last_level.qty);
            } else {
                if (level.qty > last_level.qty + eps) {
                    gob_update.get(side, BookOrderType::Insert).push_back(level.qty - last_level.qty);
                } else if (level.qty < last_level.qty - eps) {
                    gob_update.get(side, BookOrderType::Cancel).push_back(last_level.qty - level.qty);
                }
            }
        };

        bbo_updater(order_book.bid(0), last_order_book.bid(0), gob_update, std::greater<double>(), Side::BUY);
        bbo_updater(order_book.ask(0), last_order_book.ask(0), gob_update, std::less<double>(), Side::SELL);
    }

    void OnTrade(Trade &trade, GobUpdateT &gob_update) {
        gob_update.get(trade.side, BookOrderType::Match).push_back(trade.qty);
    }

    void OnLiquidation(md::Liquidation &liquidation, GobUpdateT &gob_update) {
        gob_update.get(liquidation.side, BookOrderType::Liquidation).push_back(liquidation.qty);
    }
};

}; // namespace demeter