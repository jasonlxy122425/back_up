#pragma once

#include <optional>
#include <type_traits>
#include <vector>

#include "CommonDefine.h"

enum class GaiabookTradeMaskPolicy {
  // go through each level of the book where price is more aggresive compare to the trade price
  // mask the qty level by level, if the level's qty is fully masked, we will erase the level
  MASK_QTY_ONLY,

  // go through each level of the book where price is more aggresive compare to the trade price
  // we erase the level directly, then we mask book level's qty with trade's qty
  MASK_PRICE_AND_QTY
};

enum class GaiabookExchTsCmpPolicy { EXCH_TS_GREATOR, EXCH_TS_EQUAL_OR_GREATOR };

template <class GaiabookTraits>
class GaiaOrderbookBase {
 public:
  using PriceLevel = md::PriceLevel;

  GaiaOrderbookBase() {
    bids_.reserve(md::MAX_ORDERBOOK_LEVELS);
    asks_.reserve(md::MAX_ORDERBOOK_LEVELS);
    // make sure top of book always has sensible values
    bids_[0] = PriceLevel(0, 0);
    asks_[0] = PriceLevel(0, 0);

    last_buy_trade = Trade();
    last_sell_trade = Trade();
    buy_trade_exch_ts_ = 0;
    sell_trade_exch_ts_ = 0;
    last_data_type_ = TickEventType::TICK_NONE;
  }

  const std::vector<PriceLevel> &bids() const {
    return bids_;
  }

  const std::vector<PriceLevel> &asks() const {
    return asks_;
  }

  int num_bids() const {
    return bids().size();
  }

  int num_asks() const {
    return asks().size();
  }

  PriceLevel bid(int i) const {
    return bids()[i];
  }

  PriceLevel ask(int i) const {
    return asks()[i];
  }

  Nanoseconds exch_ts() const {
    return std::max(std::max(ob_exch_ts_, bbo_exch_ts_), trade_exch_ts_);
  }

  int64_t seq_id() const {
    return seq_id_;
  }

  void OnOrderbook(const md::FlatOrderbook &book) {

    bids_.assign(book.bid_data(), book.bid_data() + book.num_bids);
    asks_.assign(book.ask_data(), book.ask_data() + book.num_asks);

    bool slow_than_last_quote = (bbo_seq_id_ > book.seq_id && bbo_exch_ts_ >= book.exch_ts) || bbo_exch_ts_ > book.exch_ts;
    bool slow_than_last_trade = buy_trade_exch_ts_ >= book.exch_ts || sell_trade_exch_ts_ >= book.exch_ts;
    if (slow_than_last_quote) {
        OnBestQuote(last_quote);
        // ob -> bq -> trade / ob -> trade -> bq
        if (slow_than_last_trade) {
            if(buy_trade_exch_ts_ >= bbo_exch_ts_ || sell_trade_exch_ts_ >= bbo_exch_ts_) {
                if(buy_trade_exch_ts_ >= bbo_exch_ts_) OnTrade(last_buy_trade);
                if(sell_trade_exch_ts_ >= bbo_exch_ts_) OnTrade(last_sell_trade);
            }
        }
    } else if (slow_than_last_trade) {
        // bq -> ob -> trade / bq -> ob -> trade
        if(buy_trade_exch_ts_ >= book.exch_ts) OnTrade(last_buy_trade);
        if(sell_trade_exch_ts_ >= book.exch_ts) OnTrade(last_sell_trade);
    }

    // some exchanges would reset seq_id
    if (slow_than_last_quote) {
        seq_id_ = std::max(book.seq_id, seq_id_);
    } else {
        seq_id_ = book.seq_id;
    }
    ob_seq_id_ = book.seq_id;
    ob_exch_ts_ = book.exch_ts;

    updated_by_cur_tick_ = true;
  }

  void OnTrade(const md::Trade &trade) {
    if(G_UNLIKELY(trade.src == Source::DMM)) OnTradeSeq(trade.price, trade.qty, trade.side, trade.exch_ts, trade.trade_id_as_int(), trade.src);
    else OnTradeExch(trade.price, trade.qty, trade.side, trade.exch_ts, trade.src);
  }

  G_INLINE void OnTradeSeq(const Price &prc, const Qty &qty, const Side &side, const Nanoseconds &trade_ts, const int64_t &seq_id, const Source &src) {
    updated_by_cur_tick_ = false;
    if(!IsTradeLeadingObBboSeq(seq_id)) return;
    if(!IsCrossBbo(prc, side)) return;

    if(trade_ts <= trade_exch_ts_) return;
    OnTrade(prc, qty, side, trade_ts, src);
  }

  G_INLINE void OnTradeExch(const Price &prc, const Qty &qty, const Side &side, const Nanoseconds &trade_ts, const Source &src) {
    updated_by_cur_tick_ = false;
    if (!IsTradeLeadingObBbo(trade_ts, prc, qty, side)) return;
    Nanoseconds prev_trade_ts = (side == Side::BUY? last_buy_trade.exch_ts : last_sell_trade.exch_ts);
    if (trade_ts < prev_trade_ts) return;

    bool last_trade_is_dmm = (side == Side::BUY ? (last_buy_trade.src == Source::DMM) : (last_sell_trade.src == Source::DMM));
    if (last_trade_is_dmm && trade_ts <= trade_exch_ts_) return;
    OnTrade(prc, qty, side, trade_ts, src);
  }

  G_INLINE void OnTrade(const Price &prc, const Qty &qty, const Side &side, const Nanoseconds &trade_ts, const Source &src) {
    updated_by_cur_tick_ = false;
    // AssertBookInGoodShape();

    TradeMaskBookPxAndQty(prc, qty, side);
    if (side == Side::BUY) {
    // auto de-cross bids as we might insert new levels in asks
        size_t i = 0;
        while (i < bids_.size() && Double::GreaterOrEqual(bids_[i].price, prc)) {
            i++;
        }
        bids_.erase(bids_.begin(), bids_.begin() + i);
        if (bids_.empty() && !asks_.empty() && prc_tick_) {
            auto syntatic_level = PriceLevel(asks_[0].price - *prc_tick_, default_qty_);
            if (Double::Greater(syntatic_level.price, 0.0)) {
                bids_.push_back(syntatic_level);
            }
        }
    } else {
        size_t i = 0;
        while (i < asks_.size() && Double::LessOrEqual(asks_[i].price, prc)) {
            i++;
        }
        asks_.erase(asks_.begin(), asks_.begin() + i);
        if (asks_.empty() && !bids_.empty() && prc_tick_) {
            auto syntatic_level = PriceLevel(bids_[0].price + *prc_tick_, default_qty_);
            asks_.push_back(syntatic_level);
        }
    }

    trade_exch_ts_ = std::max(trade_exch_ts_, trade_ts);
    if(side == Side::BUY) {
        last_buy_trade.price = prc;
        last_buy_trade.qty = qty;
        last_buy_trade.side = side;
        last_buy_trade.exch_ts = trade_ts;
        last_buy_trade.src = src;
        buy_trade_exch_ts_ = std::max(buy_trade_exch_ts_, trade_ts);
    } else {
        last_sell_trade.price = prc;
        last_sell_trade.qty = qty;
        last_sell_trade.side = side;
        last_sell_trade.exch_ts = trade_ts;
        last_sell_trade.src = src;
        sell_trade_exch_ts_ = std::max(sell_trade_exch_ts_, trade_ts);
    }
    last_data_type_ = TickEventType::TICK_TRADE;

    // AssertBookInGoodShape();
    updated_by_cur_tick_ = true;
  }

  void OnBestQuote(const md::BestQuote &bbo) {
    updated_by_cur_tick_ = false;
    // AssertBookInGoodShape();
    if(bbo.best_bid.price == 0 || bbo.best_ask.price == 0) {
        return;
    }

    if(!Double::Greater(bbo.best_ask.price, bbo.best_bid.price)) {
        return;
    }

    // slow than ob/bbo
    if (!IsBboLeadingOb(bbo.exch_ts, bbo.seq_id)) {
        return;
    }

    // slow than buy_trade / sell_trade
    if(bbo.exch_ts <= buy_trade_exch_ts_ && bbo.exch_ts <= sell_trade_exch_ts_) {
        return;
    }

     if(bbo.exch_ts > trade_exch_ts_) {
         UpdateBestQuoteImpl<std::greater<Price>>(bbo.best_bid, bids_);
         UpdateBestQuoteImpl<std::less<Price>>(bbo.best_ask, asks_);
     } else if (bbo.exch_ts > sell_trade_exch_ts_) {
         if(asks_.size() > 0 && Double::GreaterOrEqual(bbo.best_bid.price, asks_[0].price)) return;
         UpdateBestQuoteImpl<std::greater<Price>>(bbo.best_bid, bids_);
     } else if (bbo.exch_ts > buy_trade_exch_ts_) {
         if(bids_.size() > 0 && Double::LessOrEqual(bbo.best_ask.price, bids_[0].price)) return;
         UpdateBestQuoteImpl<std::less<Price>>(bbo.best_ask, asks_);
     }
    seq_id_ = bbo.seq_id;
    bbo_seq_id_ = bbo.seq_id;
    bbo_exch_ts_ = std::max(bbo_exch_ts_, bbo.exch_ts);

    last_data_type_ = TickEventType::TICK_BBO;
    last_quote = bbo;
    // AssertBookInGoodShape();

    updated_by_cur_tick_ = true;
  }

    void OnLiquidation(const md::Liquidation &liquidation) {
        updated_by_cur_tick_ = false;
    }

  bool IsBboLeadingOb(const Nanoseconds &bbo_exch_ts, const int64_t &bbo_seq_id) const {
    // handle exch ts first, some exchanges seq_id might restart from 0/1
    // when exchange restart the system
    if (bbo_exch_ts > ob_exch_ts_ || bids_.empty() || asks_.empty()) {
      return true;
    }

    if (bbo_seq_id) {
      return bbo_seq_id > seq_id_;
    }

    assert(bbo_exch_ts <= ob_exch_ts_);
    return false;
  }

  bool IsTradeLeadingObBbo(const Nanoseconds &trade_ts, const Price &prc, const Qty &qty, const Side &side) const {
    if(trade_ts > std::max(ob_exch_ts_, bbo_exch_ts_)) {
        return true;
    } else if (trade_ts == std::max(ob_exch_ts_, bbo_exch_ts_)) {
        if(last_data_type_ == TickEventType::TICK_TRADE) return true;

        if(side == Side::BUY && Double::GreaterOrEqual(prc, asks_[0].price)) return true;
        else if(side == Side::SELL && Double::LessOrEqual(prc, bids_[0].price)) return true;
    }
    return false;
  }

  bool IsTradeLeadingObBboSeq(const Nanoseconds &trade_seq_id) const {
    if(trade_seq_id > std::max(ob_seq_id_, bbo_seq_id_)) {
        return true;
    }
    return false;
  }

  bool IsCrossBbo(const Price &price, const Side &side) const {
    if(side == Side::BUY && asks_.size() > 0 && Double::Equal(asks_[0].price, price)) {
      return false;
    }
    if(side == Side::SELL && bids_.size() > 0 && Double::Equal(bids_[0].price, price)) {
      return false;
    }

    return true;
  }

    void DeleteExcessLevels(const int &max_level) {
        if (bids_.size() > max_level) {
            bids_.erase(bids_.begin() + max_level, bids_.end());
        }
        if (asks_.size() > max_level) {
            asks_.erase(asks_.begin() + max_level, asks_.end());
        }
    }

  void set_price_tick_size(const Price &price_tick) {
    prc_tick_ = price_tick;
  }

  // value to init the syntatic book level
  void set_default_qty_size(const Qty &qty) {
    default_qty_ = qty;
  }

  void capBookLevel(int &num_levels) {
    if (bids_.size() > num_levels) bids_.erase(bids_.begin() + num_levels, bids_.end());
    if (asks_.size() > num_levels) asks_.erase(asks_.begin() + num_levels, asks_.end());

    if (bids_.size() < num_levels) {
      int prev_size = bids_.size();
      bids_.resize(num_levels);
      std::fill(bids_.begin() + prev_size, bids_.end(), PriceLevel(0, 0));
    }

    if (asks_.size() < num_levels) {
      int prev_size = asks_.size();
      asks_.resize(num_levels);
      std::fill(asks_.begin() + prev_size, asks_.end(), PriceLevel(0, 0));
    }
  }

  bool updated_by_cur_tick() const { return updated_by_cur_tick_; }

 private:
  Nanoseconds ob_exch_ts_ = 0;
  Nanoseconds trade_exch_ts_ = 0;
  Nanoseconds buy_trade_exch_ts_ = 0;
  Nanoseconds sell_trade_exch_ts_ = 0;
  Nanoseconds bbo_exch_ts_ = 0;

  md::BestQuote last_quote;
  md::Trade     last_buy_trade;
  md::Trade     last_sell_trade;

  int64_t seq_id_ = 0;
  int64_t ob_seq_id_ = 0;
  int64_t bbo_seq_id_ = 0;
  // TODO, change to absl::btree or other data structure to reduce the latency
  // if we enabled 400 level book, current 95% tail latency is around 0.6 us which
  // is acceptable
  std::vector<PriceLevel> bids_;
  std::vector<PriceLevel> asks_;
  Qty default_qty_{1};
  std::optional<Price> prc_tick_;

  TickEventType last_data_type_;
  bool updated_by_cur_tick_ = false;

  template <class Compare>
  void UpdateBestQuoteImpl(PriceLevel best, std::vector<PriceLevel> &levels) {
    int num_levels = levels.size();
    if (num_levels == 0) {
      levels.push_back(best);
    }

    Compare cmp;
    if (cmp(best.price, levels[0].price)) {
      if (levels.size() == levels.capacity()) levels.pop_back();
      levels.insert(levels.begin(), best);
    } else if (best.price == levels[0].price) {
      levels[0].qty = best.qty;
    } else {
      levels[0] = best;

      // find first level worse than best and delete everying in between
      int i = 1;
      for (; i < num_levels; ++i) {
        if (cmp(best.price, levels[i].price)) break;
      }
      levels.erase(levels.begin() + 1, levels.begin() + i);
    }
  }

  template <class Compare>
  void TradeMaskBookQtyOnly(Price prc, Qty qty, std::vector<PriceLevel> &levels) {
    Compare cmp;
    int num_levels = levels.size();

    int i = 0;
    for (; i < num_levels && qty > 0; ++i) {
      if (cmp(prc, levels[i].price)) break;
      if (levels[i].qty > qty) {
        levels[i].qty -= qty;
        break;
      } else {
        qty -= levels[i].qty;
      }
    }
    levels.erase(levels.begin(), levels.begin() + i);

    if (levels.empty()) {
      // make sure top of book always has sensible values
      levels.emplace_back(prc, default_qty_);
    }

  }

  void TradeMaskBookPxAndQty(const Price &prc,const Qty &qty, const Side &side) {
    int i = 0;
    bool is_new_level = false;

    auto &levels(side == Side::BUY ? asks_ : bids_);
    const int &num_levels = levels.size();

    for (; i < num_levels; ++i) {
      // try to locate the level where price is [same]/[more aggresive]
      if (side == Side::BUY) {
        if (Double::Greater(prc, levels[i].price)) continue;
      } else {
        if (Double::Less(prc, levels[i].price)) continue;
      }

      if (Double::Equal(prc, levels[i].price)) {
        // if the level exists
        if (levels[i].qty >= qty) {
          levels[i].qty -= qty;
          levels[i].qty = std::max(levels[i].qty, default_qty_);
        } else {
          levels[i].qty = default_qty_;
        }
      } else {
        is_new_level = true;
      }

      break;
    }

    if (is_new_level) {
      if (i > 0) {
        levels.erase(levels.begin(), levels.begin() + i - 1);
        levels[0] = PriceLevel(prc, default_qty_);
      } else {
        levels.insert(levels.begin(), PriceLevel(prc, default_qty_));
      }
    } else {
      levels.erase(levels.begin(), levels.begin() + i);
    }

    if (levels.empty()) {
      // make sure top of book always has sensible values
      levels.emplace_back(prc, default_qty_);
    }
  }

  void AssertBookInGoodShape() const {
    // bids in discend order
    assert(std::is_sorted(bids_.begin(), bids_.end(), [](const auto &x, const auto &y) {
      assert(x.qty > 0);
      assert(y.qty > 0);
      return x.price > y.price;
    }));
    // asks in ascend order
    assert(std::is_sorted(asks_.begin(), asks_.end(), [](const auto &x, const auto &y) {
      assert(x.qty > 0);
      assert(y.qty > 0);
      return x.price < y.price;
    }));
  }
};

struct SmartGaiabookTraits {
  static constexpr GaiabookTradeMaskPolicy trade_mask_policy =
      GaiabookTradeMaskPolicy::MASK_PRICE_AND_QTY;
  static constexpr GaiabookExchTsCmpPolicy exch_ts_cmp_policy =
      GaiabookExchTsCmpPolicy::EXCH_TS_GREATOR;
};

class GaiaOrderbook : public GaiaOrderbookBase<SmartGaiabookTraits> {};
