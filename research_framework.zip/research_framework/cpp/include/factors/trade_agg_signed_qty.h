#include "Factor.h"
#include "Ema.h"
#include <cmath>
#include "GaiaCircularBuffer.h"

class TradeAggSignedQtyFactor : public FactorInterface
{
public:
    TradeAggSignedQtyFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
        ema_int = config.Get<int64_t>("ema_int");
        ema_decay_rate = ema_int/100.0;
    };

    virtual std::string gen_name() {;
        return std::string("TradeAggSignedQtyFactor") + "@ema_int=" + std::to_string(ema_int);
    }

    virtual void calculate(const FactorInput& input_data) {
        auto agg_trade = input_data.preprocess_result->GetAggTrade(input_data.cur_contract->symbol_info->sid);
        if (!agg_trade.has_value()){
            return;
        } 
        else {
            double this_value = 0.0;
            if (agg_trade->side == Side::BUY){
                this_value = std::log(agg_trade->qty+1.0);
            }
            else if (agg_trade->side == Side::SELL){
                this_value = -std::log(agg_trade->qty+1.0);
            }
            factor_value = ema_decay_rate * factor_value + (1.0 - ema_decay_rate) * this_value;
        }
        
    };

private:
    int64_t ema_int;
    double ema_decay_rate;
};
                              
