#ifndef __STRATEGY_FIELDS_H__
#define __STRATEGY_FIELDS_H__

#include <iostream>
#include "ContractInfo.h"
#include "GaiaUtils.h"
#include "Predictor.h"
#include "CommonDefine.h"
#include "PredictorGeneral.h"
#include "SpdLogger.h"
#include "SpdLoggerMessage.h"
#include "parallel_hashmap/phmap.h"
#include "objectpool/object_pool.hpp"
#include "GOrderState.h"

class Hedger;
#define INITIAL_ORDER_POOL_SIZE 256

struct RiskInfo
{
    // coin based risk
    double symbol_risk = 0;
    double symbol_risk_avg_price = 0;
    bool   avg_price_initialized = false;
    double  initial_pos_coin = 0;
    bool    initial_pos_coin_checked = false;
    int64_t stop_loss_first_trigger_ts = 0;

    // for inverse perps
    double contract_coin_risk = 0;
    double contract_usd_risk = 0;
    double wallet_balance = 0;
    double avail_balance = 0;
    Nanoseconds balance_ts = 0;

    int leverage = 1;
    double initialized = false;

    double total_pnl = 0;
    double total_realized_pnl = 0;
    double max_pnl = 0;
    double unrealized_pnl = 0;
    double realized_pnl = 0;
};

struct RiskCheckResult
{
    void reset()
    {
        allow_process_bid = true;
        allow_process_ask = true;
    }
    bool allow_process_bid = true;
    bool allow_process_ask = true;
};

struct StrategyFields
{
    StrategyFields():order_state_pool(INITIAL_ORDER_POOL_SIZE){};
    std::string  tag;
    StrategyMode current_mode;
    SignalStruct signal;
    SignalStruct assist_signal;
    bool         is_signal_update = false;
    ContractInfo *contract_info;
    SymId cur_tick_sid;

    ContractInfoMapType *contract_map;
    SidContractInfoMapType *sid_contract_map;
    std::unordered_map<uint64_t, struct GOrderState* > order_state_map;

    trading_system_st::OrderManager *order_manager;
    Predictor *predictor = nullptr;

    double order_size_coin;
    double order_size_usd;
    double max_pos_coin;
    double max_pos_usd;
    RiskInfo sym_risk;
    bool   use_gob_for_ref_price = true;

    int64_t last_rate_limit_ts = 0;
    int64_t last_balance_limit_ts = 0;

    std::string machine_name;

    StrategySnapshot snapshot;
    struct StrategyLatency latency;

    RiskCheckResult risk_check_result;
    objectpool::DynamicObjectPool<GOrderState> order_state_pool;

    void setLastSendTs(const int64_t &_ts) { snapshot.last_insert_or_replace_ts = _ts; }

    void setStrategyMode(StrategyMode mode, std::string reason)
    {
        if(current_mode == StrategyMode::ExitMode) {
            return;
        }

        StrategyMode prev_mode = current_mode;
        current_mode = mode;

        strncpy(snapshot.mode_change_reason, reason.c_str(), sizeof(snapshot.mode_change_reason) - 1);
        snapshot.mode_change_reason[sizeof(snapshot.mode_change_reason) - 1] = '\0';

        // auto now = GaiaUtils::GetSysTimestamp();
        // std::cout << GaiaUtils::NanoTimestampToString(now)<< ", mode change, prev_mode: " << getStrategyModeStr(prev_mode) << " mode: " << getStrategyModeStr(mode) << " reason: " << reason << std::endl;
        LOG_AUTO(StrategyModeChangeMsg, prev_mode, mode, reason);
        LOG_AUTO(StrategySnapshotMsg, contract_info->symbol_info->mirana_ticker, mode, snapshot);
    }
};


struct TradeWrapper
{
    TradeWrapper(){};
    TradeWrapper(const double &_fill_price, const double &_fill_qty, const double &_need_hedge_qty,
                const uint64_t &_client_order_id, const uint32_t &_logic_acct_id, const int8_t &_side_int,
                const double &_fill_qty_coin, const uint32_t &_strategy_order_type)
    {
        fill_price = _fill_price;
        need_hedge_qty = _need_hedge_qty;
        fill_qty = _fill_qty;
        fill_qty_coin = _fill_qty_coin;
        client_order_id = _client_order_id;
        logic_acct_id = _logic_acct_id;
        hedger_order_num = 0;
        side_int = _side_int;
        strategy_order_type = _strategy_order_type;
    };

    double fill_qty;
    double fill_qty_coin;
    double need_hedge_qty;
    double fill_price;
    uint64_t client_order_id;
    uint64_t hedger_order_num;
    uint32_t logic_acct_id;
    int8_t side_int;
    uint32_t strategy_order_type;
};

//typedef std::unordered_map<std::string, TradeWrapper> TradeWrapperMapType;
typedef std::unordered_map<std::string, TradeWrapper> TradeWrapperMapType;
typedef std::unordered_map<SymId, StrategyFields> StrategyFieldsMapType;

#endif
