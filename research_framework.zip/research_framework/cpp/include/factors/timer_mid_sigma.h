#include "Factor.h"
#include "Ema.h"
#include <cmath>
#include "GaiaCircularBuffer.h"
#include "GaiaUtils.h"

class TimerMidSigmaFactor : public FactorInterface
{
public:
    TimerMidSigmaFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
        backward_ms = config.Get<int64_t>("backward_ms");
        timer_interval_ms = config.Get<int64_t>("timer_interval_ms");
        RegisterTimer(timer_interval_ms*1e6L);
        // int64_t buffer_size = backward_ms/timer_interval_ms;
        // mid_buffer.setSize(buffer_size, 0.0);
    };

    virtual std::string gen_name() {;
        return std::string("TimerMidSigmaFactor") + "@backward_ms=" + std::to_string(backward_ms) + "@timer_interval_ms=" + std::to_string(timer_interval_ms);
    }

    virtual void calculate(const FactorInput& input_data) {
        auto &gob = input_data.cur_contract->alphaBook;
        mid_price = (gob->bid(0).price + gob->ask(0).price)/2.0;
        if (data_exch_time < input_data.cur_contract->latency_record.mkt_data.mkt_exch_ts) {
            data_exch_time = input_data.cur_contract->latency_record.mkt_data.mkt_exch_ts;
        }

        factor_value = sigma;
    };
    
    void OnTimer() override {
        if (last_update_time > MinErr){
            time_ratio = (data_exch_time - last_update_time) / (double)(1000000000);
            time_decay_rate = std::exp(-time_ratio/(backward_ms*1e3));
            var_decay_rate = 1 - time_decay_rate;
            price_diff = mid_price - std_price_ewma;
            std_var_ewma = time_decay_rate * (std_var_ewma + (var_decay_rate * (price_diff * price_diff)));
            std_price_ewma = time_decay_rate * (std_price_ewma - mid_price) + mid_price;
            sigma = std::sqrt(std_var_ewma)/std_price_ewma*1e4;
        }
        else {
            std_var_ewma = 0.0;
            std_price_ewma = mid_price;
            sigma = 0.0;
        }
        
        last_update_time = data_exch_time;
    }

private:
    // GaiaCircularBuffer<double> mid_buffer;
    int64_t timer_interval_ms;
    int64_t backward_ms;
    int64_t last_update_time = 0;
    int64_t data_exch_time = 0;
    double mid_price = 0.0;
    double std_var_ewma = 0.0;
    double std_price_ewma = 0.0;
    double sigma = 0.0;
    double time_ratio, time_decay_rate, var_decay_rate, price_diff;
};
                              
