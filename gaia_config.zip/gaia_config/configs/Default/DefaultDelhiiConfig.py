class SourceConfig:
    def __init__(self):
        self.source_list = ["MidPrice", 
                            "LastBqDonkPrice", 
                            "LastBqMidPrice",
                            "LastPrice",
                            "High",
                            "Low"]
        self.source_record_length = 1200
        self.source_interval_sec = 0.1
        self.origin_record_length = 200

class CommonConfig:
    def __init__(self):
        self.use_synthetic_fill = False
        self.order_logic_code = ""

class LGBMPredictorConfig:
    def __init__(self):
        self.LGBM_model_path = ""
        self.LGBM_model_name = ""

class OrderLogicConfig:
    def __init__(self):
        self.leading_price_ratio = 1
        self.max_cancel_bp = 0.2
        self.min_edge_bp = 0.5
        self.max_distance_in_bps = 50.0
        self.max_waiting_time = 5
        self.max_price_deviation_bps = 20.0
        
class OrderLogicCommonConfig:
    def __init__(self):
        self.notional_size = 500
        self.max_pos_in_clips = 3
        self.stop_loss = -500
        self.use_full_liquidation = True
        self.use_market_order_for_liq = False
        self.liquidate_take_bp = 30
        self.liquidate_max_notional = 3000
        self.liquidate_min_notional = 10
        self.use_reduce_only_mode = False
        self.use_fr_check = False
        self.reduce_only_minute_before_fr = 20
        self.reduce_only_minute_after_fr = 10
        self.reduce_only_param_multi = 1
        self.use_reduceonly_for_liq = True
        self.cancel_interval_ms = 100
