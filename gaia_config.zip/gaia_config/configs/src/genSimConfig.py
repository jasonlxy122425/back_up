import os
import sys
import argparse

cur_dir = os.getcwd()
sys.path.append(f"{cur_dir}/")
sys.path.append(f"{cur_dir}/ServerInfo")
from ServerInfo import *
from FileGenerator import *
from Default.BuildArbitrage import *
import importlib

class ConfigBuilder(object):
    def __init__(self):
        self.placements = []
        self.file_generator = FileGenerator()

    def build(self, machine, config_path="./"):
        print(f"importing {machine}")
        machine_module = importlib.import_module(machine)
        machine_config = machine_module.MachineConfig()
        configs = machine_config.getConfig()

        index = 0
        for i, config in enumerate(configs):
            index +=1

            self.file_generator.generateConfig(config, config_path, index)


if __name__ == "__main__":

    parser = argparse.ArgumentParser(description='deploy args')
    parser.add_argument('-m','--machine', type=str, help='input an machine name')
    parser.add_argument('-c','--config_path', type=str, default="./configs/", help='config path')

    args = parser.parse_args()

    ConfigBuilder().build(args.machine, f"{args.config_path}/{args.machine}")
    os.system(f"chown master:master -R {args.config_path}/{args.machine}")
