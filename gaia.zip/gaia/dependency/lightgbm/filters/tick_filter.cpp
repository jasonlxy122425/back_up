//
// Created by Hongjian Han on 2021/8/2.
// TickFilter is used to filter market data by tick
//
# include "tick_filter.h"

// **************************** TickFilter ****************************

bool TickFilter::calculate(const Tick &data)
{
    return false;
}

// **************************** PxFilter ****************************
PxFilter::PxFilter():TickFilter(), min_change_(0.0)
{
}

PxFilter::PxFilter(Type min_change):TickFilter(), min_change_(min_change)
{
}

PxFilter::~PxFilter() = default;

bool PxFilter::calculate(const Tick & data)
{
    Type px = 0.5 * static_cast<double>(data.buy_side_[0].px + data.sell_side_[0].px);
    // std::cout << "Px: " << std::abs(px - last_px_) << " - " << min_change_ << "\n";
    bool ret = std::abs(px - last_px_) >= min_change_;
    last_px_ = px;
    return ret;
}

// **************************** VolumeFilter ****************************
VolumeFilter::VolumeFilter():TickFilter(), min_change_(0.0)
{
}

VolumeFilter::VolumeFilter(Type min_change):TickFilter(), min_change_(min_change)
{
}

VolumeFilter::~VolumeFilter() = default;

bool VolumeFilter::calculate(const Tick & data)
{
    Type vol = data.last_volume;
    // std::cout << "VOLUME: " << vol << " - " << target_vol_ << "\n";
    if (vol >= target_vol_)
    {
        target_vol_ = vol + min_change_;
        return true;
    }
    else
    {
        return false;
    }
}

// **************************** SpreadFilter ****************************
SpreadFilter::SpreadFilter():TickFilter(), max_spread_(100000.0)
{
}

SpreadFilter::SpreadFilter(Type max_spread):TickFilter(), max_spread_(max_spread)
{
}

SpreadFilter::~SpreadFilter() = default;

bool SpreadFilter::calculate(const Tick & data)
{
    // std::cout << "SPREAD: " << data.spread() << " - " << max_spread_ << "\n";
    return static_cast<double>(data.sell_side_[0].px - data.buy_side_[0].px) <= max_spread_;
}

// **************************** MultiFilter ****************************
MultiFilter::MultiFilter()
{
    method_ = MultiMethod::DEFAULT;
    filters_ = std::vector<TickFilter *> {};
}

MultiFilter::MultiFilter(MultiMethod method, const std::vector<TickFilter *> & filters):TickFilter()
{
    method_ = method;
    for (auto f: filters)
    {
        filters_.push_back(f);
    }
}

MultiFilter::~MultiFilter() = default;

bool MultiFilter::calculate(const Tick & data)
{
    bool ret;
    if (method_ == MultiMethod::AND)
    {
        ret = true;
        for(auto f: filters_)
        {
            bool fs = (*f).calculate(data);
            ret = ret && fs;
        }
    }
    else
    {
        ret = false;
        for(auto f: filters_)
        {
            bool fs = (*f).calculate(data);
            ret = ret || fs;
        }
    }
    return ret;
}

MultiFilter & MultiFilter::operator=(const MultiFilter &mf) {
    if (this == &mf)
        return *this;
    method_ = mf.method_;
    filters_ = mf.filters_;
    return *this;
}
