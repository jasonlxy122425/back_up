#include "Factor.h"
#include "Ema.h"
#include "GaiaCircularBuffer.h"
#include <cmath>

class BookQtyImbaFactor : public FactorInterface
{
public:
    BookQtyImbaFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
        book_level_start_idx = config.Get<int64_t>("book_level_start_idx");
        book_level_end_idx = config.Get<int64_t>("book_level_end_idx");
    };

    virtual std::string gen_name() {
        return std::string("BookQtyImbaFactor") + "@book_level_start_idx=" + std::to_string(book_level_start_idx) + "@book_level_end_idx=" + std::to_string(book_level_end_idx);
    }

    virtual void calculate(const FactorInput& input_data) { 
        auto &ob = input_data.cur_contract->alphaBook;
        int64_t num_bids = ob->num_bids();
        int64_t num_asks = ob->num_asks();
        double tmp_bid = 0.0;
        double tmp_ask = 0.0;
        num_bids = std::min(num_bids, book_level_end_idx);
        num_asks = std::min(num_asks, book_level_end_idx);
        for (int i = book_level_start_idx ; i < num_bids; i++){
            tmp_bid += ob->bid(i).qty;     
        }
        for (int i = book_level_start_idx; i < num_asks; i++){
            tmp_ask += ob->ask(i).qty;       
        }
        factor_value = tmp_bid - tmp_ask;

    };


private:
    int64_t book_level_start_idx = 0;
    int64_t book_level_end_idx = 0;
};  
                              
