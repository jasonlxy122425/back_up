#pragma once
#include <vector>
#include "FactorFactory.h"
#include "Factor.h"
#include "FactorTimer.h"

class FactorManager {
public:
    FactorFactory factory_;
    FactorManager() {}

    void Init(FactorTimer *factor_timer, SidContractInfoMapType *sid_contract_info_map) {
        factor_timer_ = factor_timer;
        sid_contract_info_map_ = sid_contract_info_map;

        factory_.Register();

        block_offset = 0;
        block_size = 0;
        block_ptr = nullptr;
    }

    ~FactorManager() {
        sid_memory_.clear();

        if(block_ptr) {
            free(block_ptr);
            block_ptr = nullptr;
        }
        block_offset = 0;
        block_size = 0;
    }

    // create factor instance from memory managed by FactorManager
    FactorInterface* CreateFactorInstance(const std::string& factor_name, SymId sid, Config &config) {
        auto factor_info = factory_.GetFactorInfo(factor_name);
        auto it = sid_memory_.find(sid);
        FactorInterface* factor = factor_info.creator_at(it->second.base_ptr + it->second.offset);
        it->second.offset += factor_info.factor_size;
        // std::cout << "Create factor: " << factor_name 
        //           << ", sid: " << sid 
        //           << ", offset: " << it->second.offset 
        //           << ", max_offset: " << it->second.max_offset 
        //           << std::endl;
        factor->Init(config, factor_timer_, sid_contract_info_map_);
        return factor;
    }

    // create factor instance from stack directly
    FactorInterface* CreateFactor(const std::string& factor_name, Config &config) {
        auto factor_info = factory_.GetFactorInfo(factor_name);
        FactorInterface* factor = factor_info.creator();
        factor->Init(config, factor_timer_, sid_contract_info_map_);
        return factor;
    }

    void InitMemoryForFactors(std::vector<Config> &factors_config) {
        phmap::flat_hash_map<SymId, size_t> sid_size;

        int factor_num = 0;
        size_t total_factor_size = 0;
        size_t sid_factor_size = 0;
        for(auto f_conf : factors_config) {
            ++factor_num;
            std::string name = f_conf.Get<std::string>("factor_name");
            std::string symbol = f_conf.Get<std::string>("symbol");

            auto sid = SecMaster::instance().FindSid(symbol);
            size_t factor_size = factory_.GetFactorInfo(name).factor_size;
            if(sid_size.find(sid) == sid_size.end()) {
                sid_size[sid] = 0;
            }
            sid_size[sid] += factor_size;
            total_factor_size += factor_size;
        }

        AllocateMemory(total_factor_size);

        for (auto iter : sid_size) {
            AllocateMemoryForSids(iter.first, iter.second);
        }
        // std::cout << "Total factor size: " << total_factor_size << std::endl;
    }

private:
    FactorTimer *factor_timer_;
    SidContractInfoMapType *sid_contract_info_map_;

    // record memory info for each SymId
    struct SidMemoryInfo {
        char* base_ptr;
        size_t offset;
        size_t max_offset;
    };

    char* block_ptr;
    size_t block_offset;
    size_t block_size;

    phmap::flat_hash_map<SymId, SidMemoryInfo> sid_memory_;

    void AllocateMemory(size_t size) {
        // std::cout << __FUNCTION__ << ", size: " << size << std::endl;
        block_ptr = static_cast<char*>(aligned_alloc(64, size));
        if (!block_ptr) {
            std::cerr << "Memory allocation failed for size: " << size << std::endl;
            abort();
        }
        block_size = size;
    }

    void AllocateMemoryForSids(SymId sid, size_t size) {
        if (sid_memory_.find(sid) != sid_memory_.end()) {
            return;
        }

        SidMemoryInfo info;
        info.base_ptr = block_ptr + block_offset;
        info.offset = 0;
        info.max_offset = size;

        block_offset += size;
        if (block_offset > block_size) {
            std::cerr << "Memory block overflow for SID: " << sid << ", block_offset: " << block_offset << ", block_size:" << block_size << std::endl;
            abort();
        }
        // std::cout << "Allocate memory for SID: " << sid 
        //           << ", offset: " << info.offset 
        //           << ", max_offset: " << info.max_offset 
        //           << std::endl;
        sid_memory_[sid] = info;
    }
};
