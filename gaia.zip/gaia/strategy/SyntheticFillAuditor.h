#pragma once
#include "SpdLogger.h"
#include "StrategyFields.h"
#include "GOrderState.h"
#include "GaiaUtils.h"

class SyntheticFillAuditor {
public:
    static void Audit(const md::Trade &trade, StrategyFields * strategyFields, Hedger* hedger)
    {
        int64_t now = GaiaUtils::GetSysTimestamp();
        int tradeSideInt = trade.side == Side::BUY ? 1 : -1;
        double tradedPrice = trade.price;
        double tradedQty = trade.qty;
        std::string tradedId = trade.trade_id;

        for(auto& orderStateIter : strategyFields->order_state_map) {
            GOrderState *order_state = orderStateIter.second; 
            int orderSideInt = order_state->ts_order->side() == Side::BUY ? 1 : -1;

            if ((tradedPrice > order_state->ts_order->price() + eps) &&
                (order_state->ts_order->order_status() == OrderStatus::LIVE) && (order_state->syntheticFilledTs == 0) &&
                (order_state->ts_order->sid() == trade.sid) && (orderSideInt != tradeSideInt) &&
                (order_state->orderConfirmExchangeTs < trade.exch_ts) && (order_state->orderConfirmExchangeTs > 0) && (order_state->ts_order->time_in_force() != TimeInForce::IOC) &&
                (order_state->ts_order->cancel_status() == CancelStatus::UNKNOWN) && (order_state->ts_order->replace_status() == ReplaceStatus::UNKNOWN))
            {

                order_state->syntheticFilledTs = now;
                order_state->syntheticFillTriggeredLeavesQty = order_state->leavesQty;
                order_state->leavesQty = 0;

                double sym_riskBefore = strategyFields->sym_risk.symbol_risk;

                GaiaUtils::updatePosition(strategyFields, order_state->ts_order->leaves_qty(), orderSideInt, order_state->ts_order->price(), 0);
                hedger->HedgingLogic(*strategyFields, order_state, tradedId, order_state->ts_order->price(), order_state->leavesQty, orderSideInt, 0);

                double sym_riskAfter = strategyFields->sym_risk.symbol_risk;

                LOG_AUTO(SyntheticFillMsg, tradedId.c_str(), order_state->ts_order->client_order_id().value,
                                                sym_riskBefore, sym_riskAfter, tradedPrice, tradedQty, tradeSideInt,
                                                now, order_state->leavesQty, order_state->ts_order->price(),
                                                order_state->leavesQty, orderSideInt, order_state->ts_order->price(),
                                                order_state->ts_order->qty());
            }
        }
    }
};