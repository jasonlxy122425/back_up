#pragma once
#include <memory>
#include <deque>
#include "SamplerBase.h"

namespace demeter {

class FixedIntervalSampler : public SamplerBase {
public:
    FixedIntervalSampler():SamplerBase() {
        ob_buf_.setSize(2);
    }

    ~FixedIntervalSampler() {}

    void Sample() final {
        clear();
    }

    bool Update(const GaiaOrderbook &order_book, ContractInfo *contract) final {
        if(!order_book.updated_by_cur_tick() && contract->update_tick_type != TickEventType::TICK_LIQUIDATION) {
            return false;
        }

        ob_buf_.push(order_book);
        // update gob_update of this tick
        GobUpdate cur_gob_update;
        if(ob_buf_.isFull()) builder_.Update(ob_buf_, contract, cur_gob_update);

        GetDemeterData()->gob_update_.push_back(cur_gob_update);
        GetDemeterData()->gob_update_sum_.add(cur_gob_update);

        return true;
    }

private:
    // buffer
    GaiaCircularBuffer<GaiaOrderbook> ob_buf_;
};

}; // namespace demeter
