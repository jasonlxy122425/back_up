#include "Factor.h"
#include "Ema.h"


class TickTypeFactor : public FactorInterface
{
public:
    TickTypeFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
    };

    virtual std::string gen_name() {
        return std::string("TickTypeFactor");
    }

    virtual void calculate(const FactorInput& input_data) {
        factor_value = 0.0;
        auto &tick_type = input_data.cur_contract->update_tick_type;
        if (tick_type == TickEventType::TICK_OB){
            factor_value = 1.0;
        }
        else if (tick_type == TickEventType::TICK_TRADE){
            factor_value = 2.0;
        }
        else if (tick_type == TickEventType::TICK_BBO){
            factor_value = 4.0;
        }
        else if (tick_type == TickEventType::TICK_LIQUIDATION){
            factor_value = 14.0;
        }
    };

};
                              