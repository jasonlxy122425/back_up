#include "Factor.h"
#include "Ema.h"


class BookNumImbaFactor : public FactorInterface
{
public:
    BookNumImbaFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
    };

    virtual std::string gen_name() {
        return std::string("BookNumImbaFactor");
    }

    virtual void calculate(const FactorInput& input_data) {
        auto &gob = input_data.cur_contract->alphaBook;
        double num_bids = gob->num_bids();
        double num_asks = gob->num_asks();
        factor_value = (num_bids - num_asks)/(num_bids + num_asks);
    };


private:
};
                              
