cp ../libs/prod/*.so ../libs/
cd ../../ATHENA ; make -j4 ; cd -
cd ../../ZEUS ; make -j4 ; cd -
cd ../../APOLLO ; make -j4 ; cd -
cd ../../Kronos-cpp ; make -j4 ; cd -
cd ../../research_framework/cpp ; make -j4 ; cd -
make -j8
