#pragma once
#include <Factor.h>


class PriceEma : public FactorInterface
{
public:
    PriceEma(){}
    void Init(Config &config)
    {
        ema_interval = config.Get<int64_t>("ema_interval");
        ema_ratio = std::exp(-1.0/ema_interval);
    }
    virtual std::string gen_name() {
        return std::string("PriceEma") + "@ema_interval" + std::to_string(ema_interval);
    }

    virtual void calculate(int64_t &current_time, double &micro_price)
    {
        if(last_time == 0) {
            factor_value = micro_price;
        }
        else {
            double time_diff = (current_time - last_time)/1e6;
            double ema_decay_rate = std::pow(ema_ratio, time_diff);
            factor_value = ema_decay_rate * factor_value + (1 - ema_decay_rate) * micro_price;
            // std::cout << "PriceEma: " << ema_decay_rate << " " << micro_price << " " << factor_value << std::endl;
        }
        last_time = current_time;
    }

private:
    int64_t ema_interval;
    double ema_ratio;
    int64_t last_time = 0;
};
