#include "DemeterType.h"

namespace demeter {

std::string ToString(BookOrderType type) {
    switch (type) {
        case BookOrderType::Insert:
            return "Insert";
        case BookOrderType::Cancel:
            return "Cancel";
        case BookOrderType::Match:
            return "Match";
        case BookOrderType::Liquidation:
            return "Liquidation";
        default:
            return "Unknown";
    }
};
}; // namespace demeter