#include "Predictor.h"


// public
ContractInfo* Predictor::GetContractInfo(const std::string &symbolName)
{
    return (*state->contract_map)[symbolName];
}

void Predictor::CalculatePredictor(const TickEventType &_cur_tick_type,
                        const SymId &_cur_tick_sid,
                        struct GLatencyRecord* _latency_record,
                        const SymId &_main_sid)
{
    state->cur_tick_type = _cur_tick_type;
    state->cur_tick_sid = _cur_tick_sid;
    state->latency_record = _latency_record;
    state->main_sid = _main_sid;
    factor_input.cur_contract = (*state->sid_contract_map)[state->cur_tick_sid];

    // calc predictor
    this->Calculate();

    state->signal.sid = _cur_tick_sid;
    state->signal.recv_ts = _latency_record->mkt_data.mkt_recv_ts;
    state->signal.exch_ts = _latency_record->mkt_data.mkt_exch_ts;
}

void Predictor::OnTimer(int64_t& now) {
    factor_timer.Update(now);
}
