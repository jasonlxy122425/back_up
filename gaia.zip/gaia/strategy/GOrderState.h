#pragma once
#include "stdint.h"
#include "SpdLogger.h"
#include "SpdLoggerMessage.h"
#include "GaiaUtils.h"

class StrategyFields;

struct GOrderState
{
    GOrderState(){}
    trading_system_st::Order* ts_order = nullptr;

    struct StrategyFields* strategy = nullptr;
    struct ContractInfo* contract_info = nullptr;

    trading_system_st::OrderStatusEvent order_status_event = trading_system_st::OrderStatusEvent::UNKNOWN;
    int err_code;

    std::string exchange_order_id;
    uint64_t client_order_id;

    int64_t last_cancel_reject_time = 0;
    int64_t last_cancel_time = 0;
    int64_t last_replace_time = 0;
    int64_t new_order_time = 0;
    int64_t last_order_update_time = 0;
    int64_t live_status_time = 0;

    int64_t syntheticFilledTs = 0;
    int64_t orderConfirmExchangeTs = 0;
    double syntheticFillTriggeredLeavesQty = 0;
    double  leavesQty = 0;

    double fillQty = 0;
    double fillPrice = 0;
    double fillFee = 0;

    double queue_front_pos = 0.0;
    int strategy_order_type = 0;
    int cancel_order_type = 0;
    bool is_open = true;

};