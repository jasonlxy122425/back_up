#pragma once

#include <parallel_hashmap/phmap.h>

#include "GaiaOrderbook.h"
#include "CommonDefine.h"

template <class GaiaOrderbookT>
class GaiaOrderbookManagerT {
 public:
  GaiaOrderbookT &operator[](SymId sid) {
    return Get(sid);
  }

  G_INLINE GaiaOrderbookT &Get(SymId sid) {
    return *(books_[sid]);
  }

  void InitBooks(std::vector<SymId> &sids) {
    books_.reserve(sids.size());
    
    for (const auto &sid : sids) {
      auto &ptr = books_[sid];
      if (!ptr) {
        ptr = std::make_unique<GaiaOrderbookT>();
        
        // 从SecMaster获取symbol信息并初始化
        auto *sym_data = SecMaster::instance().GetSymbol(sid);
        if (sym_data) {
          if (sym_data->prc_tick_size > 0) {
            ptr->set_price_tick_size(sym_data->prc_tick_size);
          }

          if (sym_data->min_qty > 0 || sym_data->qty_tick_size) {
            ptr->set_default_qty_size(std::max(sym_data->min_qty, sym_data->qty_tick_size));
          }
        }
      }
    }
  }

#ifdef OUTPUT_DATA

  GaiaOrderbookT output_ob;
  GaiaOrderbookT &GetOutput(SymId sid) {
    auto &ptr = books_[sid];
    if (!ptr) {
      ptr = std::make_unique<GaiaOrderbookT>();
      const auto *sym_data = SecMaster::instance().GetSymbol(sid);
      if (sym_data) {
        if (sym_data->prc_tick_size > 0) {
          ptr->set_price_tick_size(sym_data->prc_tick_size);
        }

        if (sym_data->min_qty > 0 || sym_data->qty_tick_size) {
          ptr->set_default_qty_size(std::max(sym_data->min_qty, sym_data->qty_tick_size));
        }
      }
    }

    output_ob = *ptr;
    if(num_levels != 0) output_ob.capBookLevel(num_levels);
    return output_ob;
  }
#endif

  GaiaOrderbookT &OnOrderbook(const md::FlatOrderbook &ob) {
    auto &book = Get(ob.sid);
    book.OnOrderbook(ob);
    return book;
  }

  GaiaOrderbookT &OnTrade(const md::Trade &trade) {
    auto &book = Get(trade.sid);
    book.OnTrade(trade);
    book.DeleteExcessLevels(max_num_level);
    return book;
  }

  GaiaOrderbookT &OnBestQuote(const md::BestQuote &bbo) {
    auto &book = Get(bbo.sid);
    book.OnBestQuote(bbo);
    book.DeleteExcessLevels(max_num_level);
    return book;
  }

  GaiaOrderbookT &OnLiquidation(const md::Liquidation &liquidation) {
    auto &book = Get(liquidation.sid);
    book.OnLiquidation(liquidation);
    return book;
  }

  void set_num_book_levels(int num) { 
	  num_levels = num; 
	  std::cout << "using num_levels for OrderbookManager " << num_levels << std::endl;
  }

  void set_max_level(int num) {
      max_num_level = num;
      std::cout << "using max_num_level for OrderbookManager " << max_num_level << std::endl;
  }

 private:
  phmap::flat_hash_map<SymId, std::unique_ptr<GaiaOrderbookT>> books_;
  int num_levels = 1; // used for capping book levels in GetOutput
  int max_num_level = md::MAX_ORDERBOOK_LEVELS;
};


class GaiaOrderbookManager : public GaiaOrderbookManagerT<GaiaOrderbook> {};

