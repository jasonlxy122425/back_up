#pragma once
#include <vector>

class GaiaModelBase {
public:
    virtual ~GaiaModelBase() = default;

    virtual void Init(std::string &model_path, int feature_num, const Config &config = {}) = 0;
    virtual void Calculate(const std::vector<double> &input, std::vector<double> &output, int64_t &output_len) = 0;
};
