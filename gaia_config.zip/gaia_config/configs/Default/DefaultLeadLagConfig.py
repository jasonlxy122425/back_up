class PredictorConfig:
    def __init__(self):
        self.predictor_code = "LeadLag"
        self.quoter_symbol = ""
        self.leader_symbol = ""
        self.quoter_ref_leader_price_ratio = 1
        self.theo_edge_weight = 0
        self.calculate_interval_ns = 5000000
        self.decay_rate_base_ns = 1000000000
        self.exp_base_num = 30
        self.stdExp_long_interval = 5000000
        self.stdExp_long_base = 60
        self.stdExp_short_interval = 5000000
        self.stdExp_short_base = 30
        self.stdExp_shortSpike_interval = 5000000
        self.stdExp_shortSpike_base = 180

class OrderLogicConfig:
    def __init__(self):
        self.order_logic_code = "LeadLag"
        self.custom_min_notional = 5
        self.custom_max_notional = 50000
        self.edge_weight = 4
        self.edge_range_weight = 3
        self.pos_penalty_weight = 0
        self.cancel_edge_weight = 10000
        self.take_edge_weight = 10000
        self.use_replace = False
        self.mkt_timeout_ns = 500000000