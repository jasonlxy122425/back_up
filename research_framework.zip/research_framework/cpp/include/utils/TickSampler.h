#pragma once
#include <memory>
#include <deque>
#include "SamplerBase.h"

namespace demeter {

class TickSampler : public SamplerBase {
public:
    TickSampler(int sample_num):SamplerBase() {
        ob_buf_.setSize(2);
        gob_update_buf_.setSize(sample_num);
    }

    ~TickSampler() {}

    bool Update(const GaiaOrderbook &order_book, ContractInfo *contract) {
        if(!order_book.updated_by_cur_tick() && contract->update_tick_type != TickEventType::TICK_LIQUIDATION) {
            return false;
        }

        ob_buf_.push(order_book);
        if(gob_update_buf_.isFull()) {
            removed_gob_update_ = gob_update_buf_[0];
            GetDemeterData()->gob_update_.pop_front(gob_update_buf_[0]);
        }

        // update gob_update of this tick
        auto &cur_gob_update  = gob_update_buf_.getNext();
        cur_gob_update.clear();
        if(ob_buf_.isFull()) builder_.Update(ob_buf_, contract, cur_gob_update);
        gob_update_buf_.write();

        GetDemeterData()->gob_update_.push_back(gob_update_buf_[-1]);
        GetDemeterData()->gob_update_sum_.update_for_rolling(gob_update_buf_[-1], removed_gob_update_);

        return true;
    }

private:
    // buffer
    GaiaCircularBuffer<GaiaOrderbook> ob_buf_;
    GobUpdate removed_gob_update_;
    GaiaCircularBuffer<GobUpdate> gob_update_buf_; // gob_update of each tick
};

}; // namespace demeter
