#include "GOrderOp.h"
#include "StrategyFields.h"

GOrderState* GOrderOp::InsertOrder(StrategyFields& strategy_fields, double price, double size, Side side, OrderType type, TimeInForce tif, PositionOffset offset, int strategy_order_type, bool is_warmup) {
    static OrderExtraParams params;
    if(offset != PositionOffset::UNKNOWN) {
        params.position_offset = offset;
    }

    if(round_for_hyperliquid && strategy_fields.contract_info->symbol_info->exch == Exchange::HYPERLIQUID) {
        GaiaUtils::roundPriceViaSignificantNum(price);
    }
    // prepare order 
    auto ts_order = strategy_fields.order_manager->PrepareOrder(
        strategy_fields.contract_info->logic_acct_id, 
        strategy_fields.contract_info->symbol_info->sid, 
        side, 
        type,
        price, 
        size, 
        tif, 
        params
    );

    if (is_warmup) {
        strategy_fields.order_manager->CloseOrder(ts_order);
        return nullptr;
    }

    int64_t now = GaiaUtils::GetSysTimestamp();

#ifdef RECORD_LATENCY
    int64_t real_now = GaiaUtils::GetRealSysTimestamp();
#endif
    bool insert_ret = strategy_fields.order_manager->InsertOrder(ts_order);
    if(insert_ret)
    {
        // GOrderState *orderState = new GOrderState();
        GOrderState *orderState = strategy_fields.order_state_pool.new_object();

        orderState->strategy = &strategy_fields;
        orderState->contract_info = strategy_fields.contract_info;
        orderState->ts_order = ts_order;

        strategy_fields.order_state_map[orderState->ts_order->client_order_id().value] = orderState;

        orderState->new_order_time = now;
        orderState->client_order_id = orderState->ts_order->client_order_id().value;
        orderState->strategy_order_type = strategy_order_type;

        strategy_fields.setLastSendTs(now);
        ContractInfo *cur_contract = (*strategy_fields.sid_contract_map)[strategy_fields.cur_tick_sid];
        LOG_AUTO(SendReplaceOrderMessage, now, cur_contract->latency_record, cur_contract->update_tick_type,
                                                orderState->contract_info->symbol_info->mirana_ticker.c_str(),
                                                cur_contract->symbol_info->mirana_ticker.c_str(), orderState->contract_info->logic_acct_id,
                                                orderState->ts_order->client_order_id().value, price, size, orderState->ts_order->side() == Side::BUY ? 1 : -1,
                                                int(orderState->ts_order->time_in_force()), strategy_order_type,
                                                GaiaUtils::BookGetBestBidPrice(orderState->contract_info), GaiaUtils::BookGetBestAskPrice(orderState->contract_info),
                                                GaiaUtils::BookGetBestBidSize(orderState->contract_info), GaiaUtils::BookGetBestAskSize(orderState->contract_info));
#ifdef RECORD_LATENCY
        strategy_fields.latency.gaia_end_ts = real_now;
        LOG_AUTO(LatencyMsg, true, orderState->contract_info->symbol_info->mirana_ticker,
                    cur_contract->symbol_info->mirana_ticker, cur_contract->update_tick_type,
                    cur_contract->latency_record, strategy_fields.latency,
                    strategy_fields.is_signal_update, strategy_fields.assist_signal.sid,
                    strategy_fields.assist_signal.recv_ts, strategy_fields.assist_signal.push_ts,
                    strategy_fields.assist_signal.exch_ts, strategy_fields.assist_signal.cb_start_ts);
#endif

        return orderState;
    }
    else
    {
        ContractInfo* &contract_info = strategy_fields.contract_info;
        ContractInfo *cur_contract = (*strategy_fields.sid_contract_map)[strategy_fields.cur_tick_sid];
        LOG_AUTO(SendReplaceOrderFailedMessage, now,
                                                contract_info->symbol_info->mirana_ticker.c_str(),
                                                contract_info->logic_acct_id,
                                                ts_order->client_order_id().value, price, size, ts_order->side() == Side::BUY ? 1 : -1,
                                                GaiaUtils::BookGetBestBidPrice(contract_info), GaiaUtils::BookGetBestAskPrice(contract_info),
                                                GaiaUtils::BookGetBestBidSize(contract_info), GaiaUtils::BookGetBestAskSize(contract_info));
        strategy_fields.order_manager->CloseOrder(ts_order);
        return nullptr;
    }
}

bool GOrderOp::CancelOrder(GOrderState* orderState) {
    bool cancel_ret = false;
    if(canCancelOrder(orderState))
    {
        StrategyFields &strategy_fields = *orderState->strategy;
#ifdef RECORD_LATENCY
        int64_t real_now = GaiaUtils::GetRealSysTimestamp();
#endif
        cancel_ret = strategy_fields.order_manager->CancelOrder(orderState->ts_order);
        int64_t now = GaiaUtils::GetSysTimestamp();
        orderState->last_cancel_time = now;
        ContractInfo *cur_contract = (*strategy_fields.sid_contract_map)[strategy_fields.cur_tick_sid];
        ContractInfo *target_contract = orderState->contract_info;

        if(cancel_ret) {
            LOG_AUTO(CancelMessage, now, cur_contract, target_contract, orderState->ts_order->client_order_id().value, orderState->cancel_order_type);
#ifdef RECORD_LATENCY
            strategy_fields.latency.gaia_end_ts = real_now;
            LOG_AUTO(LatencyMsg, false, target_contract->symbol_info->mirana_ticker,
                        cur_contract->symbol_info->mirana_ticker, cur_contract->update_tick_type,
                        cur_contract->latency_record, strategy_fields.latency,
                        strategy_fields.is_signal_update, strategy_fields.assist_signal.sid,
                        strategy_fields.assist_signal.recv_ts, strategy_fields.assist_signal.push_ts,
                        strategy_fields.assist_signal.exch_ts, strategy_fields.assist_signal.cb_start_ts);
#endif
        }
        else {
            LOG_AUTO(CancelMessage, now, cur_contract, target_contract, orderState->ts_order->client_order_id().value, orderState->cancel_order_type, true);
        }
    }

    return cancel_ret;
}

bool GOrderOp::ReplaceOrder(GOrderState* orderState, double price, double size) {
    bool replace_ret = false;
    if(price != orderState->ts_order->price())
    {
        double origin_price = orderState->ts_order->price();
        double origin_size = orderState->ts_order->qty();
        replace_ret = orderState->strategy->order_manager->ReplaceOrder(orderState->ts_order, price, size);
        int64_t now = GaiaUtils::GetSysTimestamp();
        orderState->last_replace_time = now;
        if(replace_ret) {
            orderState->strategy->setLastSendTs(now);
            auto cur_contract = (*orderState->strategy->sid_contract_map)[orderState->strategy->cur_tick_sid];
            LOG_AUTO(SendReplaceOrderMessage, now, cur_contract->latency_record, cur_contract->update_tick_type,
                                                    orderState->contract_info->symbol_info->mirana_ticker.c_str(),
                                                    cur_contract->symbol_info->mirana_ticker.c_str(), orderState->contract_info->logic_acct_id,
                                                    orderState->ts_order->client_order_id().value, price, size, orderState->ts_order->side() == Side::BUY ? 1 : -1,
                                                    int(orderState->ts_order->time_in_force()), orderState->strategy_order_type,
                                                    GaiaUtils::BookGetBestBidPrice(orderState->contract_info), GaiaUtils::BookGetBestAskPrice(orderState->contract_info),
                                                    GaiaUtils::BookGetBestBidSize(orderState->contract_info), GaiaUtils::BookGetBestAskSize(orderState->contract_info),
                                                    true, origin_price, origin_size);
        } else {
            LOG_AUTO(SendReplaceOrderFailedMessage, now, orderState->contract_info->symbol_info->mirana_ticker.c_str(), orderState->contract_info->logic_acct_id,
                                                orderState->ts_order->client_order_id().value, price, size, orderState->ts_order->side() == Side::BUY ? 1 : -1,
                                                GaiaUtils::BookGetBestBidPrice(orderState->contract_info), GaiaUtils::BookGetBestAskPrice(orderState->contract_info),
                                                GaiaUtils::BookGetBestBidSize(orderState->contract_info), GaiaUtils::BookGetBestAskSize(orderState->contract_info),
                                                true, origin_price, origin_size);
        }
    }

    return replace_ret;
}

void GOrderOp::setCancelInterval(int64_t &_interval) {
    cancel_interval = _interval;
}

bool GOrderOp::canCancelOrder(struct GOrderState* orderState) {
    if (orderState->ts_order->time_in_force() == TimeInForce::IOC)
        return false;

    // if (orderState->order_status_event == OrderStatusEvent::TS_CANCEL_ACKED) return false;
    // if (orderState->order_status_event == OrderStatusEvent::TS_REPLACE_ACKED) return false;

    int64_t now = GaiaUtils::GetSysTimestamp();

    bool cancel_reject_timeout_within_limit = now < orderState->last_cancel_reject_time + ONE_MILLI_IN_NANOS * cancel_interval;
    bool cancel_timeout_within_limit = now < orderState->last_cancel_time + ONE_MILLI_IN_NANOS * cancel_interval;
    if (cancel_reject_timeout_within_limit) return false;
    if (cancel_timeout_within_limit) return false;

    // bool cancellable = orderState->ts_order->cancelable();
    // if (!cancellable) return false;

    bool replaceable = orderState->ts_order->replaceable();
    if (!replaceable) return false;


    switch(orderState->ts_order->order_status())
    {
        case OrderStatus::LIVE:
            return true;

        case OrderStatus::PENDING_NEW:
            // phemex & dydx does not support cancel by client order id 
            if (orderState->contract_info->symbol_info->exch == Exchange::PHEMEX) return false;
            if (orderState->contract_info->symbol_info->exch == Exchange::DYDX) return false;
            if ((orderState->contract_info->symbol_info->product_type == ProductType::LINEAR_SWAP) && (orderState->contract_info->symbol_info->exch == Exchange::KUCOIN)) return false;

            return true;
        
        case OrderStatus::REJECTED:

            // for specific error rejected codes from binance, keep cancelling
            // if ((order->details.symbol_info->exch == Exchange::BINANCE) && (order->errCode == -1001)) return true;

            return false;

        case OrderStatus::INTERNAL_REJECTED:

            switch(orderState->err_code){
                case 211:
                    return now > orderState->last_cancel_reject_time + ONE_MILLI_IN_NANOS * 1000;
                default:
                    return false;
            }

            return false;

        case OrderStatus::FILLED:
            return false;
        case OrderStatus::CANCELED:
            return false;
        case OrderStatus::ERROR:
            // for specific error rejected codes from binance, keep cancelling
            // if ((order->details.symbol_info->exch == Exchange::BINANCE) && (order->errCode == -1001)) return true;
            return false;
        case OrderStatus::UNKNOWN:
            return false;
        default:
            return false;
    }

    return false;
}
