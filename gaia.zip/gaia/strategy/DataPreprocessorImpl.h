#pragma once

#include "DataPreprocessor.h"
#include <cmath>
#include <parallel_hashmap/phmap.h>

class TradeFilterPreprocessor : public DataPreprocessorInterface {
public:
    void Init(const Config& config) override {
    }

    void Process(ContractInfo* contract, const TickEventType& cur_tick_type,
                                        GLatencyRecord* latency_record, PreprocessResult* result) override {
        // keep agg trade is null for all data at first
        result->SetAggTrade(contract->symbol_info->sid, std::nullopt);
        if (cur_tick_type != TickEventType::TICK_TRADE) {
            return;
        }

        SymId sid = contract->symbol_info->sid;
        const Trade& current_trade = contract->trade;
        
        if (sid_trade_.find(sid) == sid_trade_.end()) {
            sid_trade_[sid] = TradeInfo();
        }
        
        TradeInfo& trade_info = sid_trade_[sid];
        
        if (!trade_info.initialized) {
            trade_info.agg_trade = current_trade;
            trade_info.initialized = true;
        } else {
            bool same_price = (std::abs(trade_info.agg_trade.price - current_trade.price) < 1e-8);
            bool same_side = (trade_info.agg_trade.side == current_trade.side);
            
            if (same_price && same_side) {
                trade_info.agg_trade.qty += current_trade.qty;
                trade_info.agg_trade.count += current_trade.count;

                trade_info.agg_trade.recv_ts = current_trade.recv_ts;
                trade_info.agg_trade.exch_ts = current_trade.exch_ts;
                trade_info.agg_trade.qs_send_ts = current_trade.qs_send_ts;
                trade_info.agg_trade.cb_start_ts = current_trade.cb_start_ts;
            } else {
                // copy to output space
                result->SetAggTrade(sid, trade_info.agg_trade);

                // save current trade
                trade_info.agg_trade = current_trade;
            }
        }
    }

private:
    struct TradeInfo {
        Trade agg_trade;
        bool initialized = false;
    };
    
    phmap::flat_hash_map<SymId, TradeInfo> sid_trade_;
};
