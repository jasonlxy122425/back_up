#include "Factor.h"
#include "Ema.h"
#include <cmath>

class TradeSellBasisFactor : public FactorInterface
{
public:
   TradeSellBasisFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
        asst_symbol = config.Get<std::string>("asst_symbol");
        asst_sid = SecMaster::instance().FindSid(asst_symbol);

    };

    virtual std::string gen_name() {
        return std::string("TradeSellBasisFactor") + "@asst_symbol=" + asst_symbol;
    }

    virtual void calculate(const FactorInput& input_data) {
        factor_value = 0.0;
        current_sid = input_data.cur_contract->symbol_info->sid;
        auto &trade = input_data.cur_contract->trade;
        if (trade.side == Side::SELL) {
            if (asst_sid == current_sid) {
                asst_buy_price = trade.price;
            } else {
                target_buy_price = trade.price;
            }
        }
        // if (asst_sid == current_sid) {
        //     if (trade.side == Side::SELL){
        //         asst_buy_price = trade.price;
        //     }
        // } else {
        //     if (trade.side == Side::SELL){
        //         target_buy_price = trade.price;
        //     }
        // }

        if (target_buy_price > MinErr && asst_buy_price > MinErr) {
            basis = target_buy_price - asst_buy_price;
            factor_value = basis - prev_basis;
            prev_basis = basis;
        }
    };

private:
    std::string asst_symbol;
    int16_t current_sid;
    int16_t asst_sid;
    double target_buy_price = 0.0;
    double asst_buy_price = 0.0;
    double prev_basis = 0.0;
    double basis = 0.0;
};
                              
