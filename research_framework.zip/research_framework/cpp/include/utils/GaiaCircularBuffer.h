#pragma once

#include <vector>
#include <stdexcept>
#include <numeric>
#include <iostream>


template<typename T>
class GaiaCircularBuffer {
public:

    void setSize(uint32_t _max_size, T v) {
        max_size = _max_size;
        cur_size = 0;
        vec.resize(max_size, v);

        next_idx = 0;
        oldest_idx = 0;
        latest_idx = 0;
    }

    void setSize(uint32_t _max_size) {
        max_size = _max_size;
        cur_size = 0;
        vec.resize(max_size);

        next_idx = 0;
        oldest_idx = 0;
        latest_idx = 0;
    }

    void push(const T& v) {
        getNext() = v;
        write();
    }

    T& operator[](const int32_t &idx) {
        if(idx < 0) {
            // std::cout << "idx < 0, get index: " << (latest_idx + idx + 1) % max_size << std::endl;
            if(latest_idx + idx + 1 < 0) {
                return vec[(latest_idx + idx + 1 + max_size) % max_size];
            } else {
                return vec[(latest_idx + idx + 1) % max_size];
            }
        }
        else {
            // std::cout << "idx >= 0, get index: " << (oldest_idx + idx) % max_size << std::endl;
            return vec[(oldest_idx + idx) % max_size];
        }
    }

    // return oldest element
    T front() {
        return vec[oldest_idx];
    }

    // return newest element
    T back() {
        return vec[latest_idx];
    }

    T max() {
        return *(std::max_element(vec.begin(), vec.end()));
    }

    T min() {
        return *(std::min_element(vec.begin(), vec.end()));
    }

    T sum() {
        return std::accumulate(vec.begin(), vec.end(), T(0));
    }

    T pos_sum() {
        T sum = T(0);
        for (const T& val : vec) {
            if (val > T(0)) {
                sum += val;
            }
        }
        return sum;
    }

    T pos_large_sum(T threshold) {
        T sum = T(0);
        for (const T& val : vec) {
            if ((val > T(0))&& (val > threshold)) {
                sum += val;
            }
        }
        return sum;
    }

    T neg_sum() {
        T sum = T(0);
        for (const T& val : vec) {
            if (val < T(0)) {
                sum += -val;
            }
        }
        return sum;
    }

    T neg_large_sum(T threshold) {
        T sum = T(0);
        for (const T& val : vec) {
            if ((val < T(0))&& (val < -threshold)) {
                sum += -val;
            }
        }
        return sum;
    }

    T mean() {
        return sum() / cur_size;
    }

    T std() {
        T mean_value = mean();
        T sq_sum = std::accumulate(vec.begin(), vec.end(), T(0), [mean_value](T acc, const T& val) {
            return acc + (val - mean_value) * (val - mean_value);
        });
        return std::sqrt(sq_sum / cur_size);
    }

    T skew() {
        if (cur_size < 3) {
            // skew needs points>=3
            return T(0);
        }

        T mean_value = mean();
        T std_value = std();

        if (std_value == T(0)) {
            return T(0);
        }

        // 计算三阶中心矩
        T cubed_sum = std::accumulate(vec.begin(), vec.end(), T(0), [mean_value](T acc, const T& val) {
            T diff = val - mean_value;
            return acc + diff * diff * diff;
        });

        return (cubed_sum / static_cast<T>(cur_size)) / (std_value * std_value * std_value);
    }

    T& getNext() {
        return vec[next_idx];
    }

    int size() { return cur_size; }

    int get_max_size() { return max_size; }

    bool isFull() {
        return cur_size == max_size;
    }
    
    void write() {
	    latest_idx = next_idx;
	    next_idx = (next_idx + 1) % max_size;
        if (cur_size < max_size) {
            cur_size++;
        } else {
            // oldest_idx = (oldest_idx + 1) % max_size;
            oldest_idx += 1;
            if (oldest_idx == max_size) {
                oldest_idx = 0;
            }
	    }
    }

    void printStatus() {
                std::cout << "write " << latest_idx << ","
                  << "next_idx: " << next_idx << ","
                  << "oldest_idx: " << oldest_idx << ","
                  << "cur_size: " << cur_size << ","
                  << "max_size: " << max_size << ","
                  << "latest_idx: " << latest_idx << std::endl;
    }

private:
    int32_t             cur_size;
    int32_t             max_size;
    int32_t             oldest_idx;
    int32_t             latest_idx;
    int32_t             next_idx;
    std::vector<T>      vec;
};

#define GAIA_CIRCULAR_BUFFER_DEFAULT_SIZE 10240
template<typename T>
class FixedGaiaCircularBuffer {
public:
    class Iterator {
    public:
        // 迭代器特性
        using iterator_category = std::random_access_iterator_tag;
        using value_type = T;
        using difference_type = std::ptrdiff_t;
        using pointer = T*;
        using reference = T&;

        // 构造函数
        Iterator(T* data, int32_t index, int32_t base_idx, int32_t max_size)
            : data_(data), index_(index), base_idx_(base_idx), max_size_(max_size) {}

        // 解引用
        reference operator*() const {
            return data_[(base_idx_ + index_) % max_size_];
        }

        // 箭头操作符
        pointer operator->() const {
            return &(data_[(base_idx_ + index_) % max_size_]);
        }

        // 前置自增
        Iterator& operator++() {
            ++index_;
            return *this;
        }

        // 后置自增
        Iterator operator++(int) {
            Iterator tmp = *this;
            ++(*this);
            return tmp;
        }

        // 前置自减
        Iterator& operator--() {
            --index_;
            return *this;
        }

        // 后置自减
        Iterator operator--(int) {
            Iterator tmp = *this;
            --(*this);
            return tmp;
        }

        // 相等比较
        bool operator==(const Iterator& other) const {
            return index_ == other.index_;
        }

        // 不等比较
        bool operator!=(const Iterator& other) const {
            return !(*this == other);
        }

        // 加法操作
        Iterator operator+(difference_type n) const {
            return Iterator(data_, index_ + n, base_idx_, max_size_);
        }

        // 减法操作
        Iterator operator-(difference_type n) const {
            return Iterator(data_, index_ - n, base_idx_, max_size_);
        }

        // 迭代器之间的差值
        difference_type operator-(const Iterator& other) const {
            return index_ - other.index_;
        }

    private:
        T* data_;         // 指向数组的指针
        int32_t index_;   // 逻辑索引（从0开始）
        int32_t base_idx_; // 基础索引（oldest_idx）
        int32_t max_size_; // 数组最大容量
    };

    void setSize(uint32_t _max_size, T v) {
        max_size = _max_size;
        cur_size = 0;
        if (_max_size > GAIA_CIRCULAR_BUFFER_DEFAULT_SIZE) {
            throw std::runtime_error("max_size exceeds GAIA_CIRCULAR_BUFFER_DEFAULT_SIZE");
        }
        for (int i = 0; i < GAIA_CIRCULAR_BUFFER_DEFAULT_SIZE; i++) {
            vec[i] = v;
        }

        next_idx = 0;
        oldest_idx = 0;
        latest_idx = 0;
    }

    void setSize(uint32_t _max_size) {
        max_size = _max_size;
        cur_size = 0;
        if ( _max_size > GAIA_CIRCULAR_BUFFER_DEFAULT_SIZE) {
            throw std::runtime_error("max_size exceeds GAIA_CIRCULAR_BUFFER_DEFAULT_SIZE");
        }
        memset(vec, 0, sizeof(T) * GAIA_CIRCULAR_BUFFER_DEFAULT_SIZE);

        next_idx = 0;
        oldest_idx = 0;
        latest_idx = 0;
    }

    Iterator begin() {
        return Iterator(vec, 0, oldest_idx, max_size);
    }

    Iterator end() {
        return Iterator(vec, cur_size, oldest_idx, max_size);
    }

    void push(const T& v) {
        getNext() = v;
        write();
    }

    T& operator[](const int32_t &idx) {
        if(idx < 0) {
            // std::cout << "idx < 0, get index: " << (latest_idx + idx + 1) % max_size << std::endl;
            if(latest_idx + idx + 1 < 0) {
                return vec[(latest_idx + idx + 1 + max_size) % max_size];
            } else {
                return vec[(latest_idx + idx + 1) % max_size];
            }
        }
        else {
            // std::cout << "idx >= 0, get index: " << (oldest_idx + idx) % max_size << std::endl;
            return vec[(oldest_idx + idx) % max_size];
        }
    }

    // return oldest element
    T front() {
        return vec[oldest_idx];
    }

    // return newest element
    T back() {
        return vec[latest_idx];
    }

    T max() {
        return *(std::max_element(begin(), end()));
    }

    T min() {
        return *(std::min_element(begin(), end()));
    }

    T sum() {
        return std::accumulate(begin(), end(), T(0));
    }

    T pos_sum() {
        T sum = T(0);
        for (const T& val : vec) {
            if (val > T(0)) {
                sum += val;
            }
        }
        return sum;
    }

    T pos_large_sum(T threshold) {
        T sum = T(0);
        for (const T& val : vec) {
            if ((val > T(0))&& (val > threshold)) {
                sum += val;
            }
        }
        return sum;
    }

    T neg_sum() {
        T sum = T(0);
        for (const T& val : vec) {
            if (val < T(0)) {
                sum += -val;
            }
        }
        return sum;
    }

    T neg_large_sum(T threshold) {
        T sum = T(0);
        for (const T& val : vec) {
            if ((val < T(0))&& (val < -threshold)) {
                sum += -val;
            }
        }
        return sum;
    }

    T mean() {
        return sum() / cur_size;
    }

    T std() {
        T mean_value = mean();
        T sq_sum = std::accumulate(begin(), end(), T(0), [mean_value](T acc, const T& val) {
            return acc + (val - mean_value) * (val - mean_value);
        });
        return std::sqrt(sq_sum / cur_size);
    }

    T skew() {
        if (cur_size < 3) {
            // skew needs points>=3
            return T(0);
        }

        T mean_value = mean();
        T std_value = std();

        if (std_value == T(0)) {
            return T(0);
        }

        // 计算三阶中心矩
        T cubed_sum = std::accumulate(begin(), end(), T(0), [mean_value](T acc, const T& val) {
            T diff = val - mean_value;
            return acc + diff * diff * diff;
        });

        return (cubed_sum / static_cast<T>(cur_size)) / (std_value * std_value * std_value);
    }

    T& getNext() {
        return vec[next_idx];
    }

    int size() { return cur_size; }

    int get_max_size() { return max_size; }

    bool isFull() {
        return cur_size == max_size;
    }
    
    void write() {
        if (cur_size < max_size) {
	    latest_idx = next_idx;
	    next_idx = (next_idx + 1) % max_size;
            cur_size++;
        } else {
	    latest_idx = next_idx;
	    next_idx = (next_idx + 1) % max_size;
            oldest_idx = (oldest_idx + 1) % max_size;
	    }
    }

    void printStatus() {
                std::cout << "write " << latest_idx << ","
                  << "next_idx: " << next_idx << ","
                  << "oldest_idx: " << oldest_idx << ","
                  << "cur_size: " << cur_size << ","
                  << "max_size: " << max_size << ","
                  << "latest_idx: " << latest_idx << std::endl;
    }

private:
    int32_t             cur_size;
    int32_t             max_size;
    int32_t             oldest_idx;
    int32_t             latest_idx;
    int32_t             next_idx;
    T                   vec[GAIA_CIRCULAR_BUFFER_DEFAULT_SIZE]; // default size is 256
};
