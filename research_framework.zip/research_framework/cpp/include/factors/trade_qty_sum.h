#include "Factor.h"
#include "Ema.h"
#include <cmath>
#include "GaiaCircularBuffer.h"
#include "GaiaUtils.h"
class TradeQtySumFactor : public FactorInterface
{
public:
    TradeQtySumFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
        timer_interval_ms = config.Get<int64_t>("timer_interval_ms");
        RegisterTimer(timer_interval_ms*1e6L);
    };

    virtual std::string gen_name() {;
        return std::string("TradeQtySumFactor") + '@' + std::to_string(timer_interval_ms);
    }

    virtual void calculate(const FactorInput& input_data) {
        bool is_trade = input_data.cur_contract->update_tick_type == TickEventType::TICK_TRADE;
        if (is_trade){
            double prc_tick_size = input_data.cur_contract->symbol_info->prc_tick_size;
            auto &trade = input_data.cur_contract->trade;
            //factor_value += trade.qty;
        }
        
    };
    void OnTimer() override {
        factor_value += 1; 
    }
private:
    int64_t timer_interval_ms;
    
};
                              
