#pragma once

#include "Predictor.h"
#include "arb/PriceEma.h"
#include "SpdLoggerMessage.h"
#include "SpdLogger.h"
#include "KronosGeneralPredictorImpl.h"

class ApolloPredictorImpl : public Predictor
{
public:
    ApolloPredictorImpl(){};

    virtual void Init(const Config &_conf, const Config &_pred_conf) {
        std::cout << "init apollo predictor config" << std::endl;
        auto orderConfig = _conf.Get<Config>("order_logic_config");
        auto commonConfig = orderConfig.Get<Config>("common");
        notional_size = GaiaUtils::GetParam<double>(commonConfig, "notional_size");
        coin_size = GaiaUtils::GetParam<double>(commonConfig, "custom_coin_size");
        std::cout << "predictor notional size: " << notional_size << ", coin_size: " << coin_size << std::endl;

        auto conf = _conf.Get<Config>("predictor_config");
        quote_symbol = GaiaUtils::GetParam<std::string>(conf, "quoter_symbol");
        hedge_symbol = GaiaUtils::GetParam<std::string>(conf, "hedger_symbol");
        try {
            quote_coin_ref_mode = GaiaUtils::GetParam<int>(conf, "quote_coin_ref_mode");
            if(quote_coin_ref_mode != 0) quote_coin_ref_symbol = GaiaUtils::GetParam<std::string>(conf, "quote_coin_ref_symbol");
        } catch(...) {
            quote_coin_ref_symbol = "";
            quote_coin_ref_mode = 0;
        }
        if(quote_coin_ref_mode != 0) std::cout << "predictor quote_coin_ref_mode: " << quote_coin_ref_mode << ", quote_coin_ref_symbol: " << quote_coin_ref_symbol << std::endl;
        quote_coin_ref_ratio = 1;

        ema_interval = GaiaUtils::GetParam<int64_t>(conf, "ema_interval");
        book_theo_price_levels = GaiaUtils::GetParam<int64_t>(conf, "book_theo_price_levels");
        quoter_theo_alpha = GaiaUtils::GetParam<double>(conf, "quoter_theo_alpha");
        quoter_theo_gamma = GaiaUtils::GetParam<double>(conf, "quoter_theo_gamma");
        hedger_theo_alpha = GaiaUtils::GetParam<double>(conf, "hedger_theo_alpha");
        hedger_theo_gamma = GaiaUtils::GetParam<double>(conf, "hedger_theo_gamma");

        // generate factors config
        Config tmp_conf;
        tmp_conf.Set("ema_interval", ema_interval);
        quoter_theo_price_ema.Init(tmp_conf);
        hedger_theo_price_ema.Init(tmp_conf);

        // multi
        main_signal_weight = _pred_conf.Get<double>("main_signal_weight");
        assist_signal_weight = _pred_conf.Get<double>("assist_signal_weight");

        // init other predictor
        kronos_predictor_.setState(state);
        kronos_predictor_.Initialize(_conf, _pred_conf);
    };

    void Calculate() override {
	    HandleData();
        kronos_predictor_.CalculatePredictor(state->cur_tick_type, state->cur_tick_sid, state->latency_record, state->main_sid);
        state->signal.pred_value = kronos_predictor_.getState().signal.pred_value;
    }

    void HandleData() {
        if (!CheckData()) return;
        Predict();
    }


    bool CheckData() {
        ContractInfo *quote_contract = (*state->contract_map)[quote_symbol];
        ContractInfo *hedge_contract = (*state->contract_map)[hedge_symbol];

        if(state->cur_tick_sid != quote_contract->symbol_info->sid && state->cur_tick_sid != hedge_contract->symbol_info->sid) {
            return false;
        }

        double quoter_best_bid_price = GaiaUtils::BookGetBestBidPrice(quote_contract);
        double quoter_best_ask_price = GaiaUtils::BookGetBestAskPrice(quote_contract);
        double quoter_mid_price = (quoter_best_bid_price + quoter_best_ask_price) / 2.0;
        double hedger_best_bid_price = GaiaUtils::BookGetBestBidPrice(hedge_contract);
        double hedger_best_ask_price = GaiaUtils::BookGetBestAskPrice(hedge_contract);
        double hedger_mid_price = (hedger_best_bid_price + hedger_best_ask_price) / 2.0;

        if (quoter_best_bid_price < eps || quoter_best_ask_price < eps || hedger_best_bid_price < eps || hedger_best_ask_price < eps){
            return false;
        }
        state->signal.quoter_ema_theo_price = quoter_mid_price;
        state->signal.hedger_ema_theo_price = hedger_mid_price;
        state->signal.hedger_eff_bid_price = hedger_best_bid_price;
        state->signal.hedger_eff_ask_price = hedger_best_ask_price;
        quoter_theo_price = quoter_mid_price;
        hedger_theo_price = hedger_mid_price;
        return true;
    }



    void Predict(){
        // std::cout << "----- predictor -----" << std::endl; 
        ContractInfo *quote_contract = (*state->contract_map)[quote_symbol];
        ContractInfo *hedge_contract = (*state->contract_map)[hedge_symbol];
        // 
        if  (state->cur_tick_sid == quote_contract->symbol_info->sid) {
            int64_t current_time = GaiaUtils::GetSysTimestamp();
            CalTheoPrice(quote_contract, quoter_theo_price, quoter_theo_gamma, quoter_theo_alpha, quoter_eff_bid_price, quoter_eff_ask_price, notional_size);
            quoter_theo_price_ema.calculate(current_time, quoter_theo_price);
            quoter_tick_num += 1;
        } 
        else if (state->cur_tick_sid == hedge_contract->symbol_info->sid) {
            CalTheoPrice(hedge_contract, hedger_theo_price, hedger_theo_gamma, hedger_theo_alpha, hedger_eff_bid_price, hedger_eff_ask_price, notional_size);
            int64_t current_time = GaiaUtils::GetSysTimestamp();
            if (hedger_theo_price > 0) {
                hedger_theo_price_ema.calculate(current_time, hedger_theo_price);
            }
            // if (quoter_theo_price > 0) {
            //     quoter_theo_price_ema.calculate(current_time, quoter_theo_price);
            // }
            hedger_tick_num += 1;
        }
        state->signal.quoter_ema_theo_price = quoter_theo_price_ema.get_value();
        state->signal.hedger_ema_theo_price = hedger_theo_price_ema.get_value();
        state->signal.hedger_eff_bid_price = hedger_eff_bid_price;
        state->signal.hedger_eff_ask_price = hedger_eff_ask_price;
    };

    void CalMicroPrice(ContractInfo *contract, double &eff_bid_price, double &eff_ask_price, double &micro_price, double &quote_size) {
        auto &gob = contract->alphaBook;
        double total_bid_amt = 0.0;
        double total_ask_amt = 0.0;
        double total_bid_qty = 0.0;
        double total_ask_qty = 0.0;
        int64_t num_bids = gob->num_bids();
        int64_t num_asks = gob->num_asks();
        for (int i = 0; i < num_bids; i++) {
            total_bid_amt += gob->bid(i).price * gob->bid(i).qty;
            total_bid_qty += gob->bid(i).qty;
            if (total_bid_amt > quote_size || i >= book_theo_price_levels) {
                break;
            }
            std::cout << "bid " << i << ", price: " << gob->bid(i).price << ", qty: " << gob->bid(i).qty << ", total_bid_amt: " << total_bid_amt << ", total_bid_qty: " << total_bid_qty << std::endl;
        }
        for (int i = 0; i < num_asks; i++) {
            total_ask_amt += gob->ask(i).price * gob->ask(i).qty;
            total_ask_qty += gob->ask(i).qty;
            if (total_ask_amt > quote_size || i >= book_theo_price_levels) {
                break;
            }
            std::cout << "ask " << i << ", price: " << gob->ask(i).price << ", qty: " << gob->ask(i).qty << ", total_ask_amt: " << total_ask_amt << ", total_ask_qty: " << total_ask_qty << std::endl;
        }
        eff_bid_price = total_bid_amt / total_bid_qty;
        eff_ask_price = total_ask_amt / total_ask_qty;
        double ln_bid_qty = std::log10(total_bid_qty*ONE_BASE_POINT);
        double ln_ask_qty = std::log10(total_ask_qty*ONE_BASE_POINT);
        if (ln_bid_qty > 0 && ln_ask_qty > 0) {
            micro_price = (eff_bid_price * ln_ask_qty + eff_ask_price * ln_bid_qty) / (ln_ask_qty + ln_bid_qty);
        }
        else {
            micro_price = (eff_bid_price + eff_ask_price)/2.0;
        }
        std::cout << "eff_bid_price: " << eff_bid_price << ", eff_ask_price: " << eff_ask_price << ", micro_price: " << micro_price << std::endl;
    }
    
    void CalTheoPrice(ContractInfo *contract, double &theo_price, double &theo_gamma, double &theo_alpha, double &eff_bid_price, double &eff_ask_price, double &quote_size) {
        auto &gob = contract->alphaBook;
        auto &trade = contract->trade;
        double total_bid_amt = 0.0;
        double total_ask_amt = 0.0;
        double total_bid_qty = 0.0;
        double total_ask_qty = 0.0;
        int64_t num_bids = gob->num_bids();
        int64_t num_asks = gob->num_asks();
        for (int i = 0; i < num_bids; i++) {
            total_bid_amt += gob->bid(i).price * gob->bid(i).qty;
            total_bid_qty += gob->bid(i).qty;
            if (total_bid_amt > quote_size || i >= book_theo_price_levels) {
                break;
            }
        }
        for (int i = 0; i < num_asks; i++) {
            total_ask_amt += gob->ask(i).price * gob->ask(i).qty;
            total_ask_qty += gob->ask(i).qty;
            if (total_bid_amt > quote_size || i >= book_theo_price_levels) {
                break;
            }
        }
        eff_bid_price = total_bid_amt / total_bid_qty;
        eff_ask_price = total_ask_amt / total_ask_qty;
        double trade_price = trade.price;
        double adj_bid_qty = std::pow(total_bid_qty, theo_gamma);
        double adj_ask_qty = std::pow(total_ask_qty, theo_gamma);
        theo_price = (adj_bid_qty*eff_ask_price + adj_ask_qty*eff_bid_price)/(adj_bid_qty + adj_ask_qty);
        theo_price = theo_alpha*trade_price + (1.0 - theo_alpha)*theo_price;
    }
    
    
private:
    KronosGeneralPredictorImpl kronos_predictor_;
    double main_signal_weight = 1.0; // default weight for main signal, can be set by derived class
    double assist_signal_weight = 0.0; // default weight for sub signal, can be set by derived class

    std::string    quote_symbol;
    std::string    hedge_symbol;
    std::string    quote_coin_ref_symbol;
    double notional_size;
    double coin_size;
    double hedge_ref_quote_price_ratio;
    double quote_coin_ref_ratio;
    int    quote_coin_ref_mode; // 1: multi, -1: divide, 0: inactive

    int64_t ema_interval;
    int64_t book_theo_price_levels;
    PriceEma quoter_theo_price_ema;
    PriceEma hedger_theo_price_ema;

    double quoter_theo_price = 0.0;
    double quoter_eff_bid_price = 0.0;
    double quoter_eff_ask_price = 0.0;
    double hedger_theo_price = 0.0;
    double hedger_eff_bid_price = 0.0;
    double hedger_eff_ask_price = 0.0;
    int64_t md_latency;
    // theo
    double quoter_theo_alpha = 0.0;
    double quoter_theo_gamma = 0.0;

    double hedger_theo_alpha = 0.0;
    double hedger_theo_gamma = 0.0;

    int64_t quoter_tick_num = 0;
    int64_t hedger_tick_num = 0;
};

