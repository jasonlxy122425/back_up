#include "Factor.h"
#include "Ema.h"
#include <cmath>

class BestCancelImbaFactor : public FactorInterface
{
public:
    BestCancelImbaFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
        ewma_int = config.Get<int64_t>("ewma_int");
        ewma_decay = ewma_int/100.0;
    };

    virtual std::string gen_name() {
        return std::string("BestCancelImbaFactor") + "@ewma_int=" + std::to_string(ewma_int);
    }

    virtual void calculate(const FactorInput& input_data) {
        if (input_data.cur_contract->update_tick_type != TickEventType::TICK_BBO){
            return;
        }
        auto &ob = input_data.cur_contract->alphaBook;
        double bid_price =  ob->bid(0).price;
        double ask_price =  ob->ask(0).price;
        double bid_qty = ob->bid(0).qty;
        double ask_qty = ob->ask(0).qty;
        double tmp_bid = 0.0;
        double tmp_ask = 0.0; 
        if (bid_price < prev_bid_price - MinErr){
            tmp_bid = prev_bid_qty;
        }
        else if (std::abs(bid_price - prev_bid_price) < MinErr){
            if (bid_qty < prev_bid_qty - MinErr){
                tmp_bid = prev_bid_qty - bid_qty;
            }
        }
        if (ask_price > prev_ask_price + MinErr){
            tmp_ask = prev_ask_qty;
        }
        else if (std::abs(ask_price - prev_ask_price) < MinErr){
            if (ask_qty < prev_ask_qty - MinErr){
                tmp_bid = prev_ask_qty - ask_qty;
            }
        }
        double tmp_value = log(tmp_bid+1.0) - log(tmp_ask+1.0);
        factor_value = ewma_decay*factor_value + (1.0 - ewma_decay)*tmp_value;
        prev_bid_price = bid_price;
        prev_ask_price = ask_price;
        prev_bid_qty = bid_qty;
        prev_ask_qty = ask_qty;
    };


private:
    int64_t ewma_int;
    double ewma_decay = 0.0;
    double prev_bid_price = 0.0;
    double prev_ask_price = 0.0;
    double prev_bid_qty = 0.0;
    double prev_ask_qty = 0.0;
};
                              
