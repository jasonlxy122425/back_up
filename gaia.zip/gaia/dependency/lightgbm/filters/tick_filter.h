//
// Created by Hongjian Han on 2021/8/2.
//
# pragma once
# include <iostream>
# include <vector>
# include <memory>
# include "../common/tick.h"
typedef double Type;

class TickFilter
{
public:
    TickFilter() = default;
    virtual ~TickFilter() = default;
    virtual bool calculate(const Tick & data);
};

class PxFilter: public TickFilter
{
private:
    Type min_change_;
    Type last_px_ = 0.0;
public:
    PxFilter();
    explicit PxFilter(Type min_change);
    ~PxFilter() override;
    bool calculate(const Tick & data) override;
};

class VolumeFilter: public TickFilter
{
private:
    Type min_change_;
    Type target_vol_ = 0.0;
public:
    VolumeFilter();
    explicit VolumeFilter(Type min_change);
    ~VolumeFilter() override;
    bool calculate(const Tick & data) override;
};

class SpreadFilter: public TickFilter
{
private:
    Type max_spread_;
public:
    SpreadFilter();
    explicit SpreadFilter(Type max_spread);
    ~SpreadFilter() override;
    bool calculate(const Tick & data) override;
};

enum MultiMethod : uint8_t {
    AND = 0,
    OR = 1,
    DEFAULT = 2,
};

class MultiFilter : public TickFilter
{
private:
    MultiMethod method_;
    std::vector<TickFilter *> filters_;
public:
    MultiFilter();
    MultiFilter(MultiMethod method, const std::vector<TickFilter *> & filters);
    ~MultiFilter() override;
    bool calculate(const Tick & data) override;
    MultiFilter & operator=(const MultiFilter & mf);
};
