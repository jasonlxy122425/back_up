#pragma once
#include "DemeterData.h"
#include "SamplerLayer.h"

namespace demeter {

class DemeterDataManager {
public:
    DemeterDataManager() = default;

    void Init(SymId sid, std::string sampler_type, int sample_num) {
        sampler_layer_.Init(sid, sampler_type, sample_num);
    }

    void Sample(Nanoseconds now) {
        return sampler_layer_.Sample(now);
    }

    bool isTickSample(SymId sid) { return sampler_layer_.isTickSample(sid); }
    bool needSample(SymId sid) { return sampler_layer_.needSample(sid);}

    void Update(const GaiaOrderbook &order_book, ContractInfo *contract) {
        sampler_layer_.Update(order_book, contract);
    }

    std::shared_ptr<DemeterData> Get(SymId sid) {return sampler_layer_.GetDemeterData(sid);}

private:
    SamplerLayer sampler_layer_;
};

}; // namespace demeter