#pragma once
#include <cstdlib>
#include "OrderLogic.h"
#include "GaiaUtils.h"
#include "SpdLogger.h"
#include "FactorMsg.h"
#include "Predictor.h"
#include "SystemDefine.h"
#include "ApolloHedger.h"


struct ArbConfig {
    // edge
    double bid_offset_bps;
    double ask_offset_bps;
    double inventory_beta;
    // cancel
    double quote_range_bps;
    // order_type
    bool use_replace;
    // risk
    double custom_max_notional = 1e8L;
    double custom_min_notional = 0;
    int32_t warm_up_ticks = 5000;
    bool funding_rate_mode = false;
    bool buy_only = false;
    bool sell_only = false;

    bool futures_spot_arb_mode = false;
    // kronos signal
    double kronos_signal_beta = 0.0;
    // to_ouput
    bool to_output_logs = false;
};

class ApolloImpl : public OrderLogic {
public:
    struct OrderLevel
    {
        double upper;
        double lower;
        double price;
        GOrderState *orderState = nullptr;
    };

    std::vector<OrderLevel> bid_order_levels;
    std::vector<OrderLevel> ask_order_levels;

    SymId hedger_sid;
    std::unordered_map<SymId, int32_t> warmup_ticks_map;
    bool warmup_done = false;
    FactorOutputType output;

    bool first_data_after_init = false;
    /// @brief 
    double m_best_bid_price = 0.0;
    double m_best_ask_price = 0.0;
    double m_ema_spread_bps = 0.0;
    double m_spread_bid_bps = 0.0;
    double m_spread_ask_bps = 0.0;
    double m_quote_best_bid_price = 0.0;
    double m_quote_best_ask_price = 0.0;
    bool m_quote_first_tick = false;
    bool m_hedge_first_tick = false;
    bool m_risk_check_cond = false;

    ArbConfig config;
    int64_t last_risk_print_ts = 0;

    ApolloHedger* hedger = nullptr;
    
    ApolloImpl(){
        hedger = new ApolloHedger();
    }
        
    Hedger* getHedger() override {
        return hedger;
    }

    void Init(const Config& _conf)
    {
        version = "apollo_1.0.0";

        std::cout << "init Apollo config" << std::endl;
        auto conf = _conf.Get<Config>("order_logic_config");
        // read config

        config.custom_max_notional = GaiaUtils::GetParam<double>(conf, "custom_max_notional");
        config.custom_min_notional = GaiaUtils::GetParam<double>(conf, "custom_min_notional");

        config.bid_offset_bps = GaiaUtils::GetParam<double>(conf, "bid_offset_bps");
        config.ask_offset_bps = GaiaUtils::GetParam<double>(conf, "ask_offset_bps");
        config.inventory_beta = GaiaUtils::GetParam<double>(conf, "inventory_beta");
        config.quote_range_bps = GaiaUtils::GetParam<double>(conf, "quote_range_bps");
        config.use_replace = GaiaUtils::GetParam<bool>(conf, "use_replace");

        config.warm_up_ticks = GaiaUtils::GetParam<int32_t>(conf, "warm_up_ticks");

        try {
            config.funding_rate_mode = GaiaUtils::GetParam<bool>(conf, "funding_rate_mode");
            config.buy_only = GaiaUtils::GetParam<bool>(conf, "buy_only");
            config.sell_only = GaiaUtils::GetParam<bool>(conf, "sell_only");
        } catch(...) {
            config.funding_rate_mode = false;
        }

        try {
            config.futures_spot_arb_mode = GaiaUtils::GetParam<bool>(conf, "futures_spot_arb_mode");
            std::string hedger_symbol = GaiaUtils::GetParam<std::string>(conf, "hedger_symbol");
            hedger_sid = SecMaster::instance().FindSid(hedger_symbol);
        } catch(...) {
            config.futures_spot_arb_mode = false;
        }

        
        first_data_after_init = true;

        // kronos signal
        config.kronos_signal_beta = GaiaUtils::GetParam<double>(conf, "kronos_signal_beta");
        config.to_output_logs = GaiaUtils::GetParam<int64_t>(conf, "to_output_logs") == 0 ? false : true;
    };

    G_INLINE void RiskCheck(StrategyFields &strategy_fields)
    {
        auto &risk_check_result = strategy_fields.risk_check_result;
        if (m_quote_first_tick && m_hedge_first_tick) {
            m_risk_check_cond = true;
        }
    }

    G_INLINE void CalculateEdge(StrategyFields &strategy_fields, double &placeBidPrice, double &placeAskPrice, const int64_t &recv_ts)
    {

        ContractInfo* & quote_contract  = strategy_fields.contract_info;
        double net_pos = strategy_fields.sym_risk.symbol_risk/quote_contract->symbol_info->multiplier;
        double max_pos = strategy_fields.max_pos_coin/quote_contract->symbol_info->multiplier;
        ContractInfo* mainContract = strategy_fields.contract_info;

        m_ema_spread_bps = (strategy_fields.signal.quoter_ema_theo_price - strategy_fields.signal.hedger_ema_theo_price) / strategy_fields.signal.hedger_ema_theo_price * ONE_BASE_POINT;
        // std::cout << "ema_spread_bps: " << m_ema_spread_bps << "," << strategy_fields.signal.quoter_ema_theo_price << "," << strategy_fields.signal.hedger_ema_theo_price << std::endl;
        // inventory risk
        double max_inventory_bias = (config.bid_offset_bps + config.ask_offset_bps)/2.0;
        double inventory_bias = - config.inventory_beta * max_inventory_bias * (net_pos/max_pos);
        if (inventory_bias > max_inventory_bias) {
            inventory_bias = max_inventory_bias;
        }
        if (inventory_bias < -max_inventory_bias) {
            inventory_bias = -max_inventory_bias;
        }
        m_spread_bid_bps = m_ema_spread_bps + config.bid_offset_bps + inventory_bias;
        m_spread_ask_bps = m_ema_spread_bps + config.ask_offset_bps + inventory_bias;
        placeBidPrice = placeBidPrice * ( 1 - m_spread_bid_bps/ONE_BASE_POINT);
        placeAskPrice = placeAskPrice * ( 1 + m_spread_ask_bps/ONE_BASE_POINT);

        mainContract->custom_min_notional = config.custom_min_notional;
        mainContract->custom_max_notional = config.custom_max_notional;

        if (m_quote_best_ask_price > eps && m_quote_best_bid_price > eps) {
            if (placeBidPrice >= m_quote_best_ask_price) {
                placeBidPrice = m_quote_best_bid_price;
            }
            if (placeAskPrice <= m_quote_best_bid_price) {
                placeAskPrice = m_quote_best_ask_price;
            }
        }         
    }

    void Process(TickEventType _cur_tick_type, const SymId &_cur_tick_sid, StrategyFields &strategy_fields)
    {
        ContractInfo* & quote_contract  = strategy_fields.contract_info;
        // quote_contrat
        if (quote_contract->symbol_info->sid == _cur_tick_sid) {
            m_quote_best_bid_price = GaiaUtils::BookGetBestBidPrice(quote_contract);
            m_quote_best_ask_price = GaiaUtils::BookGetBestAskPrice(quote_contract);
            m_quote_first_tick = true;
        } else {
            m_hedge_first_tick = true;
        }
        RiskCheck(strategy_fields);

        int64_t now = (*strategy_fields.sid_contract_map)[_cur_tick_sid]->latency_record.mkt_data.mkt_recv_ts;

        double placeBidPrice = strategy_fields.signal.hedger_eff_bid_price;
        double placeAskPrice = strategy_fields.signal.hedger_eff_ask_price;
        CalculateEdge(strategy_fields, placeBidPrice, placeAskPrice, now);

        //
        double net_pos = strategy_fields.sym_risk.symbol_risk/quote_contract->symbol_info->multiplier;
        double max_pos = strategy_fields.max_pos_coin/quote_contract->symbol_info->multiplier;
        double quote_qty = strategy_fields.order_size_coin/quote_contract->symbol_info->multiplier;
        double buyOrderTotalCount = 0.0;
        double sellOrderTotalCount = 0.0;
        processExistingOrders(strategy_fields, buyOrderTotalCount, sellOrderTotalCount, placeBidPrice, placeAskPrice);
        bool can_buy = buyOrderTotalCount < eps;
        bool can_sell = sellOrderTotalCount < eps;
        if  (m_risk_check_cond) {
            if (can_buy) {
                Buy(strategy_fields, placeBidPrice, quote_qty, buyOrderTotalCount, net_pos, max_pos, TimeInForce::PO, 1);
            }
            if (can_sell) {
                Sell(strategy_fields, placeAskPrice, quote_qty, sellOrderTotalCount, net_pos, max_pos, TimeInForce::PO, -1);
            }
        }
        if (config.to_output_logs) {
            output.clear();
            output["_cur_tick_type"] = _cur_tick_type;
            output["_cur_tick_sid"] = _cur_tick_sid;
            output["ema_spread_bps"] = m_ema_spread_bps;
            output["spread_bid_bps"] = m_spread_bid_bps;
            output["spread_ask_bps"] = m_spread_ask_bps;
            output["placeBidPrice"] = placeBidPrice;
            output["placeAskPrice"] = placeAskPrice;
            output["best_bid_price"] = m_quote_best_bid_price;
            output["best_ask_price"] = m_quote_best_ask_price;
            LOG_AUTO(FactorMsg, output, quote_contract->symbol_info->mirana_ticker);
        }
    }



    void processExistingOrders(StrategyFields& strategy_fields, double &buyOrderTotalCount, double &sellOrderTotalCount, double &placeBidPrice, double &placeAskPrice)
    {
        ContractInfo* &main_contract  = strategy_fields.contract_info;
        for(auto orderStateIter : strategy_fields.order_state_map)
        {
            auto &orderState = orderStateIter.second;
            double order_price = orderState->ts_order->price();
            double order_qty = orderState->ts_order->qty();
            if(orderState->ts_order->side() == Side::BUY)
            {
                buyOrderTotalCount += order_qty;
                if (std::abs(order_price - placeBidPrice)/ placeBidPrice > config.quote_range_bps / ONE_BASE_POINT){
                    CancelAllOnSide(strategy_fields, true, false);
                }
            }
            else if(orderState->ts_order->side() == Side::SELL)
            {
                sellOrderTotalCount += order_qty;
                if (std::abs(order_price - placeAskPrice) / placeAskPrice > config.quote_range_bps / ONE_BASE_POINT){
                    CancelAllOnSide(strategy_fields, false, true);
                }
            }
        }
    }

    void Buy(StrategyFields& strategy_fields, double &price, double &qty, double buyOrderTotalCount, double net_pos, double max_pos, TimeInForce tif, int64_t strategy_order_type)
    {
        ContractInfo* &main_contract  = strategy_fields.contract_info;
        double min_qty = main_contract->symbol_info->min_qty/main_contract->symbol_info->multiplier;
        double min_notional = main_contract->symbol_info->min_notional;
        double buy_total_risk = buyOrderTotalCount + net_pos;
        if (buy_total_risk <= max_pos){
            qty = std::min(qty, max_pos - buy_total_risk);
            qty = std::max(qty, 2*min_notional/price);
            qty = std::max(qty, min_qty);
            price = GaiaUtils::roundPriceViaTickSize(price, main_contract);
            qty = GaiaUtils::roundSizeViaQtyTick(qty, main_contract);
            GOrderState* new_order_state = GOrderOp::InsertOrder(strategy_fields, price, qty, Side::BUY, OrderType::LIMIT, tif, PositionOffset::UNKNOWN, strategy_order_type);

        }
    }

    void Sell(StrategyFields& strategy_fields, double &price, double &qty, double sellOrderTotalCount, double net_pos, double max_pos, TimeInForce tif, int64_t strategy_order_type)
    {
        ContractInfo* &main_contract  = strategy_fields.contract_info;
        double min_qty = main_contract->symbol_info->min_qty/main_contract->symbol_info->multiplier;
        double min_notional = main_contract->symbol_info->min_notional;
        double sell_total_risk = sellOrderTotalCount - net_pos;
        if (sell_total_risk <= max_pos){
            qty = std::min(qty, max_pos - sell_total_risk);
            qty = std::max(qty, 2*min_notional/price);
            qty = std::max(qty, min_qty);
            price = GaiaUtils::roundPriceViaTickSize(price, main_contract);
            qty = GaiaUtils::roundSizeViaQtyTick(qty, main_contract);
            GOrderState* new_order_state = GOrderOp::InsertOrder(strategy_fields, price, qty, Side::SELL, OrderType::LIMIT, tif, PositionOffset::UNKNOWN, strategy_order_type);

        }
    }

    bool ReplaceOrder(GOrderState* orderState, double price, double size, StrategyFields& strategy_fields) 
    {
        bool replace_ret = GOrderOp::ReplaceOrder(orderState, price, size);

        // log
        if (replace_ret) {
        }    

        return replace_ret;
    }
};
