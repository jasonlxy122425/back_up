#pragma once
#include <unordered_map>
#include <unistd.h>
#include "SystemDefine.h"

class GaiaPosMonitor {
public:
    constexpr static int64_t default_valid_pos_max_ns = 60 * 1000000000L;

    GaiaPosMonitor(int64_t valid_pos_max_sec = 60, int64_t abnormal_duration_sec = 120) {
        valid_pos_max_ns_ = valid_pos_max_sec * 1000000000L;
        abnormal_duration_ns_ = abnormal_duration_sec * 1000000000L;
    }

    void update_pos(LogicAcctId logic_acct_id, SymId sid, Qty net_pos, Nanoseconds ts) {
        auto &pos = get_pos(logic_acct_id, sid);

        if (std::abs(pos.net_pos - net_pos) > 1e-8) {
            pos.abnormal_start_ts = 0;
        }
        pos.net_pos = net_pos;
        pos.last_update_ts = ts;
    }

    // need input 
    bool process(LogicAcctId logic_acct_id, SymId sid, Nanoseconds ts, Qty trade_net_pos) {
        auto &pos = get_pos(logic_acct_id, sid);
        if(ts - pos.last_update_ts > valid_pos_max_ns_) {
            return true;
        }

        if (std::fabs(trade_net_pos - pos.net_pos) > 1e-8) {
            if(pos.abnormal_start_ts == 0) {
                pos.abnormal_start_ts = ts;
                pos.last_update_ts = 0; // need reqry pos
            } else if (ts - pos.abnormal_start_ts > abnormal_duration_ns_) {
                return false;
            }
        } else if(pos.abnormal_start_ts != 0) {
            pos.abnormal_start_ts = 0;
        }

        return true;
    }

    double get_record_pos(LogicAcctId logic_acct_id, SymId sid) {
        auto key = get_key(logic_acct_id, sid);
        return pos_infos_[key].net_pos;
    }

private:
    int64_t valid_pos_max_ns_;
    int64_t abnormal_duration_ns_;

struct PosInfo {
    Qty net_pos = 0;

    Nanoseconds last_update_ts = 0;

    Nanoseconds abnormal_start_ts = 0;
};

struct pair_hash {
    template <class T1, class T2>
    size_t operator()(const std::pair<T1, T2>& p) const {
        auto h1 = std::hash<T1>{}(p.first);
        auto h2 = std::hash<T2>{}(p.second);
        return h1 ^ (h2 << 1); // 使用 XOR 组合两个哈希值
    }
};
    using PosKeyType = std::pair<LogicAcctId, SymId>;

    std::unordered_map<PosKeyType, PosInfo, pair_hash> pos_infos_;
    
    PosKeyType get_key(LogicAcctId logic_acct_id, SymId sid) {
        return std::make_pair(logic_acct_id, sid);
    }

    PosInfo& get_pos(LogicAcctId logic_acct_id, SymId sid) {
        auto key = get_key(logic_acct_id, sid);
        if (pos_infos_.find(key) == pos_infos_.end()) {
            pos_infos_.emplace(key, PosInfo());
        }

        return pos_infos_[key];
    }
};
