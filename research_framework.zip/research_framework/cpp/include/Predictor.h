#pragma once

#include "PredictorGeneral.h"
#include "GaiaUtils.h"
#include "FactorTimer.h"
#include "Factor.h"
#include "FactorManager.h"

class Predictor {
public:
    Predictor(){
	    state = new PredictorState();
    }

    ~Predictor() {
    }

    void CalculatePredictor(const TickEventType &_cur_tick_type,
                        const SymId &_cur_tick_sid,
                        struct GLatencyRecord* _latency_record,
                        const SymId &_main_sid);
    void OnTimer(int64_t& now);

    void Initialize(const Config &config, const Config &_pred_conf) {
        this->Init(config, _pred_conf);
    }
    virtual void Init(const Config &config, const Config &_pred_conf) {};
    virtual void Calculate() {};
    virtual void CalculateAssistSignal(SignalStruct &output_signal, const SignalStruct &assist_signal) {
        output_signal = state->signal; // default implementation ignore assist_signal
    };

    virtual void getFactors(FactorOutputType &output) {}

    // const PredictorState& getState() {return *state;} ;
    PredictorState& getState() {return *state;} ;
    void setState(PredictorState *_state) {
        state = _state;
    };

    void setContractInfoMap(ContractInfoMapType *_contract_map) { state->contract_map = _contract_map; };
    void setSidContractInfoMap(SidContractInfoMapType *_sid_contract_map) { state->sid_contract_map = _sid_contract_map; };
protected:
    ContractInfo* GetContractInfo(const std::string &symbolName);

    FactorInput factor_input;
    FactorTimer factor_timer;
    PredictorState* state = nullptr;
};

