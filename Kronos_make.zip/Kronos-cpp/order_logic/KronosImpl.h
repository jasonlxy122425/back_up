#pragma once
#include "OrderLogic.h"
#include "GaiaUtils.h"
#include "SpdLogger.h"
#include "SpdLoggerMessage.h"
#include "FactorMsg.h"
#include "KronosFactorMsg.h"
#include "Predictor.h"
#include "GaiaCircularBuffer.h"
#include <cmath>


struct KronosConfig 
{
    // theo
    double theo_gamma;
    double theo_alpha;
    double theo_gamma2;
    double theo_alpha2;
    // price
    double mid_ewma;
    double var_ewma;
    // sigma
    int64_t theo_buffer_len;
    double init_var;
    bool use_sigma_adj;
    double sigma_alpha;
    double sigma_beta;
    double sigma_base;
    // pred
    double signal_floor;
    double pred_beta;
    double pred_alpha;
    double pred_base;
    // frac_cut
    double frac_cut;
    // edge
    double minimum_edge_bps;
    double minimum_edge;
    // cancel
    double quote_range_bps;
    int64_t quote_range_ticks;
    double edge_lower_bound;
    bool use_queue_cancel;
    int64_t queue_cancel_levels;
    double queue_cancel_max_amount;
    // pos pen
    double pos_pen_intercept;
    double pos_pen_coef;
    double pos_pen_lower_bound;
    double pos_pen_one_side_target;
    // spread
    bool use_spread_filter;
    // improve
    double improve_spread_ratio;
    int64_t improve_tick;
    //
    bool to_output_logs;
};  

class KronosImpl : public OrderLogic {
public:
    struct OrderLevel
    {
        double upper;
        double lower;
        double price;
        GOrderState *orderState = nullptr;
    };

    std::vector<OrderLevel> bid_order_levels;
    std::vector<OrderLevel> ask_order_levels;

    FactorOutputType output;


    KronosConfig config;
    // init
    int64_t m_num_ticks = 0;
    double m_ewma_mid = 0.0;
    double m_ewma_spread = 0.0;
    double m_ewma_var = 0.0;
    // sigma
    GaiaCircularBuffer<double> m_theo_buffer;
    double m_sigma_factor_take;
    double m_sigma_factor_join;
    double m_sigma_factor_improve;
    //
    double m_volume = 0.0;
    double m_ewma_volume = 0.0;
    double m_volume_ewma = 0.0;
    //
    int64_t m_prev_exch_ts = 0;
    int64_t m_current_exch_ts = 0;
    int64_t m_prev_recv_ts = 0;
    int64_t m_current_recv_ts = 0;
    //
    double m_prc_tick_size = 0.0;
    double m_qty_tick_size = 0.0;

    KronosImpl(){}

    void Init(const Config& _conf)
    {
        version = "kronos_1.0.0";

        std::cout << "init Kronos config" << std::endl;
        auto conf = _conf.Get<Config>("order_logic_config");

        // read config

        // theo
        config.theo_gamma = GaiaUtils::GetParam<double>(conf, "theo_gamma");
        config.theo_alpha = GaiaUtils::GetParam<double>(conf, "theo_alpha");
        config.theo_gamma2 = GaiaUtils::GetParam<double>(conf, "theo_gamma2");
        config.theo_alpha2 = GaiaUtils::GetParam<double>(conf, "theo_alpha2");

        // price
        config.mid_ewma = GaiaUtils::GetParam<double>(conf, "mid_ewma");
        config.var_ewma = GaiaUtils::GetParam<double>(conf, "var_ewma");
    
        // sigma
        config.theo_buffer_len = GaiaUtils::GetParam<int64_t>(conf, "theo_buffer_len");
        config.init_var = GaiaUtils::GetParam<double>(conf, "init_var");
        config.use_sigma_adj = GaiaUtils::GetParam<int64_t>(conf, "use_sigma_adj") == 0 ? false : true;
        config.sigma_alpha = GaiaUtils::GetParam<double>(conf, "sigma_alpha");
        config.sigma_beta = GaiaUtils::GetParam<double>(conf, "sigma_beta");
        config.sigma_base = GaiaUtils::GetParam<double>(conf, "sigma_base");

        // pred
        config.signal_floor = GaiaUtils::GetParam<double>(conf, "signal_floor");
        config.pred_beta = GaiaUtils::GetParam<double>(conf, "pred_beta");
        config.pred_alpha = GaiaUtils::GetParam<double>(conf, "pred_alpha");
        config.pred_base = GaiaUtils::GetParam<double>(conf, "pred_base");
    
        // frac_cut
        config.frac_cut = GaiaUtils::GetParam<double>(conf, "frac_cut");
        
        // cancel
        config.minimum_edge_bps = GaiaUtils::GetParam<double>(conf, "minimum_edge_bps");
        config.minimum_edge = GaiaUtils::GetParam<double>(conf, "minimum_edge");
        config.quote_range_bps = GaiaUtils::GetParam<double>(conf, "quote_range_bps");
        config.quote_range_ticks = GaiaUtils::GetParam<int64_t>(conf, "quote_range_ticks");
        config.edge_lower_bound = GaiaUtils::GetParam<double>(conf, "edge_lower_bound");
        config.use_queue_cancel = GaiaUtils::GetParam<int64_t>(conf, "use_queue_cancel") == 0 ? false : true;
        config.queue_cancel_levels = GaiaUtils::GetParam<int64_t>(conf, "queue_cancel_levels");
        config.queue_cancel_max_amount = GaiaUtils::GetParam<double>(conf, "queue_cancel_max_amount");
        
        // pos pen
        config.pos_pen_intercept = GaiaUtils::GetParam<double>(conf, "pos_pen_intercept");
        config.pos_pen_coef = GaiaUtils::GetParam<double>(conf, "pos_pen_coef");
        config.pos_pen_lower_bound = GaiaUtils::GetParam<double>(conf, "pos_pen_lower_bound");
        config.pos_pen_one_side_target = GaiaUtils::GetParam<double>(conf, "pos_pen_one_side_target");
    
        // spread
        config.use_spread_filter = GaiaUtils::GetParam<int64_t>(conf, "use_spread_filter") == 0 ? false : true;
    
        // improve
        config.improve_tick = GaiaUtils::GetParam<int64_t>(conf, "improve_tick");
        config.improve_spread_ratio = GaiaUtils::GetParam<double>(conf, "improve_spread_ratio");

        //
        config.to_output_logs = GaiaUtils::GetParam<int64_t>(conf, "to_output_logs") == 0 ? false : true;
        m_theo_buffer.setSize(config.theo_buffer_len, 0.0);
    };


    bool RiskCheck(StrategyFields &strategy_fields)
    {

        return true;
    }

    void Process(TickEventType _cur_tick_type, const SymId &_cur_tick_sid, StrategyFields &strategy_fields)
    {
        // get book&trade information
        ContractInfo* &main_contract  = strategy_fields.contract_info;
        auto &trade = main_contract->trade;
        // get book&trade information
        double best_bid_price = GaiaUtils::BookGetBestBidPrice(main_contract);
        double best_ask_price = GaiaUtils::BookGetBestAskPrice(main_contract);
        double best_bid_qty = GaiaUtils::BookGetBestBidSize(main_contract);
        double best_ask_qty = GaiaUtils::BookGetBestAskSize(main_contract);
        Side trade_side = trade.side;
        double trade_price = trade.price;
        double trade_qty = trade.qty;
        double mid_price = (best_bid_price + best_ask_price)/2.0;
        double spread = best_ask_price - best_bid_price;
        m_prc_tick_size = main_contract->symbol_info->prc_tick_size;
        m_qty_tick_size = main_contract->symbol_info->qty_tick_size;

        // first tick
        if (std::abs(m_num_ticks) < MinErr) {
            std::cout << "SANITY CHECK: first tick !!!" << std::endl;
            m_ewma_mid = mid_price;
            m_ewma_spread = spread;
        }

        double theo = computeGATheo(best_bid_price, best_ask_price, best_bid_qty, best_ask_qty, trade_price);
        
        // sigma
        if (m_theo_buffer.isFull() != false){
            m_theo_buffer.push(theo);
            double theo_diff = theo - m_theo_buffer[0];
            m_ewma_var = (1.0 - config.var_ewma)*theo_diff*theo_diff + config.var_ewma*m_ewma_var;
        }
        else {
            m_theo_buffer.push(theo);
            m_ewma_var = config.init_var;
        }
        double sigma = std::sqrt(m_ewma_var / config.theo_buffer_len) / m_prc_tick_size;
        double sigma_adj = std::exp(config.sigma_alpha * sigma );
        double sigma_factor = config.sigma_beta * sigma_adj + config.sigma_base;

        // pred
        double pred_value = strategy_fields.signal.pred_value;
        double theo_pred = theo * (1.0 + config.pred_beta*pred_value/ONE_BASE_POINT);

        // 
        double quote_qty = strategy_fields.order_size_coin/main_contract->symbol_info->multiplier;
        double net_pos = strategy_fields.sym_risk.symbol_risk/main_contract->symbol_info->multiplier;
        double max_pos = strategy_fields.max_pos_coin/main_contract->symbol_info->multiplier;

        // process existing orders 
        double buy_order_total_count = 0.0;
        double sell_order_total_count = 0.0;
        double buy_order_count = 0.0;
        double sell_order_count = 0.0;
        processExistingOrders(strategy_fields, buy_order_total_count, sell_order_total_count, 
            buy_order_count, sell_order_count, 
            theo_pred);

        // main logic
        double minimum_edge = config.minimum_edge_bps/ONE_BASE_POINT*theo + config.minimum_edge;
        bool is_improve = spread > m_prc_tick_size + MinErr;
        double improve_spread = config.improve_spread_ratio*spread + config.improve_tick*m_prc_tick_size;

        // buy
        // position penalty
        double pos_pen = config.pos_pen_intercept + config.pos_pen_coef*(-config.pos_pen_one_side_target + buy_order_count + net_pos);
        double pos_scaler = std::max(config.pos_pen_lower_bound, pos_pen); 

        // buy
        bool pred_filter_buy = pred_value > config.signal_floor;
        if (pred_filter_buy){
        double buy_price = best_bid_price + improve_spread;
            buy_price = std::min(buy_price, best_ask_price - m_prc_tick_size);
            double buy_edge = theo_pred - buy_price;
            bool buy_edge_cond = buy_edge > sigma_factor*pos_scaler*minimum_edge;
            if (is_improve && buy_edge_cond){
                double q_pos = best_bid_qty;
                Buy(strategy_fields, buy_price, quote_qty, buy_order_total_count, net_pos, max_pos, q_pos, TimeInForce::PO, 1);
            }
        }

        // sell
        pos_pen = config.pos_pen_intercept + config.pos_pen_coef*(-config.pos_pen_one_side_target + sell_order_count - net_pos);
        pos_scaler = std::max(config.pos_pen_lower_bound, pos_pen);
        bool pred_filter_sell =  pred_value < -config.signal_floor;
        if (pred_filter_sell){
            double sell_price = best_ask_price - improve_spread;
            sell_price = std::max(sell_price, best_bid_price + m_prc_tick_size);
            double sell_edge = sell_price - theo_pred;
            bool sell_edge_cond = sell_edge > sigma_factor*pos_scaler*minimum_edge;
            if (is_improve && sell_edge_cond){
                double q_pos = best_ask_qty;
                Sell(strategy_fields, sell_price, quote_qty, sell_order_total_count, net_pos, max_pos, q_pos, TimeInForce::PO, 1);
            }
        }
        

        m_prev_recv_ts = m_current_recv_ts;
        m_prev_exch_ts = m_current_recv_ts;
        m_num_ticks += 1;
        if (config.to_output_logs){
            output.clear();
            output["_cur_tick_type"] = _cur_tick_type;
            output["_cur_tick_sid"] = _cur_tick_sid;
            output["best_bid_price"] = best_bid_price;
            output["best_ask_price"] = best_ask_price;
            auto cur_contract_info = (*strategy_fields.sid_contract_map)[strategy_fields.cur_tick_sid];
            LOG_AUTO(KronosFactorMsg, output, main_contract->symbol_info->mirana_ticker.c_str(),
                                        cur_contract_info->latency_record.mkt_data.mkt_recv_ts,
                                        cur_contract_info->latency_record.mkt_data.mkt_exch_ts);
        }
    }



    void processExistingOrders(StrategyFields& strategy_fields, 
                                double &buy_order_total_count, double &sell_order_total_count, double &buy_order_count, double &sell_order_count, 
                                double &theo_pred)
    {
        ContractInfo* &main_contract  = strategy_fields.contract_info;
        double best_bid_price = GaiaUtils::BookGetBestBidPrice(main_contract);
        double best_ask_price = GaiaUtils::BookGetBestAskPrice(main_contract);
        double quote_range = config.quote_range_bps/ONE_BASE_POINT*theo_pred + config.quote_range_ticks*m_prc_tick_size;
        for(auto orderStateIter : strategy_fields.order_state_map)
        {
            auto &orderState = orderStateIter.second;
            double order_price = orderState->ts_order->price();
            double order_qty = orderState->ts_order->qty();
            if(orderState->ts_order->side() == Side::BUY){
                buy_order_total_count += order_qty;
                double order_distance = order_price - best_bid_price;
                bool distance_cond = order_price > best_bid_price - quote_range;
                bool edge_cond = theo_pred - order_price > config.edge_lower_bound;
                bool queue_front_cond = true;
                if (config.use_queue_cancel){
                    double bid_queue_front = 0.0;
                    for (int i = 0; i < config.queue_cancel_levels; i++){
                        double this_price = main_contract->alphaBook->bid(i).price;
                        double this_qty = main_contract->alphaBook->bid(i).qty;
                        if (this_price > order_price + MinErr){
                            bid_queue_front += this_price*this_qty;
                        }
                        else {
                            break;
                        }
                    }
                    queue_front_cond = bid_queue_front < config.queue_cancel_max_amount;
                }
                if (!distance_cond || !edge_cond || !queue_front_cond){
                    GOrderOp::CancelOrder(orderState);
                }
                else {
                    buy_order_count += order_qty;
                }
            }
            else if (orderState->ts_order->side() == Side::SELL){
                sell_order_total_count += order_qty;
                bool distance_cond = order_price < best_ask_price + quote_range;
                bool edge_cond = order_price - theo_pred > config.edge_lower_bound;
                bool queue_front_cond = true;
                if (config.use_queue_cancel){
                    double ask_queue_front = 0.0;
                    for (int i = 0; i < config.queue_cancel_levels; i++){
                        double this_price = main_contract->alphaBook->ask(i).price;
                        double this_qty = main_contract->alphaBook->ask(i).qty;
                        if (this_price < order_price - MinErr){
                            ask_queue_front += this_price*this_qty;
                        }
                        else {
                            break;
                        }
                    }
                    queue_front_cond = ask_queue_front < config.queue_cancel_max_amount;
                }
                if (!distance_cond || !edge_cond || !queue_front_cond){
                    GOrderOp::CancelOrder(orderState);
                }
                else {
                    sell_order_count += order_qty;
                }
            }
        }
    }


    void Buy(StrategyFields& strategy_fields, double &price, double &qty, double &buyOrderTotalCount, double &cur_pos_coin, double &max_pos, double &q_pos, TimeInForce tif, double order_type)
    {
        ContractInfo* &main_contract  = strategy_fields.contract_info;
        double buy_total_risk = buyOrderTotalCount + cur_pos_coin;
        if (buy_total_risk <= max_pos){
            price = roundTickSize(price, main_contract->symbol_info->prc_tick_size);
            qty = roundTickSize(qty, main_contract->symbol_info->qty_tick_size);
            qty = std::max(qty, m_qty_tick_size);
            GOrderState* new_order_state = GOrderOp::InsertOrder(strategy_fields, price, qty, Side::BUY, OrderType::LIMIT, tif);
            new_order_state->queue_front_pos = q_pos;

        }
    }

    void Sell(StrategyFields& strategy_fields, double &price, double &qty, double &sellOrderTotalCount, double &cur_pos_coin, double &max_pos, double &q_pos, TimeInForce tif, double order_type)
    {
        ContractInfo* &main_contract  = strategy_fields.contract_info;
        double sell_total_risk = sellOrderTotalCount - cur_pos_coin;
        if (sell_total_risk <= max_pos){
            price = roundTickSize(price, main_contract->symbol_info->prc_tick_size);
            qty = roundTickSize(qty, main_contract->symbol_info->qty_tick_size);
            qty = std::max(qty, m_qty_tick_size);
            GOrderState* new_order_state = GOrderOp::InsertOrder(strategy_fields, price, qty, Side::SELL, OrderType::LIMIT, tif);
            new_order_state->queue_front_pos = q_pos;

        }
    }

    double roundTickSize(double input, double tick_size) {
        double rounded_input = std::round(input / tick_size) * tick_size;
        return rounded_input;
    }

    double computeGATheo(double best_bid_price, double best_ask_price, double best_bid_qty, double best_ask_qty,  double trade_price)
    {
        double bid_qty = best_bid_qty;
        double ask_qty = best_ask_qty;
        double alpha = config.theo_alpha;
        if (bid_qty > MinErr && ask_qty > MinErr){
            if (best_ask_price - best_bid_price > m_prc_tick_size + MinErr){
                bid_qty = std::pow(best_bid_qty, config.theo_gamma2);
                ask_qty = std::pow(best_ask_qty, config.theo_gamma2);
                alpha = config.theo_alpha2;
            }
            else {
                bid_qty = std::pow(best_bid_qty, config.theo_gamma);
                ask_qty = std::pow(best_ask_qty, config.theo_gamma);
            }
        }
        double theo = (1.0 - alpha)*(bid_qty*best_ask_price + ask_qty*best_bid_price)/(bid_qty + ask_qty) + alpha*trade_price;
        return theo;
    }


    void updateQueueFront(GOrderState* order_state, Side &trade_side, double trade_price, double trade_qty, double best_bid_price, double best_ask_price, double best_bid_qty, double best_ask_qty){
        if (std::abs(order_state->queue_front_pos) < MinErr ){
            return;
        }
        double limit_price = order_state->ts_order->price();
        // buy
        if (order_state->ts_order->side() == Side::BUY){
            // trade_price cross limit_price
            if (trade_price < limit_price - MinErr && trade_side == Side::SELL){
                order_state->queue_front_pos = 0.0;
            }
            // best_bid_price cross limit_price
            else if (best_bid_price < limit_price - MinErr){
                order_state->queue_front_pos = 0.0;
            }
            // limit_price == bid
            else if (std::abs(limit_price - best_bid_price) < MinErr){
                if (trade_side == Side::BUY){
                    trade_qty = 0.0;
                }
                order_state->queue_front_pos = std::max(order_state->queue_front_pos - trade_qty, 0.0);
                order_state->queue_front_pos = std::min(order_state->queue_front_pos, best_bid_qty);
            }
        }
        // sell
        else if (order_state->ts_order->side() == Side::SELL){
            if (trade_price > limit_price + MinErr && trade_side == Side::BUY){
                order_state->queue_front_pos = 0.0;
            }
            else if (best_bid_price > limit_price + MinErr){
                order_state->queue_front_pos = 0.0;
            }
            else if (std::abs(limit_price - best_bid_price) < MinErr){
                if (trade_side == Side::SELL){
                    trade_qty = 0.0;
                }
                order_state->queue_front_pos = std::max(order_state->queue_front_pos - trade_qty, 0.0);
                order_state->queue_front_pos = std::min(order_state->queue_front_pos, best_ask_qty);
            }
        }
    }
    };
