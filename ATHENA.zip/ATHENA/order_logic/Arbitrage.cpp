#include "OrderLogicDef.h"
#include "ArbitrageImpl.h"

STANDARD_ORDER_LOGIC_DEFINITION(Arbitrage, ArbitrageImpl)
