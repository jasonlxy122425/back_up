import pickle
from Default.KronosConfig import *
from Default.DefaultCommonConfig import *

@config_interface
class TagConfig():
    def __init__(self):
        self.configs = []

    def genFactors(self, factor_path):
        with open(factor_path , 'rb') as file:
            factors = pickle.load(file)
        return factors

    def generateParams(self, sim_params, stra_params):
        config = KronosConfig("make")
        config.num_of_book_levels = 25

        # predictor log
        config.predictorConfig.demeter_sample_num = stra_params["demeter_sample_size"]
        config.predictorConfig.factor_path  = stra_params["factor_path"]
        config.predictorConfig.model_path = stra_params["model_path"]
        if stra_params["to_generate_factors"]:
            config.predictorConfig.factors = self.genFactors(config.predictorConfig.factor_path)
        else:
            config.predictorConfig.factors = []

        # orderlogic log
        for key, value in stra_params.items():
            print(key, value)
            setattr(config.orderLogicConfig, key, value)
        sim_output_engine = "parquet"
        if stra_params["to_output_gob"] is None:
            sim_output_engine = None
        # sim 
        config.set_sim(mode = 'SIM',
                    start_date = sim_params["start_date"],
                    end_date = sim_params["end_date"],
                    sign_str = sim_params["sign_str"],
                    target_server =  sim_params["target_server"],
                    target_path = "/home/master/Data/md_dump/",
                    sim_engine = 'alphaless',
                    use_ts_log = True,
                    sim_output_engine = sim_output_engine,
                    sim_output_target = './gaia_orderbook.parquet',
                    sim_output_factors = stra_params["to_output_factors"],
                    sim_output_sample_count = stra_params["output_sample_size"],

                    )
        config.simConfig.set_sim_fee(sim_params["target_exchange"], {'taker': sim_params["taker"], 'maker': sim_params["maker"]})

        config.simConfig.set_sim_latency(sim_params["target_exchange"], "all", {'req_insert_order': sim_params["insert_latency"]})

        config.simConfig.set_sim_order(sim_params["target_exchange"], "all", {'cancel_front_ratio': 0.0,
                                                                              'taker_cross_decay_ratio': 0.0,
                                                                              'trade_cross_policy': 'eq_price_qty', #eq_price_qty,all_qty,better_price_all,better_price_qty
                                                                              'bbo_cross_policy': 'none',   #eq_price_qty,better_price_all,better_price_qty
                                                                              'use_fill_latency_hint': True,
                                                                              'fill_latency_lead': '0ms',
                                                                              'min_fill_latency': '0ms',
                                                                              'max_fill_latency': '0ms'})
        config.setSymbol(sim_params["target_instrument"])
        return config 

    def getConfig(self):
        sim_params = {
            "start_date": '20250213',
            "end_date": '20250213',
            "target_exchange": f"Bybit",
            "target_instrument": f"Bybit_Spot_BTCUSDT",
            "target_server": "sgp-kronos-prod-md-az2-01",
            "insert_latency": "1ms",
            "maker": -0.000075,
            "taker": 0.00015,
        }
        stra_params = {
            "to_generate_factors": True,
            "to_output_factors": True,
            "to_output_gob": False,
            "demeter_sample_size": 10,
            "output_sample_size": 10,
            "factor_path": "/mnt/share/jsc/config/pred/by_sp_btc_mrt=1s_sample=10/factors.txt",
            "model_path": "/mnt/share/jsc/config/pred/by_sp_btc_mrt=1s_sample=10/lgb_model.txt",
            "stop_loss": -10000000,
            "mkt_timeout_ns": 3000000000,
            "notional_size": 300,
            "max_pos_in_clips": 1,
            "quote_qty": 0.001,
            "theo_alpha": 0.0,
            "theo_gamma": 1.0,
            "init_var":0.0,
            "var_ewma":0.95,
            "theo_buffer_len": 30,
            "sigma_alpha": 0.0,
            "sigma_beta": 1.0,
            "sigma_base": 0.0,
            "pos_pen_intercept": 1.0,
            "pos_pen_coef": 0.0,
            "pos_pen_lowerbound": 0.0,
            "quote_range":100,
            "queue_front_cancel":100000,
            "min_edge_cancel":0.0,
            "min_edge_bps":0.5,
            "min_edge":0.0,
            "signal_floor":0.2,
            "improve_tick_num":0,
            "improve_spread_ratio": 0.1,
            "is_tif_po": 1,
        }
        for i in [0.2, 0.3]:
            for j in [0.0]:
                stra_params["signal_floor"]  = i
                stra_params["improve_spread_ratio"] = j
                sim_params["sign_str"] = "{}_{}".format(i, j)
                config = self.generateParams(sim_params, stra_params)
                self.configs.append(config)
        return self.configs
