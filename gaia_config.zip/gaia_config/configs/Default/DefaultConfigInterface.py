from Default.DefaultSimConfig import *
from Default.DefaultCommonConfig import *

## default config for all strategies
def add_default_config(cls):
    def set_server(self,server, ip = "", ts = -1):
        self.machineName = server
        self.machineIp = ip
        self.ts = ts
        self.log_path = f"/mnt/share/data/realtime_logs/strategy/{self.machineName}"

    def set_hedger_server(self,server, ip, ts = -1):
        self.hedgerMachineName = server
        self.hedgerMachineIp = ip
        self.hedgerTs = ts
    
    def set_logic_acct(self, logic_acct_id, logic_acct_str):
        self.logicAcctId = logic_acct_id
        self.logicAcctStr = logic_acct_str
        quoter_coin = "_".join(self.quoter_symbol.split('_')[2:])
        self.strategy_name = f"{self.order_logic}_{quoter_coin}_{self.logicAcctId}"

    def set_hedger_logic_acct(self, logic_acct_id, logic_acct_str):
        self.hedgerLogicAcctId = logic_acct_id
        self.hedgerLogicAcctStr = logic_acct_str
        self.hedgerConfig.hedger_logic_acct_id = logic_acct_id

    def set_sim(self,mode : str, start_date : str, end_date : str, sign_str : str = "0", sign : dict = {},
                target_server : str = "", target_path : str = "", sim_engine : str = "as",
                use_ts_log : bool = False,
                # sim_use_exch_ts : bool = True,
                sim_configs : dict = {"sim_use_exch_ts":True},
                sim_output_engine : str = None,
                sim_output_target : str = None,
                sim_output_orderbook : bool = True,
                sim_output_demeter : bool = True,
                sim_output_factors : bool = False,
                sim_output_sample_count : int = 0,
                sim_output_config : dict = {
                    "sim_output_sample_count": 0,
                    "sim_output_demeter": True,
                    "sim_output_orderbook": True,
                    "sim_output_factors": False,
                    "sim_output_origin_quote": True,
                    "sim_output_latency": True,
                    "sim_output_ob_l1": True,
                }
                ):
        self.mode = mode
        self.start_date = start_date
        self.end_date = end_date
        self.target_server = target_server
        self.target_path = target_path
        self.sign_str = sign_str
        self.sign = sign

        if sim_output_engine is not None:
            self.sim_output_engine = sim_output_engine
            self.sim_output_target = sim_output_target
            self.sim_output_orderbook = sim_output_orderbook
            self.sim_output_demeter = sim_output_demeter
            self.sim_output_factors = sim_output_factors
            self.sim_output_sample_count = sim_output_sample_count

            for key, value in sim_output_config.items():
                print(key,value)
                setattr(self, key, value)


        self.mode = 'SIM'
        self.use_ts_log = use_ts_log
        self.simConfig = SimConfig(sim_engine, sim_configs)


    def build(self):
        if self.mode == 'SIM':
            self.set_logic_acct(1,"1")
            self.set_server("sim")
            self.log_path = "./"
            quoter_coin = "_".join(self.quoter_symbol.split('_')[2:])
            self.strategy_name = f"{self.order_logic}_{quoter_coin}_{self.logicAcctId}"
            if hasattr(self, "hedger_symbol"):
                self.set_hedger_logic_acct(2,"2")
                self.set_hedger_server("hedger_sim", "1.1.1.1")
                self.simConfig.initSimConfig(self.start_date, self.end_date, self.target_server, self.quoter_symbol, self.hedger_symbol)
            else:
                self.simConfig.initSimConfig(self.start_date, self.end_date, self.target_server, self.quoter_symbol)
        return self
    
    


    cls.set_server = set_server
    cls.set_logic_acct = set_logic_acct
    cls.set_hedger_logic_acct = set_hedger_logic_acct
    cls.set_hedger_server = set_hedger_server
    cls.set_sim = set_sim
    cls.build = build

    origin_init = cls.__init__

    def new_init(self, *args, **kwargs):
        self.commonConfig = CommonConfig()
        self.orderLogicCommonConfig = OrderLogicCommonConfig()
        self.cpu = -1
        self.algo_name = ""
        self.algo_id = 0
        self.algo_id_2 = 0
        self.use_microwave = False
        self.use_udp = False
        self.mode = 'PROD'
        self.use_48bits_order_id = False
        self.max_qry_order_count = 3

        self.need_run = True

        self.num_of_book_levels = 100
        self.leverage = 7

        origin_init(self, *args, **kwargs)


 
    
    cls.__init__ = new_init

    
    origin_set_symbol = cls.setSymbol
    def set_symbol(self, quoter_symbol, hedger_symbol = None):
        self.quoter_symbol = quoter_symbol
        self.quoter_exchange = quoter_symbol.split("_")[0]
        if hedger_symbol is not None:
            origin_set_symbol(self, quoter_symbol, hedger_symbol)
            self.hedger_symbol = hedger_symbol
            self.hedger_exchange = hedger_symbol.split("_")[0]
        else:
            origin_set_symbol(self, quoter_symbol)

        if hasattr(self, "reference_symbols") == False:
            print(f"{self} does not have attribute: reference_symbols")
            exit(0)

    cls.setSymbol = set_symbol
    return cls

def config_interface(cls):
    origin_getConfig = cls.getConfig
    def get_config(self):
        configs = origin_getConfig(self)
        for config in configs:
            config.build()
        return configs

    cls.getConfig = get_config
    return cls
