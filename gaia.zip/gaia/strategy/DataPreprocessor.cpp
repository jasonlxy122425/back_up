#include "DataPreprocessor.h"
#include "DataPreprocessorImpl.h"
#include <iostream>

PreprocessorCenter::PreprocessorCenter(const std::vector<Config>& config) {
    for (auto& preprocessor_config : config) {
        std::string name = preprocessor_config.Get<std::string>("name");
        std::unique_ptr<DataPreprocessorInterface> preprocessor = DataPreprocessorFactory::Create(name);
        std::cout << "Preprocessor: " << name << std::endl;
        if (preprocessor == nullptr) {
            std::cerr << "Preprocessor not found: " << name << std::endl;
            abort();
        }
        preprocessor->Init(preprocessor_config);
        AddPreprocessor(std::move(preprocessor));
    }
}

void PreprocessorCenter::Process(ContractInfo* contract, const TickEventType& cur_tick_type,
                                                   GLatencyRecord* latency_record) {
    
    for (auto& preprocessor : preprocessors_) {
        preprocessor->Process(contract, cur_tick_type, latency_record, &result_);
    }
}

std::unique_ptr<DataPreprocessorInterface> PreprocessorCenter::DataPreprocessorFactory::Create(const std::string& name) {
    if (name == "TradeFilterPreprocessor") {
        return std::make_unique<TradeFilterPreprocessor>();
    }

    return nullptr;
}
