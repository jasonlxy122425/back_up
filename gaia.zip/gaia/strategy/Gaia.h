#pragma once
#include "StrategyFields.h"
#include "Hedger.h"
#include "ContractInfo.h"
#include "GaiaUtils.h"
#include "Predictor.h"
#include "OrderLogic.h"
#include "OrderLogicFactory.h"
#include "PredictorFactory.h"
#include "SyntheticFillAuditor.h"
#include "SpdLoggerMessage.h"
#include "SpdLogger.h"
#include "FileWatcher.h"
#include "TradeIdFilter.h"
#include "DemeterDataManager.h"
#include "GaiaPosMonitor.h"
#include "GAssistCalculator.h"
#include "DataPreprocessor.h"
#ifdef OUTPUT_DATA
#include "utils/data_writer.h"
#endif
#include <set>


struct CommonConfig 
{
    bool useSyntheticFill = false;
    bool useBalanceLimitMode = false;
    bool useQryPosResult = true;
    bool useBatchMode = false;
    bool useQryPosMonitor = false;
    bool useFullLiqInRiskExitMode = false;
    bool isMarginTrading = false;

    bool useOrderbook = true;
    bool useBestquote = true;
    bool useTrade = true;
    bool useLiquidation = true;
    bool useFundingrate = true;
    bool useKline = true;
    bool useDmmTrade = true;
    bool useWarmUp = false;
    GAssistCalculator::TradeMode predictor_trade_mode = GAssistCalculator::TradeMode::HYBRID;

    bool useInitialPosCoin = false;
    std::unordered_map<SymId, double> initial_pos_coin_map;
};

class Gaia : public trading_system_st::Strategy
{
public:

    Gaia(std::string _config_path);

    void setNumBookLevels(int num) { ob_manager_.set_num_book_levels(num); }

    Hedger* getHedger() {
        return hedger;
    }

    std::string getHedgerSymbol() {
        return hedger_symbol_;
    }

    std::vector<SymId> GetUniverse() override
    {
        // use this function to declare the symbols you want to subscribe,
        // you can also use Strategy::Subscribe and Strategy::Unsubscribe to
        // manage subscriptions dynamically

        return univ;
    }

    void OnInitialize(const Config &config) override;
    void OnReconDone(const ReconState &recon) override;
    void OnReady() override;
    void OnDisconnect() override;
    void OnNewTradingDay() override;
    void OnQryBalance(const trading_system_ts::RespQryBalance &balance) override;
    void OnQryPosition(const trading_system_ts::RespQryPosition &position) override;
    void OnQryOpenOrder(const RespQryOpenOrder &order);
    void OnPositionUpdate(const trading_system_ts::PositionUpdate &position) override;
    void OnFundingRate(const md::FundingRate &fr) override;


    void OnTrade(const md::Trade &trade) override;
    void OnOrderbook(const md::FlatOrderbook &ob) override;
    void OnBestQuote(const md::BestQuote &quote) override;
    void OnLiquidation(const md::Liquidation &liquidation) override;
    void OnKline(const md::Kline &kline) override;

    void OnUnknownFill(const Order *order, const OrderFill &fill) override;
    void OnOrderUpdate(Order *order, const OrderStatusUpdate &update);

    void OnUserMsg(const uint8_t *data, size_t size) override;
    void OnSignalUpdate(const SignalStruct &signal);

    void OnIdle() override;
    void OnMdBatch(const std::vector<const md::Message *> &) override;

    // other supported trade server calbacks:
    // void OnStart() override {}
    /* void OnQryBalance(const trading_system_ts::RespQryBalance &) override {} */
    /* void OnQryWallet(const trading_system_ts::RespQryWallet &) override {} */
    /* void OnQryOpenOrder(const RespQryOpenOrder &) override {} */
    /* void OnQryPosition(const trading_system_ts::RespQryPosition &) override {} */
    /* void OnQryLogicAcctOpenOrder(const RespQryOpenOrder &) override {} */
    /* void OnQryLogicAcctPosition(const trading_system_ts::RespQryLogicAcctPosition &) override {} */
    /* void OnPositionUpdate(const trading_system_ts::PositionUpdate &position) override {}  */
    /* void OnBalanceUpdate(const trading_system_ts::BalanceUpdate &balance) override; */


    /* void OnMdStatusUpdate(const md::StatusUpdate &status) override; */
    /* void OnUserCustom(const trading_system_ts::RespTsUserCustom &) override {} */
    /* void OnUserCustom(const trading_system_ts::RespExchUserCustom &) override {} */

private:
    constexpr static int64_t WARMUP_INTERVAL = 5 * NS_PER_SEC;
#ifdef OUTPUT_DATA
    std::shared_ptr<DataWriter> data_writer;
#endif
    void SampleDemeter(Nanoseconds &now);
    int quoter_logic_acct_id;
    SymId quoter_sid_;
    std::string tag_;
    std::string sub_tag_;
    std::string quoter_symbol_;
    std::string hedger_symbol_;
    std::string quoter_machine_name;


    std::unique_ptr<Predictor> predictor_;
    std::unique_ptr<GAssistCalculator> assist_calculator_;
    std::unique_ptr<PreprocessorCenter> data_preprocessor_;

    std::string order_logic_code;
    std::unique_ptr<OrderLogic> order_logic;

    phmap::flat_hash_set<SymId> main_sids_;
    phmap::flat_hash_set<SymId> assist_sids_;
    std::set<std::string> subscribes_;
    std::set<std::string> assist_subscribes_;
    std::vector<SymId> univ;

    // data structs
    GaiaOrderbookManager ob_manager_;
    std::shared_ptr<demeter::DemeterDataManager> demeter_data_manager_;

    int demeter_sample_num_;
    std::string demeter_sample_type_;

    Order::UpdateCb orderCb;

    // configs
    std::string config_path;
    FileWatcher config_file_watcher;
    FileWatcher::FileWatcherCb configCb;

    phmap::flat_hash_map<SymId, TradeIdFilter> trade_filter_map;

    // target / hedger
    StrategyFieldsMapType strategy_fieldsMap;
    StrategyFields        *quoter_strategy_fields_;
    Hedger                *hedger;

    // maps below has same content , but different key type for different use case
    ContractInfoMapType contract_map;
    SidContractInfoMapType sid_contract_map;
    phmap::flat_hash_map<SymId, md::Trade*> last_trades_in_batch_;

    int64_t last_force_exit_ts = 0;
    int64_t last_liquidation_ts = 0;
    int64_t last_warmup_ts = 0;

    int64_t last_log_snapshot_ts = 0;
    int64_t last_config_check_time = 0;
    int64_t last_qry_balance_ts = 0;
    int64_t last_qry_pos_ts = 0;


    bool allBooksPopulated = false;
    bool allTradePopulated = false;
    bool allBestQuotePopulated = false;
    bool hasReceivedAllPositionUpdate = false;
    bool connected_ = false;
    CommonConfig common_config;

    std::shared_ptr<GaiaPosMonitor> gaia_pos_monitor;

    void InitContractInfo(const std::string &s, bool is_main_contract = true);
    void InitDataPreprocessor(const std::vector<Config>& config);
    void updateStrategyConfig(const Config &config);
    void OnConfigChange(std::string config_file);
    void saveStrategySnapshot(int64_t &now);
    void scheduleTask(int64_t &now);
    void checkQryPos(int64_t &now);

    void qryPosition();

    G_INLINE bool checkBookAndPosStatus();
    G_INLINE void StrategyStatusChange();
    G_INLINE void StrategyProcess(ContractInfo *&cur_contract, const TickEventType &cur_tick_type, const SymId &cur_tick_sid);
    G_INLINE void RiskCheck();
    G_INLINE void CalcPred(ContractInfo *&cur_contract, const TickEventType &_cur_tick_type);
    G_INLINE void CalcOrderLogic(ContractInfo *&cur_contract, const TickEventType &_cur_tick_type);
    void CalcAssist(ContractInfo *&cur_contract, const TickEventType &_cur_tick_type);


    void HedgingLogic(StrategyFields &strategy_fields, GOrderState *orderState, const std::string &tradeId,
                    const double &quoterFilledPrice, const double &quoterFilledSize, const int8_t &quoterFilledSideInt,
                    const double &quoterFilledFees);
    void FullLiquidation();
    void LiquidationRisk();
    void StrategyForceExit();
    void RiskExit();
    void DisconnectLogic();

    bool hasQuoterInflightOrder();
    bool hasHedgerInflightOrder();

    void WarmUp(int64_t &now, bool force = false);
};
