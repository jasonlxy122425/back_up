#pragma once

#include "StrategyFields.h"
#include "GOrderOp.h"
#include "GaiaUtils.h"

struct OrderLogicCommonConfig {
    double notional_size;
    double custom_coin_size;
    double stop_loss;
    int64_t stop_loss_duration;
    bool    stop_loss_use_unrealized;
    bool    stop_loss_use_drawdown;

    int32_t max_pos_in_clips;

    bool   use_full_liquidation;
    bool   use_market_order_for_liq;
    bool   use_reduceonly_for_liq;

    double liquidate_take_bp;
    double liquidate_max_notional;
    double liquidate_min_notional;

    bool    use_reduce_only_mode;
    bool    use_balance_limit_mode;
    int64_t balance_limit_recovery_sec;

    bool    use_fr_check;
    int64_t reduce_only_minute_before_fr;
    int64_t reduce_only_minute_after_fr;
    double  reduce_only_param_multi;

    int64_t rate_limit_duration_ms;
    int64_t mkt_timeout_ns;
};

class OrderLogic
{
public:
    OrderLogic(){}
    void InitLogic(const Config& _config);
    void ProcessBeforeRiskCheck(StrategyFields &strategy_fields);

    G_INLINE void ProcessLogic(TickEventType _cur_tick_type, StrategyFields &strategy_fields)
    {
        this->Process(_cur_tick_type, strategy_fields.cur_tick_sid, strategy_fields);
    }

    void FullLiquidation(StrategyFields &strategy_fields);

    bool fullLiquidateSingleStrategy(StrategyFields &strategy_fields);

    virtual void Init(const Config& config) = 0;
    void RiskCheckLogic(StrategyFields&);
    virtual void Process(TickEventType _cur_tick_type, const SymId &_cur_tick_sid, StrategyFields &strategy_fields) = 0;
    virtual void Warmup(StrategyFields &strategy_fields) {
        // default warmup logic
        GOrderOp::InsertOrder(strategy_fields, 0, 0, Side::BUY, OrderType::LIMIT, TimeInForce::IOC, PositionOffset::UNKNOWN, 0, true);
    };
    virtual Hedger* getHedger() { return nullptr; }

    virtual void LiquidateRisk(StrategyFields &strategy_fields, double &baseCoinSum);

    virtual void OnHedgeOrderUpdate(Order *order, const OrderStatusUpdate &update){};
    virtual void OnOrderAccepted(GOrderState* order_state){};
    virtual void OnOrderFilled(GOrderState* order_state){};
    virtual void OnOrderClosed(GOrderState* order_state){};

    virtual const OrderLogicCommonConfig& getCommonConfig() { return common_config; };
    virtual const std::string& getVersion() { return version; };
    void setCommonConfig(OrderLogicCommonConfig &_common_config) { common_config = _common_config;}
    void setStrategyFieldsMap(StrategyFieldsMapType &_strategy_fieldsMap) { strategy_fieldsMap = &_strategy_fieldsMap; }

    void CancelAllOnSide(struct StrategyFields &strategy_fields, bool cancelBid, bool cancelAsk);

protected:
    OrderLogicCommonConfig common_config;
    std::string version = "";
    StrategyFieldsMapType *strategy_fieldsMap;

    void adjustSizeFromNotional(StrategyFields &strategy_fields, const double &notional_size, double& size);

    void getInFlightCoin(StrategyFields &strategy_fields, double &bid_inflight_coin, double &ask_inflight_coin);

};

#define STANDARD_ORDER_LOGIC_DECLARATION(name) \
class name : public OrderLogic { \
public: \
    name(); \
    virtual ~name(); \
    virtual void Init(const Config& _conf) override; \
    virtual void Process(TickEventType _cur_tick_type, const SymId &_cur_tick_sid, StrategyFields &strategy_fields) override; \
    virtual void Warmup(StrategyFields &strategy_fields) override; \
    virtual void OnOrderAccepted(GOrderState* order_state) override; \
    virtual void OnOrderFilled(GOrderState* order_state) override; \
    virtual void OnOrderClosed(GOrderState* order_state) override; \
    virtual void OnHedgeOrderUpdate(Order *order, const OrderStatusUpdate &update) override; \
    virtual void LiquidateRisk(StrategyFields &strategy_fields, double &baseCoinSum) override; \
    virtual const OrderLogicCommonConfig& getCommonConfig() override; \
    virtual const std::string& getVersion() override; \
    virtual Hedger* getHedger() override; \
private: \
    OrderLogic *impl; \
};

#define STANDARD_ORDER_LOGIC_DEFINITION(name, impl_name) \
name::name() { \
    impl = new impl_name(); \
} \
name::~name() { \
    delete impl; \
} \
void name::Init(const Config& _conf) { \
    impl->setStrategyFieldsMap(*strategy_fieldsMap); \
    impl->setCommonConfig(common_config); \
    impl->Init(_conf); \
    version = impl->getVersion(); \
} \
const OrderLogicCommonConfig& name::getCommonConfig() { \
    return impl->getCommonConfig(); \
} \
const std::string& name::getVersion() { return impl->getVersion(); }; \
void name::Process(TickEventType _cur_tick_type, const SymId &_cur_tick_sid, StrategyFields &strategy_fields) { \
    impl->Process(_cur_tick_type, _cur_tick_sid, strategy_fields); \
} \
void name::Warmup(StrategyFields &strategy_fields) { \
    impl->Warmup(strategy_fields); \
} \
void name::OnOrderAccepted(GOrderState* order_state) { \
    impl->OnOrderAccepted(order_state); \
} \
void name::OnOrderFilled(GOrderState* order_state) { \
    impl->OnOrderFilled(order_state); \
} \
void name::OnOrderClosed(GOrderState* order_state) { \
    impl->OnOrderClosed(order_state); \
} \
void name::OnHedgeOrderUpdate(Order *order, const OrderStatusUpdate &update) { \
    impl->OnHedgeOrderUpdate(order, update); \
} \
void name::LiquidateRisk(StrategyFields &strategy_fields, double &baseCoinSum) { \
    impl->LiquidateRisk(strategy_fields, baseCoinSum); \
} \
Hedger* name::getHedger() { \
    return impl->getHedger(); \
};

