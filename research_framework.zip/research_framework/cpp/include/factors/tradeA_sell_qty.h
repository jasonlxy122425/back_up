#include "Factor.h"
#include "Ema.h"
#include <cmath>
#include "GaiaCircularBuffer.h"

class TradeASellQtyFactor : public FactorInterface
{
public:
    TradeASellQtyFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
        lookback = config.Get<int64_t>("lookback");
        qty_buffer.setSize(lookback, 0.0);

    };

    virtual std::string gen_name() {;
        return std::string("TradeASellQtyFactor") + "@lookback=" + std::to_string(lookback);
    }

    virtual void calculate(const FactorInput& input_data) {
        factor_value = 0.0;
        auto &trade = input_data.cur_contract->trade;
        exch_ts = trade.exch_ts;
        this_qty = trade.qty;
        if (trade.side == Side::SELL) {
            this_qty = -trade.qty;
        }

        double prev_qty = 0;
        if (exch_ts != prev_exch_ts) {
            if(qty_buffer.isFull()) {
                prev_qty = qty_buffer[0];
                if(prev_qty < -MinErr) {
                    qty_sum -= -prev_qty;
                }
            }

            if(this_qty < -MinErr) {
                qty_sum += -this_qty;
            }
            qty_buffer.push(this_qty);
        } else {
            double old_qty = qty_buffer[-1];
            double new_qty = old_qty + this_qty;
            if (old_qty < -MinErr) {
                qty_sum -= -old_qty;
            }
            if (new_qty < -MinErr) {
                qty_sum += -new_qty;
            }
            qty_buffer[-1] += this_qty;
        }


        if(qty_buffer.isFull()){
            factor_value = qty_sum;
        }
        prev_exch_ts = exch_ts;
    };

    // virtual void calculate(const FactorInput& input_data) {
    //     factor_value = 0.0;
    //     auto &trade = input_data.cur_contract->trade;
    //     int64_t exch_ts = trade.exch_ts;
    //     if (trade.side == Side::BUY){
    //         this_qty = trade.qty;
    //     }
    //     else if (trade.side == Side::SELL){
    //         this_qty = -trade.qty;
    //     }
    //     if (std::abs(exch_ts - prev_exch_ts) > MinErr){
    //         qty_buffer.push(this_qty);
    //     }
    //     else {
    //         qty_buffer[-1] += this_qty;
    //     }

    //     if(qty_buffer.isFull() != false){
    //         factor_value = qty_buffer.neg_sum();
    //     }
    //     prev_exch_ts = exch_ts;
        
    // };

private:
    int64_t lookback;
    GaiaCircularBuffer<double> qty_buffer;
    int64_t prev_exch_ts = 0;
    double this_qty = 0.0;

    int64_t exch_ts = 0;
    double qty_sum = 0.0;
};
                 