#include "Factor.h"
#include "Ema.h"
#include "GaiaCircularBuffer.h"
#include <cmath>

class BookImbaRatioFactor : public FactorInterface
{
public:
    BookImbaRatioFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
        max_depth = config.Get<int64_t>("max_depth");
        decay = config.Get<double>("decay");

    };

    virtual std::string gen_name() {
        return std::string("BookImbaRatioFactor") + "@max_depth=" + std::to_string(max_depth) + "@decay=" + std::to_string(decay);
    }

    virtual void calculate(const FactorInput& input_data) {
        auto &ob = input_data.cur_contract->alphaBook;
        int64_t num_bids = ob->num_bids();
        int64_t num_asks = ob->num_asks();
        double tmp_bid = 0.0;
        double tmp_ask = 0.0;
        for (int i = 0; i < max_depth; i++){
            double this_decay = std::pow(decay, max_depth);
            if (i < num_bids){
                tmp_bid += this_decay*ob->bid(i).qty;
            }
            if (i < num_asks){
                tmp_ask += this_decay*ob->ask(i).qty;
            }           

        }
        factor_value = (tmp_bid - tmp_ask)/(tmp_bid + tmp_ask);
    };


private:
    int64_t max_depth;
    double decay;
};
                              
