#pragma once
#include "StrategyFields.h"
#include "ContractInfo.h"
#include "SpdLoggerMessage.h"
#include "SpdLogger.h"
#include "GOrderState.h"
#include "GaiaUtils.h"
#include "GaiaPosMonitor.h"

struct HedgerConfig
{
    bool use_market_order;
    bool round_for_hyperliquid;
    int64_t mkt_timeout_ns;
    int64_t quoter_hedger_mkt_recv_diff_ns;
    double hedge_take_bp;
    double custom_hedge_min_notional;
    double custom_hedge_max_notional;
    double custom_pos_hedge_max_notional;

    double net_pos_risk_ratio;


    bool use_qry_result = true;
    bool use_qry_pos_monitor = false;
    bool is_margin_trading = false;

    int64_t hedge_interval_ns_in_exit;
    int64_t exit_ns_in_disconnect;
    int64_t hedge_interval_ns_in_disconnect;
    // hedger price / quoter price
    double hedger_ref_quoter_price_ratio;
};

class Hedger : public trading_system_st::Strategy
{
public:

    Hedger() {
        last_disconnect_ns = 0;
        last_hedge_ns = 0;

        quoter_strategy_fields_ = nullptr;
    }

    ~Hedger() {
        ts_client()->Logout();
    }

    virtual void InitConfig(const Config &conf) {}
    virtual bool isHedged() { return true; }
    virtual void OnOrder(Order *order, const OrderStatusUpdate &update) {}
    virtual void RiskCheck() {
    }
    virtual void tryHedge() {}
    virtual void HedgingLogic(StrategyFields &quoter_strategy_fields, GOrderState *orderState,
                        const std::string &tradeId, const double &quoterFilledPrice,
                        const double &quoterFilledSize, const int8_t &quoterFilledSideInt,
                        const double &quoterFilledFees) {}

    void OnReady() override {
        connected_ = true;
        std::string msg_type = __FUNCTION__;
        std::string msg = "Hedger OnReady";
        LOG_AUTO(CustomMsg, msg_type, msg);
        if(quoter_strategy_fields_ != nullptr)
            quoter_strategy_fields_->setStrategyMode(StrategyMode::UnknownMode, "Hedger OnReady");
    }

    void OnDisconnect() override {
        connected_ = false;
        std::string msg_type = __FUNCTION__;
        std::string msg = "Hedger Disconnect";
        LOG_AUTO(CustomMsg, msg_type, msg);

        if (quoter_strategy_fields_ != nullptr) {
            quoter_strategy_fields_->setStrategyMode(StrategyMode::DisconnectMode, "Hedger OnDisconnect");
        }
        last_disconnect_ns = GaiaUtils::GetSysTimestamp();
    }

    StrategyFields *getStrategyFields() { return strategy_fields_; }

    struct HedgerComponent {
        StrategyFields *quoter_strategy_fields;
        ContractInfoMapType *contract_map;
        SidContractInfoMapType *sid_contract_map;
        StrategyFieldsMapType *strategy_fields_map;

        bool use_qry_result;
        bool is_margin_trading;
        bool use_qry_pos_monitor;
        std::shared_ptr<GaiaPosMonitor> gaia_pos_monitor;
    } hedger_component_;
    
    void setHedgerComponent(HedgerComponent _hedger_component, const Config &conf) { 
        quoter_strategy_fields_ = _hedger_component.quoter_strategy_fields;
        contract_map = _hedger_component.contract_map;
        sid_contract_map = _hedger_component.sid_contract_map;
        strategy_fields_map = _hedger_component.strategy_fields_map;

        config.use_qry_result = _hedger_component.use_qry_result;
        config.is_margin_trading = _hedger_component.is_margin_trading;
        config.use_qry_pos_monitor = _hedger_component.use_qry_pos_monitor;
        gaia_pos_monitor = _hedger_component.gaia_pos_monitor;

        auto hedger_config = conf.Get<Config>("hedger");

        int logic_acct_id = hedger_config.Get<int>("hedger_logic_acct_id");
        std::string hedger_symbol = hedger_config.Get<std::string>("hedger_symbol");
        SymId sid = SecMaster::instance().FindSid(hedger_symbol);
        strategy_fields_ = &(*strategy_fields_map)[sid];

        strategy_fields_->contract_info = (*sid_contract_map)[sid];
        strategy_fields_->contract_info->logic_acct_id = logic_acct_id;
    }

    double getBaseCoinRelQuoter()
    {
        return strategy_fields_->sym_risk.symbol_risk * config.hedger_ref_quoter_price_ratio;
    }

    bool connected() { return connected_; }

    void calculateHedgerPnl() {
        GaiaUtils::calculateRealTimePnl(strategy_fields_);
    }

    bool hasInFlightOrder() {
        double bid_in_flight_coin = 0, ask_in_flight_coin = 0;
        GaiaUtils::GetInFlightOrderCoin(*strategy_fields_, bid_in_flight_coin, ask_in_flight_coin);
        if (bid_in_flight_coin > eps || ask_in_flight_coin > eps) {
            return true;
        }

        return false;
    }

    void OnInitialize(const Config &conf) override {
        orderCb = Order::UpdateCb(this, &Hedger::OnOrderUpdate);
        order_manager()->set_default_order_update_cb(orderCb);

        strategy_fields_->order_manager = order_manager();
    }

    void OnReconDone(const ReconState &recon) override {
        struct ContractInfo *contract_info = strategy_fields_->contract_info;

        for (auto order : recon.orders) {
            std::cout << "order: " << order->client_order_id().value << " sid:" << order->sid() << order->price()
                      << "@" << order->leaves_qty() << std::endl;
        }

        auto hedger_logic_acct_id = contract_info->logic_acct_id;
        auto hedger_sid = contract_info->symbol_info->sid; 
        if (!recon.orders.empty()) {
            strategy_fields_->order_manager->CancelAll(hedger_logic_acct_id, hedger_sid);
        }

        if (recon.positions.count(hedger_logic_acct_id)) {
        }
        auto now = GaiaUtils::GetSysTimestamp();
        if (recon.balances.count(hedger_logic_acct_id)) {
            for (auto &bal : recon.balances.at(hedger_logic_acct_id)) {
                GaiaUtils::FillBalance(*strategy_fields_, hedger_logic_acct_id, bal.sid, bal.total, bal.available, now);
            }
        }

        qryPosition();
    }

    void qryPosition() {
        struct ContractInfo *contract_info = strategy_fields_->contract_info;
        if (strategy_fields_->contract_info->symbol_info->mirana_ticker.find("_Spot_") != std::string::npos) {
            std::cout << "hedger qry position from balance " << contract_info->logic_acct_id << "," << contract_info->symbol_info->sid << "," << contract_info->symbol_info->base_sid<< std::endl;
            std::this_thread::sleep_for(std::chrono::seconds(2));
            ts_client()->QryBalance(strategy_fields_->contract_info->logic_acct_id, strategy_fields_->contract_info->symbol_info->base_sid);
        } else {
            std::cout << "hedger qry position " << contract_info->logic_acct_id << "," << contract_info->symbol_info->sid << std::endl;
            ts_client()->QryPosition(contract_info->logic_acct_id, contract_info->symbol_info->sid);
        }
    }

    void setContractMap(ContractInfoMapType *_contract_map) {
        contract_map = _contract_map;
    }

    void setSidContractMap(SidContractInfoMapType *_sid_contract_map) {
        sid_contract_map = _sid_contract_map;
    }

    void setStrategyFieldsMap(StrategyFieldsMapType *_strategy_fields_map) {
        strategy_fields_map = _strategy_fields_map;
    }

    bool allPosUpdated() {
        if (!strategy_fields_->sym_risk.initialized) {
            std::cout << strategy_fields_->contract_info->symbol_info->mirana_ticker << " pos not updated yet ..." << std::endl;
        }

        return strategy_fields_->sym_risk.initialized;
    }

    void CancelAll() {
        ContractInfo *contract_info = strategy_fields_->contract_info;
        strategy_fields_->order_manager->CancelAll(contract_info->logic_acct_id, contract_info->symbol_info->sid);
    }

    Order *PrepareAndSendOrder(Side side, Price hedgePrice, Qty hedgeQty, TimeInForce tif, OrderType type=OrderType::LIMIT, int strategy_order_type=0) {
        OrderExtraParams params;
        if(config.round_for_hyperliquid && strategy_fields_->contract_info->symbol_info->exch == Exchange::HYPERLIQUID) {
            GaiaUtils::roundPriceViaSignificantNum(hedgePrice);
        }

        order_ = order_manager()->PrepareOrder(
            strategy_fields_->contract_info->logic_acct_id,
            strategy_fields_->contract_info->symbol_info->sid,
            side,
            type,
            hedgePrice,
            hedgeQty,
            tif,
            params);

        bool insert_ret = false;
        insert_ret = order_manager()->InsertOrder(order_);

        int64_t now = GaiaUtils::GetSysTimestamp();
        if(insert_ret) {
            ContractInfo *ci = strategy_fields_->contract_info;
            ContractInfo *cur_ci = (*sid_contract_map)[quoter_strategy_fields_->cur_tick_sid];
            LOG_AUTO(SendReplaceOrderMessage, now, cur_ci->latency_record, cur_ci->update_tick_type, ci->symbol_info->mirana_ticker.c_str(),
                                                    ci->symbol_info->mirana_ticker.c_str(), 
                                                    strategy_fields_->contract_info->logic_acct_id, order_->client_order_id().value,hedgePrice, hedgeQty,
                                                    side == Side::BUY ? 1 : -1, int(tif), strategy_order_type,
                                                    GaiaUtils::BookGetBestBidPrice(ci), GaiaUtils::BookGetBestAskPrice(ci),
                                                    GaiaUtils::BookGetBestBidSize(ci), GaiaUtils::BookGetBestAskSize(ci));
            
            return order_;
        } else {
            order_manager()->CloseOrder(order_);

            if(quoter_strategy_fields_->current_mode != StrategyMode::DisconnectMode) {
                last_disconnect_ns = now;
                quoter_strategy_fields_->setStrategyMode(StrategyMode::DisconnectMode, "disconnect, error insert");
            }
            return nullptr;
        }
    }

    double getMtmPnlUsd() {
        if(strategy_fields_->contract_info->is_reverse) {
            return (strategy_fields_->sym_risk.realized_pnl + strategy_fields_->sym_risk.unrealized_pnl) * GaiaUtils::GetMidPrice(strategy_fields_->contract_info);
        } else {
            return strategy_fields_->sym_risk.realized_pnl + strategy_fields_->sym_risk.unrealized_pnl;
        }
    }

    double getRealizedPnlUsd() {
        if(strategy_fields_->contract_info->is_reverse) {
            return strategy_fields_->sym_risk.realized_pnl * GaiaUtils::GetMidPrice(strategy_fields_->contract_info);
        } else {
            return strategy_fields_->sym_risk.realized_pnl;
        }
    }

    double getUnrealizedPnlUsd() {
        if(strategy_fields_->contract_info->is_reverse) {
            return strategy_fields_->sym_risk.unrealized_pnl * GaiaUtils::GetMidPrice(strategy_fields_->contract_info);
        } else {
            return strategy_fields_->sym_risk.unrealized_pnl;
        }
    }

    void OnQryPosition(const trading_system_ts::RespQryPosition &position) override {
        struct ContractInfo *contract_info = strategy_fields_->contract_info;

        int logic_acct_id = position.logic_acct_id;
        int sid = position.sid;
        int err_code = position.err_code;
        bool is_last = position.is_last;

        PositionSide position_side = position.position_side;
        int sideInt = 1;
        if (position_side == PositionSide::SHORT)
            sideInt = -1;

        double cum_realised_pnl = position.cum_realised_pnl;
        double unrealised_pnl = position.unrealised_pnl;
        double leverage = position.leverage;
        double liq_price = position.liq_price;

        double pos_size = position.pos_size;
        if (SIGN(pos_size) != sideInt)
            pos_size *= sideInt;
        double position_mm = position.position_mm;
        double avg_entry_price = position.avg_entry_price;

        // strategy_fields->sym_risk.symbol_risk_avg_price = avg_entry_price;
        auto now = GaiaUtils::GetSysTimestamp();
        SymId hedger_sid = contract_info->symbol_info->sid;
        if (err_code == 0) {
            if ((sid == hedger_sid) && (!is_last)) {
                if(!strategy_fields_->sym_risk.initialized) {
                    if(config.use_qry_result) GaiaUtils::updateNetPos(strategy_fields_, pos_size , avg_entry_price);
                    strategy_fields_->sym_risk.initialized = true;
                }

                if(config.use_qry_pos_monitor && !is_last) {
                    double net_pos = pos_size - strategy_fields_->sym_risk.initial_pos_coin;
                    if (contract_info->symbol_info->product_type == ProductType::INVERSE_SWAP ||
                        contract_info->symbol_info->product_type == ProductType::INVERSE_FUTURE) {
                            net_pos = pos_size * contract_info->symbol_info->multiplier - strategy_fields_->sym_risk.initial_pos_coin * avg_entry_price;
                    }
                    // inverse use usd based net pos, otherwise use coin based net pos
                    gaia_pos_monitor->update_pos(contract_info->logic_acct_id,
                                                contract_info->symbol_info->sid,
                                                net_pos,
                                                now);
                }
            }

            if(is_last && !strategy_fields_->sym_risk.initialized) {
                if(config.use_qry_result) GaiaUtils::updateNetPos(strategy_fields_, 0, 0);
                strategy_fields_->sym_risk.initialized = true;
            }
        } else if ((err_code == 340 || err_code == 308) && (contract_info->symbol_info->exch == Exchange::GATEIO)) {
            if(!strategy_fields_->sym_risk.initialized) {
                if(config.use_qry_result) GaiaUtils::updateNetPos(strategy_fields_, 0, 0);
                strategy_fields_->sym_risk.initialized = true;
            }

            if(!is_last && config.use_qry_pos_monitor) {
                double net_pos = - strategy_fields_->sym_risk.initial_pos_coin;
                if (contract_info->symbol_info->product_type == ProductType::INVERSE_SWAP ||
                    contract_info->symbol_info->product_type == ProductType::INVERSE_FUTURE) {
                        net_pos = - strategy_fields_->sym_risk.initial_pos_coin * avg_entry_price;
                }
                // inverse use usd based net pos, otherwise use coin based net pos
                gaia_pos_monitor->update_pos(strategy_fields_->contract_info->logic_acct_id,
                                                strategy_fields_->contract_info->symbol_info->sid,
                                                0,
                                                now);
            }
        } else if((!strategy_fields_->sym_risk.initialized) && err_code == 211) {
            qryPosition();
        }

        LOG_AUTO(OnQryPositionMessage, logic_acct_id, sid, err_code, cum_realised_pnl, unrealised_pnl,
                                                leverage, liq_price, pos_size, position_mm, avg_entry_price,
                                                is_last);
    }

    void OnQryBalance(const trading_system_ts::RespQryBalance &balance) override {
        int logic_acct_id = balance.logic_acct_id;
        int sid = balance.sid;
        int err_code = balance.err_code;
        std::string coin = balance.coin;
        if(err_code != 0) {
            std::cout << "err_code:" << err_code << std::endl;
            return;
        }

        double available = balance.available;
        double frozen = balance.frozen;
        double total = balance.total;
        double unrealised_pnl = balance.unrealised_pnl;
        double realised_pnl = balance.realised_pnl;
        double borrowed = balance.borrowed;
        if(config.is_margin_trading && strategy_fields_->contract_info->symbol_info->exch == Exchange::BINANCE) {
            total = balance.total - borrowed;
        }

        auto now = GaiaUtils::GetSysTimestamp();
        if (strategy_fields_->contract_info->symbol_info->mirana_ticker.find("_Spot_") != std::string::npos) {

            if ((err_code == 0) && (!balance.is_last) &&
                (logic_acct_id == strategy_fields_->contract_info->logic_acct_id) && (sid == strategy_fields_->contract_info->symbol_info->base_sid)) {
                // strategy_fields->sym_risk.symbol_risk = total - strategy_fields->sym_risk.initial_pos_coin;
                if(!strategy_fields_->sym_risk.initialized) {
                    if(config.use_qry_result) GaiaUtils::updateNetPos(strategy_fields_, total, 0);
                    strategy_fields_->sym_risk.initialized = true;
                }

                if(config.use_qry_pos_monitor) {
                    gaia_pos_monitor->update_pos(strategy_fields_->contract_info->logic_acct_id,
                                                strategy_fields_->contract_info->symbol_info->sid,
                                                total - strategy_fields_->sym_risk.initial_pos_coin,
                                                now);
                }
            }

            if(balance.is_last && (!strategy_fields_->sym_risk.initialized)) {
                if(config.use_qry_result) GaiaUtils::updateNetPos(strategy_fields_, 0, 0);
                strategy_fields_->sym_risk.initialized = true;
            }
        }

        if ((err_code == 0) && (!balance.is_last)) {
            GaiaUtils::FillBalance(*strategy_fields_, logic_acct_id, sid, total, available);
        }


        LOG_AUTO(OnQryBalanceMessage, logic_acct_id,sid, strategy_fields_->contract_info->symbol_info->mirana_ticker.c_str(),
                                            coin.c_str(), err_code, available, frozen, total,
                                            unrealised_pnl, realised_pnl);
    }

    void OnQryOpenOrder(const RespQryOpenOrder &order) override {

        if ((order.order != NULL) || (order.order != nullptr)) {
            order_manager()->CancelOrder(order.order);

            LOG_AUTO(OnQryOpenOrderMessage, order.order->client_order_id().value);
        }
    }

    void OnUnknownFill(const Order *order, const OrderFill &fill) override {
        struct ContractInfo *contract_info = strategy_fields_->contract_info;
        if(contract_info->symbol_info->sid != order->sid())
        {
            std::cout << "Hedger cannot find sid " << order->sid() << " in " << __FUNCTION__ << std::endl;
            return;
        }
        int64_t now = GaiaUtils::GetSysTimestamp();
        int sign = order->side() == Side::BUY ? 1 : -1;

        GaiaUtils::updatePosition(strategy_fields_, fill.qty, sign, fill.prc, fill.fee);
        double fee = fill.fee;
        LOG_AUTO(ExecMessage, 0, "UnknownFill", 0, GaiaUtils::BookGetBestBidPrice(contract_info),
                                        GaiaUtils::BookGetBestAskPrice(contract_info), now, 0, order->client_order_id().value,
                                        order->exch_order_id(), "UnknownFill", 0, contract_info->logic_acct_id, contract_info->symbol_info->mirana_ticker.c_str(),
                                        contract_info->symbol_info->sid, strategy_fields_->sym_risk.symbol_risk, 9, 0, sign, fill.prc, fee, fill.fee_sid, 0, fill.qty, fill.exch_ts, -1);
    }

    void OnOrderUpdate(Order *order, const OrderStatusUpdate &update) {
        struct ContractInfo *contract_info = strategy_fields_->contract_info;

        auto e = update.event;
        int8_t sign;
        if (order->side() == Side::BUY)
            sign = 1;
        else
            sign = -1;

        // if IOC and missed or not fully filled, resubmit

        if (update.fill_qty > 0)
        {

            ExecLiquidityType lqd_type = update.lqd_type;

            GaiaUtils::updatePosition(strategy_fields_, update.fill_qty, sign, update.fill_price, update.fee);

            std::string orderStatusEventStr;
            switch (e)
            {
            case OrderStatusEvent::NEW:
                orderStatusEventStr = "NEW";
                break;
            case OrderStatusEvent::REPLACED:
                orderStatusEventStr = "REPLACED";
                break;
            case OrderStatusEvent::UNKNOWN:
                orderStatusEventStr = "UNKNOWN";
                break;
            case OrderStatusEvent::CANCELED:
                orderStatusEventStr = "CANCELED";
                break;
            case OrderStatusEvent::FILLED:
                orderStatusEventStr = "FILLED";
                break;
            case OrderStatusEvent::PARTIALLY_FILLED:
                orderStatusEventStr = "PARTIALLY_FILLED";
                break;
            case OrderStatusEvent::TS_CANCEL_ACKED:
                orderStatusEventStr = "TS_CANCEL_ACKED";
                break;
            case OrderStatusEvent::TS_NEW_ACKED:
                orderStatusEventStr = "TS_NEW_ACKED";
                break;
            case OrderStatusEvent::INTERNAL_REJECTED:
                orderStatusEventStr = "INTERNAL_REJECTED";
                break;
            case OrderStatusEvent::CANCEL_INTERNAL_REJECTED:
                orderStatusEventStr = "CANCEL_INTERNAL_REJECTED";
                break;
            case OrderStatusEvent::CANCEL_ERROR:
                orderStatusEventStr = "CANCEL_ERROR";
                break;
            case OrderStatusEvent::REPLACE_INTERNAL_REJECTED:
                orderStatusEventStr = "REPLACE_INTERNAL_REJECTED";
                break;
            case OrderStatusEvent::REPLACE_ERROR:
                orderStatusEventStr = "REPLACE_ERROR";
                break;
            case OrderStatusEvent::TS_REPLACE_ACKED:
                orderStatusEventStr = "TS_REPLACE_ACKED";
                break;
            case OrderStatusEvent::REJECTED:
                orderStatusEventStr = "REJECTED";
                break;
            case OrderStatusEvent::CANCEL_REJECTED:
                orderStatusEventStr = "CANCEL_REJECTED";
                break;
            case OrderStatusEvent::REPLACE_REJECTED:
                orderStatusEventStr = "REPLACE_REJECTED";
                break;
            default:
                break;
            }
            int64_t now = GaiaUtils::GetSysTimestamp();

            int strategy_order_type = 0;
            if (hedgerOrderIdToQuoterTradeMap.find(order->client_order_id().value) != hedgerOrderIdToQuoterTradeMap.end()) {
                std::string quoterTradeId = hedgerOrderIdToQuoterTradeMap[order->client_order_id().value];

                if (savedQuoterTradeMap.find(quoterTradeId) != savedQuoterTradeMap.end()) {
                    TradeWrapper &tradeWrapper = savedQuoterTradeMap[quoterTradeId];
                    strategy_order_type = tradeWrapper.strategy_order_type;
                }
            }

            double fee = update.fee;
            LOG_AUTO(ExecMessage, 0, orderStatusEventStr.c_str(), 0, GaiaUtils::BookGetBestBidPrice(contract_info),
                                        GaiaUtils::BookGetBestAskPrice(contract_info), now, 0, order->client_order_id().value,
                                        order->exch_order_id(), update.trade_id, 0, contract_info->logic_acct_id, contract_info->symbol_info->mirana_ticker.c_str(),
                                        contract_info->symbol_info->sid, strategy_fields_->sym_risk.symbol_risk, 9, 0, sign,
                                        update.fill_price, fee, update.fee_sid, update.remain_order_rate, update.fill_qty, update.exch_ts, strategy_order_type);
        }

        OnOrder(order, update);

        if (order->closed())
        {
            GOrderState *localOrder = strategy_fields_->order_state_map[order->client_order_id().value];

            order_manager()->CloseOrder(order);
            strategy_fields_->order_state_map.erase(localOrder->client_order_id);
            strategy_fields_->order_state_pool.delete_object(localOrder);

            tryHedge();
        }
    }

protected:
    std::string hedgerName;
    Order::UpdateCb orderCb;

    StrategyFields *strategy_fields_;
    StrategyFields *quoter_strategy_fields_;

    ContractInfoMapType *contract_map;
    SidContractInfoMapType *sid_contract_map;
    StrategyFieldsMapType *strategy_fields_map;

    HedgerConfig config;

    Order *order_ = nullptr;
    bool connected_ = false;

    std::shared_ptr<GaiaPosMonitor> gaia_pos_monitor;
    int64_t last_disconnect_ns;
    int64_t last_hedge_ns;

    TradeWrapperMapType savedQuoterTradeMap;
    std::unordered_map<uint64_t, std::string> hedgerOrderIdToQuoterTradeMap;
    std::unordered_map<uint64_t, std::string> hedgerOrderIdToTypeMap;




};
