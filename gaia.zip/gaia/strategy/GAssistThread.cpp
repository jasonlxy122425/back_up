#include "GAssistThread.h"
#include "GAssistCalculator.h"
#include <sched.h>

GAssistThread::GAssistThread(GAssistCalculator *calculator, std::string shm_name, int cpu) {
    calculator_ = calculator;
    shm_name_ = shm_name;
    cpu_ = cpu;
}

void GAssistThread::Run() {
    thread_ = std::thread(&GAssistThread::AssistProcess, this);
    thread_.detach();
}

void GAssistThread::Stop() {
    stop_requested_ = true;
}

void GAssistThread::AssistProcess() {
    InitMd();
    std::cout << "assist thread started" << std::endl;
    if (batch_mode_) {
        std::cout << "assist thread in batch mode" << std::endl;
        while (true) {
            if (stop_requested_) {
                break;
            }
            calculator_->OnTimer();
            auto batch = md_reader_.PollBatch();
            if (!batch.empty()) {
                calculator_->OnMdBatch(batch);
            }
        }
        return;
    } else {
        AddCb();
        while (true) {
            if(stop_requested_) {
                break;
            }
            calculator_->OnTimer();
            md_reader_.Poll();
        }
    }
}

void GAssistThread::InitMd() {
    for(auto sid : symbols_) {
        std::cout << "assist subscribe sid: " << sid << std::endl;
    }
    md_reader_.Initialize(shm_name_,
                                md::MdReader::Options{.univ = symbols_});

    if (cpu_ >= 0) {
        cpu_set_t cpuset;
        CPU_ZERO(&cpuset);
        CPU_SET(cpu_, &cpuset);
        sched_setaffinity(0, sizeof(cpu_set_t), &cpuset);
    }
}

void GAssistThread::AddCb() {
    md_reader_.AddBestQuoteCb(calculator_, &GAssistCalculator::OnBestQuote);
    md_reader_.AddOrderbookCb(calculator_, &GAssistCalculator::OnOrderbook);
    md_reader_.AddTradeCb(calculator_, &GAssistCalculator::OnTrade);
    md_reader_.AddLiquidationCb(calculator_, &GAssistCalculator::OnLiquidation);
    md_reader_.AddKlineCb(calculator_, &GAssistCalculator::OnKline);
}