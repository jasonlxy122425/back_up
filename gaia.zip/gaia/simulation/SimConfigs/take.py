import pickle
from Default.KronosConfig import *
from Default.DefaultCommonConfig import *

@config_interface
class TagConfig():
    def __init__(self):
        self.configs = []

    def genFactors(self, factor_path):
        with open(factor_path , 'rb') as file:
            factors = pickle.load(file)
        return factors

    def generateParams(self, sim_params, stra_params):
        config = KronosConfig("take")
        config.num_of_book_levels = 25

        # predictor log
        config.predictorConfig.demeter_sample_num = stra_params["demeter_sample_size"]
        config.predictorConfig.factor_path  = stra_params["factor_path"]
        config.predictorConfig.model_path = stra_params["model_path"]
        config.predictorConfig.demeter_sample_type = stra_params["demeter_sample_type"]
        if stra_params["to_generate_factors"]:
            config.predictorConfig.factors = self.genFactors(config.predictorConfig.factor_path)
        else:
            config.predictorConfig.factors = []

        # orderlogic log
        for key, value in stra_params.items():
            print(key, value)
            setattr(config.orderLogicConfig, key, value)
        sim_output_engine = "parquet"
        if stra_params["to_output_gob"] is None:
            sim_output_engine = None
        # sim 
        config.orderLogicCommonConfig.set_values(notional_size = stra_params["notional_size"],
                                                max_pos_in_clips = stra_params["max_pos_in_clips"])
        config.set_sim(mode = 'SIM',
                    start_date = sim_params["start_date"],
                    end_date = sim_params["end_date"],
                    sign_str = sim_params["sign_str"],
                    target_server =  sim_params["target_server"],
                    #target_path = "/home/master/Data/md_dump/",
                    sim_engine = 'alphaless',
                    use_ts_log = True,
                    sim_output_engine = sim_output_engine,
                    sim_output_target = './gaia_orderbook.parquet',
                    sim_output_factors = stra_params["to_output_factors"],
                    sim_output_sample_count = stra_params["output_sample_size"],

                    )
        config.simConfig.set_sim_fee(sim_params["target_exchange"], {'taker': sim_params["taker"], 'maker': sim_params["maker"]})

        config.simConfig.set_sim_latency(sim_params["target_exchange"], "all", {'req_insert_order': sim_params["insert_latency"]})

        config.simConfig.set_sim_order(sim_params["target_exchange"], "all", {'cancel_front_ratio': 0.0,
                                                                              'taker_cross_decay_ratio': 0.0,
                                                                              'trade_cross_policy': 'eq_price_qty',
                                                                              'bbo_cross_policy': 'qty',
                                                                              'use_fill_latency_hint': True,
                                                                              'fill_latency_lead': '0ms',
                                                                              'min_fill_latency': '0ms',
                                                                              'max_fill_latency': '0ms'})
        config.setSymbol(sim_params["target_instrument"])
        return config 

    def getConfig(self):
        sim_params = {
            "start_date": '20250301',
            "end_date": '20250310',
            "target_exchange": f"Bybit",
            "target_instrument": f"Bybit_LinearSwap_BTCUSDT",
            "target_server": "sgp-kronos-prod-md-az2-01",
            "insert_latency": "2ms",
            "maker": -0.00005,
            "taker": 0.00015,
        }
        stra_params = {
            "to_generate_factors": True,
            "to_output_factors": True,
            "to_output_gob": False,
            "demeter_sample_type": "tick",
            "demeter_sample_size": 100,
            "output_sample_size": 10,
            "factor_path": "/mnt/share/jsc/config/pred/[Bybit_LinearSwap_BTCUSDT][HRTLabel_forward_ticks_10][100]/factors.txt",
            "model_path": "/mnt/share/jsc/config/pred/[Bybit_LinearSwap_BTCUSDT][HRTLabel_forward_ticks_10][100]/model.txt",
            "notional_size": 100,
            "max_pos_in_clips": 3,
            "open_threshold": 0.5,
            "close_threshold": 0.5,
            "improve_ticks": 1,
            "stop_loss": -10000000,
            "dmm_filter": 0,
            "use_log_factor": 0,
            "mkt_timeout_ns": 3000000000,
            "mid_change_filter": 0,
            "spread_filter_min_ticks":1,
            "spread_filter_max_ticks":1000,
            "quote_range":5,
            "use_make_to_close": 0,
        }
        for i in [0.5]:
            for j in [0.7]:
                stra_params["open_threshold"]  = i
                stra_params["close_threshold"] = j
                sim_params["sign_str"] = "{}_{}_k1".format(i, j)
                config = self.generateParams(sim_params, stra_params)
                self.configs.append(config)
        return self.configs