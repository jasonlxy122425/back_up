#include "Factor.h"
#include <cmath>
#include "GaiaUtils.h"

class TimerDemoFactor : public FactorInterface
{
public:
    TimerDemoFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");

        // GetContractInfo will return nullptr if symbol not found
        // if you need any other data, you can get it from GetContractInfo, save it , use it in OnTimer
        contract_info = GetContractInfo(symbol);

        int64_t interval = config.Get<int64_t>("timer_interval_ms");
        RegisterTimer(interval*1e6L);
    };

    virtual std::string gen_name() {;
        return std::string("TimerDemoFactor");
    }

    // will called every tick for symbol
    // void calculate(const FactorInput& input_data) override {
    // };

    // will called every interval
    // notice: in simulation, interval will be larger than config interval because of the sim data time interval
    void OnTimer() override {
        std::cout << "TimerDemoFactor OnTimer, now:" << GaiaUtils::GetSysTimestamp() << std::endl;
        factor_value = (contract_info->alphaBook->bid(0).price + contract_info->alphaBook->ask(0).price)/2;
    }

private:
    int64_t prev_exch_ts = 0;
    ContractInfo *contract_info = nullptr;
    Side prev_side = Side::SELL;
};
