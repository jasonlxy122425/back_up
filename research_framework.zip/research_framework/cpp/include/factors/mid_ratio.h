#include "Factor.h"
#include "Ema.h"
#include "GaiaCircularBuffer.h"
#include <cmath>

class MidRatioFactor : public FactorInterface
{
public:
    MidRatioFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
        lookback = config.Get<int64_t>("lookback");
        mid_buffer.setSize(lookback, 0.0);

    };

    virtual std::string gen_name() {
        return std::string("MidRatioFactor") + '@' + std::to_string(lookback);
    }

    virtual void calculate(const FactorInput& input_data) {
        factor_value = 0.0;
        auto &gob = input_data.cur_contract->alphaBook;
        double mid_price = (gob->bid(0).price + gob->ask(0).price)/2.0;
        mid_buffer.push(mid_price);
        if(mid_buffer.isFull() != false){
            double min_mid = mid_buffer.min();
            double max_mid = mid_buffer.max();
            double mid_range = max_mid - min_mid;
            if (mid_range > MinErr){
                factor_value = 2*(mid_price - min_mid)/mid_range - 1.0;
            }
            else {
                factor_value = 0.0;
            }
        }
    };


private:
    int64_t ema_int;
    Ema ema;
    int64_t lookback;
    GaiaCircularBuffer<double> mid_buffer;
};
                              
