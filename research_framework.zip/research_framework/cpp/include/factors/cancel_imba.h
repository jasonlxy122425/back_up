#include "Factor.h"
#include "Ema.h"
#include <cmath>

class CancelImbaFactor : public FactorInterface
{
public:
    CancelImbaFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
        ema_int = config.Get<int16_t>("ema_int");
        ema.init(ema_int);

    };

    virtual std::string gen_name() {;
        return std::string("CancelImbaFactor") + '@' + std::to_string(ema_int);
    }

    virtual void calculate(const FactorInput& input_data) {
        auto &gob = input_data.cur_contract->alphaBook;
        auto &demeter_data = input_data.cur_contract->demeter_data;
        double bid_cancel =  demeter_data->GetGobUpdateSum(Side::BUY, demeter::BookOrderType::Cancel);
        double ask_cancel = demeter_data->GetGobUpdateSum(Side::SELL, demeter::BookOrderType::Cancel);
        double imba = std::log(bid_cancel+1.0) - std::log(ask_cancel+1.0);
        factor_value = imba;
        predict();
    };

    void predict() {
        ema.update(factor_value);
        factor_value = ema.get();

    }

private:
    int64_t ema_int;
    Ema ema;
};
                              
