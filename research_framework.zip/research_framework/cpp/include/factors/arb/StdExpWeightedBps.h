#pragma once
#include <Factor.h>


class StdExpWeightedBps : public FactorInterface
{
public:
    StdExpWeightedBps(){}

    virtual void Init(Config &config)
    {
        interval_ns = config.Get<int64_t>("interval_ns");
        exp_base = config.Get<double>("exp_base");
    }

    virtual std::string gen_name() {
        return std::string("StdExpWeightedBps")+ '@' + std::to_string(interval_ns) + '@' + std::to_string(exp_base);
    }

    virtual void calculate(const FactorInput& input_data) {
        mid_price = input_data.price;
        if(last_time == 0) {
            priceEma = mid_price;
            varEma = 0.0;

            factor_value = 0.0;
            last_time = input_data.current_time;
        }
        else if(input_data.current_time - last_time > interval_ns){
            double time_ratio = (input_data.current_time - last_time) / (double)(1000000000);
            double time_decay_rate = std::exp(-time_ratio / exp_base);
            double var_decay_rate = 1 - time_decay_rate;
            
            double price_deviation = mid_price - priceEma;

            varEma = time_decay_rate * (varEma + (var_decay_rate * (price_deviation * price_deviation)));

            priceEma = time_decay_rate * (priceEma - mid_price) + mid_price;
    
            // factor_value = sqrt(varEma)/mid_price*10000;
            factor_value = sqrt(varEma);
            last_time = input_data.current_time;
        }

        prev_factor_value = factor_value;
    };

private:
    int64_t interval_ns;
    int64_t exp_base;

    double priceEma;
    double varEma;
    double mid_price;

};
