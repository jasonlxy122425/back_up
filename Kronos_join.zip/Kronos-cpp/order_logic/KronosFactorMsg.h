#pragma once
#include "PredictorGeneral.h"

class KronosFactorMsg : public SpdLoggerMessage<KronosFactorMsg>
{
public:
    KronosFactorMsg(FactorOutputType &_output, const std::string &_symbol, const int64_t &_recv_ts = 0, const int64_t &_exch_ts = 0)
    {
        saved_output = _output;
	symbol = _symbol;
        recv_ts = _recv_ts;
        exch_ts = _exch_ts;
    }

    virtual void writeLog()
    {
        ret = {
            {"msg_type", "Factors"},
            {"symbol", symbol},
            {"recv_ts", tostring(recv_ts)},
            {"exch_ts", tostring(exch_ts)}
        };


        for (auto &it : saved_output) {
            ret[it.first] = tostring(it.second);
        }
    }

private:
    FactorOutputType saved_output;
    int64_t recv_ts,exch_ts;
    std::string symbol;
};
