#include "OrderLogicDef.h"
#include "ZeusImpl.h"

STANDARD_ORDER_LOGIC_DEFINITION(Zeus, ZeusImpl)
