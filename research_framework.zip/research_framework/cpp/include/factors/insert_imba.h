#include "Factor.h"
#include "Ema.h"
#include <cmath>

class InsertImbaFactor : public FactorInterface
{
public:
    InsertImbaFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
        ema_int = config.Get<int16_t>("ema_int");
        ema.init(ema_int);

    };

    virtual std::string gen_name() {;
        return std::string("InsertImbaFactor") + '@' + std::to_string(ema_int);
    }

    virtual void calculate(const FactorInput& input_data) {
        auto &gob = input_data.cur_contract->alphaBook;
        auto &demeter_data = input_data.cur_contract->demeter_data;
        double insert_bid = demeter_data->GetGobUpdateSum(Side::BUY, demeter::BookOrderType::Insert);
        double insert_ask = demeter_data->GetGobUpdateSum(Side::SELL, demeter::BookOrderType::Insert);
        double imba = std::log(insert_bid + 1.0) - std::log(insert_ask + 1.0);
        factor_value = imba;
        predict();
    };

    void predict() {
        ema.update(factor_value);
        factor_value = ema.get();

    }

private:
    int64_t ema_int;
    Ema ema;
};
                              
