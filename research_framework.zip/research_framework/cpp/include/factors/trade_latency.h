#include "Factor.h"
#include "Ema.h"
#include <cmath>
#include "GaiaCircularBuffer.h"

class TradeLatencyFactor : public FactorInterface
{
public:
    TradeLatencyFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
    };

    virtual std::string gen_name() {;
        return std::string("TradeLatencyFactor");
    }

    virtual void calculate(const FactorInput& input_data) {
        factor_value = 0.0;
        auto &trade = input_data.cur_contract->trade;
        factor_value = (trade.recv_ts - trade.exch_ts)/1e3;
        
    };

private:
    double this_qty = 0.0;
    
};
                              
