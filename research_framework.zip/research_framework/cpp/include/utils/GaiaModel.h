#pragma once
#include <memory>

#include "GaiaLightGbmWrapper.h"
#include "GaiaLinearModel.h"

enum GaiaModelType {
    GAIA_LINEAR_MODEL,
    GAIA_LIGHTGBM_MODEL,
};

class GaiaModel {
public:
    GaiaModel() = default;
    ~GaiaModel() = default;

    // Function to load the model from a file
    bool LoadModel(std::string modelType = "lgb") {
        if (modelType == "linear") {
            model = std::make_shared<GaiaLinearModel>();
	    std::cout << "loading GaiaLinearModel" << std::endl;
        } else if (modelType == "lgb") {
            model = std::make_shared<GaiaLightGbmWrapper>();
	    std::cout << "loading GaiaLightGbmModel" << std::endl;
        }
        return false;
    }

    void Init(std::string &model_path, int feature_num, const Config &feature_config) {
        if (model == nullptr) {
            std::cout << "Model is not loaded" << std::endl;
            return;
        }
        model->Init(model_path, feature_num, feature_config);
    }

    void Calculate(const std::vector<double> &input, std::vector<double> &output, int64_t &output_len) {
        model->Calculate(input, output, output_len);
    }

    void GetBuffer(double *data, size_t &len) {
        if (model == nullptr) {
            return;
        }
        data = model_input.data();
        len = model_input.size();
    }

private:
    std::shared_ptr<GaiaModelBase> model = nullptr;
    std::vector<double> model_input;
};
