class SimConfig:
    def __init__(self, sim_engine, sim_configs):
        self.sim_leverage = {}
        self.sim_latency = {
                        "req": "10us",
                        "resp": "10us",
                        "ts_order_req": "1us"
                      }
        self.sim_fee = {}
        self.sim_order = {}
        self.sim_engine = sim_engine
        self.sim_configs = sim_configs

    def initSimConfig(self,
                      start_date, end_date, target_server,
                      quoter_symbol, hedger_symbol = None,
                      ):
        self.quoter_symbol = quoter_symbol
        if hedger_symbol is not None:
            self.hedger_symbol = hedger_symbol
        self.start_date = start_date
        self.end_date = end_date
        self.target_server = target_server
        self.sim_data_mode = 'split_by_day'
 
        ## leverage
        self.sim_leverage[quoter_symbol] = 5.0
        if hasattr(self, "hedger_symbol"):
            self.sim_leverage[self.hedger_symbol] = 5.0       

        ## fee
        quote_exch = self.quoter_symbol.split('_')[0]
        self.set_sim_fee(quote_exch, {"taker":0.0002, "maker":-0.0001}, False)

        if hasattr(self, "hedger_symbol"):
            hedger_exch = self.hedger_symbol.split('_')[0]
            self.set_sim_fee(hedger_exch, {"taker":0.0002, "maker":-0.0001}, False)

        ## latency
        self.set_sim_latency(quote_exch, "all", {
                                            "req_insert_order": "3ms",
                                            "req_cancel_order": "3ms",
                                            "req_cancel_all": "3ms",
                                            "req_replace_order": "3ms",
                                            "req_cancel_replace_order": "3ms"
                                        }, False)

        if hasattr(self, "hedger_symbol"):
            hedger_exch = self.hedger_symbol.split('_')[0]
            self.set_sim_latency(hedger_exch, 'all', {
                                                "req_insert_order": "43ms",
                                                "req_cancel_order": "43ms",
                                                "req_cancel_all": "43ms",
                                                "req_replace_order": "43ms",
                                                "req_cancel_replace_order": "43ms"
                                            }, False)
        ## sim_order
        self.set_sim_order(quote_exch, 'all', {
                "cancel_front_ratio": 0.2,
                "taker_cross_decay_ratio": 0.2,
                "trade_cross_policy": "eq_price_qty",
                "bbo_cross_policy": "qty",
                "use_fill_latency_hint": True,
                "fill_latency_lead": "0ms",
                "min_fill_latency": "0ms",
                "max_fill_latency": "0ms"
        }, False)
        if hasattr(self, "hedger_symbol"):
            self.set_sim_order(hedger_exch, 'all', {
                        "cancel_front_ratio": 0.2,
                        "taker_cross_decay_ratio": 0.2,
                        "trade_cross_policy": "eq_price_qty",
                        "bbo_cross_policy": "qty",
                        "use_fill_latency_hint": True,
                        "fill_latency_lead": "0ms",
                        "min_fill_latency": "0ms",
                        "max_fill_latency": "0ms"
            }, False)

    def set_sim_fee(self, exch, configs, replace = True):
        for key, value in configs.items():
            if self.sim_fee.__contains__(exch) == False:
                self.sim_fee[exch] = {}

            if replace or self.sim_fee[exch].__contains__(key) == False:
                self.sim_fee[exch][key] = value
            
            self.set_sim_order(exch, 'all', {key+'_fee': value}, replace)
            # self.sim_order[key+'_fee'] = value
            
    def set_sim_latency(self, exch, type, configs, replace = True):
        if self.sim_latency.__contains__(exch) == False:
            self.sim_latency[exch] = {}

        if self.sim_latency[exch].__contains__(type) == False:  
            self.sim_latency[exch][type] = {}

        for key, value in configs.items():
            if replace or self.sim_latency[exch][type].__contains__(key) == False:
                self.sim_latency[exch][type][key] = value

    def set_sim_order(self, exch, type, configs, replace = True):
        if self.sim_order.__contains__(exch) == False:
            self.sim_order[exch] = {}

        if self.sim_order[exch].__contains__(type) == False:  
            self.sim_order[exch][type] = {}

        for key, value in configs.items():
            if replace or self.sim_order[exch][type].__contains__(key) == False:
                self.sim_order[exch][type][key] = value
