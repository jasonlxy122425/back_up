#include "Factor.h"
#include "Ema.h"
#include <cmath>
#include "GaiaCircularBuffer.h"

class TradeALastSlopeFactor : public FactorInterface
{
public:
    TradeALastSlopeFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
        lookback = config.Get<int64_t>("lookback");
        last_prc_buffer.setSize(lookback, 0.0);
        qty_buffer.setSize(lookback, 0.0);

        qty_total = 0;
    };

    virtual std::string gen_name() {;
        return std::string("TradeALastSlopeFactor") + "@lookback=" + std::to_string(lookback);
    }


    virtual void calculate(const FactorInput& input_data) {
        factor_value = 0.0;
        auto &trade = input_data.cur_contract->trade;
        exch_ts = trade.exch_ts;
        if (exch_ts != prev_exch_ts) {
            if(last_prc_buffer.isFull()) {
                qty_total -= qty_buffer[0];
            }

            qty_total += trade.qty;
            last_prc_buffer.push(trade.price);
            qty_buffer.push(trade.qty);
        } else {
            qty_total += trade.qty;

            last_prc_buffer[-1] = trade.price;
            qty_buffer[-1] += trade.qty;
        }

        if(last_prc_buffer.isFull() != false) {
            prc_diff = last_prc_buffer[-1] - last_prc_buffer[0];
            factor_value = prc_diff/qty_total;
        }

        prev_exch_ts = exch_ts;
    };

    // virtual void calculate(const FactorInput& input_data) {
    //     factor_value = 0.0;
    //     auto &trade = input_data.cur_contract->trade;
    //     int64_t exch_ts = trade.exch_ts;
    //     if (std::abs(exch_ts - prev_exch_ts) > MinErr){
    //         last_prc_buffer.push(trade.price);
    //         qty_buffer.push(trade.qty);
    //     }
    //     else {
    //         last_prc_buffer[-1] = trade.price;
    //         qty_buffer[-1] += trade.qty;
    //     }
    //     if(last_prc_buffer.isFull() != false){
    //         double prc_diff = last_prc_buffer[-1] - last_prc_buffer[0];
    //         double qty_total = qty_buffer.sum();
    //         factor_value = prc_diff/qty_total;
    //     }

    //     prev_exch_ts = exch_ts;
        
    // };

private:
    int64_t lookback;
    GaiaCircularBuffer<double> last_prc_buffer;
    GaiaCircularBuffer<double> qty_buffer;
    int64_t prev_exch_ts = 0;
    double last_price = 0.0;
    double qty_total = 0.0;

    int64_t exch_ts;
    double prc_diff;
    double prev_qty = 0.0;
};
                              
