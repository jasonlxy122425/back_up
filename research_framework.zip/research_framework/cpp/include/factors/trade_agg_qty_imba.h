#include "Factor.h"
#include "Ema.h"
#include <cmath>
#include "GaiaCircularBuffer.h"

class TradeAggQtyImbaFactor : public FactorInterface
{
public:
    TradeAggQtyImbaFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");

    };

    virtual std::string gen_name() {;
        return std::string("TradeAggQtyImbaFactor");
    }

    virtual void calculate(const FactorInput& input_data) {
        auto agg_trade = input_data.preprocess_result->GetAggTrade(input_data.cur_contract->symbol_info->sid);
        if (!agg_trade.has_value()){
            return;
        } else {
            //double side = agg_trade->side;
            double price = agg_trade->price;
            double qty = agg_trade->qty;
            factor_value += qty;
        }
        
    };

private:
    double last_bid_price = 0.0;
    double last_ask_price = 0.0;
    
};
                              
