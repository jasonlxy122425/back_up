import os, importlib, sys, fcntl
import json
class AccountPool:
    def __init__(self, config_path, account_info_path):
        self.config_path = config_path
        self.account_info_path = account_info_path
        self.account_info_file = None
        self.load_modules()
    
    def load_modules(self):
        self.module_names = [os.path.splitext(p)[0] for p in os.listdir(self.config_path) if p.endswith('.py')]

        self.configs = {}

        sys.path.append(self.config_path)
        for module_name in self.module_names:
            try:
                module = importlib.import_module(module_name)
                if hasattr(module, "TagConfig") == False:
                    continue
                self.configs[module_name] = module.TagConfig()
            except:
                print(f"{module_name} in {self.config_path} is not valid")

    def lock_file(self,file):
        fcntl.flock(file.fileno(), fcntl.LOCK_EX)

    def unlock_file(self,file):
        fcntl.flock(file.fileno(), fcntl.LOCK_UN)

    def load_account_info(self):
        with open(self.account_info_path, 'r') as f:
            self.account_info = json.load(f)
            # self.lock_file(f)
            # self.unlock_file(f)
    
    def update_account_info(self):
        with open(self.account_info_path, "w") as f:
            # self.lock_file(f)
            json.dump(self.account_info, f, indent=2)
            f.flush()
            os.fsync(f.fileno())
            # self.unlock_file(f)
    
    def check_dup_accts(self):
        self.load_modules()
        
        configured_acct = {}  # Use a set to store configured accounts
        
        for name, config in self.configs.items():
            if configured_acct.__contains__(name) == False:
                configured_acct[name] = set()

            configured_acct[name].update(config.accts)  # Add accounts to the set
        
        duplicates = set()
        unique_accts = set()

        for name, accts in configured_acct.items():
            for acct in accts:
                if acct in unique_accts:
                    duplicates.add(acct)  # Add duplicate accounts to the duplicates set
                    print(f"duplicate account found: {acct}, in config: {name}")
                else:
                    unique_accts.add(acct)  # Add unique accounts to the unique_accts set

    def clear_unconfigured_sub_tag(self, running_sub_tags, all_configured_id_sub_tag_pair):
        self.load_account_info()
        # print(self.account_info)
        modified = False
        for group, group_ids in self.account_info['acct_group'].items():
            if 'big' in group or 'cm' in group:
                continue
            for group_id in group_ids.keys():
                acct_pair = group_ids[group_id]
                for pair in acct_pair:
                    if pair.__contains__('running_sub_tag') and pair['running_sub_tag'] != '' and pair['running_sub_tag'] not in running_sub_tags:
                        pair['running_sub_tag'] = ""
                        modified = True
                    if pair.__contains__('running_sub_tag') and pair['running_sub_tag'] != '' and (group, group_id, pair['running_sub_tag']) not in all_configured_id_sub_tag_pair:
                        pair['running_sub_tag'] = ""
                        modified = True
        
        if modified:
            self.update_account_info()
        # print(self.account_info)
    
    def get_account(self, symbol, acct_group, acct_id, sub_tag):
        self.load_account_info()
        
        exchange = "_".join([symbol.split("_")[0], symbol.split("_")[1]])
        if self.account_info['acct_group'].__contains__(acct_group) == False:
            print(f"cannot find {acct_group} in account_info")
            exit(0)

        target_acct_group = self.account_info['acct_group'][acct_group]

        if target_acct_group.__contains__(acct_id) == False:
            print(f"cannot find account: {acct_id} in {acct_group}")
            exit(0)

        accts_info = target_acct_group[acct_id]
        running_tag = [ pairs['running_sub_tag'] for pairs in accts_info if pairs.__contains__('running_sub_tag') ]

        ret = None
        modified = False
        if sub_tag in running_tag:
            for pair in accts_info:
                if pair.__contains__('running_sub_tag') and pair['running_sub_tag'] == sub_tag:
                    pair_acct = pair['acct_info']
                    for info in pair_acct:
                        if info['exch'] == exchange:
                            ret = {}
                            ret['logic_acct'] = info['logic_acct']
                            if info.__contains__('ts'):
                                ret['ts'] = info['ts']
                    if ret is None:
                        print(f"cannot find account for {exchange} in {acct_id} in {acct_group}")
                        exit(0)
                    else:
                        pair['running_sub_tag'] = sub_tag
                        if pair.__contains__("symbols"):
                            pair.pop('symbols')
                            modified = True
                        # if pair.__contains__("symbols") == False:
                        #     pair['symbols'] = []
                        # pair['symbols'] = list(set(pair['symbols'].append(symbol)))
        else:
            for pair in accts_info:
                if pair.__contains__('running_sub_tag') == False or (pair['running_sub_tag'] == ""):
                    pair_acct = pair['acct_info']
                    for info in pair_acct:
                        if info['exch'] == exchange:
                            ret = {}
                            ret['logic_acct'] = info['logic_acct']
                            if info.__contains__('ts'):
                                ret['ts'] = info['ts']
                            break
                    
                if ret is not None:
                    pair['running_sub_tag'] = sub_tag
                    modified = True
                    if pair.__contains__("symbols"):
                        pair.pop('symbols')
                        modified = True
                    # if pair.__contains__("symbols") == False:
                    #     pair['symbols'] = []
                    # pair['symbols'] = list(set(pair['symbols'].append(symbol)))
                    break

            if ret is None:
                print(f"cannot find available account for acct_group: {acct_group}, sub_tag:{sub_tag}")
                exit(0)

        if modified:
            self.update_account_info()

        return ret
