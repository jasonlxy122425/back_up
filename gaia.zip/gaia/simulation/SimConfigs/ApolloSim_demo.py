from Default.ApolloConfig import *
from Default.DefaultCommonConfig import *
import pickle

@config_interface
class TagConfig():
    def __init__(self):
        self.configs = []
        self.tag = 'sim_test'

    def genFactors(self, factor_path):
        with open(factor_path , 'rb') as file:
            factors = pickle.load(file)
        return factors

    def generateParams(self, base_min_edge_bp, symbol):
        step = 0
        configs = []
        for idx in [1]:
            arb_config = ApolloConfig()
            arb_config.predictor = 'Apollo'

            # arb predictor config
            arb_config.predictorConfig.hedger_ref_quoter_price_ratio = 1

            # kronos predictor config
            arb_config.predictorConfig.demeter_sample_num = 0
            arb_config.predictorConfig.demeter_sample_type = 'tick'

            arb_config.predictorConfig.factor_path = f"/home/syq/pred_test/factors.txt"
            arb_config.predictorConfig.model_path = f"/home/syq/pred_test/model.txt"
            arb_config.predictorConfig.model_type = 'lgb'

            # config.assistPredictorConfig.model_path = f"/home/syq/pred_test/model.txt"
            # config.assistPredictor = 'Apollo'

            arb_config.predictorConfig.factors = self.genFactors(arb_config.predictorConfig.factor_path)
            # if stra_params["to_generate_factors"]:
            #     arb_config.predictorConfig.factors = self.genFactors(arb_config.predictorConfig.factor_path)
            # else:
            #     arb_config.predictorConfig.factors = []
            if len(arb_config.predictorConfig.factors) >0 and arb_config.predictorConfig.factors[0].__contains__('model_type'):
                arb_config.predictorConfig.model_type = arb_config.predictorConfig.factors[0]['model_type']
                arb_config.predictorConfig.factors = arb_config.predictorConfig.factors[1:].copy()

            arb_config.orderLogicConfig.open_threshold_bps = 5
            arb_config.orderLogicConfig.offset_bps = 5
            arb_config.orderLogicConfig.min_edge_bp = base_min_edge_bp + step * idx
            arb_config.orderLogicConfig.edge_range_bp = 3
            arb_config.orderLogicConfig.use_log_factor = 0
            arb_config.orderLogicConfig.vol_max_cap = 0
            arb_config.orderLogicConfig.vol_min_cap = 10000
            arb_config.orderLogicConfig.custom_max_notional = 360000
            arb_config.orderLogicConfig.custom_min_notional = 100

            arb_config.orderLogicConfig.max_edge_entry_bp = 0
            arb_config.orderLogicConfig.max_edge_exit_bp = 6
            arb_config.orderLogicConfig.use_log_factor = 0

            arb_config.predictorConfig.theo_edge_lower_level = 1
            arb_config.predictorConfig.theo_edge_upper_level = 10
            arb_config.orderLogicConfig.theo_edge_lower_filter = -10000
            arb_config.orderLogicConfig.theo_edge_upper_filter = 10000
            arb_config.orderLogicConfig.spread_filter = 10000
            arb_config.orderLogicConfig.sigma_filter = 0


            arb_config.hedgerConfig.mkt_timeout_ns = 500000000
            arb_config.hedgerConfig.quoter_hedger_mkt_recv_diff_ns = 1000000000
            

            arb_config.hedgerConfig.hedger_ref_quoter_price_ratio = 1
            arb_config.hedgerConfig.custom_hedge_max_notional = 400000
            arb_config.hedgerConfig.use_market_order_for_hedge = True
            arb_config.tag = self.tag
            arb_config.sub_tag = f"{self.tag}_{idx}"


            arb_config.hedgerConfig.use_market_order_for_hedge = True
            arb_config.num_of_book_levels = 5
            
            arb_config.orderLogicCommonConfig.set_values(notional_size = 350000,
                                                        stop_loss = -5000000,
                                                        use_market_order_for_liq = True,
                                                        max_pos_in_clips = 3,
                                                        mkt_timeout_ns = 500000000,
                                                        use_balance_limit_mode = True 
                                                        )
            arb_config.orderLogicCommonConfig.rate_limit_duration_ms=0
            arb_config.hedgerConfig.custom_pos_hedge_max_notional = arb_config.orderLogicCommonConfig.notional_size
            arb_config.setSymbol(f"Bybit_LinearSwap_{symbol}USDT", f"Binance_LinearSwap_{symbol}USDT")

            arb_config.set_sim(mode = 'SIM',
                    start_date = '20250610',
                    end_date = '20250610',
                    sign_str = f"{idx}",
                    target_server = 'sgp-kronos-prod-md-az2-01',
                    #target_path = "/home/master/Data/md_dump/",
                    sim_engine = 'as',
                    use_ts_log = False,
                    #sim_output_engine = "parquet",
                    sim_output_engine = None,
                    sim_output_target = './gaia_orderbook.parquet',
                    sim_output_factors = False,
                    sim_output_sample_count = 1,
                    sim_configs = {"sim_use_exch_ts":True,
                                   "sim_use_enqueue_recv_diff":True,
                                   "sim_use_same_exch_ts_recv_diff":True},

                    )
            arb_config.simConfig.set_sim_fee(arb_config.quoter_exchange, {'taker': 0.000153, 'maker': -0.00005})
            arb_config.simConfig.set_sim_fee(arb_config.hedger_exchange, {'taker': 0.000153, 'maker': -0.00005})

            arb_config.simConfig.sim_latency[arb_config.quoter_exchange] = {
                                                    "all": {
                                                        "req_insert_order": "2ms",
                                                        "req_cancel_order": "4ms",
                                                        "req_cancel_all": "4ms",
                                                        "req_replace_order": "2ms",
                                                        "req_cancel_replace_order": "2ms",
                                                        "resp": "4ms",
                                                        "use_mkt_latency_for_req": False
                                                    }
                                                }

            arb_config.simConfig.sim_latency[arb_config.hedger_exchange] = {
                                                    "all": {
                                                        "req_insert_order": "40ms",
                                                        "req_cancel_order": "40ms",
                                                        "req_cancel_all": "40ms",
                                                        "req_replace_order": "40ms",
                                                        "req_cancel_replace_order": "40ms",
                                                        "resp": "40ms",
                                                        "use_mkt_latency_for_req": True
                                                    }
                                                }

            arb_config.simConfig.set_sim_order(arb_config.quoter_exchange, "all", {'cancel_front_ratio': 0.0,
                                                                                'taker_cross_decay_ratio': 0.0,
                                                                                'trade_cross_policy': 'eq_price_qty', #eq_price_qty,eq_price_all,better_price,none
                                                                                'bbo_cross_policy': 'none',   #eq_price_qty,eq_price_all,better_price_all,better_price_qty,none
                                                                                'match_use_dmm_trade': False,
                                                                                "use_all_trade": True,
                                                                                "use_match_log": True})

            arb_config.simConfig.set_sim_order(arb_config.hedger_exchange, "all", {'cancel_front_ratio': 0.0,
                                                                                'taker_cross_decay_ratio': 0.0,
                                                                                'trade_cross_policy': 'none', #eq_price_qty,eq_price_all,better_price,none
                                                                                'bbo_cross_policy': 'eq_price_qty',   #eq_price_qty,eq_price_all,better_price_all,better_price_qty,none
                                                                                'match_use_dmm_trade': False,
                                                                                "use_all_trade": True,
                                                                                "use_match_log": True})


            configs.append(arb_config)
        return configs
    
    def getSymbolConfig(self):
        symbol_name = ["ETH"]
        for symbol in symbol_name:
            for param_config in self.generateParams(5, symbol):
                self.configs.append(param_config)


    def getConfig(self):
        self.getSymbolConfig()

        return self.configs
