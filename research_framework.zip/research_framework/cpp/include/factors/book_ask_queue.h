#include "Factor.h"
#include "Ema.h"
#include <cmath>

class BookAskQueueFactor : public FactorInterface
{
public:
    BookAskQueueFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
        max_depth = config.Get<int64_t>("max_depth");
    };

    virtual std::string gen_name() {;
        return std::string("BookAskQueueFactor") + "@max_depth=" + std::to_string(max_depth);

    }

    virtual void calculate(const FactorInput& input_data) {
        auto &gob = input_data.cur_contract->alphaBook;
        int64_t num_bids = gob->num_asks();
        double queue_front_qty = std::log(gob->ask(0).qty+1.0);
        double queue_total_qty = 0.0;
        for (int i = 0; i <num_bids; i++){
            if (i >= max_depth){
                break;
            }
            queue_total_qty += std::log(gob->ask(i).qty+1.0);
    
        }
        factor_value = 2*(queue_front_qty/queue_total_qty) - 1.0;
    };


private:
    int64_t max_depth;
};
                              
