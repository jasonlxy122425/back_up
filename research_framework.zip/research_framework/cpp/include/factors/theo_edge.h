#include "Factor.h"
#include "Ema.h"
#include "GaiaCircularBuffer.h"
#include <cmath>

class TheoEdgeFactor : public FactorInterface
{
public:
    TheoEdgeFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
        max_depth = config.Get<int64_t>("max_depth");
    };

    virtual std::string gen_name() {
        return std::string("TheoEdgeFactor") + "@max_depth=" + std::to_string(max_depth);
    }

    virtual void calculate(const FactorInput& input_data) {
        auto &gob = input_data.cur_contract->alphaBook;
        int64_t num_bids = gob->num_bids();
        int64_t num_asks = gob->num_asks();
        double tmp_bid_amt = 0.0;
        double tmp_ask_amt = 0.0;
        double tmp_bid_qty = 0.0;
        double tmp_ask_qty = 0.0;
        for (int i = 0; i < max_depth; i++){
            if (i < num_bids){
                tmp_bid_amt += gob->bid(i).qty*gob->bid(i).price;
                tmp_bid_qty += gob->bid(i).qty;
            }
            if (i < num_asks){
                tmp_ask_amt += gob->ask(i).qty*gob->ask(i).price;
                tmp_ask_qty += gob->ask(i).qty;
            }           
        }

        double tmp_bid = tmp_bid_amt/tmp_bid_qty;
        double tmp_ask = tmp_ask_amt/tmp_ask_qty;
        double tmp_mid = (gob->bid(0).price+gob->ask(0).price)/2;
        double theo = (tmp_bid*tmp_ask_qty+tmp_ask*tmp_bid_qty)/(tmp_bid_qty+tmp_ask_qty);
        factor_value = (theo/tmp_mid-1)*10000;
    };


private:
    int64_t max_depth;
};
                              
