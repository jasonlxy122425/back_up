#include "Factor.h"
#include "Ema.h"
#include <cmath>
#include "GaiaCircularBuffer.h"

class TradeALargeBuyRatioFactor : public FactorInterface
{
public:
    TradeALargeBuyRatioFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
        lookback = config.Get<int64_t>("lookback");
        threshold = config.Get<int64_t>("threshold");
        d_threshold = 1e3 * static_cast<double>(threshold);
        qty_buffer.setSize(lookback, 0.0);
    };

    virtual std::string gen_name() {;
        return std::string("TradeALargeBuyRatioFactor") + "@threshold=" + std::to_string(threshold) + "@lookback=" + std::to_string(lookback);
    }

    virtual void calculate(const FactorInput& input_data) {
        factor_value = 0.0;
        auto &trade = input_data.cur_contract->trade;
        exch_ts = trade.exch_ts;
        
        this_qty = trade.price * trade.qty;
        if (trade.side == Side::SELL) {
            this_qty = -this_qty;
        }
        
        if (exch_ts != prev_exch_ts) {
            if (qty_buffer.isFull()) {
                double& oldest_qty = qty_buffer[0];
                
                if (oldest_qty > MinErr) {
                    total_buys -= oldest_qty;
                    
                    if (oldest_qty > d_threshold) {
                        total_large_buys -= oldest_qty;
                    }
                }
            }
            
            if (this_qty > MinErr) {
                total_buys += this_qty;
                
                if (this_qty > d_threshold) {
                    total_large_buys += this_qty;
                }
            }

            qty_buffer.push(this_qty);
        } else {
            double old_qty = qty_buffer[-1];
            double new_qty = old_qty + this_qty;
            
            if (old_qty > MinErr) {
                total_buys -= old_qty;
                
                if (old_qty > d_threshold) {
                    total_large_buys -= old_qty;
                }
            }
            
            if (new_qty > MinErr) {
                total_buys += new_qty;
                
                if (new_qty > d_threshold) {
                    total_large_buys += new_qty;
                }
            }
            
            qty_buffer[-1] += this_qty;
        }
        
        if (qty_buffer.isFull()) {
            if (total_buys < min_precision) total_buys = 0.0;
            if (total_large_buys < min_precision) total_large_buys = 0.0;

            if(total_buys > MinErr) factor_value = total_large_buys / total_buys;
        }
        
        prev_exch_ts = exch_ts;
    };

    // virtual void calculate(const FactorInput& input_data) {
    //     factor_value = 0.0;
    //     auto &trade = input_data.cur_contract->trade;
    //     int64_t exch_ts = trade.exch_ts;
    //     if (trade.side == Side::BUY){
    //         this_qty = trade.price*trade.qty;
    //     }
    //     else if (trade.side == Side::SELL){
    //         this_qty = -trade.price*trade.qty;
    //     }
    //     if (std::abs(exch_ts - prev_exch_ts) > MinErr){
    //         qty_buffer.push(this_qty);
    //     }
    //     else {
    //         qty_buffer[-1] += this_qty;
    //     }
    
    //     if(qty_buffer.isFull() != false){
    //         double buys = qty_buffer.pos_sum();
    //         double large_buys = qty_buffer.pos_large_sum(1e3*threshold);
    //         if (buys > MinErr){
    //             factor_value = large_buys / buys;
    //         }
    //     }
    //     prev_exch_ts = exch_ts;
        
    // };

private:
    int64_t lookback;
    GaiaCircularBuffer<double> qty_buffer;
    int64_t prev_exch_ts = 0;
    double this_qty = 0.0;
    int64_t threshold;
    double d_threshold;
    
    int64_t exch_ts;
    double total_buys = 0, total_large_buys = 0;
    double total_buys_c = 0.0;
    double total_large_buys_c = 0.0;
    constexpr static double min_precision = 1e-4;
};
                              
