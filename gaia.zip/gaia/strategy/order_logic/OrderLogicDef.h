#ifndef __ORDER_LOGIC_DEF_H__
#define __ORDER_LOGIC_DEF_H__
#include "OrderLogic.h"

STANDARD_ORDER_LOGIC_DECLARATION(Arbitrage)
STANDARD_ORDER_LOGIC_DECLARATION(Kronos)

STANDARD_ORDER_LOGIC_DECLARATION(Zeus)
STANDARD_ORDER_LOGIC_DECLARATION(Apollo)


// define empty order logic
STANDARD_ORDER_LOGIC_DECLARATION(Empty)
class EmptyImpl : public OrderLogic {
public:
    EmptyImpl(){}
    virtual ~EmptyImpl(){}
    void Init(const Config& _conf) override {}
    void Process(TickEventType _cur_tick_type, const SymId &_cur_tick_sid, StrategyFields &strategy_fields) override {}
};
STANDARD_ORDER_LOGIC_DEFINITION(Empty, EmptyImpl)

#endif
