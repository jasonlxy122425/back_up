#include "Factor.h"
#include "Ema.h"
#include <cmath>
#include "GaiaCircularBuffer.h"

class TradeAggQtyFactor : public FactorInterface
{
public:
    TradeAggQtyFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
    };

    virtual std::string gen_name() {;
        return std::string("TradeAggQtyFactor");
    }

    virtual void calculate(const FactorInput& input_data) {
        auto &trade = input_data.cur_contract->trade;
        bool isAggTrade = (trade.side == prev_side);
        if (isAggTrade){
            if (trade.side == Side::BUY){
                factor_value += trade.qty;
            }
            else if (trade.side == Side::SELL){
                factor_value -= trade.qty;
            }
        }
        else {
            factor_value = 0.0;
        }
        prev_exch_ts = trade.exch_ts;
        prev_side = trade.side;
    };



private:
    int64_t prev_exch_ts = 0;
    Side prev_side = Side::SELL;
};
                              
