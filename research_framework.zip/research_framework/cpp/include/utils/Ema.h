#pragma once

class Ema {
public:
    Ema() : initialized(false) {}
    void init(double _decay) { decay = _decay; }
    void init(int64_t _decay) { decay = _decay / 100.0; }
    
    double update(double value) {
        if (!initialized) {
            initialized = true;
            ema = 0.0;
        } 
        ema = decay * ema + (1 - decay) * value;
        return ema;
    }

    double get() const {
        return ema;
    }
private:
    double decay;
    double ema;
    bool initialized;
};      