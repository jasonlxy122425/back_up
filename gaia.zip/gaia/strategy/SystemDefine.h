#pragma once

#ifdef USE_AS
#include "base/fmt_headers.h"
#include "secmaster/sec_master.h"
#include "secmaster/sec_master_loader.h"
#include "trading/order_manager.h"
#include "base/config.h"
#include "base/time.h"
#include "base/types.h"
#include "md/types.h"
#include "trading/types.h"
#include "trading/algo_trading_script.h"
#include "trading/engine.h"
namespace trading_system = algostation;
namespace trading_system_st = algostation::trading;
namespace trading_system_md = algostation::md;
namespace trading_system_ts = algostation::trading;
namespace algostation::md {
    using FlatOrderbook = Orderbook;
    using FlatOrderbookData = Orderbook;
    using MessageType = MktDataType;
    using Message = MktDataBase;
}
namespace algostation::trading {
    using Strategy = AlgoTradingScript;
}
#else
#include "alphaless/secmaster/sec_master.h"
#include "alphaless/secmaster/sec_master_loader.h"
#include "alphaless/base/types.h"
#include "alphaless/base/double_ops.h"
#include "alphaless/base/optim.h"
#include "alphaless/base/config.h"
#include "alphaless/base/logging_config.h"
#include "alphaless/md/messages.h"
#include "alphaless/md/lowband_messages.h"
#include "alphaless/st/strategy.h"
#include "alphaless/st/engine.h"
#include "alphaless/st/order_manager.h"
namespace trading_system = alphaless;
namespace trading_system_st = alphaless::st;
namespace trading_system_md = alphaless::md;
namespace trading_system_ts = alphaless::ts::server;
#endif

using namespace trading_system;
using namespace trading_system_md;
using namespace trading_system_st;