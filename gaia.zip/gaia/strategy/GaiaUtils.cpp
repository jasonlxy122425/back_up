#include "GaiaUtils.h"
#include "StrategyFields.h"
#include "SpdLogger.h"
#include "SpdLoggerMessage.h"

std::atomic<bool> GaiaUtils::ForceExitFlag = false;
std::atomic<bool> GaiaUtils::FullLiquidationFlag = false;
std::atomic<bool> GaiaUtils::LiquidateRiskFlag = false;

std::unordered_map<std::string, std::tuple<double, double>> GaiaUtils::fees_table = {
    {"Binance_LinearSwap_All", std::make_tuple(-0.5, 1.62)},

    {"Binance_InverseSwap_All", std::make_tuple(-0.8, 2.4)},

    {"Bybit_LinearSwap_BTCUSDT", std::make_tuple(-0.5, 1.5)},
    {"Bybit_LinearSwap_ETHUSDT", std::make_tuple(-0.5, 1.5)},
    {"Bybit_LinearSwap_All", std::make_tuple(-1.0, 1.5)},

    {"Bybit_InverseSwap_All", std::make_tuple(-1.0, 2.5)},

    {"Okex_LinearSwap_All", std::make_tuple(-0.2, 2.0)},

    {"Okex_InverseSwap_All", std::make_tuple(0.0, 2.5)},

    {"Gateio_LinearSwap_BTC_USDT", std::make_tuple(-0.9, 1.8)},
    {"Gateio_LinearSwap_ETH_USDT", std::make_tuple(-0.9, 1.8)},
    {"Gateio_LinearSwap_All", std::make_tuple(-1.25, 2.25)},

    {"Kucoin_LinearSwap_All", std::make_tuple(0, 3)},

    {"Dydx_LinearSwap_All", std::make_tuple(0.0, 0.0)},
    {"Hyperliquid_LinearSwap_All", std::make_tuple(1.5,4.5)}
};

void GaiaUtils::initSymbolRisk(struct StrategyFields* strategy_fields) {
    struct ContractInfo* orderContract = strategy_fields->contract_info;
    if(!strategy_fields->sym_risk.avg_price_initialized) {
        double mid_price = 0;
        if(strategy_fields->use_gob_for_ref_price) {
            mid_price = (GaiaUtils::BookGetBestBidPrice(orderContract) + GaiaUtils::BookGetBestAskPrice(orderContract)) / 2.0;
        } else {
            mid_price = (orderContract->quote.best_bid.price + orderContract->quote.best_ask.price) / 2.0;
        }
        if(strategy_fields->sym_risk.symbol_risk > eps or strategy_fields->sym_risk.symbol_risk < -eps) {
            strategy_fields->sym_risk.symbol_risk_avg_price = mid_price;
        } else {
            strategy_fields->sym_risk.symbol_risk_avg_price = 0;
        }

        strategy_fields->sym_risk.avg_price_initialized = true;

        if(strategy_fields->contract_info->is_reverse) {
            if(strategy_fields->sym_risk.contract_usd_risk > eps or strategy_fields->sym_risk.contract_usd_risk < -eps) {
                strategy_fields->sym_risk.symbol_risk = strategy_fields->sym_risk.contract_usd_risk / strategy_fields->sym_risk.symbol_risk_avg_price;
                strategy_fields->sym_risk.contract_coin_risk = strategy_fields->sym_risk.symbol_risk;
            } else {
                strategy_fields->sym_risk.symbol_risk = 0;
            }
            std::cout << strategy_fields->contract_info->symbol_info->mirana_ticker << " init avg price: " << strategy_fields->sym_risk.symbol_risk_avg_price << ", symbol_risk: " << strategy_fields->sym_risk.symbol_risk 
                        << ", contract_usd risk:" << strategy_fields->sym_risk.contract_usd_risk << std::endl;
        }
    }

}

void GaiaUtils::calculatePnlByTrade(struct StrategyFields* strategy_fields, const double filledQty, const int filledSideInt, const double filledPrice, const double filledFee)
{
    // std::cout << __FUNCTION__ << std::endl;
    struct ContractInfo* orderContract = strategy_fields->contract_info;

    // init pos avg price due to large price diff between history pos and cur price
    if(!strategy_fields->sym_risk.avg_price_initialized) {
        initSymbolRisk(strategy_fields);
    }

    double close_coin = 0;
    double new_avg_price = 0;
    double filled_coin = 0;
    double new_symbol_risk = 0;
    double new_usd_risk = 0;
    if(!orderContract->is_reverse) {
        filled_coin = filledQty * orderContract->symbol_info->multiplier;
        new_symbol_risk = strategy_fields->sym_risk.symbol_risk + filledSideInt * filledQty * orderContract->symbol_info->multiplier;
        new_usd_risk = strategy_fields->sym_risk.contract_usd_risk + filledSideInt * filledQty * orderContract->symbol_info->multiplier * filledPrice;
    } else {
        filled_coin = filledQty * orderContract->symbol_info->multiplier / filledPrice;
        new_symbol_risk = strategy_fields->sym_risk.symbol_risk + filledSideInt * filledQty * orderContract->symbol_info->multiplier / filledPrice;
        new_usd_risk = strategy_fields->sym_risk.contract_usd_risk + filledSideInt * filledQty * orderContract->symbol_info->multiplier;
    }

    if(filledSideInt == 1)
    {
        if(strategy_fields->sym_risk.symbol_risk < -eps)
        {
            close_coin = std::min(filled_coin, -strategy_fields->sym_risk.symbol_risk);

        }
    }else if(filledSideInt == -1)
    {
        if(strategy_fields->sym_risk.symbol_risk > eps)
        {
            close_coin = std::min(filled_coin, strategy_fields->sym_risk.symbol_risk);
        }
    }

    if(close_coin > eps or close_coin < -eps) {
        if(!orderContract->is_reverse) {
            strategy_fields->sym_risk.realized_pnl += (strategy_fields->sym_risk.symbol_risk_avg_price - filledPrice) * close_coin * filledSideInt - filledFee;
        } else {
            double close_usd = close_coin * filledPrice;
            strategy_fields->sym_risk.realized_pnl += (1 / filledPrice - 1 / strategy_fields->sym_risk.symbol_risk_avg_price) * filledSideInt * close_usd - filledFee;
        }
    }

    // adjust symbol_risk and avg_price

    if(close_coin > eps && new_symbol_risk * strategy_fields->sym_risk.symbol_risk > eps)
    {
        // if close partial pos , we will keep pos avg price
        new_avg_price = strategy_fields->sym_risk.symbol_risk_avg_price;
    }else if (close_coin > eps && new_symbol_risk * strategy_fields->sym_risk.symbol_risk < -eps){
        // if close all pos and open new pos on other side use fill price as pos avg price
        new_avg_price = filledPrice;
    }else
    {
        // open position will recalc avg price
        new_avg_price = 
            (std::abs(strategy_fields->sym_risk.symbol_risk) * strategy_fields->sym_risk.symbol_risk_avg_price + filledPrice * filled_coin) / (std::abs(strategy_fields->sym_risk.symbol_risk) + filled_coin);

        if(strategy_fields->contract_info->is_reverse) {
            new_avg_price = 
                (std::abs(strategy_fields->sym_risk.contract_usd_risk) * strategy_fields->sym_risk.symbol_risk_avg_price + filledPrice * filledQty * orderContract->symbol_info->multiplier) / (std::abs(strategy_fields->sym_risk.contract_usd_risk) + filledQty * orderContract->symbol_info->multiplier);
        }
        // std::cout << "new_avg_price: " << new_avg_price << ", sym_risk: " << strategy_fields->sym_risk.symbol_risk << ", filled_coin: " << filled_coin << ", filledPrice: " << filledPrice << std::endl;
    }


    if(strategy_fields->contract_info->is_reverse) {
        if(std::abs(new_usd_risk) < eps)
        {
            new_avg_price = 0.0;
        }
    } else {
        if(std::abs(new_symbol_risk) < eps)
        {
            new_avg_price = 0.0;
        }
    }

    strategy_fields->sym_risk.symbol_risk_avg_price = new_avg_price;


    // std::cout << "new sym_risk: " << new_symbol_risk << ","
    //             << "strategy sym_risk: " << strategy_fields->sym_risk.symbol_risk << ","
    //             << "new avg_price: " << new_avg_price << ","
    //             << "unreadlized_pnl: " << strategy_fields->sym_risk.unrealized_pnl << std::endl;
}

void GaiaUtils::calculateRealTimePnl(struct StrategyFields* strategy_fields)
{
    struct ContractInfo* orderContract = strategy_fields->contract_info;
    double trade_price = orderContract->trade.price;
    if(trade_price < eps) {
        return;
    }

    if(!strategy_fields->sym_risk.avg_price_initialized) {
        double mid_price = 0;
        if(strategy_fields->use_gob_for_ref_price) {
            mid_price = (GaiaUtils::BookGetBestBidPrice(orderContract) + GaiaUtils::BookGetBestAskPrice(orderContract)) / 2.0;
        } else {
            mid_price = (orderContract->quote.best_bid.price + orderContract->quote.best_ask.price) / 2.0;
        }
        if(strategy_fields->sym_risk.symbol_risk > eps or strategy_fields->sym_risk.symbol_risk < -eps) {
            strategy_fields->sym_risk.symbol_risk_avg_price = mid_price;
        } else {
            strategy_fields->sym_risk.symbol_risk_avg_price = 0;
        }

        strategy_fields->sym_risk.avg_price_initialized = true;
    }

    if(!orderContract->is_reverse) {
        strategy_fields->sym_risk.unrealized_pnl = strategy_fields->sym_risk.symbol_risk * (trade_price - strategy_fields->sym_risk.symbol_risk_avg_price);
    } else {
        // std::cout << "trade_price: " << trade_price << ", symbol_risk_avg_price: " << strategy_fields->sym_risk.symbol_risk_avg_price << ", symbol_risk: " << strategy_fields->sym_risk.symbol_risk << ", unrealized_pnl: " << strategy_fields->sym_risk.unrealized_pnl << std::endl;

        if(strategy_fields->sym_risk.symbol_risk_avg_price < eps) {
            strategy_fields->sym_risk.unrealized_pnl = 0;
        } else {
            strategy_fields->sym_risk.unrealized_pnl = strategy_fields->sym_risk.contract_usd_risk * (1/trade_price - 1/strategy_fields->sym_risk.symbol_risk_avg_price);
        }
    }
}

void GaiaUtils::updatePosition(struct StrategyFields* strategy_fields, const double filledQty, const int filledSideInt, const double filledPrice, const double filledFee)
{
    struct ContractInfo* orderContract = strategy_fields->contract_info;

    double realisedPnl = 0;
    double averageEntryPrice= 0.0;

    if (!orderContract->is_reverse) {
        calculatePnlByTrade(strategy_fields, filledQty, filledSideInt, filledPrice, filledFee);
        strategy_fields->sym_risk.symbol_risk += filledSideInt * filledQty * orderContract->symbol_info->multiplier;
        calculateRealTimePnl(strategy_fields);
    } else {
        calculatePnlByTrade(strategy_fields, filledQty, filledSideInt, filledPrice, filledFee);
        strategy_fields->sym_risk.contract_usd_risk += filledSideInt * filledQty * orderContract->symbol_info->multiplier;
        strategy_fields->sym_risk.contract_coin_risk += filledSideInt * filledQty * orderContract->symbol_info->multiplier / filledPrice;

        if(std::abs(strategy_fields->sym_risk.contract_usd_risk) < eps) {
            strategy_fields->sym_risk.contract_coin_risk = 0.0;
            strategy_fields->sym_risk.symbol_risk = 0.0;
        } else {
            strategy_fields->sym_risk.symbol_risk = strategy_fields->sym_risk.contract_coin_risk;
        }

        calculateRealTimePnl(strategy_fields);
    }

    LOG_AUTO(PositionUpdateMsg, orderContract->symbol_info->mirana_ticker.c_str(), orderContract->logic_acct_id,
                                        filledQty, filledPrice, filledSideInt, filledFee,
                                        strategy_fields->sym_risk.symbol_risk_avg_price, strategy_fields->sym_risk.symbol_risk, strategy_fields->sym_risk.unrealized_pnl,
                                        strategy_fields->sym_risk.realized_pnl, strategy_fields->sym_risk.max_pnl);
}

void GaiaUtils::updateNetPos(StrategyFields* strategy_fields, double pos_size, double avg_entry_price) {
    struct ContractInfo *orderContract = strategy_fields->contract_info;
    if (orderContract->is_reverse) {
        if(std::fabs(pos_size) > eps && std::fabs(avg_entry_price) < eps) {
            std::cout << "error: avg_entry_price for cm is zero, pos_size: " << pos_size << ","
                      << "avg_entry_price: " << avg_entry_price << std::endl;
            abort();
        }
        strategy_fields->sym_risk.contract_coin_risk = pos_size * orderContract->symbol_info->multiplier / avg_entry_price;
        strategy_fields->sym_risk.contract_usd_risk = pos_size * orderContract->symbol_info->multiplier;

        strategy_fields->sym_risk.symbol_risk = strategy_fields->sym_risk.contract_coin_risk;
    } else if (orderContract->symbol_info->product_type == ProductType::SPOT) {
        strategy_fields->sym_risk.symbol_risk = pos_size;
    } else {
        strategy_fields->sym_risk.symbol_risk = pos_size * orderContract->symbol_info->multiplier;
    }

    if(std::fabs(strategy_fields->sym_risk.initial_pos_coin) > eps) {
        if (orderContract->is_reverse) {
            strategy_fields->sym_risk.contract_usd_risk -= strategy_fields->sym_risk.initial_pos_coin * avg_entry_price / orderContract->symbol_info->multiplier;

            strategy_fields->sym_risk.contract_coin_risk -= strategy_fields->sym_risk.initial_pos_coin;
            strategy_fields->sym_risk.symbol_risk = strategy_fields->sym_risk.contract_coin_risk;
        } else {
            strategy_fields->sym_risk.symbol_risk -= strategy_fields->sym_risk.initial_pos_coin / orderContract->symbol_info->multiplier;
        }
    }
}

const SymbolInfo* GaiaUtils::getSecMasterSymbol(std::string s) {
    std::cout << "symbol: " << s << std::endl;

    SymId sid = SecMaster::instance().FindSid(s); // or sec_master()->FindSid();


    return getSecMasterSymbol(sid);
}

const SymbolInfo* GaiaUtils::getSecMasterSymbol(SymId sid) {

    const SymbolInfo *symbol = SecMaster::instance().GetSymbol(sid);

    std::cout << "========================================================================================================================" << std::endl;

    std::cout << "base_sid： " << symbol->base_sid << std::endl;
    std::cout << "md_ticker " << symbol->md_ticker << std::endl;
    std::cout << "exch " << symbol->exch << std::endl;
    std::cout << "exch_ticker " << symbol->exch_ticker << std::endl;
    std::cout << "maker_fee_rate " << symbol->maker_fee_rate << std::endl;
    std::cout << "margin_rate " << symbol->margin_rate << std::endl;
    std::cout << "min_notional " << symbol->min_notional << std::endl;
    std::cout << "min_qty " << symbol->min_qty << std::endl;
    std::cout << "max_qty " << symbol->max_qty << std::endl;
    std::cout << "mirana_ticker " << symbol->mirana_ticker << std::endl;
    std::cout << "multiplier " << symbol->multiplier << std::endl;
    std::cout << "prc_tick_size " << symbol->prc_tick_size << std::endl;
    std::cout << "product_type " << symbol->product_type << std::endl;
    std::cout << "qty_tick_size " << symbol->qty_tick_size << std::endl;
    std::cout << "sid " << symbol->sid << std::endl;
    std::cout << "symbol_type " << symbol->symbol_type << std::endl;
    std::cout << "taker_fee_rate " << symbol->taker_fee_rate << std::endl;
    std::cout << "underlier_sid " << symbol->underlier_sid << std::endl;

    if (sid == INVALID_SID)
    {
        throw std::runtime_error("Invalid sid");
    }
    return symbol;
}

void GaiaUtils::GetInFlightOrderCoin(StrategyFields &strategy_fields, double &bid_inflight_coin, double &ask_inflight_coin)
{
    ContractInfo *contract = strategy_fields.contract_info;
    OrderManager::OrderMap orderMap = strategy_fields.order_manager->orders();
    for (auto &pair : orderMap)
    {
        uint64_t client_order_id = pair.first;
        Order *alphalessOrder = pair.second;

        if(strategy_fields.contract_info->symbol_info->sid == alphalessOrder->sid())
        {
            if (alphalessOrder->side() == Side::BUY) {
                if(contract->is_reverse) {
                    bid_inflight_coin += (alphalessOrder->leaves_qty() * contract->symbol_info->multiplier / alphalessOrder->price());
                } else {
                    bid_inflight_coin += (alphalessOrder->leaves_qty() * contract->symbol_info->multiplier);
                }
            }
            else if (alphalessOrder->side() == Side::SELL) {
                if(contract->is_reverse) {
                    ask_inflight_coin += (alphalessOrder->leaves_qty() * contract->symbol_info->multiplier / alphalessOrder->price());
                } else {
                    ask_inflight_coin += (alphalessOrder->leaves_qty() * contract->symbol_info->multiplier);
                }
            }
        }

    }
}

void GaiaUtils::GetInFlightOrderUsd(StrategyFields &strategy_fields, double &bid_inflight_coin, double &ask_inflight_coin)
{
    ContractInfo *contract = strategy_fields.contract_info;
    OrderManager::OrderMap orderMap = strategy_fields.order_manager->orders();
    // alphaless order map
    for (auto &pair : orderMap)
    {
        uint64_t client_order_id = pair.first;
        Order *alphalessOrder = pair.second;

        if(strategy_fields.contract_info->symbol_info->sid == alphalessOrder->sid())
        {
            if (alphalessOrder->side() == Side::BUY) {
                if(contract->is_reverse) {
                    bid_inflight_coin += (alphalessOrder->leaves_qty() * contract->symbol_info->multiplier);
                } else {
                    bid_inflight_coin += (alphalessOrder->leaves_qty() * contract->symbol_info->multiplier * alphalessOrder->price());
                }
            }
            else if (alphalessOrder->side() == Side::SELL) {
                if(contract->is_reverse) {
                    ask_inflight_coin += (alphalessOrder->leaves_qty() * contract->symbol_info->multiplier);
                } else {
                    ask_inflight_coin += (alphalessOrder->leaves_qty() * contract->symbol_info->multiplier * alphalessOrder->price());
                }
            }
        }

    }
}

int GaiaUtils::GetInFlightOrderCount(StrategyFields &strategy_fields)
{
    int order_count = 0;
    const OrderManager::OrderMap order_map = strategy_fields.order_manager->orders();
    for (const auto &iter : order_map)
    {
        Order *currentOrder = iter.second;
        if(strategy_fields.contract_info->symbol_info->sid == currentOrder->sid())
        {

            std::cout << "has sid:" << currentOrder->sid() << ","
                      << "order_id:" << currentOrder->client_order_id().value << std::endl;
            order_count = order_count + 1;
        }
    }

    return order_count;
}

void GaiaUtils::GetCoinSizeFromNotional(StrategyFields &strategy_fields, const double &notional_size, const double &order_coin)
{
    double referencePrice = 0;
    if(strategy_fields.use_gob_for_ref_price) {
        referencePrice = (GaiaUtils::BookGetBestBidPrice(strategy_fields.contract_info) + GaiaUtils::BookGetBestAskPrice(strategy_fields.contract_info)) / 2.0;
    } else {
        referencePrice = (strategy_fields.contract_info->quote.best_bid.price + strategy_fields.contract_info->quote.best_ask.price) / 2.0;
    }
    strategy_fields.order_size_coin = notional_size / referencePrice;
    strategy_fields.order_size_usd = notional_size;
    if(strategy_fields.contract_info->is_reverse) {
        strategy_fields.order_size_coin = order_coin;
        strategy_fields.order_size_usd = order_coin * referencePrice;
    }
}

Nanoseconds GaiaUtils::GetSysTimestamp()
{
#ifdef SIM_MODE
    return trading_system::Clock::instance().trade_ns();
#else

    return trading_system::GetTscTimestamp();
    // return trading_system::GetSysTimestamp();
#endif
}

Nanoseconds GaiaUtils::GetRealSysTimestamp()
{
    return trading_system::GetTscTimestamp();
    // return trading_system::GetSysTimestamp();
}

std::string GaiaUtils::NanoTimestampToString(Nanoseconds nanoTimestamp)
{
    auto nanoTimePoint = std::chrono::time_point<std::chrono::system_clock, std::chrono::nanoseconds>{std::chrono::nanoseconds{nanoTimestamp}};
    auto timeT = std::chrono::system_clock::to_time_t(nanoTimePoint);
    auto nanoSeconds = std::chrono::duration_cast<std::chrono::nanoseconds>(nanoTimePoint.time_since_epoch()).count() % 1000000000;
    std::ostringstream oss;
    oss << std::put_time(std::localtime(&timeT), "%Y-%m-%d %H:%M:%S") << "." << std::setw(9) << std::setfill('0') << nanoSeconds;
    return oss.str();
}

md::Trade GaiaUtils::convertOrderUpdateToTrade(Order *order, const OrderStatusUpdate &update, md::Trade &custom_trade)
{
    ExecLiquidityType lqd_type = update.lqd_type;

    if ((order->side() == Side::BUY) && (lqd_type == ExecLiquidityType::MAKER))
        custom_trade.side = Side::SELL;
    else if ((order->side() == Side::SELL) && (lqd_type == ExecLiquidityType::MAKER))
        custom_trade.side = Side::BUY;
    else if (lqd_type == ExecLiquidityType::TAKER)
        custom_trade.side = order->side();

    custom_trade.sid = order->sid();
    custom_trade.price = update.fill_price;
    custom_trade.qty = update.fill_qty;
    strcpy(custom_trade.trade_id, std::string(update.trade_id).c_str());
    custom_trade.private_fill = 1;
    custom_trade.exch_ts = update.exch_ts;
    custom_trade.cb_start_ts = order->latency_record().points.get(trading_system_st::LatencyTracePointType::MD_CB_START);
    custom_trade.qs_send_ts = order->latency_record().points.get(trading_system_st::LatencyTracePointType::MD_QS_SEND_TIME);
    custom_trade.parser_end_ts = order->latency_record().points.get(trading_system_st::LatencyTracePointType::MD_PARSER_END);
    custom_trade.recv_ts = GaiaUtils::GetSysTimestamp();
    custom_trade.src = md::Source::UNKNOWN;
    custom_trade.msg_type = md::MessageType::TRADE;
    return custom_trade;
}


void GaiaUtils::getFeeRate(double &makerFeeBps, double &takerFeeBps, const std::string mirana_ticker)
{
    std::string feeTicker = "";

    auto it = fees_table.find(mirana_ticker);

    // which symbol or market ticker belongs to
    if (it != fees_table.end())
    {
        feeTicker = mirana_ticker;
    }
    else
    {
        if (mirana_ticker.find("Binance_LinearSwap") != std::string::npos)
        {
            feeTicker = "Binance_LinearSwap_All";
        }
        else if (mirana_ticker.find("Binance_InverseSwap") != std::string::npos)
        {
            feeTicker = "Binance_InverseSwap_All";
        }
        else if (mirana_ticker.find("Bybit_LinearSwap") != std::string::npos)
        {
            feeTicker = "Bybit_LinearSwap_All";
        }
        else if (mirana_ticker.find("Bybit_InverseSwap") != std::string::npos)
        {
            feeTicker = "Bybit_InverseSwap_All";
        }
        else if (mirana_ticker.find("Okex_LinearSwap") != std::string::npos)
        {
            feeTicker = "Okex_LinearSwap_All";
        }
        else if (mirana_ticker.find("Okex_InverseSwap") != std::string::npos)
        {
            feeTicker = "Okex_InverseSwap_All";
        }
        else if (mirana_ticker.find("Dydx_LinearSwap") != std::string::npos)
        {
            feeTicker = "Dydx_LinearSwap_All";
        }
        else if (mirana_ticker.find("Gateio_LinearSwap") != std::string::npos)
        {
            feeTicker = "Gateio_LinearSwap_All";
        }
        else if (mirana_ticker.find("Kucoin_LinearSwap") != std::string::npos)
        {
            feeTicker = "Kucoin_LinearSwap_All";
        }
        else if (mirana_ticker.find("Hyperliquid_LinearSwap") != std::string::npos)
        {
            feeTicker = "Hyperliquid_LinearSwap_All";
        }
    }

    if (feeTicker == "")
    {
        makerFeeBps = 0.0;
        takerFeeBps = 0.0;
        std::cout << mirana_ticker << " fee could not be found" << std::endl;
    }
    else
    {
        auto maker_taker_fees_tup = fees_table[feeTicker];
        makerFeeBps = std::get<0>(maker_taker_fees_tup);
        takerFeeBps = std::get<1>(maker_taker_fees_tup);
        // std::cout << mirana_ticker << " maker fee is: " << makerFeeBps << " taker fee is: " << takerFeeBps << " fee ticker: " << feeTicker << std::endl;
    }
}

void GaiaUtils::FillBalance(StrategyFields &strategy_fields, LogicAcctId logic_acct_id, SymId sid, double total, double available, Nanoseconds exch_ts) {
    if(logic_acct_id != strategy_fields.contract_info->logic_acct_id) {
        return;
    }

    if(strategy_fields.contract_info->is_reverse || strategy_fields.contract_info->symbol_info->mirana_ticker.find("_Spot_") != std::string::npos) {
        if (sid == strategy_fields.contract_info->symbol_info->base_sid) {
            strategy_fields.sym_risk.wallet_balance = total;
            strategy_fields.sym_risk.avail_balance = available;
            strategy_fields.sym_risk.balance_ts = exch_ts;
        }
    } else {
        if (sid == strategy_fields.contract_info->symbol_info->quote_sid) {
            double prev_wallet_balance = strategy_fields.sym_risk.wallet_balance;
            strategy_fields.sym_risk.wallet_balance = total;
            strategy_fields.sym_risk.avail_balance = available;
            strategy_fields.sym_risk.balance_ts = exch_ts;
        }
    }
}
