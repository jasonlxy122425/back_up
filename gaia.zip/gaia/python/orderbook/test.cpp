#include <unordered_map>
#include <fstream>
#include "alphaless/md/messages.h"
#include "GaiaOrderbook.h"
#include "GaiaOrderbookManager.h"
#include "alphaless/secmaster/sec_master_loader.h"
using namespace alphaless;
using namespace alphaless::md;

int main() {
    auto config = Config::LoadFile("/mnt/share/syq/secmaster.yml");
    SecMasterLoader loader;
    auto secmaster_config = config.Get<Config>("secmaster");
    std::string secmaster_url = secmaster_config.Get<std::string>("base_url");
    std::vector<std::string> exchanges = secmaster_config.Get<std::vector<std::string>>("exchanges");

    for ( auto exchange : exchanges )
    {
        while(!loader.LoadHttp(secmaster_url, alphaless::ParseExchange(exchange))) {
            std::cout << "reloading " << exchange << std::endl;
        }

        std::cout << "loaded " << exchange << std::endl;
    }

    std::ifstream file("./data_set.csv");
    if (!file.is_open()) {
        std::cout << "Failed to open file." << std::endl;
        return 1;
    }

    std::vector<std::unordered_map<std::string, std::string>> data;

    std::string line;
    bool first = true;
    std::vector<std::string> header;
    while (std::getline(file, line)) {
        std::string cell;
        std::stringstream lineStream(line);

        int idx = 0;
        std::string ob_str = "";
        std::unordered_map<std::string, std::string> row;
        if(first) {
            while (std::getline(lineStream, cell, ',')) {
                if(idx == 0) header.push_back("index");
                else header.push_back(cell);
                idx++;
            }
            first = false;
            continue;
        }
        
        while (std::getline(lineStream, cell, ',')) {
            if(ob_str != "") {
                ob_str += "," + cell;
                if(cell.find("]\"") != std::string::npos) {
                    row[header[idx]] = ob_str;
                    ob_str = "";
                    idx++;
                }
                continue;
            }

            if(cell.find("\"[") != std::string::npos) {
                ob_str = cell;
                continue;
            }

            row[header[idx]] = cell;

            idx++;
        }
        data.push_back(row);
    }

    std::cout << "data size: " << data.size() << std::endl;

    std::ofstream output("./gaia_ob_cpp.csv");
    GaiaOrderbookManager ob_manager;
    for(auto &row : data) {
        int64_t recv_ts = std::atoll(row["recv_ts_ns"].c_str());
        int64_t exch_ts = std::atoll(row["exch_ts"].c_str());
        int64_t qs_send_ts = std::atoll(row["qs_send_ts"].c_str());
        uint32_t sid = std::atoi(row["sid"].c_str());
        if(row["type"] == "trade") {
            Trade trade;
            trade.price = std::atof(row["price"].c_str());
            trade.qty = std::atof(row["qty"].c_str());
            trade.side = row["side"] == "Buy" ? Side::BUY : Side::SELL;
            trade.sid = sid;
            trade.recv_ts = recv_ts;
            trade.exch_ts = exch_ts;
            trade.set_trade_id(row["trade_id"]);
            // Process trade here
            ob_manager.OnTrade(trade);
        } else if(row["type"] == "ob") {
            FlatOrderbookData ob;
            ob.seq_id = std::atol(row["seq_id"].c_str());
            ob.recv_ts = recv_ts;
            ob.exch_ts = exch_ts;
            ob.sid = sid;
            auto array_parser = [&](std::string &str) {
                std::vector<double> result;
                std::stringstream ss(str);
                std::string token;
                while (std::getline(ss, token, ',')) {
                    if(token.find("[") != std::string::npos) {
                        token = token.substr(2);
                    } else if (token.find("]") != std::string::npos) {
                        token = token.substr(0, token.size() - 2);
                    }
                    double f_token = std::atof(token.c_str());
                    result.push_back(f_token);
                }
                return result;
            };
            auto ask_price = array_parser(row["ask_price"]);
            auto ask_qty = array_parser(row["ask_qty"]);
            auto bid_price = array_parser(row["bid_price"]);
            auto bid_qty = array_parser(row["bid_qty"]);

            ob.num_bids = bid_price.size();
            ob.num_asks = ask_price.size();
            for(int i = 0; i < ob.num_bids; i++) {
                PriceLevel level;
                level.price = bid_price[i];
                level.qty = bid_qty[i];
                ob.bid_data()[i] = level;
            }
            for(int i = 0; i < ob.num_asks; i++) {
                PriceLevel level;
                level.price = ask_price[i];
                level.qty = ask_qty[i];
                ob.ask_data()[i] = level;
            }
            // Process orderbook here
            ob_manager.OnOrderbook(ob.get_view());
        } else if(row["type"] == "bq") {
            BestQuote bq;
            bq.seq_id = std::atol(row["seq_id"].c_str());
            bq.recv_ts = recv_ts;
            bq.exch_ts = exch_ts;
            bq.sid = sid;
            bq.best_bid.price = std::atof(row["best_bid_price"].c_str());
            bq.best_bid.qty = std::atof(row["best_bid_qty"].c_str());
            bq.best_ask.price = std::atof(row["best_ask_price"].c_str());
            bq.best_ask.qty = std::atof(row["best_ask_qty"].c_str());
            // Process best quote here
            ob_manager.OnBestQuote(bq);
        }
        GaiaOrderbook &gaia_ob = ob_manager.Get(sid);
        output << gaia_ob.exch_ts() << ","
               << recv_ts << ","
               << qs_send_ts << ","
               << sid << ","
               << row["src"] << ","
               << gaia_ob.seq_id() << ",";
        for(int i = 0; i < gaia_ob.num_asks(); i++) {
            if(i == 0) output << "\"[";
            if(i == gaia_ob.num_asks() - 1) output << gaia_ob.ask(i).price << "]\",";
            else output << gaia_ob.ask(i).price << ",";
        }
        for(int i = 0; i < gaia_ob.num_asks(); i++) {
            if(i == 0) output << "\"[";
            if(i == gaia_ob.num_asks() - 1) output << gaia_ob.ask(i).qty << "]\",";
            else output << gaia_ob.ask(i).qty << ",";
        }
        for(int i = 0; i < gaia_ob.num_bids(); i++) {
            if(i == 0) output << "\"[";
            if(i == gaia_ob.num_bids() - 1) output << gaia_ob.bid(i).price << "]\",";
            else output << gaia_ob.bid(i).price << ",";
        }
        for (int i = 0; i < gaia_ob.num_bids(); i++) {
            if (i == 0) output << "\"[";
            if (i == gaia_ob.num_bids() - 1) output << gaia_ob.bid(i).qty << "]\",";
            else output << gaia_ob.bid(i).qty << ",";
        }

        output << row["zone"] << "," << row["type"] << std::endl;
    }

    file.close();

    return 0;
}
