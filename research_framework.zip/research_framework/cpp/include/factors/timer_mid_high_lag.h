#include "Factor.h"
#include "Ema.h"
#include <cmath>
#include "GaiaCircularBuffer.h"
#include "GaiaUtils.h"

class TimerMidHighLagFactor : public FactorInterface
{
public:
    TimerMidHighLagFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
        backward_ms = config.Get<int64_t>("backward_ms");
        RegisterTimer(timer_interval_ms*1e6L);
        int64_t buffer_size = backward_ms/timer_interval_ms;
        mid_buffer.setSize(buffer_size, 0.0);
    };

    virtual std::string gen_name() {;
        return std::string("TimerMidHighLagFactor") + "@backward_ms=" + std::to_string(backward_ms);
    }

    virtual void calculate(const FactorInput& input_data) {
        auto &gob = input_data.cur_contract->alphaBook;
        mid_price = (gob->bid(0).price + gob->ask(0).price)/2.0;
        if (mid_buffer.isFull() != false){
            factor_value = mid_price - mid_buffer.max();
        }
        else {
            factor_value = 0.0;
        }
        
    };
    void OnTimer() override {
        if (mid_price > MinErr){
            mid_buffer.push(mid_price);
        }
    }

private:
    GaiaCircularBuffer<double> mid_buffer;
    int64_t timer_interval_ms = 100;
    int64_t backward_ms;
    double mid_price = 0.0;
};
                              
