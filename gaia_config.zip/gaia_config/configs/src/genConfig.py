import os
import sys
import argparse
import pwd
import pandas as pd

cur_dir = os.getcwd()
sys.path.append(f"{cur_dir}/")
sys.path.append('./ServerInfo/')
from ServerInfo import *
from ConfigBuilder import ConfigBuilder

if __name__ == "__main__":

    parser = argparse.ArgumentParser(description='deploy args')
    parser.add_argument('-t','--tag_module_name', type=str, help='input a name of tag module')
    parser.add_argument('-c','--config_path', type=str, default=cur_dir, help='config path')
    parser.add_argument('-s','--source_config_path', type=str, default="./ServerConfigs/", help='config path')

    args = parser.parse_args()

    ConfigBuilder("./ServerInfo/AccountInfo.json").buildConfigs(args.tag_module_name, f"{args.config_path}/{args.tag_module_name}", f"{args.source_config_path}")