#include "OrderLogicFactory.h"
#include "OrderLogic.h"
#include "OrderLogicDef.h"
#include <iostream>

OrderLogic* OrderLogicFactory::generateOrderLogic(const std::string& order_logic_code) {

    std::cout << "generating order_logic_code: " << order_logic_code << std::endl;
    if (order_logic_code == "Arbitrage") {
        return new Arbitrage();
    }
    else if (order_logic_code == "Kronos") {
        return new Kronos();
    }
    else if (order_logic_code == "Zeus") {
        return new Zeus();
    }
    else if (order_logic_code == "Apollo") {
        return new Apollo();
    }
    else if (order_logic_code == "Empty") {
        return new Empty();
    }
    else
    {
        std::cout << "error: cannot find order logic: " << order_logic_code << std::endl;
        abort();
    }

    return nullptr;
}
