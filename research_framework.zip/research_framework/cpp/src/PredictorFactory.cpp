#include "Predictor.h"
#include "PredictorFactory.h"
#include "ArbitragePredictorImpl.h"
#include "KronosGeneralPredictorImpl.h"
#include "LeadLagPredictorImpl.h"
#include "ApolloPredictorImpl.h"

Predictor* PredictorFactory::generatePredictor(const std::string& strategy_code)
{

    std::cout << "generating predictor: " << strategy_code << std::endl;

    if (strategy_code == "Arbitrage") {
        return new ArbitragePredictorImpl();
    }
    else if (strategy_code == "Kronos") {
        return new KronosGeneralPredictorImpl();
    }
    else if (strategy_code == "LeadLag") {
        return new LeadLagPredictorImpl();
    }
    else if (strategy_code == "Apollo") {
        return new ApolloPredictorImpl();
    }

    return nullptr;
}
