#include "Factor.h"
#include "Ema.h"
#include <cmath>
#include "GaiaCircularBuffer.h"

class TradeABuyChgFactor : public FactorInterface
{
public:
    TradeABuyChgFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
        lookback = config.Get<int64_t>("lookback");
        last_prc_buffer.setSize(lookback, 0.0);
    };

    virtual std::string gen_name() {;
        return std::string("TradeABuyChgFactor") + "@lookback=" + std::to_string(lookback);
    }

    virtual void calculate(const FactorInput& input_data) {
        factor_value = 0.0;
        auto &trade = input_data.cur_contract->trade;
        exch_ts = trade.exch_ts;
        
        if (trade.side == Side::BUY) {
            if (exch_ts != prev_exch_ts) {
                if (last_prc_buffer.isFull()) {
                    double oldest_price = last_prc_buffer[0];
                    double next_oldest_price = last_prc_buffer[1];
                    
                    if (std::abs(oldest_price - next_oldest_price) > MinErr) {
                        prc_chg_cnt -= 1.0;
                    }
                }
                
                double prev_price = last_prc_buffer.size() > 0 ? last_prc_buffer[-1] : trade.price;
                if (std::abs(trade.price - prev_price) > MinErr) {
                    prc_chg_cnt += 1.0;
                }
                
                last_prc_buffer.push(trade.price);
            } else {
                if (last_prc_buffer.size() > 1) {
                    double old_latest = last_prc_buffer[-1];
                    double prev_price = last_prc_buffer[-2];
                    bool old_changed = std::abs(old_latest - prev_price) > MinErr;
                    
                    bool new_changed = std::abs(trade.price - prev_price) > MinErr;
                    
                    if (old_changed && !new_changed) {
                        prc_chg_cnt -= 1.0;
                    } else if (!old_changed && new_changed) {
                        prc_chg_cnt += 1.0;
                    }
                }
                
                last_prc_buffer[-1] = trade.price;
            }
        }

        if (last_prc_buffer.isFull()) {
            factor_value = prc_chg_cnt;
        }
        
        prev_exch_ts = exch_ts;
    }

    // virtual void calculate(const FactorInput& input_data) {
    //     factor_value = 0.0;
    //     auto &trade = input_data.cur_contract->trade;
    //     int64_t exch_ts = trade.exch_ts;
    //     if (trade.side == Side::BUY){
    //         if (std::abs(exch_ts - prev_exch_ts) > MinErr){
    //             last_prc_buffer.push(trade.price);
    //         }
    //         else {
    //             last_prc_buffer[-1] = trade.price;
    //         }
    //     }
    //     if(last_prc_buffer.isFull() != false){
    //         factor_value = 0.0;
    //         for (int i=1; i < lookback; i++){
    //             if (std::abs(last_prc_buffer[-i] - last_prc_buffer[-i-1]) > MinErr){
    //                 factor_value += 1;
    //             }
    //         }
    //     }
    //     prev_exch_ts = exch_ts;
    // };

private:
    int64_t lookback;
    int64_t prev_exch_ts = 0;
    GaiaCircularBuffer<double> last_prc_buffer;

    int64_t exch_ts = 0;
    double prc_chg_cnt = 0.0;
};

