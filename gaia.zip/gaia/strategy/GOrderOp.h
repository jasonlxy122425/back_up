#pragma once
#include "GOrderState.h"

class GOrderOp {
public:
    static GOrderState* InsertOrder(StrategyFields& strategy_fields, double price, double size, Side side, OrderType type, TimeInForce tif, PositionOffset offset = PositionOffset::UNKNOWN, int strategy_order_type = 0, bool is_warmup = false);

    static bool CancelOrder(GOrderState* orderState);

    static bool ReplaceOrder(GOrderState* orderState, double price, double size);

    static int64_t cancel_interval;
    static bool round_for_hyperliquid;
    static void setCancelInterval(int64_t &_interval);
    static void setRoundForHyperliquid(bool round) {
        round_for_hyperliquid = round;
    }

    static bool canCancelOrder(struct GOrderState* orderState);
};