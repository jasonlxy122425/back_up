#pragma once

#include "Predictor.h"
#include "arb/PriceEmaByTime.h"
#include "arb/StdExpWeightedBps.h"
#include "SpdLoggerMessage.h"
#include "SpdLogger.h"
class ArbitragePredictorImpl : public Predictor
{
public:
    ArbitragePredictorImpl(){};

    virtual void Init(const Config &_conf, const Config &_pred_conf) {
        std::cout << "init predictor config" << std::endl;
        auto orderConfig = _conf.Get<Config>("order_logic_config");
        auto commonConfig = orderConfig.Get<Config>("common");
        notional_size = GaiaUtils::GetParam<double>(commonConfig, "notional_size");
        coin_size = GaiaUtils::GetParam<double>(commonConfig, "custom_coin_size");
        std::cout << "predictor notional size: " << notional_size << ", coin_size: " << coin_size << std::endl;

        auto conf = _conf.Get<Config>("predictor_config");
        quote_symbol = GaiaUtils::GetParam<std::string>(conf, "quoter_symbol");
        hedge_symbol = GaiaUtils::GetParam<std::string>(conf, "hedger_symbol");
        try {
            quote_coin_ref_mode = GaiaUtils::GetParam<int>(conf, "quote_coin_ref_mode");
            if(quote_coin_ref_mode != 0) quote_coin_ref_symbol = GaiaUtils::GetParam<std::string>(conf, "quote_coin_ref_symbol");
        } catch(...) {
            quote_coin_ref_symbol = "";
            quote_coin_ref_mode = 0;
        }
        if(quote_coin_ref_mode != 0) std::cout << "predictor quote_coin_ref_mode: " << quote_coin_ref_mode << ", quote_coin_ref_symbol: " << quote_coin_ref_symbol << std::endl;
        quote_coin_ref_ratio = 1;

        int64_t calculate_interval_ns = GaiaUtils::GetParam<int64_t>(conf, "calculate_interval_ns");
        int64_t exp_base_num_price = GaiaUtils::GetParam<int64_t>(conf, "exp_base_num_price");
        int64_t exp_base_num_notional = GaiaUtils::GetParam<int64_t>(conf, "exp_base_num_notional");

        int64_t stdExp_long_interval = GaiaUtils::GetParam<int64_t>(conf, "stdExp_long_interval");
        int64_t stdExp_long_base = GaiaUtils::GetParam<int64_t>(conf, "stdExp_long_base");
        int64_t stdExp_short_interval = GaiaUtils::GetParam<int64_t>(conf, "stdExp_short_interval");
        int64_t stdExp_short_base = GaiaUtils::GetParam<int64_t>(conf, "stdExp_short_base");
        int64_t stdExp_shortSpike_interval = GaiaUtils::GetParam<int64_t>(conf, "stdExp_shortSpike_interval");
        int64_t stdExp_shortSpike_base = GaiaUtils::GetParam<int64_t>(conf, "stdExp_shortSpike_base");  

        // hedge price / quote price
        hedge_ref_quote_price_ratio = GaiaUtils::GetParam<double>(conf, "hedger_ref_quoter_price_ratio");

        // theo edge alpha
        theo_edge_lower_level = GaiaUtils::GetParam<double>(conf, "theo_edge_lower_level");
        theo_edge_upper_level = GaiaUtils::GetParam<double>(conf, "theo_edge_upper_level");

        Config tmp_conf;
        /*
                interval_ns = config.Get<int64_t>("interval_ns");
                exp_base = config.Get<double>("exp_base");
        */
        tmp_conf.Set("interval_ns", calculate_interval_ns);

        tmp_conf.Set("exp_base", exp_base_num_price);
        quote_mid_price_ema.Init(tmp_conf);
        hedge_mid_price_ema.Init(tmp_conf);

        tmp_conf.Set("exp_base", exp_base_num_notional);
        hedge_not_bid_diff_ema.Init(tmp_conf);
        hedge_not_ask_diff_ema.Init(tmp_conf);

        /*
        interval_ns = config.Get<int64_t>("interval_ns");
            exp_base = config.Get<double>("exp_base");
        */

        tmp_conf.Set("interval_ns", stdExp_long_interval);
        tmp_conf.Set("exp_base", stdExp_long_base);
        stdExp_long_quote.Init(tmp_conf);

        tmp_conf.Set("interval_ns", stdExp_short_interval);
        tmp_conf.Set("exp_base", stdExp_short_base);
        stdExp_short_quote.Init(tmp_conf);

        tmp_conf.Set("interval_ns", stdExp_shortSpike_interval);
        tmp_conf.Set("exp_base", stdExp_shortSpike_base);
        stdExp_shortSpike_quote.Init(tmp_conf);
        stdExp_shortSpike_basis.Init(tmp_conf);

        tmp_conf.Set("interval_ns", stdExp_long_interval);
        tmp_conf.Set("exp_base", stdExp_long_base);
        stdExp_long_basis.Init(tmp_conf);

        tmp_conf.Set("interval_ns", stdExp_short_interval);
        tmp_conf.Set("exp_base", stdExp_short_base);
        stdExp_short_basis.Init(tmp_conf);

        stdExp_long_quote_value = 0.0;
        stdExp_short_quote_value = 0.0;
        stdExp_shortSpike_quote_value = 0.0;
        stdExp_long_basis_value = 0.0;
        stdExp_short_basis_value = 0.0;
        stdExp_shortSpike_basis_value = 0.0;
        theo_edge_lower = 0.0;
        theo_edge_upper = 0.0;
    };

    virtual void getFactors(FactorOutputType &output) {
        output["stdExp_long_quote"] = stdExp_long_quote_value;
        // output["stdExp_short_quote"] = stdExp_short_quote_value;
        // output["stdExp_shortSpike_quote"] = stdExp_shortSpike_quote_value;
        output["stdExp_long_basis"] = stdExp_long_basis_value;
        // output["stdExp_short_basis"] = stdExp_short_basis_value;
        // output["stdExp_shortSpike_basis"] = stdExp_shortSpike_basis_value;
        // output["price_mid_ema"] = price_mid_ema;
        output["theo_edge_lower"] = theo_edge_lower;
        output["theo_edge_upper"] = theo_edge_upper;
        output["quote_bid"] = quote_bid;
        output["quote_ask"] = quote_ask;
        output["quote_bz"] = quote_bz;
        output["quote_az"] = quote_az;
        output["hedge_bid"] = hedge_bid;
        output["hedge_ask"] = hedge_ask;
        output["hedge_bz"] = hedge_bz;
        output["hedge_az"] = hedge_az;
        output["quote_theo_edge_1"] = quote_theo_edge_1;
        output["quote_theo_edge_5"] = quote_theo_edge_5;
        output["quote_theo_edge_10"] = quote_theo_edge_10;
        output["quote_theo_edge_30"] = quote_theo_edge_30;
        output["quote_theo_edge_50"] = quote_theo_edge_50;
        output["num_hedge_bid_levels"] = num_hedge_bid_levels;
        output["num_hedge_ask_levels"] = num_hedge_ask_levels;
        // output["md_latency"] = md_latency;
    }

    void Calculate() override {
	    HandleData();
    }
    /*
    void OnTrade(const md::Trade &trade) override {
        HandleData();
    };
    void OnOrderbook(const md::FlatOrderbook &ob) override {
        HandleData();
    };
    void OnBestQuote(const md::BestQuote &quote) override {
        HandleData();
    };
    */

    void HandleData() {
        void CalcQuoteCoinRefRatio();
        if (!CheckData()) return;

        PrepareInput();
        Predict();
    }

    void CalcQuoteCoinRefRatio() {
        if (quote_coin_ref_mode != 0 && !quote_coin_ref_symbol.empty()) {
            ContractInfo *quote_coin_ref_ci = (*state->contract_map)[quote_coin_ref_symbol];
            if(quote_coin_ref_mode == 1) {
                quote_coin_ref_ratio = 1 * GaiaUtils::GetMidPrice(quote_coin_ref_ci);
            } else if (quote_coin_ref_mode == -1) {
                quote_coin_ref_ratio = 1 / GaiaUtils::GetMidPrice(quote_coin_ref_ci);
            }
        }
    }

    bool CheckData() {
        ContractInfo *quote_contract = (*state->contract_map)[quote_symbol];
        ContractInfo *hedge_contract = (*state->contract_map)[hedge_symbol];

        if(state->cur_tick_sid != quote_contract->symbol_info->sid && state->cur_tick_sid != hedge_contract->symbol_info->sid) {
            return false;
        }

        state->signal.pred_value = 0;
        state->signal.bid_pred_value = 0;
        state->signal.ask_pred_value = 0;
        state->signal.vol_long = 0;
        state->signal.vol_short = 0;

        quote_bid = GaiaUtils::BookGetBestBidPrice(quote_contract);
        quote_ask = GaiaUtils::BookGetBestAskPrice(quote_contract);
        quote_bz = GaiaUtils::BookGetBestBidSize(quote_contract);
        quote_az = GaiaUtils::BookGetBestAskSize(quote_contract);
        quote_last_price = GaiaUtils::TradeGetPrice(quote_contract);

        hedge_bid = GaiaUtils::BookGetBestBidPrice(hedge_contract) * quote_coin_ref_ratio / hedge_ref_quote_price_ratio;
        hedge_ask = GaiaUtils::BookGetBestAskPrice(hedge_contract) * quote_coin_ref_ratio / hedge_ref_quote_price_ratio;
        hedge_bz = GaiaUtils::BookGetBestBidSize(hedge_contract) *  hedge_ref_quote_price_ratio;
        hedge_az = GaiaUtils::BookGetBestAskSize(hedge_contract) *  hedge_ref_quote_price_ratio;
        hedge_last_price = GaiaUtils::TradeGetPrice(hedge_contract) * quote_coin_ref_ratio / hedge_ref_quote_price_ratio;

        quote_mid = (quote_bid + quote_ask) / 2;
        hedge_mid = (hedge_bid + hedge_ask) / 2;
        quote_spread = (quote_ask-quote_bid)/quote_mid*10000;

        num_quote_bid_levels = GaiaUtils::BookGetNumBidLevels(quote_contract);
        num_quote_ask_levels = GaiaUtils::BookGetNumAskLevels(quote_contract);
        num_hedge_bid_levels = GaiaUtils::BookGetNumBidLevels(hedge_contract);
        num_hedge_ask_levels = GaiaUtils::BookGetNumAskLevels(hedge_contract);

        if(quote_bid < eps || quote_ask < eps || hedge_bid < eps || hedge_ask < eps) return false;

        // check price ratio
        if(std::abs(quote_mid - hedge_mid) / hedge_mid > 0.5)
        {
            std::cout << "Risk Check: hedge_ref_quote_price_ratio in predictor error, "
                      << "hedge_ref_quote_price_ratio: " << hedge_ref_quote_price_ratio << ","
                      << "hedge_mid: " << hedge_mid << ","
                      << "quote_mid: " << quote_mid << ","
                      << "hedge recv_ts: " << hedge_contract->latency_record.mkt_data.mkt_recv_ts << ","
                      << "quote recv_ts: " << quote_contract->latency_record.mkt_data.mkt_recv_ts
                      << std::endl;
            return false;
        }

        return true;
    }

    void PrepareInput() {
        ContractInfo *quote_contract = (*state->contract_map)[quote_symbol];
        ContractInfo *hedge_contract = (*state->contract_map)[hedge_symbol];

        factor_input.current_time = state->latency_record->mkt_data.mkt_recv_ts;
        md_latency = hedge_contract->latency_record.mkt_data.mkt_recv_ts - hedge_contract->latency_record.mkt_data.mkt_exch_ts;
        // stdExp
        if  (state->cur_tick_sid == quote_contract->symbol_info->sid) {
            // quote
            factor_input.price = quote_mid;
            stdExp_long_quote.calculate(factor_input);
            stdExp_short_quote.calculate(factor_input);
            stdExp_shortSpike_quote.calculate(factor_input);

            // basis
            factor_input.price = quote_mid-hedge_mid;
            stdExp_long_basis.calculate(factor_input);
            stdExp_short_basis.calculate(factor_input);
            stdExp_shortSpike_basis.calculate(factor_input);

            // assign value
            stdExp_long_quote_value = stdExp_long_quote.get_value()/quote_mid*10000;
            stdExp_short_quote_value = stdExp_short_quote.get_value()/quote_mid*10000;
            stdExp_shortSpike_quote_value = stdExp_shortSpike_quote.get_value()/quote_mid*10000;
            stdExp_long_basis_value = stdExp_long_basis.get_value()/quote_mid*10000;
            stdExp_short_basis_value = stdExp_short_basis.get_value()/quote_mid*10000;
            stdExp_shortSpike_basis_value = stdExp_shortSpike_basis.get_value()/quote_mid*10000;
        }

        // hedge notional bid ask
        hedge_bid_turnover = 0; hedge_ask_turnover = 0;
        hedge_notional_bid = 0; hedge_notional_ask = 0;
        double hedge_multiplier = hedge_contract->symbol_info->multiplier;
        for (int i = 0; i < num_hedge_bid_levels; i++) {
            if(hedge_contract->is_reverse) {
                // coin based
                hedge_bid_turnover += hedge_contract->alphaBook->bid(i).qty*hedge_multiplier / hedge_contract->alphaBook->bid(i).price;
                if(hedge_bid_turnover >= coin_size) {
                    hedge_notional_bid = hedge_contract->alphaBook->bid(i).price;
                    break;
                }
            } else {
                // u based
                hedge_bid_turnover += hedge_contract->alphaBook->bid(i).qty*hedge_contract->alphaBook->bid(i).price*hedge_multiplier;
                if (hedge_bid_turnover >= notional_size) {
                    hedge_notional_bid = hedge_contract->alphaBook->bid(i).price;
                    break;
                }
            }
        }
        if (hedge_notional_bid < eps) {
            hedge_notional_bid = hedge_contract->alphaBook->bid(num_hedge_bid_levels-1).price;
        }
        for (int i = 0; i < num_hedge_ask_levels; i++) {
            if(hedge_contract->is_reverse) {
                // coin based
                hedge_ask_turnover += hedge_contract->alphaBook->ask(i).qty*hedge_multiplier / hedge_contract->alphaBook->ask(i).price;
                if (hedge_ask_turnover >= coin_size) {
                    hedge_notional_ask = hedge_contract->alphaBook->ask(i).price;
                    break;
                }
            } else {
                // u based
                hedge_ask_turnover += hedge_contract->alphaBook->ask(i).qty*hedge_contract->alphaBook->ask(i).price*hedge_multiplier;

                if (hedge_ask_turnover >= notional_size) {
                    hedge_notional_ask = hedge_contract->alphaBook->ask(i).price;
                    break;
                }
            }

        }
        if (hedge_notional_ask < eps) {
            hedge_notional_ask = hedge_contract->alphaBook->ask(num_hedge_ask_levels-1).price;
        }
        hedge_notional_bid = hedge_notional_bid * quote_coin_ref_ratio / hedge_ref_quote_price_ratio;
        hedge_notional_ask = hedge_notional_ask * quote_coin_ref_ratio / hedge_ref_quote_price_ratio;

        factor_input.price = quote_mid;
        quote_mid_price_ema.calculate(factor_input);

        factor_input.price = hedge_mid;
        hedge_mid_price_ema.calculate(factor_input);

        factor_input.price = hedge_bid - hedge_notional_bid;
        hedge_not_bid_diff_ema.calculate(factor_input);

        factor_input.price = hedge_notional_ask - hedge_ask;
        hedge_not_ask_diff_ema.calculate(factor_input);

        // quote theo edge
        quote_bid_turnover = 0; quote_bz_total = 0; quote_ask_turnover = 0; quote_az_total = 0;
        // bid side
        for (int i = 0; i < num_quote_bid_levels; i++) {
            quote_bz_total += quote_contract->alphaBook->bid(i).qty;
            quote_bid_turnover += quote_contract->alphaBook->bid(i).qty*quote_contract->alphaBook->bid(i).price;
            if (i == theo_edge_lower_level-1) {
                if (quote_bz_total > eps) {
                    theo_edge_lower_bid = quote_bid_turnover/quote_bz_total;
                    theo_edge_lower_bz = quote_bz_total;
                }
            }
            if (i == theo_edge_upper_level-1) {
                if (quote_bz_total > eps) {
                    theo_edge_upper_bid = quote_bid_turnover/quote_bz_total;
                    theo_edge_upper_bz = quote_bz_total;
                }
            }
            if (i == 4) {
                if (quote_bz_total > eps) {
                    quote_bid_5 = quote_bid_turnover/quote_bz_total;
                    quote_bz_5 = quote_bz_total;
                }
            }
            else if (i == 9) {
                if (quote_bz_total > eps) {
                    quote_bid_10 = quote_bid_turnover/quote_bz_total;
                    quote_bz_10 = quote_bz_total;
                }
            }
            else if (i == 29) {
                if (quote_bz_total > eps) {
                    quote_bid_30 = quote_bid_turnover/quote_bz_total;
                    quote_bz_30 = quote_bz_total;
                }
            }
            else if (i == 49) {
                if (quote_bz_total > eps) {
                    quote_bid_50 = quote_bid_turnover/quote_bz_total;
                    quote_bz_50 = quote_bz_total;
                }
            }
        }
        // ask side
        for (int i = 0; i < num_quote_ask_levels; i++) {
            quote_az_total += quote_contract->alphaBook->ask(i).qty;
            quote_ask_turnover += quote_contract->alphaBook->ask(i).qty*quote_contract->alphaBook->ask(i).price;
            if (i == theo_edge_lower_level-1) {
                if (quote_bz_total > eps) {
                    theo_edge_lower_ask = quote_ask_turnover/quote_az_total;
                    theo_edge_lower_az = quote_az_total;
                }
            }
            if (i == theo_edge_upper_level-1) {
                if (quote_az_total > eps) {
                    theo_edge_upper_ask = quote_ask_turnover/quote_az_total;
                    theo_edge_upper_az = quote_az_total;
                }
            }
            if (i == 4) {
                if (quote_az_total > eps) {
                    quote_ask_5 = quote_ask_turnover/quote_az_total;
                    quote_az_5 = quote_az_total;
                }
            }
            else if (i == 9) {
                if (quote_az_total > eps) {
                    quote_ask_10 = quote_ask_turnover/quote_az_total;
                    quote_az_10 = quote_az_total;
                }
            }
            else if (i == 29) {
                if (quote_az_total > eps) {
                    quote_ask_30 = quote_ask_turnover/quote_az_total;
                    quote_az_30 = quote_az_total;
                }
            }
            else if (i == 49) {
                if (quote_az_total > eps) {
                    quote_ask_50 = quote_ask_turnover/quote_az_total;
                    quote_az_50 = quote_az_total;
                }
            }
        }
        quote_theo_edge_1 = ((quote_bid*quote_az+quote_ask*quote_bz)/(quote_bz+quote_az)/quote_mid-1)*10000;
        quote_theo_edge_5 = ((quote_bid_5*quote_az_5+quote_ask_5*quote_bz_5)/(quote_bz_5+quote_az_5)/quote_mid-1)*10000;
        quote_theo_edge_10 = ((quote_bid_10*quote_az_10+quote_ask_10*quote_bz_10)/(quote_bz_10+quote_az_10)/quote_mid-1)*10000;
        quote_theo_edge_30 = ((quote_bid_30*quote_az_30+quote_ask_30*quote_bz_30)/(quote_bz_30+quote_az_30)/quote_mid-1)*10000;
        quote_theo_edge_50 = ((quote_bid_50*quote_az_50+quote_ask_50*quote_bz_50)/(quote_bz_50+quote_az_50)/quote_mid-1)*10000;

        theo_edge_lower = ((theo_edge_lower_bid*theo_edge_lower_az+theo_edge_lower_ask*theo_edge_lower_bz)/(theo_edge_lower_bz+theo_edge_lower_az)/quote_mid-1)*10000;
        theo_edge_upper = ((theo_edge_upper_bid*theo_edge_upper_az+theo_edge_upper_ask*theo_edge_upper_bz)/(theo_edge_upper_bz+theo_edge_upper_az)/quote_mid-1)*10000;
    }


    void Predict(){
        // std::cout << "----- predictor -----" << std::endl; 
        ContractInfo *quote_contract = (*state->contract_map)[quote_symbol];
        ContractInfo *hedge_contract = (*state->contract_map)[hedge_symbol];

        // ema price diff edge
        double quote_mid_ema = quote_mid_price_ema.get_value();
        double hedge_mid_ema = hedge_mid_price_ema.get_value();
        price_mid_ema = quote_mid_ema - hedge_mid_ema;

        double adjusted_bid_price = hedge_bid + price_mid_ema;
        double adjusted_ask_price = hedge_ask + price_mid_ema;

        double saved_adjusted_bid_price = adjusted_bid_price;
        double saved_adjusted_ask_price = adjusted_ask_price;

        double bid_fee_bp = hedge_contract->takerFeeBps + quote_contract->makerFeeBps;
        double ask_fee_bp = hedge_contract->takerFeeBps + quote_contract->makerFeeBps;

        adjusted_bid_price = adjusted_bid_price * (1 - bid_fee_bp / ONE_BASE_POINT);
        adjusted_ask_price = adjusted_ask_price * (1 + ask_fee_bp / ONE_BASE_POINT);

        hedge_notional_bid_diff = hedge_not_bid_diff_ema.get_value();

        hedge_notional_ask_diff = hedge_not_ask_diff_ema.get_value();
        adjusted_bid_price = adjusted_bid_price - hedge_notional_bid_diff;
        adjusted_ask_price = adjusted_ask_price + hedge_notional_ask_diff;

        if(adjusted_bid_price >= adjusted_ask_price) {
            std::cout << "Predictor Risk Check : bid signal >= ask signal, bid signal:" << adjusted_bid_price << ","
                    << "ask signal:" << adjusted_ask_price << "," 
                    << "bid_fee_bp:" << bid_fee_bp << ","
                    << "ask_fee_bp:" << ask_fee_bp << "," 
                    << "bid signal before fee:" << saved_adjusted_bid_price << ","
                    << "ask signal before fee:" << saved_adjusted_ask_price << ","
                    << "quote_mid:" << quote_mid << ","
                    << "hedge_mid:" << hedge_mid << ","
                    << "quote_mid_ema:" << quote_mid_ema << ","
                    << "hedge_mid_ema:" << hedge_mid_ema << std::endl;
        }

        state->signal.spread = quote_spread;
        state->signal.theo_edge_lower = theo_edge_lower;
        state->signal.theo_edge_upper = theo_edge_upper;
        state->signal.bid_pred_value = adjusted_bid_price;
        state->signal.ask_pred_value = adjusted_ask_price;
        state->signal.vol_long = stdExp_long_basis_value;
        state->signal.vol_short = stdExp_short_basis_value;
    };

private:
    std::string    quote_symbol;
    std::string    hedge_symbol;
    std::string    quote_coin_ref_symbol;
    double notional_size;
    double coin_size;
    double hedge_ref_quote_price_ratio;
    double quote_coin_ref_ratio;
    int    quote_coin_ref_mode; // 1: multi, -1: divide, 0: inactive

    PriceEmaByTime quote_mid_price_ema;
    PriceEmaByTime hedge_mid_price_ema;
    PriceEmaByTime hedge_not_bid_diff_ema;
    PriceEmaByTime hedge_not_ask_diff_ema;

    StdExpWeightedBps stdExp_long_quote;
    StdExpWeightedBps stdExp_short_quote;
    StdExpWeightedBps stdExp_shortSpike_quote;
    StdExpWeightedBps stdExp_long_basis;
    StdExpWeightedBps stdExp_short_basis;
    StdExpWeightedBps stdExp_shortSpike_basis;

    double stdExp_long_quote_value;
    double stdExp_short_quote_value;
    double stdExp_shortSpike_quote_value;
    double stdExp_long_basis_value;
    double stdExp_short_basis_value;
    double stdExp_shortSpike_basis_value;

    double price_mid_ema;

    int theo_edge_lower_level, theo_edge_upper_level;
    double theo_edge_lower, theo_edge_upper;
    double theo_edge_lower_bid, theo_edge_lower_ask, theo_edge_lower_bz, theo_edge_lower_az;
    double theo_edge_upper_bid, theo_edge_upper_ask, theo_edge_upper_bz, theo_edge_upper_az;

    double hedge_bid_turnover, hedge_bz_total;
    double hedge_ask_turnover, hedge_az_total;
    double quote_bid_turnover, quote_bz_total;
    double quote_ask_turnover, quote_az_total;

    double hedge_bid_5, hedge_bid_10, hedge_bid_20, hedge_bid_30, hedge_bid_50;
    double hedge_ask_5, hedge_ask_10, hedge_ask_20, hedge_ask_30, hedge_ask_50;
    double hedge_bz_5, hedge_bz_10, hedge_bz_20, hedge_bz_30, hedge_bz_50;
    double hedge_az_5, hedge_az_10, hedge_az_20, hedge_az_30, hedge_az_50;
    double quote_bid_5, quote_bid_10, quote_bid_20, quote_bid_30, quote_bid_50;
    double quote_ask_5, quote_ask_10, quote_ask_20, quote_ask_30, quote_ask_50;
    double quote_bz_5, quote_bz_10, quote_bz_20, quote_bz_30, quote_bz_50;
    double quote_az_5, quote_az_10, quote_az_20, quote_az_30, quote_az_50;
    double quote_theo_edge_1, quote_theo_edge_5, quote_theo_edge_10, quote_theo_edge_30, quote_theo_edge_50;

    double quote_bid, quote_ask, quote_bz, quote_az, quote_last_price, quote_mid, quote_theo, quote_spread;
    double hedge_bid, hedge_ask, hedge_bz, hedge_az, hedge_last_price, hedge_mid, hedge_theo, hedge_spread;

    double hedge_notional_bid, hedge_notional_ask, hedge_notional_bid_diff, hedge_notional_ask_diff;
    int num_quote_bid_levels, num_quote_ask_levels, num_hedge_bid_levels, num_hedge_ask_levels;

    int64_t md_latency;
};
