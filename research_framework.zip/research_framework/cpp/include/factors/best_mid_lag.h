#include "Factor.h"
#include "Ema.h"
#include <cmath>
#include "GaiaCircularBuffer.h"

class BestMidLagFactor : public FactorInterface
{
public:
    BestMidLagFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
        lookback = config.Get<int64_t>("lookback");
        mid_prc_buffer.setSize(lookback, 0.0);

    };

    virtual std::string gen_name() {;
        return std::string("BestMidLagFactor") + "@lookback=" + std::to_string(lookback);
    }

    virtual void calculate(const FactorInput& input_data) {
        if (input_data.cur_contract->update_tick_type != TickEventType::TICK_BBO){
            return;
        }
        auto &ob = input_data.cur_contract->alphaBook;
        double mid_price = (ob->bid(0).price + ob->ask(0).price)/2.0; 
        mid_prc_buffer.push(mid_price);
        if(mid_prc_buffer.isFull() != false){
            factor_value = mid_prc_buffer.back() - mid_prc_buffer.front();
        }
        else {
            factor_value = 0.0;
        }
        
    };

private:
    int64_t lookback;
    GaiaCircularBuffer<double> mid_prc_buffer;
};
