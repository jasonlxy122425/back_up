import os
import alphaless as al
from alphaless import Exchange
from alphaless.secmaster import SecMaster, SymbolInfo, SecMasterLoader
import yaml
loader = SecMasterLoader()
config=None
loader.load_file('/mnt/share/shared_files/config/secmaster_backup/Binance')
loader.load_file('/mnt/share/shared_files/config/secmaster_backup/Bybit')
loader.load_file('/mnt/share/shared_files/config/secmaster_backup/Gateio')
loader.load_file('/mnt/share/shared_files/config/secmaster_backup/Okex')
loader.load_file('/mnt/share/shared_files/config/secmaster_backup/WooX')
loader.load_file('/mnt/share/shared_files/config/secmaster_backup/Kucoin')
loader.load_file('/mnt/share/shared_files/config/secmaster_backup/Hyperliquid')
loader.load_file('/mnt/share/shared_files/config/secmaster_backup/Lighter')
loader.load_file('/mnt/share/shared_files/config/secmaster_backup/Aster')
loader.load_file('/mnt/share/shared_files/config/secmaster_backup/HuobiGlobal')
loader.load_file('/mnt/share/shared_files/config/secmaster_backup/Bitget')

data_source_path = "/mnt/share/data/md_dump/"
as_data_source_path = "/mnt/share/data/logs/{}/{}/md_dump/"
ce_data_source_path = "/efs/core/"

exchange_placement = {
    "Binance" : "tky",
    "Kucoin" : "tky",
    "Gateio" : "tky",
    "WooX" : "tky",
    "Hyperliquid" : "tky",
    "Okex" : "hk",
    "Bybit" : "sg",
    "Hyperliquid" : "tky",
    "HuobiGlobal" : "tky",
    "Bitget" : "tky",
    "Lighter" : "tky",
    "Aster": "tky"
}

def findMdDumpFiles(date : str, target_exch : str, exch : str, type_str : str, symbol : str, sim_engine : str = "as", target_server : str = "", target_path : str = ""):
    if target_server == "":
        server = f"{exchange_placement[target_exch]}-"
    else:
        server = target_server

    mirana_ticker = f"{exch}_{type_str}_{symbol}"
    sid = SecMaster.instance.find_sid(mirana_ticker)
    target_file = None
    target_data_path = data_source_path
    if sim_engine == "as_prod":
        target_data_path = as_data_source_path.format(target_server, date)
        for files in os.listdir(target_data_path):
            if f".{sid}" in files:
                target_file = f"{target_data_path}/{files}"
                break
    else:
        for sub_dir in os.listdir(data_source_path):
            if f"{server}" not in sub_dir:
                continue
            new_path = f"{data_source_path}/{sub_dir}/{date}/"

            if os.path.exists(new_path) == False:
                continue

            #print(f"finding data in {new_path}, sid: {sid}")
            for sub_file in os.listdir(new_path):
                if f".{sid}" in sub_file:
                    target_file = f"{new_path}/{sub_file}"
                    break

    if target_file is None:
        print(f"error: cannot find data file for {mirana_ticker} {date} in {target_server}")
        exit(0)
    
    # find in ce path
    target_dmm_file = None
    if target_file is None:
        data_channel_name = f"{type_str.lower()}_qsl2"
        ce_data_path = f"{ce_data_source_path}/{exchange_placement[target_exch]}/{target_exch.lower()}/{data_channel_name}/{date}"
        for f in os.listdir(ce_data_path):
            if f".{sid}." in f and 'DMM' in f:
                target_dmm_file = f"{ce_data_path}/{f}"
            elif f".{sid}." in f:
                target_file = f"{ce_data_path}/{f}"

    if target_path != "" and target_file is not None:
        os.system(f"mkdir -p {target_path}/{server}/{date}")
        custom_target_file_path = f"{target_path}/{server}/{date}/{os.path.basename(target_file)}"
        #print(custom_target_file_path)
        need_download = False
        if os.path.exists(custom_target_file_path):
            if os.path.getsize(custom_target_file_path) < os.path.getsize(target_file):
                print(f"{custom_target_file_path} size is less than {target_file}  ")
                need_download = True
            else:
                target_file = custom_target_file_path
                need_download = False
        else:
            need_download = True

        if need_download:
            print(f"copy {target_file} to {custom_target_file_path}")
            os.system(f"cp {target_file} {custom_target_file_path}")
            target_file = custom_target_file_path
            print(f"copy done")
        
    
    return target_file, target_dmm_file
