#pragma once
#include "lightgbm/c_api.h"
#include <iostream>
#include <vector>
#include "GaiaModelBase.h"


class GaiaLightGbmWrapper : public GaiaModelBase
{
public:
    GaiaLightGbmWrapper(){}
    ~GaiaLightGbmWrapper(){}

    void Init(std::string &model_path, int feature_num, const Config &config = {}) final {
	    num_iterations = 1;
        int ret =LGBM_BoosterCreateFromModelfile(model_path.c_str(), &num_iterations, &booster);
        if(ret < 0) {
            std::cout << "booster create failed" << std::endl;
            exit(0);
        }

        std::cout << "lightgbm init feature_num: " << feature_num << std::endl;
        ret = LGBM_BoosterPredictForMatSingleRowFastInit(booster, C_API_PREDICT_NORMAL, 0,
                                                    -1, C_API_DTYPE_FLOAT64, feature_num,
                                                    "None", &fast_config, nullptr);

        if(ret < 0) {
            std::cout << "fast config init failed" << std::endl;
            exit(0);
        }
    }

    void Calculate(const std::vector<double> &input, std::vector<double> &output, int64_t &output_len) final {
        LGBM_BoosterPredictForMatSingleRowFast(fast_config, input.data(), &output_len, output.data());
    }

private:
    int num_iterations;

    BoosterHandle booster;
    FastConfigHandle fast_config;
};
