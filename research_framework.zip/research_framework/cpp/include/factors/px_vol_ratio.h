#include "Factor.h"
#include "Ema.h"
#include "GaiaCircularBuffer.h"
#include <cmath>

class PxVolRatioFactor: public FactorInterface
{
public:
    PxVolRatioFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
        lookback = config.Get<int64_t>("lookback");
        px_buffer.setSize(lookback, 0.0);
        vol_buffer.setSize(lookback, 0.0);

    };

    virtual std::string gen_name() {
        return std::string("PxVolRatioFactor") + '@' + std::to_string(lookback);
    }

    virtual void calculate(const FactorInput& input_data) {
        factor_value = 0.0;
        double trade_price = 0.0;
        double trade_qty = 0.0;
        if (input_data.cur_contract->update_tick_type == TickEventType::TICK_TRADE){
            trade_price = input_data.cur_contract->trade.price;
            trade_qty = input_data.cur_contract->trade.qty;
        }
        px_buffer.push(trade_price);
        vol_buffer.push(trade_qty); 
        if(px_buffer.isFull() != false){
            double front_px = px_buffer.front();
            if (front_px > MinErr && trade_price > MinErr){
                factor_value = (trade_price - front_px)/(vol_buffer.sum());
            }

        }
    };


private:
    int64_t lookback;
    GaiaCircularBuffer<double> px_buffer;
    GaiaCircularBuffer<double> vol_buffer;
};
                              
