#include "Factor.h"
#include "Ema.h"
#include "GaiaCircularBuffer.h"
#include <cmath>

class BookMidLagFactor : public FactorInterface
{
public:
    BookMidLagFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
        lookback = config.Get<int64_t>("lookback");
        mid_prc_buffer.setSize(lookback, 0.0);
    };

    virtual std::string gen_name() {
        return std::string("BookMidLagFactor") + "@lookback=" + std::to_string(lookback);
    }

    virtual void calculate(const FactorInput& input_data) { 
        bool is_orderbook = input_data.cur_contract->update_tick_type == TickEventType::TICK_OB;
        if (is_orderbook) {
            auto &ob = input_data.cur_contract->alphaBook;
            double mid_price = (ob->bid(0).price + ob->ask(0).price)/2.0; 
            mid_prc_buffer.push(mid_price);
            if(mid_prc_buffer.isFull() != false){
                factor_value = mid_prc_buffer.back() - mid_prc_buffer.front();
            }
            else {
                factor_value = 0.0;
            }
        } 
        else {
            return;
        }
    };


private:
    int64_t lookback;
    GaiaCircularBuffer<double> mid_prc_buffer;
};  