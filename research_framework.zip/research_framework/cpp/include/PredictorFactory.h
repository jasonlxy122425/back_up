#pragma once

#include "PredictorGeneral.h"
#include "Predictor.h"

class PredictorFactory {
public:
    static Predictor* generatePredictor(const std::string& order_logic_code);
};