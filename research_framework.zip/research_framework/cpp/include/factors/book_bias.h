#include "Factor.h"
#include "Ema.h"
#include <cmath>

class BookBiasFactor : public FactorInterface
{
public:
    BookBiasFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
        ema_int = config.Get<int16_t>("ema_int");
        ema.init(ema_int);

    };

    virtual std::string gen_name() {;
        return std::string("BookBiasFactor") + '@' + std::to_string(ema_int);
    }

    virtual void calculate(const FactorInput& input_data) {
        auto &gob = input_data.cur_contract->alphaBook;
        auto &demeter_data = input_data.cur_contract->demeter_data;
        double bid_delta = demeter_data->GetGobUpdateSum(Side::BUY, demeter::BookOrderType::Insert) - demeter_data->GetGobUpdateSum(Side::BUY, demeter::BookOrderType::Cancel) - demeter_data->GetGobUpdateSum(Side::BUY, demeter::BookOrderType::Match);
        double ask_delta = demeter_data->GetGobUpdateSum(Side::SELL, demeter::BookOrderType::Insert) - demeter_data->GetGobUpdateSum(Side::SELL, demeter::BookOrderType::Cancel) - demeter_data->GetGobUpdateSum(Side::SELL, demeter::BookOrderType::Match);
        factor_value = bid_delta - ask_delta;
        predict();
    };

    void predict() {
        ema.update(factor_value);
        factor_value = ema.get();

    }

private:
    int64_t ema_int;
    Ema ema;
};
                              
