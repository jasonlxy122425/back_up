#pragma once
#include <filesystem>
#include <sys/inotify.h>
#include <sys/epoll.h>

class InotifyHelper {
public:
    #define MAX_EPOLL_EVENTS_ONETIME 10
    #define INOTIFY_EVENT_SIZE sizeof(struct inotify_event)
    using InotifyCb = fastdelegate::FastDelegate2<std::string, uint32_t>;


    InotifyHelper(): inotify_fd(-1), epoll_fd(-1), epoll_file_size(0){}
    ~InotifyHelper(){
        for(auto & wfile : file_vec) {
            if(wfile.watch_fd > 0 && inotify_fd > 0) {
                inotify_rm_watch(inotify_fd, wfile.watch_fd);
            }
        }

        if(epoll_fd > 0) close(epoll_fd); 
    }
    void reset() {
        for(auto & wfile : file_vec) {
            if(wfile.watch_fd > 0 && inotify_fd > 0) {
                inotify_rm_watch(inotify_fd, wfile.watch_fd);
            }
        }
        file_vec.clear();

        if(inotify_fd > 0) {
            close(inotify_fd);
            inotify_fd = -1;
        }

        if(epoll_fd > 0) {
            close(epoll_fd);
            epoll_fd = -1;
            epoll_file_size = 0;
        }
    }

    void addFile(std::string filename, uint32_t _mask) {
        WatchFileStruct file_s;
        file_s.filename = filename;
        file_s.watch_fd = -1;
        file_s.mask = _mask;
        file_vec.push_back(file_s);

        checkEpollAndInotify();
    } 

    void checkEpollAndInotify() {

        if(epoll_fd < 0) {
            epoll_file_size = file_vec.size();
            epoll_fd = epoll_create(epoll_file_size);
            // if(epoll_fd<0) std::cout << "epoll create failed" << std::endl;
        }else if (epoll_file_size < file_vec.size()) {
            if(epoll_fd > 0) close(epoll_fd);
            epoll_file_size = file_vec.size();
            epoll_fd = epoll_create(epoll_file_size);
            // if(epoll_fd<0) std::cout << "epoll create failed" << std::endl;
        }

        if(inotify_fd < 0) {
            inotify_fd = inotify_init();
            struct epoll_event ev;
            ev.data.fd = inotify_fd;
            ev.events = EPOLLIN | EPOLLET;
            epoll_ctl(epoll_fd, EPOLL_CTL_ADD, inotify_fd, &ev);
        }
    }

    void setCb(InotifyCb& _cb) {
        cb = _cb;
    }

    void checkEvent() {
        checkEpollAndInotify();

        struct epoll_event events[MAX_EPOLL_EVENTS_ONETIME];
    
        int nfds = epoll_wait(epoll_fd, events, MAX_EPOLL_EVENTS_ONETIME, 0);
        struct inotify_event* event;
        for(int i = 0; i < nfds; ++i) {
            if(events[i].data.fd != inotify_fd) continue;

            int length = read(inotify_fd, readBuffer, sizeof(readBuffer));
            int nread = 0;
            while(nread < length) {
                event = (struct inotify_event*)&readBuffer[nread];

                for(auto &wfile : file_vec) {
                    if(wfile.watch_fd != event->wd) continue;
                    
                    if(event->mask & wfile.mask) {
			cb(wfile.filename, event->mask);
                    }

                    if(event->mask & (IN_DELETE | IN_DELETE_SELF | IN_MOVE | IN_MOVE_SELF)) {
                        wfile.need_remove_wd = true;
                    }
                }

                nread += INOTIFY_EVENT_SIZE + event->len;
            }

        }

        for(auto &wfile : file_vec) {
            checkWd(wfile);
        }
    }

private:
struct WatchFileStruct {
    std::string filename;
    uint32_t mask;
    int watch_fd = -1;
    bool need_remove_wd = false;
};

    void checkWd(WatchFileStruct &wfile) {
        if(wfile.need_remove_wd || wfile.watch_fd < 0) {
            if(wfile.watch_fd > 0) inotify_rm_watch(inotify_fd, wfile.watch_fd);
            wfile.watch_fd = inotify_add_watch(inotify_fd, wfile.filename.c_str(), wfile.mask);
            wfile.need_remove_wd = false;
            cb(wfile.filename, IN_CREATE);
        }
    }

    std::vector<WatchFileStruct> file_vec;

    int inotify_fd;
    int epoll_fd;
    int epoll_file_size;

    char readBuffer[4096];

    InotifyCb cb;
};

class FileWatcher {
public:
    using FileWatcherCb = fastdelegate::FastDelegate1<std::string>;
    FileWatcher() {
	isDelete = false;
        file_watcher_mask = IN_CLOSE_WRITE | IN_DELETE | IN_CREATE |
                                                IN_DELETE_SELF | IN_MOVE | IN_MOVE_SELF;
    }

    void init(std::string _config_file) {
        config_file = _config_file;

        inotify_helper.reset();
        inotify_helper.addFile(config_file, file_watcher_mask);

        inotify_cb = InotifyHelper::InotifyCb(this, &FileWatcher::onFileChange);
        inotify_helper.setCb(inotify_cb);
    }

    void onFileChange(std::string filename, uint32_t mask){
	if((mask & IN_DELETE) | (mask & IN_DELETE_SELF) | (mask & IN_MOVE_SELF) | (mask & IN_MOVED_FROM)) {
            isDelete = true;
            return;
	}

	if(!isDelete && (mask & IN_CREATE)) {
	   return;
	}

	if(!std::filesystem::exists(filename)) return;
	isDelete = false;
	if(mask & (IN_CREATE | IN_CLOSE_WRITE | IN_MOVED_TO)) cb(filename);
    }

    void setCb(FileWatcherCb& _cb) {
        cb = _cb;
    }

    void check(const int64_t &now) {
        inotify_helper.checkEvent();
    }

private:
    std::string config_file;
    uint32_t    file_watcher_mask;
    bool        isDelete;

    FileWatcherCb cb;
    InotifyHelper::InotifyCb inotify_cb;
    InotifyHelper inotify_helper;
};
