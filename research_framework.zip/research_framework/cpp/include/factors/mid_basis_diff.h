#include "Factor.h"
#include "Ema.h"
#include <cmath>

class MidBasisDiffFactor : public FactorInterface
{
public:
    MidBasisDiffFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
        asst_symbol = config.Get<std::string>("asst_symbol");
        ema_int = config.Get<int64_t>("ema_int");
        asst_sid = SecMaster::instance().FindSid(asst_symbol);
        ema.init(ema_int);

    };

    virtual std::string gen_name() {;
        return std::string("MidBasisDiffFactor") + '@' + std::to_string(ema_int) + '@' + asst_symbol;
    }

    virtual void calculate(const FactorInput& input_data) {
        factor_value = 0.0;
        double basis = 0.0;
        int64_t this_sid = input_data.cur_contract->symbol_info->sid;
        auto &gob = input_data.cur_contract->alphaBook;
        double mid_price = (gob->bid(0).price + gob->ask(0).price)/2.0;
        if (std::fabs(asst_sid - this_sid) < MinErr){
            asst_mid_price = mid_price;
        }
        else {
            target_mid_price = mid_price;
        }
        if (target_mid_price > MinErr && asst_mid_price > MinErr){
            basis = target_mid_price - asst_mid_price;
        }
        factor_value = basis - prev_basis;
        if (factor_value > MinErr){
            factor_value = std::log(factor_value + 1.0);
        }
        else if (factor_value < -MinErr){
            factor_value = -std::log(-factor_value + 1.0);
        }
        ema.update(factor_value);
        factor_value = ema.get();
        prev_basis = basis;
    };


private:
    int64_t ema_int;
    Ema ema;
    std::string asst_symbol;
    int64_t asst_sid;
    double target_mid_price = 0.0;
    double asst_mid_price = 0.0;
    double prev_basis = 0.0;
};
                              
