#pragma once

#include <unistd.h>
#include "SystemDefine.h"

class GAssistCalculator;

class GAssistThread {
public:
    GAssistThread(GAssistCalculator *calculator, std::string shm_name, int cpu);
    virtual ~GAssistThread() = default;

    void Run();
    void Stop();

    void set_symbols(const std::vector<SymId> &symbols) { symbols_ = symbols; }
    void set_batch_mode(bool batch_mode) { batch_mode_ = batch_mode; }
private:
    void AssistProcess();

    void InitMd();
    void AddCb();

    md::MdReader md_reader_;
    std::vector<SymId> symbols_;
    std::string shm_name_;
    GAssistCalculator *calculator_ = nullptr;

    bool batch_mode_ = false;

    int32_t cpu_ = -1;
    std::thread thread_;
    std::atomic<bool> stop_requested_{false};

};
