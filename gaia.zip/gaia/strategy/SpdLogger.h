#pragma once

#ifndef SPDLOG_ACTIVE_LEVEL
#define SPDLOG_ACTIVE_LEVEL SPDLOG_LEVEL_DEBUG 
#endif
#ifdef USE_AS
#ifndef SPDLOG_FMT_EXTERNAL
#define SPDLOG_FMT_EXTERNAL
#endif
#ifndef FMT_HEADER_ONLY
#define FMT_HEADER_ONLY
#endif
#endif
#include <spdlog/spdlog.h>
#include <spdlog/sinks/daily_file_sink.h>
#include <SPSC_Queue/SPSCVarQueue.h>
#include <thread>
#include <queue>
#include <mutex>
#include <atomic>
#include <condition_variable>
#include "SpdLoggerMessage.h"

class Logger {
public:
    static void Init(std::string _log_name);
    static void Init();
    static std::shared_ptr<spdlog::logger> GetLogger();

    template<typename T>
    static void PushLog(const T *_msg) {
        saveState((SpdLoggerMessageBase*)(_msg));
        log_queue_->blockPush(sizeof(T*), [&](auto *header){
            auto* data = (uint8_t*)(header + 1);
            std::memcpy(data, &_msg, sizeof(T*));
        });
    }

    static void setTag(std::string _tag, std::string _sub_tag);

    static bool only_log_exec;
private:
    using SpdLoggerQueue = SPSCVarQueue<4 * 1024 * 1024>;

    static void saveState(SpdLoggerMessageBase *_msg);
    static void LogThread();
    static void OptimizedLogThread();

    static std::shared_ptr<spdlog::logger> logger_;

    static std::unique_ptr<SpdLoggerQueue> log_queue_;
    static std::atomic<bool> log_running_;
    static std::atomic<bool> change_file_;

    static std::string log_name;
    static std::string tag;
    static std::string sub_tag;
};

// LOG_AUTO 宏定义，必须在 Logger 类定义之后
#define LOG_AUTO(MessageType, ...) \
    do { \
        auto* __log_msg_ptr__ = getSpdLoggerMessage<MessageType>(__VA_ARGS__); \
        Logger::PushLog(__log_msg_ptr__); \
    } while(0)
