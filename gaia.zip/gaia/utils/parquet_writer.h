#pragma once
#include "data_writer.h"
#include <arrow/api.h>
#include <arrow/io/api.h>
#include <parquet/arrow/writer.h>
#include <parquet/arrow/reader.h>
#include <parquet/exception.h>
#include <sstream>
#include <iomanip>


class ParquetWriter : public DataWriter {
public:
    ~ParquetWriter();
    void Initialize(const Config config) final;

    virtual void WriteData(const GaiaOrderbook&, SymId sid, double price, double qty,
                   Side side, std::string trade_id,double bid_price, double bid_qty,
                   double ask_price, double ask_qty,
                   const md::Kline &kline,
                   Message *msg, int64_t seq_id);
private:
    template<typename T>
    void AddColumn(std::string_view col, T type);


    void FlushRows();

    std::shared_ptr<arrow::io::FileOutputStream> outfile_;
    std::unique_ptr<parquet::arrow::FileWriter> writer_;

    std::shared_ptr<arrow::Schema> schema_;
    arrow::FieldVector fields_;
    std::vector<std::unique_ptr<arrow::ArrayBuilder>> columns_;
    std::unordered_map<std::string, int> column_idx_;

    std::shared_ptr<arrow::MemoryPool> pool;

    std::string file_name_;
    int idx_;
    size_t cur_row_size_;
    size_t batch_size_;
};
