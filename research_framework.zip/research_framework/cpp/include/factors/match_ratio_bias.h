#include "Factor.h"
#include "Ema.h"
#include <cmath>

class MatchRatioBiasFactor : public FactorInterface
{
public:
    MatchRatioBiasFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
        ema_int = config.Get<int16_t>("ema_int");
        ema_bid.init(ema_int);
        ema_ask.init(ema_int);
    };

    virtual std::string gen_name() {;
        return std::string("MatchRatioBiasFactor") + '@' + std::to_string(ema_int);
    }

    virtual void calculate(const FactorInput& input_data) {
        auto &gob = input_data.cur_contract->alphaBook;
        auto &demeter_data = input_data.cur_contract->demeter_data;
        double bid_match = demeter_data->GetGobUpdateSum(Side::BUY, demeter::BookOrderType::Match);
        double ask_match = demeter_data->GetGobUpdateSum(Side::SELL, demeter::BookOrderType::Match);
        double bid_qty = gob->bid(0).qty;
        double ask_qty = gob->ask(0).qty;
        ema_bid.update(std::log(bid_match+1.0)/std::log(bid_qty+1.0));
        ema_ask.update(std::log(ask_match+1.0)/std::log(ask_qty+1.0));
        factor_value = ema_bid.get() - ema_ask.get();
    };

private:
    int64_t ema_int;
    Ema ema_bid;
    Ema ema_ask;
};
                              
