#include "Factor.h"
#include "Ema.h"
#include <cmath>

class TradeSellBasisPhilFactor : public FactorInterface
{
public:
    TradeSellBasisPhilFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
        asst_symbol = config.Get<std::string>("asst_symbol");
        prc_ewma_int = config.Get<int64_t>("prc_ewma_int");
        asst_sid = SecMaster::instance().FindSid(asst_symbol);
        ewma_prc_target.init(prc_ewma_int);
        ewma_prc_asst.init(prc_ewma_int);

    };

    virtual std::string gen_name() {;
        return std::string("TradeSellBasisPhilFactor") + "@prc_ewma=" + std::to_string(prc_ewma_int) + "asst_symbol=" + asst_symbol;
    }

    virtual void calculate(const FactorInput& input_data) {
        factor_value = 0.0;
        int16_t current_sid = input_data.cur_contract->symbol_info->sid;
        auto &trade = input_data.cur_contract->trade;
        if (std::fabs(asst_sid - current_sid) < MinErr){
            if (trade.side == Side::SELL){
                asst_price = trade.price;
            }
        } 
        else {
            if (trade.side == Side::SELL){
                target_price = trade.price;
            }
        }
        if (target_price > MinErr && asst_price > MinErr){
            ewma_prc_target.update(target_price);
            ewma_prc_asst.update(asst_price);
            factor_value = std::log(ewma_prc_target.get()/target_price) - std::log(ewma_prc_asst.get()/asst_price);
        }
    };


private:
    int64_t prc_ewma_int;
    Ema ewma_prc_target;
    Ema ewma_prc_asst;
    std::string asst_symbol;
    int64_t asst_sid;
    double target_price = 0.0;
    double asst_price = 0.0;
};
                              
