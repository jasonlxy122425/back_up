#include "Factor.h"
#include "Ema.h"


class BookNumAsksFactor : public FactorInterface
{
public:
    BookNumAsksFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");

    };

    virtual std::string gen_name() {
        return std::string("BookNumAsksFactor");
    }

    virtual void calculate(const FactorInput& input_data) {
        auto &ob = input_data.cur_contract->alphaBook;
        factor_value = ob->num_asks();
    };


private:
};
                              
