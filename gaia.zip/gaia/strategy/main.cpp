#include <iostream>
#include <pthread.h>
#include <signal.h>
#include "Hedger.h"
#include "Gaia.h"
#include "GaiaUtils.h"
#include "SystemDefine.h"


void SignalHandler(int sig)
{
    switch(sig)
    {
        case SIGUSR1:
        {
            GaiaUtils::ForceExitFlag = true;
            break;
        }
        case SIGUSR2:
        {
            GaiaUtils::FullLiquidationFlag = true;
            break;
        }
        default:
            break;
    }
}

int main(int argc, char **argv)
{
    if (argc < 2)
    {
        std::cout << "need input config file" << std::endl;
        abort();
    }

    if(std::string(argv[1]) == "version") {
        std::cout << "gaia version:" << GAIA_VERSION << std::endl;
        return 0;
    }

    std::string config_path = argv[1];

    signal(SIGUSR1, SignalHandler);
    signal(SIGUSR2, SignalHandler);
    // configure alphaless logging level
    trading_system::ConfigLogging(LogLevel::INFO);

    // init secmaster
    SecMasterLoader loader;
    loader.LoadFile("/mnt/share/shared_files/config/secmaster_backup/Binance");
    loader.LoadFile("/mnt/share/shared_files/config/secmaster_backup/Bybit");
    loader.LoadFile("/mnt/share/shared_files/config/secmaster_backup/Gateio");
    loader.LoadFile("/mnt/share/shared_files/config/secmaster_backup/Okex");
    loader.LoadFile("/mnt/share/shared_files/config/secmaster_backup/WooX");
    loader.LoadFile("/mnt/share/shared_files/config/secmaster_backup/Kucoin");
    loader.LoadFile("/mnt/share/shared_files/config/secmaster_backup/Bitget");
    loader.LoadFile("/mnt/share/shared_files/config/secmaster_backup/Hyperliquid");
    loader.LoadFile("/mnt/share/shared_files/config/secmaster_backup/HuobiGlobal");
    loader.LoadFile("/mnt/share/shared_files/config/secmaster_backup/ApexOmni");
    loader.LoadFile("/mnt/share/shared_files/config/secmaster_backup/Aster");
#ifdef USE_AS
    loader.LoadFile("/mnt/share/shared_files/config/secmaster_backup/Lighter");
#endif

    std::vector<Strategy *> strategies;

    // warmup log pools
    warmupLogPools();

    auto config = Config::LoadFile(config_path);
    Config conf = config.Get<Config>("strategy");

    // init logger
    std::string log_name = "log_" + conf.Get<std::string>("quoter_symbol");
    if(conf.TryGet<Config>("hedger")) {
        log_name += "_" + conf.Get<Config>("hedger").Get<std::string>("hedger_symbol");
    }
    std::string log_path = conf.Get<std::string>("log_path");
    log_name += "_" + std::to_string(conf.Get<int>("quoter_logic_acct_id")) + ".txt";
    log_name = log_path + "/" + log_name;
    Logger::Init(log_name);

    // init strategies
    std::shared_ptr<Gaia> gaia = std::make_shared<Gaia>(config_path);
    strategies.push_back((Strategy*)gaia.get());
    auto hedger = gaia->getHedger();
    if (hedger) {
        strategies.push_back((Strategy*)hedger);
    }

    // secmaster
    // strategy engine
    Engine engine;
#ifdef SIM_MODE
#ifdef USE_AS
    std::cout << "using as sim" << std::endl;
#else
    std::cout << "using alphaless default simTs" << std::endl;
#endif
    auto start_date = config.Get<int>("start_date");
    auto end_date = config.Get<int>("end_date");
    std::cout << "sim start date: "<< start_date << " end date: " << end_date << std::endl;
    Date sim_start_date(start_date);
    Date sim_end_date(end_date);
    // engine.SetSimTimeRange(sim_start_date.ToTimestamp(), sim_start_date.ToTimestamp() + 1 * NS_PER_HOUR);
    engine.SetSimTimeRange(sim_start_date.ToTimestamp(), sim_end_date.ToTimestamp() + 60 * NS_PER_SEC);

    auto md_config = config.Get<Config>("md");
    auto sub_config = md_config.Get<Config>("subscription");
    if(sub_config.TryGet<int>("num_book_levels")) {
	    std::cout << "local num_book_levels : " << sub_config.Get<int>("num_book_levels") << std::endl;
        gaia->setNumBookLevels(sub_config.Get<int>("num_book_levels"));
    }
#endif

    std::cout << "strategies size:" << strategies.size() << std::endl;
    engine.Initialize(Config::LoadFile(config_path), strategies);
    engine.Start();
    engine.Run();

    std::cout << "program ending" << std::endl;
    gaia.reset();
    return 0;
}
