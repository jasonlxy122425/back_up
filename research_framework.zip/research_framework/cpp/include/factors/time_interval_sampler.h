#include "Factor.h"
#include "Ema.h"
#include <cmath>
#include "GaiaCircularBuffer.h"
#include "GaiaUtils.h"

class TimeIntervalSampler : public FactorInterface
{
public:
    TimeIntervalSampler(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
        timer_interval_ms = config.Get<int64_t>("timer_interval_ms");
        RegisterTimer(timer_interval_ms*1e6L);
    };

    virtual std::string gen_name() {;
        return std::string("TimeIntervalSampler") + '@' + std::to_string(timer_interval_ms);
    }

    virtual void calculate(const FactorInput& input_data) {
        if (is_on_timer) {
            factor_value = 1;
        }
        else {
            factor_value = 0;
        }
        is_on_timer = false;
        
    };
    void OnTimer() override {
        is_on_timer = true;
    }

private:
    int64_t timer_interval_ms;
    bool is_on_timer = false;
};
                              
