#include "Gaia.h"
#include "CommonDefine.h"
#include "GOrderState.h"


Gaia::Gaia(std::string _config_path) {
    std::cout << "Gaia Version:" << GAIA_VERSION << std::endl;

    config_file_watcher.init(std::string(_config_path));
    configCb = FileWatcher::FileWatcherCb(this, &Gaia::OnConfigChange);
    config_file_watcher.setCb(configCb);

    auto _config = Config::LoadFile(_config_path);
    auto strategy_config = _config.Get<Config>("strategy");

    tag_ = strategy_config.Get<std::string>("tag");
    sub_tag_ = strategy_config.Get<std::string>("sub_tag");
    std::cout << "tag: " << tag_ << ", sub_tag: " << sub_tag_ << std::endl;
    Logger::setTag(tag_, sub_tag_);

    quoter_logic_acct_id = strategy_config.Get<int>("quoter_logic_acct_id");
    quoter_symbol_ = strategy_config.Get<std::string>("quoter_symbol");
    quoter_machine_name = strategy_config.Get<std::string>("quoter_machine_name");
    quoter_sid_ = SecMaster::instance().FindSid(quoter_symbol_);

    subscribes_.insert(quoter_symbol_);
    last_trades_in_batch_[quoter_sid_] = nullptr;

    demeter_sample_num_ = strategy_config.Get<Config>("predictor_config").Get<int>("demeter_sample_num", 0);
    demeter_data_manager_ = nullptr;
    if (demeter_sample_num_ > 0) {
        demeter_data_manager_ = std::make_shared<demeter::DemeterDataManager>();
    }
    demeter_sample_type_ = strategy_config.Get<Config>("predictor_config").Get<std::string>("demeter_sample_type", "tick");

    auto common_config_obj = strategy_config.Get<Config>("common_config");
    common_config.useSyntheticFill = GaiaUtils::GetParam<bool>(common_config_obj,"use_synthetic_fill");
    common_config.useQryPosResult = GaiaUtils::GetParam<bool>(common_config_obj, "use_qry_pos_result");
    common_config.isMarginTrading = GaiaUtils::GetParam<bool>(common_config_obj, "is_margin_trading");
    common_config.useBatchMode = GaiaUtils::GetParam<bool>(common_config_obj, "use_batch_mode");
    common_config.useFullLiqInRiskExitMode = common_config_obj.Get<bool>("use_fullliq_in_riskexit", false);
    common_config.useWarmUp = common_config_obj.Get<bool>("use_warmup", false);
    if (common_config.useWarmUp) {
        std::cout << "use warmup, interval: " << WARMUP_INTERVAL << std::endl;
    }

    Logger::only_log_exec = common_config_obj.Get<bool>("only_log_exec", false);

    common_config.useOrderbook = common_config_obj.Get<bool>("use_orderbook", true);
    common_config.useBestquote = common_config_obj.Get<bool>("use_bestquote", true);
    common_config.useTrade = common_config_obj.Get<bool>("use_trade", true);
    common_config.useLiquidation = common_config_obj.Get<bool>("use_liquidation", true);
    common_config.useKline = common_config_obj.Get<bool>("use_kline", true);
    common_config.useFundingrate = common_config_obj.Get<bool>("use_fundingrate", true);

    common_config.useDmmTrade = common_config_obj.Get<bool>("use_dmm_trade", true);

    if(!common_config.useOrderbook) {
        allBooksPopulated = true;
        ob_manager_.set_num_book_levels(1);
        ob_manager_.set_max_level(1);
    }

    if(!common_config.useTrade) {
        allTradePopulated = true;
    }

    if(!common_config.useBestquote) {
        allBestQuotePopulated = true;
    }

    try {
        std::string predictor_trade_mode_str = GaiaUtils::GetParam<std::string>(common_config_obj, "predictor_trade_mode");
        if (predictor_trade_mode_str == "only_public") {
            common_config.predictor_trade_mode = GAssistCalculator::TradeMode::ONLY_PUBLIC;
        } else if (predictor_trade_mode_str == "only_dmm") {
            common_config.predictor_trade_mode = GAssistCalculator::TradeMode::ONLY_DMM;
        } else {
            common_config.predictor_trade_mode = GAssistCalculator::TradeMode::HYBRID;
        }
    } catch (...) {
        common_config.predictor_trade_mode = GAssistCalculator::TradeMode::HYBRID; // default to HYBRID
    }

    common_config.useInitialPosCoin = GaiaUtils::GetParam<bool>(common_config_obj, "use_initial_pos_coin");
    if(common_config.useInitialPosCoin) {
        auto initial_pos_coin_config = common_config_obj.Get<std::unordered_map<std::string, double>>("initial_pos_coin");

        for(auto &[sym, pos_coin] : initial_pos_coin_config) {

            std::cout << "initial_pos_coin: " << sym << " : " << pos_coin << std::endl;
            SymId sym_id = SecMaster::instance().FindSid(sym);
            if(sym_id == INVALID_SID) {
                std::cout << "Invalid symbol: " << sym << " in initial_pos_coin" << std::endl;
                exit(0);
            }
            common_config.initial_pos_coin_map[sym_id] = pos_coin;
        }
    }

    try {
        common_config.useQryPosMonitor = GaiaUtils::GetParam<bool>(common_config_obj, "use_qry_pos_monitor");
    } catch (...) {
        common_config.useQryPosMonitor = false;
    }

    if(common_config.useQryPosMonitor) {
        int64_t valid_pos_max_sec = GaiaUtils::GetParam<int64_t>(common_config_obj, "valid_pos_max_sec");
        int64_t abnormal_duration_sec = GaiaUtils::GetParam<int64_t>(common_config_obj, "abnormal_duration_sec");
        gaia_pos_monitor = std::make_shared<GaiaPosMonitor>(valid_pos_max_sec, abnormal_duration_sec);
    }

    std::cout << "=============================================== init contract start ===================================================" << std::endl;
    // reference_symbol maybe some symbols for predictor or other
    for (auto &refSymbols : strategy_config.Get<std::vector<std::string>>("reference_symbols")) {
        subscribes_.insert(refSymbols);
        last_trades_in_batch_[SecMaster::instance().FindSid(refSymbols)] = nullptr;
    }

    for (auto &refSymbols : strategy_config.Get<std::vector<std::string>>("assist_reference_symbols")) {
        assist_subscribes_.insert(refSymbols);
    }
#ifdef SIM_MODE
    sid_contract_map.reserve(subscribes_.size() + assist_subscribes_.size());
    contract_map.reserve(subscribes_.size() + assist_subscribes_.size());
#else
    sid_contract_map.reserve(subscribes_.size());
    contract_map.reserve(subscribes_.size());
#endif

    for (const auto &s : subscribes_) {
        InitContractInfo(s, true);
    }

#ifdef SIM_MODE
    for (const auto &s : assist_subscribes_) {
        InitContractInfo(s, false);
    }
#endif

    std::vector<SymId> all_sids;
    for(auto sid : univ) {
        all_sids.push_back(sid);
    }
    ob_manager_.InitBooks(all_sids);

    for(auto sid : univ) {
        sid_contract_map[sid]->alphaBook = &(ob_manager_.Get(sid));
    }

    for(auto sid : main_sids_) {
        std::cout << "main contract sid: " << sid << ", ticker: " << sid_contract_map[sid]->symbol_info->mirana_ticker << std::endl;
    }

#ifdef SIM_MODE
    for(auto sid : assist_sids_) {
        std::cout << "assist contract sid: " << sid << ", ticker: " << sid_contract_map[sid]->symbol_info->mirana_ticker << std::endl;
    }
#endif
    for (const auto &s : univ)
        std::cout << "finally subscribe symbol : " << s << std::endl;

    std::cout << "=============================================== init strategy fields start ===================================================" << std::endl;
    // set quoter strategy fields
    quoter_strategy_fields_ = &strategy_fieldsMap[quoter_sid_];


    auto setup_strategy_fields = [this](StrategyFields *quoter_strategy_fields_) {
        quoter_strategy_fields_->tag = tag_;
        quoter_strategy_fields_->machine_name = quoter_machine_name;
        quoter_strategy_fields_->contract_map = &contract_map;
        quoter_strategy_fields_->sid_contract_map = &sid_contract_map;
        quoter_strategy_fields_->assist_signal.reset();
        quoter_strategy_fields_->signal.reset();
        if(!common_config.useBestquote && !common_config.useOrderbook) {
            quoter_strategy_fields_->use_gob_for_ref_price = false;
        }
    };
    setup_strategy_fields(quoter_strategy_fields_);
    quoter_strategy_fields_->contract_info->logic_acct_id = quoter_logic_acct_id;

    // create order logic
    order_logic_code = strategy_config.Get<Config>("order_logic_config").Get<std::string>("order_logic_code");
    order_logic = std::unique_ptr<OrderLogic>(OrderLogicFactory::generateOrderLogic(order_logic_code));

    // create hedger config, if hedger config exists
    std::cout << "=============================================== init hedger start ===================================================" << std::endl;
    if(strategy_config.TryGet<Config>("hedger")) {
        auto hedger_config = strategy_config.Get<Config>("hedger");
        hedger = order_logic->getHedger();
        hedger_symbol_ = hedger_config.Get<std::string>("hedger_symbol");
        subscribes_.insert(hedger_symbol_);

        Hedger::HedgerComponent hedger_component = {
            .quoter_strategy_fields = quoter_strategy_fields_,
            .contract_map = &contract_map,
            .sid_contract_map = &sid_contract_map,
            .strategy_fields_map = &strategy_fieldsMap,
            .use_qry_result = common_config.useQryPosResult,
            .is_margin_trading = common_config.isMarginTrading,
            .use_qry_pos_monitor = common_config.useQryPosMonitor,
            .gaia_pos_monitor = gaia_pos_monitor
        };
        hedger->setHedgerComponent(hedger_component, strategy_config);
        hedger->getStrategyFields()->use_gob_for_ref_price = quoter_strategy_fields_->use_gob_for_ref_price;
        std::cout << "enable hedger" << std::endl;
        setup_strategy_fields(hedger->getStrategyFields());
    } else {
        hedger = nullptr;
        std::cout << "disable hedger" << std::endl;
    }

    InitDataPreprocessor(common_config_obj.Get<std::vector<Config>>("data_preprocessor_config"));

    // predictor init
    std::cout << "=============================================== predictor init start ===================================================" << std::endl;
    std::string predictor_code = strategy_config.Get<Config>("predictor_config").Get<std::string>("predictor_code");
    predictor_ = std::unique_ptr<Predictor>(PredictorFactory::generatePredictor(predictor_code));
    PredictorState *predictor_state = new PredictorState();
    predictor_state->contract_map = &contract_map;
    predictor_state->sid_contract_map = &sid_contract_map;
    predictor_state->preprocess_result = data_preprocessor_->GetResultPtr();
    predictor_->setState(predictor_state);
    quoter_strategy_fields_->predictor = predictor_.get();

    std::cout << "=============================================== update strategy config start ===================================================" << std::endl;
    updateStrategyConfig(strategy_config);
    predictor_->Initialize(strategy_config, strategy_config.Get<Config>("predictor_config"));

    assist_calculator_.reset();
    if (strategy_config.TryGet<Config>("assist_predictor_config")) {
        GAssistCalculator::Options assist_option;
        assist_option.useBestquote = common_config.useBestquote;
        assist_option.useTrade = common_config.useTrade;
        assist_option.useDmmTrade = common_config.useDmmTrade;
        assist_option.useOrderbook = common_config.useOrderbook;
        assist_option.useLiquidation = common_config.useLiquidation;
        assist_option.useFundingrate = common_config.useFundingrate;
        assist_option.useKline = common_config.useKline;

        assist_option.useBatchMode = common_config.useBatchMode;
        assist_option.predictor_trade_mode = common_config.predictor_trade_mode;
        assist_option.quoter_sid = quoter_sid_;
        assist_calculator_ = std::make_unique<GAssistCalculator>(this, strategy_config, assist_option);

        assist_calculator_->Init();

    #ifndef SIM_MODE // in sim mode, we only use on thread
        assist_calculator_->StartThread();
    #endif
    }

#ifdef OUTPUT_DATA
    data_writer = DataWriter::CreateDataWriter(strategy_config.Get<Config>("data_writer"), quoter_strategy_fields_, predictor_.get(), demeter_data_manager_);
    data_writer->setLatency(&(quoter_strategy_fields_->latency));
#endif
}

void Gaia::updateStrategyConfig(const Config &config) {
    quoter_strategy_fields_->setStrategyMode(StrategyMode::UnknownMode, "update config");
    quoter_strategy_fields_->sym_risk.leverage = config.Get<int>("leverage");

    order_logic->setStrategyFieldsMap(strategy_fieldsMap);
    order_logic->InitLogic(config);

    if(hedger) {
        hedger->InitConfig(config);
    }
}

void Gaia::OnInitialize(const Config &config) {
#ifndef SIM_MODE
    EnableUserMsg();
#endif
    auto now = GaiaUtils::GetRealSysTimestamp();
    orderCb = Order::UpdateCb(this, &Gaia::OnOrderUpdate);
    order_manager()->set_default_order_update_cb(orderCb);

    quoter_strategy_fields_->order_manager = order_manager();

    quoter_strategy_fields_->setStrategyMode(StrategyMode::UnknownMode, "OnInit");
}

void Gaia::InitDataPreprocessor(const std::vector<Config>& config) {
    std::cout << "=============================================== data preprocessor init start ===================================================" << std::endl;

    data_preprocessor_ = std::make_unique<PreprocessorCenter>(config);

    std::cout << "=============================================== data preprocessor init done ===================================================" << std::endl;
}

void Gaia::InitContractInfo(const std::string &s, bool is_main_contract) {
    auto contract_info = ContractInfo::GetContractInfo(s);
    SymId sid = contract_info->symbol_info->sid;
    if(is_main_contract) main_sids_.insert(sid);
    else assist_sids_.insert(sid);

    sid_contract_map[sid] = contract_info;
    contract_map[contract_info->symbol_info->mirana_ticker] = contract_info;
    univ.push_back(sid);

    if(demeter_data_manager_ != nullptr) {
        demeter_data_manager_->Init(sid, demeter_sample_type_, demeter_sample_num_);
        contract_info->demeter_data = demeter_data_manager_->Get(sid);
    }

    std::cout << "=============================================== order contract ===================================================" << std::endl;

    strategy_fieldsMap[sid].contract_info = contract_info;
    if(common_config.initial_pos_coin_map.find(sid) != common_config.initial_pos_coin_map.end()) {
        strategy_fieldsMap[sid].sym_risk.initial_pos_coin = common_config.initial_pos_coin_map[sid];
    } else {
        strategy_fieldsMap[sid].sym_risk.initial_pos_coin = 0.0;
        strategy_fieldsMap[sid].sym_risk.initial_pos_coin_checked = true;
    }

    if (quoter_symbol_ == s)
    {
        quoter_sid_ = sid;
        std::cout << "quoter_sid: " << quoter_sid_ << std::endl;
    }
}

void Gaia::OnConfigChange(std::string config_file) {
    std::cout << __FUNCTION__ <<std::endl;
    if (!std::filesystem::exists(config_file))
    {
        std::cout << "config_file: " << config_file << " not exist" << std::endl;
        return;
    }

    auto config = Config::LoadFile(config_file);
    updateStrategyConfig(config.Get<Config>("strategy"));

}

void Gaia::OnQryBalance(const trading_system_ts::RespQryBalance &balance) {
    std::cout << "quoter OnQryBalance" << std::endl;
    int logic_acct_id = balance.logic_acct_id;
    SymId sid = balance.sid;
    int err_code = balance.err_code;
    if(err_code != 0) {
        std::cout << "err_code:" << err_code << std::endl;
        return;
    }
    std::string coin = balance.coin;

    double available = balance.available;
    double frozen = balance.frozen;
    double total = balance.total;
    double unrealised_pnl = balance.unrealised_pnl;
    double realised_pnl = balance.realised_pnl;
    std::cout << "sid:" << sid << ", total:" << balance.total << ",borrowed:" << balance.borrowed << ",is_last:" << balance.is_last << ",err_code:" << err_code << std::endl;
    if(common_config.isMarginTrading && quoter_strategy_fields_->contract_info->symbol_info->exch == Exchange::BINANCE) {
        total = balance.total - balance.borrowed;
    }

    auto now = GaiaUtils::GetSysTimestamp();
    if ((err_code == 0) && (!balance.is_last)) {
        GaiaUtils::FillBalance(*quoter_strategy_fields_, logic_acct_id, sid, total, available, now);
    }

    if ((quoter_strategy_fields_->contract_info->symbol_info->mirana_ticker.find("_Spot_") != std::string::npos)) {
        if ((err_code == 0) && (!balance.is_last) &&
            (logic_acct_id == quoter_strategy_fields_->contract_info->logic_acct_id) && (sid == quoter_strategy_fields_->contract_info->symbol_info->base_sid)) {
            if (!quoter_strategy_fields_->sym_risk.initialized) {
                if (common_config.useQryPosResult) GaiaUtils::updateNetPos(quoter_strategy_fields_, total, 0);
                quoter_strategy_fields_->sym_risk.initialized = true;
            }
            if (common_config.useQryPosMonitor) {
                gaia_pos_monitor->update_pos(logic_acct_id, quoter_sid_, total - quoter_strategy_fields_->sym_risk.initial_pos_coin, now);
            }
        }

        if(balance.is_last && !quoter_strategy_fields_->sym_risk.initialized) {
            GaiaUtils::updateNetPos(quoter_strategy_fields_, 0, 0);
            quoter_strategy_fields_->sym_risk.initialized = true;
        }

        double tmp_v = 0;
        LOG_AUTO(OnQryPositionMessage, quoter_strategy_fields_->contract_info->logic_acct_id, quoter_strategy_fields_->contract_info->symbol_info->sid, err_code, tmp_v,
                    tmp_v, tmp_v, tmp_v, quoter_strategy_fields_->sym_risk.symbol_risk,
                    tmp_v, tmp_v, balance.is_last);

    }

    LOG_AUTO(OnQryBalanceMessage, logic_acct_id, sid, quoter_strategy_fields_->contract_info->symbol_info->mirana_ticker.c_str(),
                                        coin.c_str(), err_code, available, frozen, total, unrealised_pnl, realised_pnl);
}

void Gaia::OnQryPosition(const trading_system_ts::RespQryPosition &position) {
    std::cout << __FUNCTION__ << std::endl;
    int logic_acct_id = position.logic_acct_id;
    SymId sid = position.sid;
    int err_code = position.err_code;
    bool is_last = position.is_last;

    PositionSide position_side = position.position_side;
    int sideInt = position_side == PositionSide::SHORT ? -1 : 1;

    double cum_realised_pnl = position.cum_realised_pnl;
    double unrealised_pnl = position.unrealised_pnl;
    double leverage = position.leverage;
    double liq_price = position.liq_price;

    double pos_size = position.pos_size;
    if (SIGN(pos_size) != sideInt)
        pos_size *= sideInt;
    double position_mm = position.position_mm;
    double avg_entry_price = position.avg_entry_price;

    struct ContractInfo *orderContract = quoter_strategy_fields_->contract_info;

    auto now = GaiaUtils::GetSysTimestamp();


    if (err_code == 0) {
        if ((!quoter_strategy_fields_->sym_risk.initialized) && (sid == quoter_sid_) && (!is_last)) {
            if(common_config.useQryPosResult) GaiaUtils::updateNetPos(quoter_strategy_fields_, pos_size, position.avg_entry_price);
            quoter_strategy_fields_->sym_risk.initialized = true;
        }

        if (is_last && !quoter_strategy_fields_->sym_risk.initialized) {
            GaiaUtils::updateNetPos(quoter_strategy_fields_, 0, 0);
            quoter_strategy_fields_->sym_risk.initialized = true;
        }

        if (!is_last && sid == quoter_sid_ && common_config.useQryPosMonitor) {
            double net_pos = pos_size * orderContract->symbol_info->multiplier - quoter_strategy_fields_->sym_risk.initial_pos_coin;

            if (orderContract->symbol_info->product_type == ProductType::INVERSE_SWAP ||
                orderContract->symbol_info->product_type == ProductType::INVERSE_FUTURE) {
                net_pos = pos_size * orderContract->symbol_info->multiplier - quoter_strategy_fields_->sym_risk.initial_pos_coin * avg_entry_price;
            }
            // inverse use usd based net pos, otherwise use coin based net pos
            gaia_pos_monitor->update_pos(logic_acct_id, sid, net_pos, now);
        }
    } else if ((err_code == 340 || err_code == 308) && (orderContract->symbol_info->exch == Exchange::GATEIO)) {
        if(!quoter_strategy_fields_->sym_risk.initialized) {
            GaiaUtils::updateNetPos(quoter_strategy_fields_, 0, 0);
            quoter_strategy_fields_->sym_risk.initialized = true;
        }

        if(common_config.useQryPosMonitor) {
            double net_pos = - quoter_strategy_fields_->sym_risk.initial_pos_coin;

            if (orderContract->symbol_info->product_type == ProductType::INVERSE_SWAP ||
                orderContract->symbol_info->product_type == ProductType::INVERSE_FUTURE) {
                net_pos = - quoter_strategy_fields_->sym_risk.initial_pos_coin * avg_entry_price;
            }

            // inverse use usd based net pos, otherwise use coin based net pos
            gaia_pos_monitor->update_pos(logic_acct_id, sid, net_pos, now);
        }
    } else if((!quoter_strategy_fields_->sym_risk.initialized) && err_code == 211) {
        qryPosition();
    }

    LOG_AUTO(OnQryPositionMessage, logic_acct_id, sid, err_code, cum_realised_pnl,
                                        unrealised_pnl, leverage, liq_price, pos_size,
                                        position_mm, avg_entry_price, is_last);

}

void Gaia::OnQryOpenOrder(const RespQryOpenOrder &order)
{
    if ((order.order != NULL) || (order.order != nullptr))
    {
        order_manager()->CancelOrder(order.order);

        LOG_AUTO(OnQryOpenOrderMessage, order.order->client_order_id().value);
    }
}

G_INLINE bool Gaia::checkBookAndPosStatus()
{
    bool prev_all_book_populated = allBooksPopulated;
    bool prev_all_trade_populated = allTradePopulated;
    bool prev_all_bq_populated = allBestQuotePopulated;
    bool prev_all_pos_update = hasReceivedAllPositionUpdate;
    if (!allBooksPopulated)
    {
        allBooksPopulated = true;
        for (const auto & entry: sid_contract_map)
        {
            if (!entry.second->hasBookPopulated)
            {
                allBooksPopulated = false;
                std::cout << entry.second->symbol_info->mirana_ticker << " book not populated yet ..." << std::endl;
            }
        }
    }

    if (!allTradePopulated)
    {
        allTradePopulated = true;
        for (const auto & entry: sid_contract_map)
        {
            if (!entry.second->hasTradePopulated)
            {
                allTradePopulated = false;
                std::cout << entry.second->symbol_info->mirana_ticker << " trade not populated yet ..." << std::endl;
            }
        }
    }

    if (!allBestQuotePopulated)
    {
        allBestQuotePopulated = true;
        for (const auto & entry: sid_contract_map)
        {
            if (!entry.second->hasBestQuotePopulated)
            {
                allBestQuotePopulated = false;
                std::cout << entry.second->symbol_info->mirana_ticker << " quote not populated yet ..." << std::endl;
            }
        }
    }

    if (!hasReceivedAllPositionUpdate)
    {
        hasReceivedAllPositionUpdate = true;
        if(!quoter_strategy_fields_->sym_risk.initialized)
        {
            hasReceivedAllPositionUpdate = false;
            std::cout << quoter_strategy_fields_->contract_info->symbol_info->mirana_ticker << " pos not populated yet ..." << std::endl;
        }

        if(hedger && !hedger->allPosUpdated())
        {
            hasReceivedAllPositionUpdate = false;
        }
    }

    if (!prev_all_book_populated || !prev_all_pos_update || !prev_all_trade_populated || !prev_all_bq_populated)
    {
        if ((allBooksPopulated) && (hasReceivedAllPositionUpdate) && (allTradePopulated) && (allBestQuotePopulated)) {

            GaiaUtils::initSymbolRisk(quoter_strategy_fields_);
            if(hedger) {
                GaiaUtils::initSymbolRisk(hedger->getStrategyFields());
            }
            std::cout << "received all book/trade/quote and position !" << std::endl;
        }
    }

    if ((allBooksPopulated) && (hasReceivedAllPositionUpdate) && (allTradePopulated) && (allBestQuotePopulated)) {
        return true;
    }

    return false;
}

void Gaia::SampleDemeter(Nanoseconds &now) {

    demeter_data_manager_->Sample(now);
    for(auto iter : sid_contract_map) {
        auto w_sid = iter.first;
#ifdef OUTPUT_DATA
        if(!demeter_data_manager_->isTickSample(w_sid) && demeter_data_manager_->needSample(w_sid)) {
            data_writer->WriteData(w_sid);
        }
#endif
    }
}

void Gaia::OnMdBatch(const std::vector<const md::Message *> &batch) {
    size_t batch_size = batch.size();
#ifdef RECORD_LATENCY
    quoter_strategy_fields_->latency.batch_start_ts = GaiaUtils::GetRealSysTimestamp();
    quoter_strategy_fields_->latency.batch_size = batch_size;
#endif

    for (size_t i = 0; i < batch_size; ++i) {
        const md::Message *msg = batch[i];
#ifdef SIM_MODE
        if (main_sids_.find(msg->sid) == main_sids_.end() && assist_sids_.find(msg->sid) == assist_sids_.end()) continue;
#else
        if (main_sids_.find(msg->sid) == main_sids_.end()) continue;
#endif

        switch(msg->msg_type) {
            case md::MessageType::TRADE:
            {
                if (!common_config.useTrade) break;
                const md::Trade &cur_trade = *static_cast<const md::Trade *>(msg);
                md::Trade* &last_trade = last_trades_in_batch_[cur_trade.sid];

                bool reach_final_trade = ((i + 1) >= batch_size || batch[i + 1]->msg_type != md::MessageType::TRADE || batch[i + 1]->sid != cur_trade.sid);
                bool need_merge = (last_trade != nullptr && last_trade->side == cur_trade.side && std::abs(last_trade->price - cur_trade.price) < eps);
                if(need_merge) {
                    last_trade->qty += cur_trade.qty;
                    last_trade->exch_ts = cur_trade.exch_ts;
                    last_trade->recv_ts = cur_trade.recv_ts;
                    last_trade->qs_send_ts = cur_trade.qs_send_ts;
                    last_trade->parser_end_ts = cur_trade.parser_end_ts;
                    last_trade->cb_start_ts = cur_trade.cb_start_ts;
                }

                if (reach_final_trade) {
                    if(last_trade == nullptr) {
                        const_cast<md::Trade&>(cur_trade).cb_start_ts = GaiaUtils::GetRealSysTimestamp();
                        OnTrade(cur_trade);
                    } else {
                        if(need_merge) {
                            last_trade->cb_start_ts = GaiaUtils::GetRealSysTimestamp();
                            OnTrade(*last_trade);
                        } else {
                            last_trade->cb_start_ts = GaiaUtils::GetRealSysTimestamp();
                            OnTrade(*last_trade);
                            const_cast<md::Trade&>(cur_trade).cb_start_ts = GaiaUtils::GetRealSysTimestamp();
                            OnTrade(cur_trade);
                        }
                        last_trade = nullptr; // reset trade after processing
                    }
                } else {
                    if(last_trade == nullptr) {
                        last_trade = const_cast<md::Trade *>(&cur_trade);
                    } else {
                        if (!need_merge) {
                            last_trade->cb_start_ts = GaiaUtils::GetRealSysTimestamp();
                            OnTrade(*last_trade);
                            last_trade = const_cast<md::Trade *>(&cur_trade);
                        }
                    }
                }
                break;
            }
            case md::MessageType::ORDERBOOK:
            {
                if (!common_config.useOrderbook) break;

                const md::FlatOrderbook &ob_msg = *static_cast<const md::FlatOrderbook *>(msg);
                if (i + 1 < batch_size && batch[i + 1]->msg_type == md::MessageType::ORDERBOOK && batch[i + 1]->sid == msg->sid) {
                    break;
                }
                const_cast<md::FlatOrderbook&>(ob_msg).cb_start_ts = GaiaUtils::GetRealSysTimestamp();
                OnOrderbook(ob_msg);
                break;
            }
            case md::MessageType::BEST_QUOTE:
            {
                const md::BestQuote &bq_msg = *static_cast<const md::BestQuote *>(msg);
                if (i + 1 < batch_size && batch[i + 1]->msg_type == md::MessageType::BEST_QUOTE && batch[i + 1]->sid == msg->sid) {
                    break;
                }

                const_cast<md::BestQuote&>(bq_msg).cb_start_ts = GaiaUtils::GetRealSysTimestamp();
                OnBestQuote(bq_msg);
                break;
            }
            case md::MessageType::LIQUIDATION:
            {
                if(!common_config.useLiquidation) break;
                const md::Liquidation &liq_msg = *static_cast<const md::Liquidation *>(msg);
                const_cast<md::Liquidation&>(liq_msg).cb_start_ts = GaiaUtils::GetRealSysTimestamp();
                OnLiquidation(liq_msg);
                break;
            }
            case md::MessageType::FUNDING_RATE:
            {
                if(!common_config.useFundingrate) break;
                const md::FundingRate &fr_msg = *static_cast<const md::FundingRate *>(msg);
                const_cast<md::FundingRate&>(fr_msg).cb_start_ts = GaiaUtils::GetRealSysTimestamp();
                OnFundingRate(*static_cast<const md::FundingRate *>(msg));
                break;
            }
            case md::MessageType::KLINE:
            {
                if(!common_config.useKline) break;
                const md::Kline &kline_msg = *static_cast<const md::Kline *>(msg);
                const_cast<md::Kline&>(kline_msg).cb_start_ts = GaiaUtils::GetRealSysTimestamp();
                OnKline(kline_msg);
                break;
            }
            default:
            break;
        }
    }
}

void Gaia::OnTrade(const md::Trade &trade) {
    if(G_UNLIKELY(!common_config.useDmmTrade && trade.src == Source::DMM)) {
        return;
    }

    auto &contract = sid_contract_map[trade.sid];
    // TODO: if use private fill, need to filter duplicate trade
    /*
    TradeIdFilter &t_filter = trade_filter_map[trade.sid];
    if (contract->symbol_info->exch != Exchange::BITGET && t_filter.isDuplicateTrade(trade)) {
        return;
    }
    */

    contract->trade = trade;
    contract->update_tick_type = TickEventType::TICK_TRADE;
    contract->hasTradePopulated = true;
    auto &mkt_latency = contract->latency_record.mkt_data;
    mkt_latency = {
        .mkt_recv_ts = trade.recv_ts,
        .mkt_exch_ts = trade.exch_ts,
        .mkt_qs_send_ts = trade.qs_send_ts,
        .mkt_parse_end_ts = trade.parser_end_ts,
        .mkt_cb_start_ts = trade.cb_start_ts,
    };
    data_preprocessor_->Process(contract, TickEventType::TICK_TRADE, &(contract->latency_record));

    if(G_UNLIKELY(!common_config.useTrade)) {
        if(!data_preprocessor_->GetResultPtr()->GetAggTrade(trade.sid).has_value()) {
            return;
        }
    } else {
        ob_manager_.OnTrade(trade);
    }

    if(common_config.useSyntheticFill)
        SyntheticFillAuditor::Audit(trade, quoter_strategy_fields_, hedger);

    StrategyProcess(contract, TickEventType::TICK_TRADE, trade.sid);
}

void Gaia::OnOrderbook(const md::FlatOrderbook &ob) {
    if(!common_config.useOrderbook) return;

    auto &contract = sid_contract_map[ob.sid];
    auto &mkt_latency = contract->latency_record.mkt_data;
    mkt_latency = {
        .mkt_recv_ts = ob.recv_ts,
        .mkt_exch_ts = ob.exch_ts,
        .mkt_qs_send_ts = ob.qs_send_ts,
        .mkt_parse_end_ts = ob.parser_end_ts,
        .mkt_cb_start_ts = ob.cb_start_ts,
    };
    contract->update_tick_type = TickEventType::TICK_OB;
#ifdef SIM_MODE
    contract->ob_data.CopyFrom(ob);
#endif

    ob_manager_.OnOrderbook(ob);

    contract->hasBookPopulated = true;

    StrategyProcess(contract, TickEventType::TICK_OB, ob.sid);
}

void Gaia::OnBestQuote(const md::BestQuote &quote) {
    auto &contract = sid_contract_map[quote.sid];
    auto &mkt_latency = contract->latency_record.mkt_data;
    mkt_latency = {
        .mkt_recv_ts = quote.recv_ts,
        .mkt_exch_ts = quote.exch_ts,
        .mkt_qs_send_ts = quote.qs_send_ts,
        .mkt_parse_end_ts = quote.parser_end_ts,
        .mkt_cb_start_ts = quote.cb_start_ts,
    };
    contract->update_tick_type = TickEventType::TICK_BBO;
    contract->quote = quote;

    if(!common_config.useBestquote) return;

    ob_manager_.OnBestQuote(quote);

    // if(!contract->hasBestQuotePopulated) {
    //     std::cout << contract->symbol_info->mirana_ticker << " received quote, num_bids: " << book.num_bids() << ", num_asks: " << book.num_asks()
    //                     << ",seq_id: "<< quote.seq_id << std::endl;
    // }
    contract->hasBestQuotePopulated = true;

    StrategyProcess(contract, TickEventType::TICK_BBO, quote.sid);
}

void Gaia::OnSignalUpdate(const SignalStruct &signal) {
    const_cast<SignalStruct&>(signal).cb_start_ts = GaiaUtils::GetRealSysTimestamp();
    // save assist signal
    quoter_strategy_fields_->assist_signal = signal;
    quoter_strategy_fields_->is_signal_update = true;

#ifdef RECORD_LATENCY
    quoter_strategy_fields_->latency.predictor_start_ts = GaiaUtils::GetRealSysTimestamp();
#endif
    predictor_->CalculateAssistSignal(quoter_strategy_fields_->signal, quoter_strategy_fields_->assist_signal);

#ifndef SIM_MODE
    ContractInfo *contract = sid_contract_map[quoter_sid_];
    StrategyProcess(contract, TickEventType::TICK_SIGNAL, quoter_sid_);
#endif
    quoter_strategy_fields_->is_signal_update = false;
}

void Gaia::OnUserMsg(const uint8_t *data, size_t size) {
    if (size == sizeof(SignalStruct)) {
        SignalStruct& signal = *(SignalStruct*)data;
        OnSignalUpdate(signal);
    }
}

void Gaia::OnLiquidation(const md::Liquidation &liquidation) {
    if(!common_config.useLiquidation) return;

    ContractInfo *contract = sid_contract_map[liquidation.sid];
    auto &mkt_latency = contract->latency_record.mkt_data;
    mkt_latency = {
        .mkt_recv_ts = liquidation.recv_ts,
        .mkt_exch_ts = liquidation.exch_ts,
        .mkt_qs_send_ts = liquidation.qs_send_ts,
        .mkt_parse_end_ts = liquidation.parser_end_ts,
        .mkt_cb_start_ts = liquidation.cb_start_ts,
    };
    contract->update_tick_type = TickEventType::TICK_LIQUIDATION;

    contract->liquidation = liquidation;
    ob_manager_[liquidation.sid].OnLiquidation(liquidation);

    StrategyProcess(contract, TickEventType::TICK_LIQUIDATION, liquidation.sid);
}

void Gaia::OnKline(const md::Kline &kline) {
    if(!common_config.useKline) return;

    ContractInfo *contract = sid_contract_map[kline.sid];
    auto &mkt_latency = contract->latency_record.mkt_data;
    mkt_latency = {
        .mkt_recv_ts = kline.recv_ts,
        .mkt_exch_ts = kline.exch_ts,
        .mkt_qs_send_ts = kline.qs_send_ts,
        .mkt_parse_end_ts = kline.parser_end_ts,
        .mkt_cb_start_ts = kline.cb_start_ts,
    };
    contract->update_tick_type = TickEventType::TICK_KLINE;

    contract->kline = kline;

    StrategyProcess(contract, TickEventType::TICK_KLINE, kline.sid);
}

void Gaia::OnFundingRate(const md::FundingRate &fr) {
    if(!common_config.useFundingrate) return;

    struct ContractInfo *orderContract = sid_contract_map[fr.sid];

    if(orderContract->next_funding_time < fr.next_funding_time)
    {
        orderContract->last_funding_time = orderContract->next_funding_time;
        orderContract->next_funding_time = fr.next_funding_time;

        if (orderContract->symbol_info->mirana_ticker.find("Okex") != std::string::npos) {
            orderContract->funding_rate = fr.funding_rate;
            orderContract->cur_funding_rate = fr.funding_rate;
        }
        else {
            orderContract->funding_rate = fr.funding_rate;
            orderContract->cur_funding_rate = fr.predicted_funding_rate;
        }
    }
}

G_INLINE void Gaia::StrategyProcess(ContractInfo *&cur_contract, const TickEventType &cur_tick_type, const SymId &cur_tick_sid) {
    auto &current_mode = quoter_strategy_fields_->current_mode;
    // Main logic
    if (G_LIKELY(current_mode < StrategyMode::UnknownMode)) {
#ifdef RECORD_LATENCY
        quoter_strategy_fields_->latency.gaia_start_ts = GaiaUtils::GetRealSysTimestamp();
#endif
        // save cur_tick_sid for log
        quoter_strategy_fields_->cur_tick_sid = cur_tick_sid;
        if(hedger) hedger->getStrategyFields()->cur_tick_sid = cur_tick_sid;

#ifdef SIM_MODE
        CalcAssist(cur_contract, cur_tick_type);
#endif
        if (cur_tick_type != TickEventType::TICK_SIGNAL) {
            CalcPred(cur_contract, cur_tick_type);
        }

        CalcOrderLogic(cur_contract, cur_tick_type);

#ifdef RECORD_LATENCY
        quoter_strategy_fields_->latency.gaia_end_ts = GaiaUtils::GetRealSysTimestamp();
#endif


#ifdef OUTPUT_DATA
        data_writer->setUnCappedNumLevels(ob_manager_.Get(cur_tick_sid).num_bids(), ob_manager_.Get(cur_tick_sid).num_asks());
        switch(cur_tick_type) {
            case TickEventType::TICK_TRADE:
                data_writer->OnTrade(cur_contract->trade);
                if(demeter_data_manager_ == nullptr || demeter_data_manager_->isTickSample(cur_tick_sid)) data_writer->WriteData(ob_manager_.GetOutput(cur_tick_sid), cur_tick_sid);
                else data_writer->saveOb(ob_manager_.GetOutput(cur_tick_sid), cur_tick_sid);
                break;
            case TickEventType::TICK_OB:
                data_writer->OnOrderbook(cur_contract->ob_data.get_view());
                if(demeter_data_manager_ == nullptr || demeter_data_manager_->isTickSample(cur_tick_sid)) data_writer->WriteData(ob_manager_.GetOutput(cur_tick_sid), cur_tick_sid);
                else data_writer->saveOb(ob_manager_.GetOutput(cur_tick_sid), cur_tick_sid);
                break;
            case TickEventType::TICK_BBO:
                data_writer->OnBestQuote(cur_contract->quote);
                if(demeter_data_manager_ == nullptr || demeter_data_manager_->isTickSample(cur_tick_sid)) data_writer->WriteData(ob_manager_.GetOutput(cur_tick_sid), cur_tick_sid);
                else data_writer->saveOb(ob_manager_.GetOutput(cur_tick_sid), cur_tick_sid);
                break;
            case TickEventType::TICK_LIQUIDATION:
                data_writer->OnLiquidation(cur_contract->liquidation);
                if(demeter_data_manager_ == nullptr || demeter_data_manager_->isTickSample(cur_tick_sid)) data_writer->WriteData(ob_manager_.GetOutput(cur_tick_sid), cur_tick_sid);
                else data_writer->saveOb(ob_manager_.GetOutput(cur_tick_sid), cur_tick_sid);
                break;
            case TickEventType::TICK_KLINE:
                data_writer->OnKline(cur_contract->kline);
                if(demeter_data_manager_ == nullptr || demeter_data_manager_->isTickSample(cur_tick_sid)) data_writer->WriteData(ob_manager_.GetOutput(cur_tick_sid), cur_tick_sid);
                else data_writer->saveOb(ob_manager_.GetOutput(cur_tick_sid), cur_tick_sid);
                break;
            default:
                break;
        }
#endif
    }
    // TODO: should call this func in OnIdle?
    StrategyStatusChange();

    switch (current_mode)
    {
    case StrategyMode::NormalMode:
        break;
    case StrategyMode::UnknownMode:
        break;
    case StrategyMode::AbnormalPosMode:
        // TODO: if we need to do something?
        break;
    case StrategyMode::LiquidateRiskMode:
        LiquidationRisk();
        break;
    case StrategyMode::FullLiquidationMode:
        FullLiquidation();
        break;
    case StrategyMode::NormalExitMode:
        StrategyForceExit();
        break;
    case StrategyMode::ExitMode:
        StrategyForceExit();
        break;
    case StrategyMode::RiskExitMode:
        if(common_config.useFullLiqInRiskExitMode) quoter_strategy_fields_->setStrategyMode(StrategyMode::FullLiquidationMode, "FullLiquidation in RiskExitMode");
        else RiskExit();
        break;
    case StrategyMode::DisconnectMode:
        DisconnectLogic();
        break;
    default:
        break;
    }
}

G_INLINE void Gaia::CalcOrderLogic(ContractInfo *&cur_contract, const TickEventType &_cur_tick_type) {
#ifdef RECORD_LATENCY
    quoter_strategy_fields_->latency.risk_start_ts = GaiaUtils::GetRealSysTimestamp();
#endif
    // prepare for mkt
    order_logic->ProcessBeforeRiskCheck(*quoter_strategy_fields_);
    if(hedger) hedger->RiskCheck();

#ifdef RECORD_LATENCY
    quoter_strategy_fields_->latency.order_logic_start_ts = GaiaUtils::GetRealSysTimestamp();
#endif
    // order logic
    if (G_LIKELY(_cur_tick_type != TickEventType::TICK_WARMUP)) {
        order_logic->ProcessLogic(_cur_tick_type, *quoter_strategy_fields_);
    } else {
        order_logic->Warmup(*quoter_strategy_fields_);
    }

#ifdef RECORD_LATENCY
    quoter_strategy_fields_->latency.hedger_start_ts = GaiaUtils::GetRealSysTimestamp();
#endif
    // order logic
    if(hedger) {
        if(!hedger->isHedged()) {
            hedger->tryHedge();
        }
    }
    // last risk check
    RiskCheck();
}

G_INLINE void Gaia::CalcPred(ContractInfo *&cur_contract, const TickEventType &_cur_tick_type) {
#ifdef RECORD_LATENCY
    quoter_strategy_fields_->latency.predictor_start_ts = GaiaUtils::GetRealSysTimestamp();
#endif

#ifdef SIM_MODE
    if(main_sids_.find(cur_contract->symbol_info->sid) == main_sids_.end()) return;
#endif

    GLatencyRecord &latency_record = cur_contract->latency_record;
    int64_t &now = latency_record.mkt_data.mkt_recv_ts;

    // calc demeter data
    if(cur_contract->demeter_data != nullptr) {
        SampleDemeter(now);
        demeter_data_manager_->Update(*cur_contract->alphaBook, cur_contract);
    }

    bool need_calc_pred = true;
    if(_cur_tick_type == TickEventType::TICK_TRADE) {
        need_calc_pred = (common_config.predictor_trade_mode == GAssistCalculator::TradeMode::HYBRID) ||
                              (common_config.predictor_trade_mode == GAssistCalculator::TradeMode::ONLY_DMM && cur_contract->trade.src == Source::DMM) ||
                              (common_config.predictor_trade_mode == GAssistCalculator::TradeMode::ONLY_PUBLIC && !(cur_contract->trade.src == Source::DMM));
    }

    if (need_calc_pred) {
        predictor_->CalculatePredictor(_cur_tick_type, cur_contract->symbol_info->sid, &(cur_contract->latency_record), quoter_sid_);
        predictor_->CalculateAssistSignal(quoter_strategy_fields_->signal, quoter_strategy_fields_->assist_signal);
    }
}

G_INLINE void Gaia::StrategyStatusChange() {
    // ExitMode / NormalExitMode is final status, no need to check
    auto &current_mode = quoter_strategy_fields_->current_mode;
    if(current_mode == StrategyMode::ExitMode || current_mode == StrategyMode::NormalExitMode) {
        return;
    }
    // changed by user signal
    if(GaiaUtils::ForceExitFlag)
    {
        if(current_mode < StrategyMode::NormalExitMode)
            quoter_strategy_fields_->setStrategyMode(StrategyMode::ExitMode, "ForceExitFlag");
    }
    else if(GaiaUtils::FullLiquidationFlag)
    {
        if(current_mode != StrategyMode::FullLiquidationMode)
            quoter_strategy_fields_->setStrategyMode(StrategyMode::FullLiquidationMode, "FullLiquidationFlag");
    }

    bool in_fr_time_range = false;
    int64_t now = GaiaUtils::GetSysTimestamp();
    if(order_logic->getCommonConfig().use_fr_check)
    {
        if(hedger)
        {
            ContractInfo* hedger_contract = hedger->getStrategyFields()->contract_info;
            bool in_next_time_range = (hedger_contract->next_funding_time > 0
                                    && (now >= hedger_contract->next_funding_time - order_logic->getCommonConfig().reduce_only_minute_before_fr)
                                    && (now <= hedger_contract->next_funding_time + order_logic->getCommonConfig().reduce_only_minute_after_fr) );
            bool in_last_time_range = (hedger_contract->last_funding_time > 0
                                    && (now >= hedger_contract->last_funding_time - order_logic->getCommonConfig().reduce_only_minute_before_fr)
                                    && (now <= hedger_contract->last_funding_time + order_logic->getCommonConfig().reduce_only_minute_after_fr) );
            in_fr_time_range |= ( in_last_time_range || in_next_time_range );
        }

        ContractInfo* contract = quoter_strategy_fields_->contract_info;
        bool in_next_time_range = (contract->next_funding_time > 0
                                && (now >= contract->next_funding_time - order_logic->getCommonConfig().reduce_only_minute_before_fr)
                                && (now <= contract->next_funding_time + order_logic->getCommonConfig().reduce_only_minute_after_fr) );
        bool in_last_time_range = (contract->last_funding_time > 0
                                && (now >= contract->last_funding_time - order_logic->getCommonConfig().reduce_only_minute_before_fr)
                                && (now <= contract->last_funding_time + order_logic->getCommonConfig().reduce_only_minute_after_fr) );

        in_fr_time_range |= ( in_next_time_range || in_last_time_range );
    }

    // changed by statue change
    switch (current_mode)
    {
    case StrategyMode::UnknownMode:
        if(checkBookAndPosStatus()) {
            quoter_strategy_fields_->setStrategyMode(StrategyMode::NormalMode, "Book Pos Initialized");
        }
        return;
    case StrategyMode::NormalMode:
        if(!checkBookAndPosStatus()) {
            quoter_strategy_fields_->setStrategyMode(StrategyMode::UnknownMode, "Book Pos Not Initialized");
        }

        if(order_logic->getCommonConfig().use_reduce_only_mode) {
            quoter_strategy_fields_->setStrategyMode(StrategyMode::ReduceOnlyMode, "Reduce Only Configured");
        }
        else if(order_logic->getCommonConfig().use_fr_check) {
            if(in_fr_time_range) {
                quoter_strategy_fields_->setStrategyMode(StrategyMode::ReduceOnlyMode, "In funding rate time range");
            }
        }
        break;
    case StrategyMode::ReduceOnlyMode:
        if(!order_logic->getCommonConfig().use_reduce_only_mode && order_logic->getCommonConfig().use_fr_check) {
            if(!in_fr_time_range) {
                quoter_strategy_fields_->setStrategyMode(StrategyMode::NormalMode, "out of funding rate time range");
            }
        }
        break;
    case StrategyMode::RateLimitMode:
        if(now - quoter_strategy_fields_->last_rate_limit_ts > order_logic->getCommonConfig().rate_limit_duration_ms * 1000000L) {
            quoter_strategy_fields_->setStrategyMode(StrategyMode::NormalMode, "Rate Limit Mode Timeout " + std::to_string(now));
            quoter_strategy_fields_->last_rate_limit_ts = 0;
        }
        break;
    case StrategyMode::BalanceLimitMode:
        if(now - quoter_strategy_fields_->last_balance_limit_ts > 10 * 1000000L) {
            quoter_strategy_fields_->setStrategyMode(StrategyMode::NormalMode, "Balance Limit Mode Timeout " + std::to_string(now));
            quoter_strategy_fields_->last_balance_limit_ts = 0;
        }
        break;
    case StrategyMode::FullLiquidationMode:
        break;
    case StrategyMode::LiquidateRiskMode:
        break;
    case StrategyMode::NormalExitMode:
        break;
    case StrategyMode::ExitMode:
        break;
    case StrategyMode::RiskExitMode:
        break;
    default:
        break;
    }
}

void Gaia::OnIdle() {
    int64_t now = GaiaUtils::GetSysTimestamp();
    if(predictor_) {
        predictor_->OnTimer(now);
#ifdef SIM_MODE
        if(assist_calculator_) {
            assist_calculator_->OnTimer(now);
        }
#endif
    }
    saveStrategySnapshot(now);
    scheduleTask(now);
}

void Gaia::saveStrategySnapshot(int64_t &now) {
    if(now - last_log_snapshot_ts > ONE_SECOND_IN_NANOS * 10) {
        LOG_AUTO(StrategySnapshotMsg, quoter_strategy_fields_->contract_info->symbol_info->mirana_ticker,
                                                quoter_strategy_fields_->current_mode,
                                                quoter_strategy_fields_->snapshot);
	    // LOG_AUTO(StrategyBalanceMsg, quoter_strategy_fields_->contract_info->symbol_info->mirana_ticker, 
        //                                         quoter_strategy_fields_->sym_risk.wallet_balance, 
        //                                         quoter_strategy_fields_->sym_risk.avail_balance, 
        //                                         quoter_strategy_fields_->sym_risk.balance_ts);
        last_log_snapshot_ts = now;
        WarmUp(now, true);
    }
}

void Gaia::scheduleTask(int64_t &now) {
    auto &mode = quoter_strategy_fields_->current_mode;
    bool running_status = (mode == StrategyMode::NormalMode ||
                            mode == StrategyMode::ReduceOnlyMode ||
                            mode == StrategyMode::RateLimitMode ||
                            mode == StrategyMode::BalanceLimitMode);

    if(order_logic->getCommonConfig().use_balance_limit_mode && running_status) {
        if(quoter_strategy_fields_->contract_info->symbol_info->exch == Exchange::BINANCE && now - last_qry_balance_ts > ONE_SECOND_IN_NANOS * 20) {
            last_qry_balance_ts = now;
            if(quoter_strategy_fields_->contract_info->symbol_info->product_type == ProductType::INVERSE_SWAP) {
                ts_client()->QryBalance(quoter_logic_acct_id, quoter_strategy_fields_->contract_info->symbol_info->base_sid);
            } else {
                ts_client()->QryBalance(quoter_logic_acct_id, quoter_strategy_fields_->contract_info->symbol_info->quote_sid);
            }
        }
    }

    // check config file change per 10 second
    if (now - last_config_check_time > 10 * ONE_SECOND_IN_NANOS) {
        config_file_watcher.check(now);
        last_config_check_time = now;
    }

    if(running_status) {
        if(common_config.useQryPosMonitor) checkQryPos(now);
        WarmUp(now);
    }
}

void Gaia::checkQryPos(int64_t &now) {
    if (now - last_qry_pos_ts > ONE_SECOND_IN_NANOS * 30) {
        last_qry_pos_ts = now;
        if (quoter_strategy_fields_->current_mode != StrategyMode::AbnormalPosMode) {
            bool ret = true;
            auto main_contract = quoter_strategy_fields_->contract_info;
            ret = gaia_pos_monitor->process(main_contract->logic_acct_id,
                                    main_contract->symbol_info->sid,
                                    now,
                                    (main_contract->is_reverse ? quoter_strategy_fields_->sym_risk.contract_usd_risk : quoter_strategy_fields_->sym_risk.symbol_risk));
            if (!ret) {
                double pos_from_exch = gaia_pos_monitor->get_record_pos(main_contract->logic_acct_id,
                                                                        main_contract->symbol_info->sid);
                std::stringstream ss;
                ss << "enter pos abnormal mode, sid: " << main_contract->symbol_info->sid << ","
                        << "logic_acct_id: " << main_contract->logic_acct_id << ","
                        << "is_reverse: " << main_contract->is_reverse << ","
                        << "pos from exch: " << pos_from_exch << ","
                        << "pos from trade(coin): " << quoter_strategy_fields_->sym_risk.symbol_risk << ","
                        << "pos from trade(usd): " << quoter_strategy_fields_->sym_risk.contract_usd_risk;
                std::cout << ss.str() << std::endl;
                quoter_strategy_fields_->setStrategyMode(StrategyMode::AbnormalPosMode, ss.str());
                quoter_strategy_fields_->order_manager->CancelAll(main_contract->logic_acct_id,
                                                                        main_contract->symbol_info->sid);
                return;
            } else {
                qryPosition();
            }
            
            if(hedger && hedger->connected()) {
                auto hedger_contract = hedger->getStrategyFields()->contract_info;
                ret = gaia_pos_monitor->process(hedger_contract->logic_acct_id,
                                            hedger_contract->symbol_info->sid,
                                            now,
                                            (hedger_contract->is_reverse ? hedger->getStrategyFields()->sym_risk.contract_usd_risk : hedger->getStrategyFields()->sym_risk.symbol_risk));
                if (!ret) {
                    double pos_from_exch = gaia_pos_monitor->get_record_pos(hedger_contract->logic_acct_id,
                                                                            hedger_contract->symbol_info->sid);
                    std::stringstream ss;
                    ss << "hedger enter pos abnormal mode, sid: " << hedger_contract->symbol_info->sid << ","
                            << "logic_acct_id: " << hedger_contract->logic_acct_id << ","
                            << "is_reverse: " << hedger_contract->is_reverse << ","
                            << "pos from exch: " << pos_from_exch << ","
                            << "pos from trade(coin): " << hedger->getStrategyFields()->sym_risk.symbol_risk << ","
                            << "pos from trade(usd): " << hedger->getStrategyFields()->sym_risk.contract_usd_risk;
                    std::cout << ss.str() << std::endl;
                    quoter_strategy_fields_->setStrategyMode(StrategyMode::AbnormalPosMode, ss.str());

                    auto main_contract = quoter_strategy_fields_->contract_info;
                    quoter_strategy_fields_->order_manager->CancelAll(main_contract->logic_acct_id,
                                                                            main_contract->symbol_info->sid);
                    return;
                } else {
                    hedger->qryPosition();
                }
            }
        }
    }
}

void Gaia::FullLiquidation() {
    int64_t now = GaiaUtils::GetSysTimestamp();
    if(now - last_liquidation_ts > ONE_SECOND_IN_NANOS) {
        std::cout << "now: " << now << ","
                 << "last_liquidation_ts: " << last_liquidation_ts << std::endl;
        order_logic->FullLiquidation(*quoter_strategy_fields_);
        last_liquidation_ts = now;
    }
}

void Gaia::LiquidationRisk() {
    int64_t now = GaiaUtils::GetSysTimestamp();
    if(now - last_liquidation_ts > ONE_SECOND_IN_NANOS) {
        std::cout << "now: " << now << ","
                 << "last_liquidation_ts: " << last_liquidation_ts << std::endl;
        bool has_flight_order = false;
        if(hedger) {
            struct StrategyFields &hedgerStrategyFields = *hedger->getStrategyFields();

            // find flying order of hedger
            double hedge_bid_flight_coin = 0;
            double hedge_ask_flight_coin = 0;
            GaiaUtils::GetInFlightOrderCoin(hedgerStrategyFields, hedge_bid_flight_coin, hedge_ask_flight_coin);


            if(hedge_bid_flight_coin + hedge_ask_flight_coin > eps) {
                order_logic->CancelAllOnSide(hedgerStrategyFields, true, true);
                has_flight_order = true;
            }
        }

        double quote_bid_flight_coin = 0;
        double quote_ask_flight_coin = 0;
        GaiaUtils::GetInFlightOrderCoin(*quoter_strategy_fields_, quote_bid_flight_coin, quote_ask_flight_coin);

        if(quote_bid_flight_coin + quote_ask_flight_coin > eps) {
            order_logic->CancelAllOnSide(*quoter_strategy_fields_, true, true);
            has_flight_order = true;
        }

        if(has_flight_order) return;


        double baseCoinSum = 0;
        double hedger_risk = 0, quoter_risk = 0;
        if(quoter_strategy_fields_->contract_info->is_reverse) {
            quoter_risk = quoter_strategy_fields_->sym_risk.contract_usd_risk / GaiaUtils::GetMidPrice(quoter_strategy_fields_->contract_info);
        } else {
            quoter_risk = quoter_strategy_fields_->sym_risk.symbol_risk;
        }

        if(hedger) {
            struct StrategyFields &hedgerStrategyFields = *hedger->getStrategyFields();
            if(hedgerStrategyFields.contract_info->is_reverse) {
                hedger_risk = hedgerStrategyFields.sym_risk.contract_usd_risk / GaiaUtils::GetMidPrice(hedgerStrategyFields.contract_info);
            } else {
                hedger_risk = hedger->getBaseCoinRelQuoter();
            }
        }
        baseCoinSum = quoter_risk + hedger_risk;

        order_logic->LiquidateRisk(*quoter_strategy_fields_, baseCoinSum);

        last_liquidation_ts = now;
    }
}

G_INLINE void Gaia::RiskCheck() {
    // TODO: whether we need this check?
    // if(!quoter_strategy_fields_->sym_risk.initial_pos_coin_checked && std::fabs(quoter_strategy_fields_->sym_risk.initial_pos_coin) > eps) {
    //     if(quoter_strategy_fields_->sym_risk.symbol_risk < (-quoter_strategy_fields_->max_pos_coin-eps) || quoter_strategy_fields_->sym_risk.symbol_risk > (quoter_strategy_fields_->max_pos_coin + eps) ||
    //         hedger->getBaseCoinRelQuoter() < (-quoter_strategy_fields_->max_pos_coin-eps) || hedger->getBaseCoinRelQuoter() > (quoter_strategy_fields_->max_pos_coin + eps)) {
    //         if(!hedger->isHedged()) {
    //             std::string exit_reason = "symbol_risk is over max_pos_coin and not hedged, symbol_risk:" + std::to_string(quoter_strategy_fields_->sym_risk.symbol_risk) +
    //                                     ", hedger symbol_risk: " + std::to_string(hedger->getBaseCoinRelQuoter()) +
    //                                     ", initial_pos_coin:" + std::to_string(quoter_strategy_fields_->sym_risk.initial_pos_coin);
    //             quoter_strategy_fields_->setStrategyMode(StrategyMode::ExitMode, exit_reason);
    //             return false;
    //         }
    //     }
    //     quoter_strategy_fields_->sym_risk.initial_pos_coin_checked = true;
    // }

    // calc pnl
    double total_pnl = 0;
    double realized_pnl = 0;

    GaiaUtils::calculateRealTimePnl(quoter_strategy_fields_);
    if(hedger) {
        // if(!hedger->getStrategyFields()->sym_risk.initial_pos_coin_checked && std::fabs(hedger->getStrategyFields()->sym_risk.initial_pos_coin) > eps) {
        //     if(quoter_strategy_fields_->sym_risk.symbol_risk < (-quoter_strategy_fields_->max_pos_coin-eps) || quoter_strategy_fields_->sym_risk.symbol_risk > (quoter_strategy_fields_->max_pos_coin + eps) ||
        //         hedger->getBaseCoinRelQuoter() < (-quoter_strategy_fields_->max_pos_coin-eps) || hedger->getBaseCoinRelQuoter() > (quoter_strategy_fields_->max_pos_coin + eps)) {
        //         if(!hedger->isHedged()) {
        //             std::string exit_reason = "hedger symbol_risk is over max_pos_coin and not hedged, symbol_risk:" + std::to_string(quoter_strategy_fields_->sym_risk.symbol_risk) +
        //                                     ", hedger symbol_risk: " + std::to_string(hedger->getBaseCoinRelQuoter()) +
        //                                     ", initial_pos_coin:" + std::to_string(hedger->getStrategyFields()->sym_risk.initial_pos_coin);
        //             quoter_strategy_fields_->setStrategyMode(StrategyMode::ExitMode, exit_reason);
        //             return false;
        //         }
        //     }
        //     hedger->getStrategyFields()->sym_risk.initial_pos_coin_checked = true;
        // }
        hedger->calculateHedgerPnl();
        total_pnl += hedger->getMtmPnlUsd();
        realized_pnl += hedger->getRealizedPnlUsd();
    }

    if(quoter_strategy_fields_->contract_info->is_reverse) {
        realized_pnl += quoter_strategy_fields_->sym_risk.realized_pnl * GaiaUtils::GetMidPrice(quoter_strategy_fields_->contract_info);
        total_pnl += (quoter_strategy_fields_->sym_risk.realized_pnl + quoter_strategy_fields_->sym_risk.unrealized_pnl) * GaiaUtils::GetMidPrice(quoter_strategy_fields_->contract_info);
    } else {
        total_pnl += quoter_strategy_fields_->sym_risk.realized_pnl + quoter_strategy_fields_->sym_risk.unrealized_pnl;
        realized_pnl += quoter_strategy_fields_->sym_risk.realized_pnl;
    }
    quoter_strategy_fields_->sym_risk.total_pnl = total_pnl;
    quoter_strategy_fields_->sym_risk.total_realized_pnl = realized_pnl;

    if (hedger && hedger->isHedged())  {
        quoter_strategy_fields_->sym_risk.max_pnl = std::max(realized_pnl, quoter_strategy_fields_->sym_risk.max_pnl);
    }

    order_logic->RiskCheckLogic(*quoter_strategy_fields_);
}

void Gaia::OnReconDone(const ReconState &recon)
{
    // order_manager performs a order and position reconciliation with trade server
    // when connected, this callback is invoked when it is finished.
    // order_manager is also ready to send out orders from this point on.

    struct ContractInfo *orderContract = quoter_strategy_fields_->contract_info;

    int64_t now = GaiaUtils::GetSysTimestamp();
    last_qry_balance_ts = now;
    // std::cout << "recon done" << std::endl;
    for (auto order : recon.orders)
    {
        std::cout << "order: " << order->client_order_id().value << " sid:" << order->sid() << order->price()
                    << "@" << order->leaves_qty() << std::endl;
    }
    order_manager()->CancelAll(quoter_logic_acct_id, quoter_sid_);

    if (recon.positions.count(quoter_logic_acct_id))
    {

        double symbol_risk;
        double contract_coin_risk;
        double contract_usd_risk;
        double realisedPnl;

        for (auto &pos : recon.positions.at(quoter_logic_acct_id))
        {
            // LOG_AUTO(OnReconPositionMessage, quoter_logic_acct_id, pos.sid, pos.avg_entry_price, pos.cum_realised_pnl, pos.unrealised_pnl, pos.pos_size);
        }
    }
    if (recon.balances.count(quoter_logic_acct_id))
    {
        for (auto &bal : recon.balances.at(quoter_logic_acct_id))
        {
            std::cout << "quoter balance coin:" << bal.coin << " frozen:" << bal.frozen
                        << " available:" << bal.available << " total:" << bal.total << std::endl;

            GaiaUtils::FillBalance(*quoter_strategy_fields_, bal.logic_acct_id, bal.sid, bal.total, bal.available, now);

            // LOG_AUTO(OnReconBalanceMessage, quoter_logic_acct_id, bal.coin, bal.frozen, bal.available, bal.total);
        }
    }

    qryPosition();
}

void Gaia::qryPosition() {
    auto now = GaiaUtils::GetSysTimestamp();
    last_qry_pos_ts = now;
    struct ContractInfo *orderContract = quoter_strategy_fields_->contract_info;

    if (quoter_strategy_fields_->contract_info->symbol_info->mirana_ticker.find("_Spot_") != std::string::npos) {
        std::cout << "QryPosition from balance: " << orderContract->logic_acct_id << "," <<  quoter_sid_ << "," << quoter_strategy_fields_->contract_info->symbol_info->base_sid << std::endl;
        std::this_thread::sleep_for(std::chrono::seconds(2));
        ts_client()->QryBalance(quoter_strategy_fields_->contract_info->logic_acct_id, quoter_strategy_fields_->contract_info->symbol_info->base_sid);
    } else {
        std::cout << "QryPosition: " << orderContract->logic_acct_id << "," <<  quoter_sid_ << std::endl;
        ts_client()->QryPosition(orderContract->logic_acct_id, quoter_sid_);
    }
}

void Gaia::OnUnknownFill(const Order *order, const OrderFill &fill)
{
    // TODO: handle late fills: some exchanges may send fills after the order is
    // rejected, canceled, etc., these fills can't be handled in the normal fill
    // callback because we may have already deleted the orders.
    // Note that the order will be automatically deleted after this callback.
    if (strategy_fieldsMap.find(order->sid()) == strategy_fieldsMap.end())
    {
        // std::cout << "warning: " << " cannot find sid  " << order->sid() << "in gaia unknown fill" << std::endl;
        return;
    }

    int64_t now = GaiaUtils::GetSysTimestamp();
    int sign = order->side() == Side::BUY ? 1 : -1;
    struct StrategyFields *strategy_fields = &strategy_fieldsMap[order->sid()];
    struct ContractInfo *orderContract = strategy_fields->contract_info;

    GaiaUtils::updatePosition(strategy_fields, fill.qty, sign, fill.prc, fill.fee);
    HedgingLogic(*strategy_fields, nullptr, "UnknownFill", fill.prc, fill.qty, sign, fill.fee);

    std::string eventStr = "UnknownFill";

    double fee = fill.fee;
    LOG_AUTO(ExecMessage, 0, eventStr.c_str(), strategy_fields->signal.pred_value, GaiaUtils::BookGetBestBidPrice(strategy_fields->contract_info),
                                GaiaUtils::BookGetBestAskPrice(strategy_fields->contract_info), now, (int64_t)0,
                                order->client_order_id().value, order->exch_order_id(), eventStr.c_str(), 0, orderContract->logic_acct_id, orderContract->symbol_info->mirana_ticker.c_str(),
                                int16_t(order->sid()), strategy_fields->sym_risk.symbol_risk, 
                                0, 0, sign, fill.prc,
                                fill.fee, fill.fee_sid, 0, fill.qty, fill.exch_ts, -1);
}

void Gaia::OnPositionUpdate(const trading_system_ts::PositionUpdate &position)
{

    int logic_acct_id = position.logic_acct_id;
    SymId sid = position.sid;
    // int err_code = position.err_code;

    double cum_realised_pnl = position.cum_realised_pnl;
    double unrealised_pnl = position.unrealised_pnl;
    double leverage = position.leverage;
    double liq_price = position.liq_price;

    double pos_size = position.pos_size;
    double position_mm = position.position_mm;
    double avg_entry_price = position.avg_entry_price;

    std::string positionSideStr;
    switch (position.position_side)
    {
    case PositionSide::UNKNOWN:
        positionSideStr = "UNKNOWN";
        break;
    case PositionSide::NET:
        positionSideStr = "NET";
        break;
    case PositionSide::LONG:
        positionSideStr = "LONG";
        break;
    case PositionSide::SHORT:
        positionSideStr = "SHORT";
        break;
    default:
        break;
    }

    // if ((pos_size > 0) && (position.position_side == PositionSide::SHORT)) pos_size = - pos_size;

    const SymbolInfo *symbol = SecMaster::instance().GetSymbol(sid);
    double sym_risk = 0;
    double symNotionalRisk = 0;
    bool is_reverse = false;

    if (symbol->mirana_ticker.find("InverseSwap") != std::string::npos)
        is_reverse = true;

    if (is_reverse) {
        double contract_coin_risk = pos_size * symbol->multiplier / avg_entry_price;
        double contract_usd_risk = pos_size * symbol->multiplier;

        double realisedPnl = 0;

        sym_risk = contract_coin_risk + realisedPnl;
    } else {
        sym_risk = pos_size * symbol->multiplier;
    }
}

void Gaia::OnOrderUpdate(Order *order, const OrderStatusUpdate &update) {
    if(strategy_fieldsMap.find(order->sid()) == strategy_fieldsMap.end()) {
        std::cout << "warning: " << " cannot find sid  " << order->sid() << "in gaia order update" << std::endl;
    }

    int64_t now = GaiaUtils::GetSysTimestamp();

    struct StrategyFields *strategy_fields = &strategy_fieldsMap[order->sid()];
    struct ContractInfo *contract_info = strategy_fields->contract_info;

    auto e = update.event;

    // if not sent by this time
    if (strategy_fields->order_manager->orders().find(order->client_order_id().value) == strategy_fields->order_manager->orders().end()) {
        return;
    }

    // if found in order_manager, but not in order_state_map, create a new order state
    if(strategy_fields->order_state_map.find(order->client_order_id().value) == strategy_fields->order_state_map.end()) {
        GOrderState *new_order_state = strategy_fields->order_state_pool.new_object();
        new_order_state->strategy = strategy_fields;
        new_order_state->contract_info = contract_info;
        new_order_state->ts_order = order;
        strategy_fields->order_state_map[order->client_order_id().value] = new_order_state;
        // if(order->closed()) order_manager()->CloseOrder(order);
        // return;
    }

    int8_t sign;
    if (order->side() == Side::BUY)
        sign = 1;
    else
        sign = -1;

    if(update.err_code == 0 && strategy_fields->current_mode == StrategyMode::BalanceLimitMode && 
        (update.event == OrderStatusEvent::NEW || update.event == OrderStatusEvent::REPLACED ||
            update.event == OrderStatusEvent::FILLED || update.event == OrderStatusEvent::PARTIALLY_FILLED)) {
        strategy_fields->setStrategyMode(StrategyMode::NormalMode, "receive order update");
    }

    struct GOrderState *localOrder = strategy_fields->order_state_map[order->client_order_id().value];
    localOrder->order_status_event = update.event;
    localOrder->err_code = update.err_code;
    localOrder->last_order_update_time = GaiaUtils::GetSysTimestamp();

    std::string orderStatusEventStr;
    switch (e)
    {
    case OrderStatusEvent::NEW:
        orderStatusEventStr = "NEW";
        localOrder->live_status_time = localOrder->last_order_update_time;
        if(!order->closed())
            order_logic->OnOrderAccepted(localOrder);
        break;
    case OrderStatusEvent::REPLACED:
        orderStatusEventStr = "REPLACED";
        break;
    case OrderStatusEvent::UNKNOWN:
        orderStatusEventStr = "UNKNOWN";
        break;
    case OrderStatusEvent::CANCELED:
        orderStatusEventStr = "CANCELED";
        break;
    case OrderStatusEvent::FILLED:
        orderStatusEventStr = "FILLED";
        break;
    case OrderStatusEvent::PARTIALLY_FILLED:
        orderStatusEventStr = "PARTIALLY_FILLED";
        break;
    case OrderStatusEvent::TS_CANCEL_ACKED:
        orderStatusEventStr = "TS_CANCEL_ACKED";
        break;
    case OrderStatusEvent::TS_NEW_ACKED:
        orderStatusEventStr = "TS_NEW_ACKED";
        break;
    case OrderStatusEvent::INTERNAL_REJECTED:
        orderStatusEventStr = "INTERNAL_REJECTED";
        break;
    case OrderStatusEvent::CANCEL_INTERNAL_REJECTED:
        orderStatusEventStr = "CANCEL_INTERNAL_REJECTED";
        break;
    case OrderStatusEvent::CANCEL_ERROR:
        orderStatusEventStr = "CANCEL_ERROR";
        break;
    case OrderStatusEvent::REPLACE_INTERNAL_REJECTED:
        orderStatusEventStr = "REPLACE_INTERNAL_REJECTED";
        break;
    case OrderStatusEvent::REPLACE_ERROR:
        orderStatusEventStr = "REPLACE_ERROR";
        break;
    case OrderStatusEvent::TS_REPLACE_ACKED:
        orderStatusEventStr = "TS_REPLACE_ACKED";
        break;
    case OrderStatusEvent::REJECTED:
        orderStatusEventStr = "REJECTED";
        break;
    case OrderStatusEvent::CANCEL_REJECTED:
        localOrder->last_cancel_reject_time = now;
        orderStatusEventStr = "CANCEL_REJECTED";
        break;
    case OrderStatusEvent::REPLACE_REJECTED:
        orderStatusEventStr = "REPLACE_REJECTED";
        break;
    default:
        break;
    }
    int tmp_err_code = update.err_code;
    if(contract_info->symbol_info->exch == Exchange::OKEX) {
        if (tmp_err_code == 51008) tmp_err_code = 322;
    } else if (contract_info->symbol_info->exch == Exchange::BINANCE) {
        // binance error code contains too many meanings.
        if ((contract_info->symbol_info->product_type == ProductType::LINEAR_SWAP ||
            contract_info->symbol_info->product_type == ProductType::INVERSE_SWAP) && tmp_err_code == -2010) tmp_err_code = 322;
    }
    switch (tmp_err_code)
    {
    case 211:
        // REJECT_MKT_CONN_ORDER_RATE
        localOrder->last_cancel_reject_time = now;
        if(order_logic->getCommonConfig().rate_limit_duration_ms > 0) {
            if(quoter_strategy_fields_->current_mode != StrategyMode::RateLimitMode) {
                quoter_strategy_fields_->setStrategyMode(StrategyMode::RateLimitMode, "211, rate limit");
            }
            quoter_strategy_fields_->last_rate_limit_ts = now;
        }
        break;
    case 322:
        // MKT_BALANCE_INSUFFICIENT
        if(order_logic->getCommonConfig().use_balance_limit_mode) {
            quoter_strategy_fields_->setStrategyMode(StrategyMode::BalanceLimitMode, "322, balance insufficient");
            quoter_strategy_fields_->last_balance_limit_ts = now;
        } else {
            quoter_strategy_fields_->setStrategyMode(StrategyMode::LiquidateRiskMode, "322, balance insufficient");
        }
        break;
    case 212:
        // REJECT_PNL_LOSS
        quoter_strategy_fields_->setStrategyMode(StrategyMode::RiskExitMode, "212, reject pnl loss");
        break;
    case 204:
        // REJECT_MAX_POSITION
        quoter_strategy_fields_->setStrategyMode(StrategyMode::LiquidateRiskMode, "204, REJECT_MAX_POSITION");
    case 205:
        // REJECT_MAX_POSITION_VALUE
        quoter_strategy_fields_->setStrategyMode(StrategyMode::LiquidateRiskMode, "205, REJECT_MAX_POSITION_VALUE");
    case 206:
        // REJECT_WORST_VALUE_EXPOSURE
        quoter_strategy_fields_->setStrategyMode(StrategyMode::LiquidateRiskMode, "206, REJECT_WORST_VALUE_EXPOSURE");
    case 207:
        // REJECT_WORST_POS_EXPOSURE
        quoter_strategy_fields_->setStrategyMode(StrategyMode::LiquidateRiskMode, "206, REJECT_WORST_POS_EXPOSURE");
    case 208:
        // REJECT_POS_INCREASE_RESTRICTED
        quoter_strategy_fields_->setStrategyMode(StrategyMode::LiquidateRiskMode, "208, REJECT_POS_INCREASE_RESTRICTED");
        break;
    default:
        break;
    }

    if (update.fill_qty > 0)
    {
        ExecLiquidityType lqd_type = update.lqd_type;


        if (!(localOrder->syntheticFilledTs > 0))
        {
            // only update position if it is not synthetically filled

            GaiaUtils::updatePosition(strategy_fields, update.fill_qty, sign, update.fill_price, update.fee);
            if(checkBookAndPosStatus())
            {
                HedgingLogic(*strategy_fields, localOrder, std::string(update.trade_id), update.fill_price, update.fill_qty, sign, update.fee);
            }
            localOrder->leavesQty = order->leaves_qty() * contract_info->symbol_info->multiplier;

            double midPrice = GaiaUtils::GetMidPrice(contract_info);
            if (contract_info->is_reverse)
                localOrder->leavesQty = localOrder->leavesQty / midPrice;
        }

        // TODO: proper hedging logic and framework
        // md::Trade custom_trade;
        // GaiaUtils::convertOrderUpdateToTrade(order, update, custom_trade);

        // OnTrade(custom_trade);

        localOrder->fillQty = update.fill_qty;
        localOrder->fillPrice = update.fill_price;
        localOrder->fillFee = update.fee;
        order_logic->OnOrderFilled(localOrder);

        // ts_client()->QryBalance(contract_info->logic_acct_id); //, order->sid());


        double fee = update.fee;
        LOG_AUTO(ExecMessage, (int)e, orderStatusEventStr.c_str(), strategy_fields->signal.pred_value, GaiaUtils::BookGetBestBidPrice(strategy_fields->contract_info),
                                    GaiaUtils::BookGetBestAskPrice(strategy_fields->contract_info),
                                    now, localOrder->syntheticFilledTs,
                                    order->client_order_id().value, order->exch_order_id(), update.trade_id, update.err_code, contract_info->logic_acct_id, contract_info->symbol_info->mirana_ticker.c_str(),
                                    int16_t(order->sid()), strategy_fields->sym_risk.symbol_risk,
                                    int(localOrder->syntheticFilledTs > 0), localOrder->syntheticFillTriggeredLeavesQty, int(sign), update.fill_price,
                                    fee, update.fee_sid, update.remain_order_rate, update.fill_qty, update.exch_ts, localOrder->strategy_order_type);
    }

    if (order->closed())
    {

        if (localOrder->syntheticFilledTs > 0)
        {
            double syntheticFillTriggeredLeavesQty = localOrder->syntheticFillTriggeredLeavesQty;
            double orderFilledQty = order->cum_fill_qty();
            double orderLeavesQty = order->leaves_qty(); // will be hardcoded to zero when closed() returns true
            double orderQty = order->qty();
            int orderSideInt = order->side() == Side::BUY ? 1 : -1;

            if (!(orderFilledQty == orderQty))
            {
                double adjustQty = syntheticFillTriggeredLeavesQty - orderFilledQty;

                GaiaUtils::updatePosition(strategy_fields, adjustQty, -orderSideInt, order->price(), 0);
                if(checkBookAndPosStatus())
                    HedgingLogic(*strategy_fields ,localOrder, std::string(update.trade_id), order->price(), adjustQty, -orderSideInt, 0);

                LOG_AUTO(SyntheticFillFalseFillMsg, orderFilledQty, order->client_order_id().value, orderLeavesQty,
                                                            localOrder->syntheticFilledTs, localOrder->syntheticFillTriggeredLeavesQty,
                                                            order->leaves_qty(), order->qty(), order->cum_fill_qty(), contract_info->logic_acct_id);

            }
        }

        order_logic->OnOrderClosed(localOrder);
        strategy_fields->order_state_map.erase(localOrder->client_order_id);
        strategy_fields->order_state_pool.delete_object(localOrder);

        bool close_status = order_manager()->CloseOrder(order);

    }

    // call hedging logic order update is not traded
    if (update.fill_qty < eps)
    {
        // if(checkBookAndPosStatus())
        // {
        //     HedgingLogic(*strategy_fields, nullptr, std::string(update.trade_id), update.fill_price, update.fill_qty, sign, update.fee);
        // }
        if(hedger) hedger->tryHedge();
    }
}

void Gaia::HedgingLogic(StrategyFields &strategy_fields, GOrderState *orderState, const std::string &tradeId,
                    const double &quoterFilledPrice, const double &quoterFilledSize, const int8_t &quoterFilledSideInt,
                    const double &quoterFilledFees)
{
    if(hedger)
        hedger->HedgingLogic(strategy_fields, orderState, tradeId, quoterFilledPrice, quoterFilledSize, quoterFilledSideInt, quoterFilledFees);
}


void Gaia::StrategyForceExit()
{
    /// check liquidation status
    int64_t now = GaiaUtils::GetSysTimestamp();
    if (now - last_force_exit_ts > NS_PER_SEC)
    {
        bool need_close_program = true;
        // count existing orders
        if(hasQuoterInflightOrder()) {
            order_manager()->CancelAll(quoter_logic_acct_id, quoter_sid_);
            std::cout << "has quoter inflight order" << std::endl;
            need_close_program = false;
        }

        if(hasHedgerInflightOrder()) {
            hedger->CancelAll();
            std::cout << "has hedger inflight order" << std::endl;
            need_close_program = false;
        }

        if(need_close_program)
        {
            std::cout << "program exit finished!!!" << std::endl;
            sleep(1);
            // hedger will be automatically destroyed by unique_ptr
            if (hedger) {
                delete hedger;
                hedger = nullptr;
            }
            ts_client()->Logout();
            for(auto it = strategy_fieldsMap.begin(); it != strategy_fieldsMap.end(); ++it)
            {
                StrategyFields &sf = it->second;
                // TODO: Add your code here
                sf.order_state_pool.delete_all();
            }
            abort();
        }

        last_force_exit_ts = now;
    }
}

void Gaia::RiskExit() {
    /// check liquidation status
    int64_t now = GaiaUtils::GetSysTimestamp();
    if (now - last_force_exit_ts > NS_PER_SEC)
    {
        std::cout << __FUNCTION__ << std::endl;
        
        std::cout << "Risk Check: stop loss , enter risk exit , total_pnl: " << quoter_strategy_fields_->sym_risk.total_pnl << ","
                    << "max_pnl: " << quoter_strategy_fields_->sym_risk.max_pnl << ","
                    << "unrealized_pnl: " << quoter_strategy_fields_->sym_risk.unrealized_pnl << ","
                    << "realized_pnl: " << quoter_strategy_fields_->sym_risk.realized_pnl << ",";
                    
        if (hedger) {
            std::cout << "hedger unrealized_pnl: " << hedger->getUnrealizedPnlUsd() << ","
                        << "hedger realized_pnl: " << hedger->getRealizedPnlUsd() << ","; 
        }
        std::cout << "first_trigger_ts:" << quoter_strategy_fields_->sym_risk.stop_loss_first_trigger_ts << ","
                    << "now:" << now
                    << std::endl;

        bool need_close_program = true;
        // count existing orders
        if(hasQuoterInflightOrder()) {
            order_logic->CancelAllOnSide(*quoter_strategy_fields_, true, true);
            std::cout << "has quoter inflight order" << std::endl;
            need_close_program = false;
        }

        if(hasHedgerInflightOrder()) {
            hedger->CancelAll();
            std::cout << "has hedger inflight order" << std::endl;
            need_close_program = false;
        }

        if(hedger)
        {
            if(!hedger->isHedged()) 
            {
                std::cout << "is not hedged" << std::endl;
                hedger->tryHedge();

                need_close_program = false;
            }
        }

        if(need_close_program)
        {
            std::cout << "program exit finished!!!" << std::endl;
            sleep(1);
            for(auto it = strategy_fieldsMap.begin(); it != strategy_fieldsMap.end(); ++it)
            {
                StrategyFields &sf = it->second;
                // TODO: Add your code here
                sf.order_state_pool.delete_all();
            }
            abort();
        }

        last_force_exit_ts = now;
    }
}

void Gaia::DisconnectLogic() {
    auto now = GaiaUtils::GetSysTimestamp();
    if (now - last_force_exit_ts < NS_PER_SEC) return;
    last_force_exit_ts = now;

    bool has_quoter_inflight = hasQuoterInflightOrder();
    if(has_quoter_inflight) {
        order_logic->CancelAllOnSide(*quoter_strategy_fields_, true, true);
    }

    if(hedger) {
        hedger->tryHedge();
    }

    bool hedged = (!hedger || hedger->isHedged());

    // if (!has_quoter_inflight && !hasHedgerInflightOrder() && hedged) {
    //     strategy_fieldsMap[quoter_sid].setStrategyMode(StrategyMode::ExitMode, "exit from DisconnectMode, no flight order, no hedger flight order, and hedged");
    // }
}

void Gaia::OnNewTradingDay()
{
}

void Gaia::OnReady()
{
    connected_ = true;
    std::string msg_type = __FUNCTION__;
    std::string msg = "Gaia OnReady";
    LOG_AUTO(CustomMsg, msg_type, msg);
    quoter_strategy_fields_->setStrategyMode(StrategyMode::UnknownMode, "OnReady");
}

void Gaia::OnDisconnect() {
    connected_ = false;
    std::string msg_type = __FUNCTION__;
    std::string msg = "Gaia Disconnect";
    LOG_AUTO(CustomMsg, msg_type, msg);

    quoter_strategy_fields_->setStrategyMode(StrategyMode::DisconnectMode, "OnDisconnect");
}

bool Gaia::hasQuoterInflightOrder()
{
    int order_count = 0;
    OrderManager::OrderMap order_map = order_manager()->orders();
    for (const auto &iter : order_map)
    {
        Order *currentOrder = iter.second;
        if (currentOrder->sid() == quoter_sid_)
        {
            std::cout << "has sid:" << currentOrder->sid() << ","
                      << "order_id:" << currentOrder->client_order_id().value << std::endl;
            order_count = order_count + 1;
        }
    }

    return order_count > 0;
}

bool Gaia::hasHedgerInflightOrder()
{
    int hedger_order_count = 0;
    if(hedger) {
        hedger_order_count = GaiaUtils::GetInFlightOrderCount(*hedger->getStrategyFields());
    }

    return hedger_order_count > 0;
}

// used only in SIM_MODE, result sent to OnSignalUpdate
void Gaia::CalcAssist(ContractInfo *&cur_contract, const TickEventType &_cur_tick_type) {
#ifdef SIM_MODE
    if(assist_sids_.find(cur_contract->symbol_info->sid) == assist_sids_.end()) return;
#ifdef RECORD_LATENCY
    quoter_strategy_fields_->latency.predictor_start_ts = GaiaUtils::GetRealSysTimestamp();
#endif
    if (assist_calculator_) {
        switch(_cur_tick_type) {
            case TickEventType::TICK_TRADE:
            assist_calculator_->OnTrade(cur_contract->trade);
            break;
            case TickEventType::TICK_OB:
            assist_calculator_->OnOrderbook(cur_contract->ob_data.get_view());
            break;
            case TickEventType::TICK_BBO:
            assist_calculator_->OnBestQuote(cur_contract->quote);
            break;
            case TickEventType::TICK_LIQUIDATION:
            assist_calculator_->OnLiquidation(cur_contract->liquidation);
            break;
            case TickEventType::TICK_KLINE:
            assist_calculator_->OnKline(cur_contract->kline);
            break;
            default:
            break;
        }
    }
#endif
}

void Gaia::WarmUp(int64_t &now, bool force) {
    if (!common_config.useWarmUp) return;
    if (quoter_strategy_fields_->current_mode != StrategyMode::NormalMode) return;

    if (!force && now - quoter_strategy_fields_->snapshot.last_insert_or_replace_ts < WARMUP_INTERVAL) return;
    if (!force && now - last_warmup_ts < WARMUP_INTERVAL) return;
    last_warmup_ts = now;

    CalcOrderLogic(quoter_strategy_fields_->contract_info, TickEventType::TICK_WARMUP);
}
