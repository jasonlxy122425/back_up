#pragma once
#include <string>
#include "CommonDefine.h"
#include "ContractInfo.h"
#include "SpdLoggerMessage.h"
#include "SpdLogger.h"

// symbol, maker fees, taker fees bps

class GaiaUtils
{
public:
    static std::unordered_map<std::string, std::tuple<double, double>> fees_table;

    static void updatePosition(struct StrategyFields* strategy_fields, const double filledQty, const int filledSideInt, const double filledPrice, const double filledFee);
    static void updateNetPos(StrategyFields* strategy_fields, double pos_size, double avg_entry_price);

    static void calculatePnlByTrade(struct StrategyFields* strategy_fields, const double filledQty, const int filledSideInt, const double filledPrice, const double filledFee);
    static void calculateRealTimePnl(struct StrategyFields* strategy_fields);

    static void initSymbolRisk(struct StrategyFields* strategy_fields);

    static const SymbolInfo* getSecMasterSymbol(std::string s);
    static const SymbolInfo* getSecMasterSymbol(SymId sid);

    static Nanoseconds GetSysTimestamp();

    static Nanoseconds GetRealSysTimestamp();
    static std::string NanoTimestampToString(int64_t nanoTimestamp);

    static bool roundPriceViaSignificantNum(double &price, int significant_num = 5) {
        if (significant_num <= 0) {
            return false;
        }

        if (std::fabs(price - std::round(price)) < eps) {
            return true;
        }

        int integer_num = static_cast<int>(std::floor(std::log10(std::fabs(price)))) + 1;
        int decimal_places = significant_num - integer_num;

        if (decimal_places <= 0) {
            price = std::floor(price);
        } else {
            double factor = std::pow(10, decimal_places);
            price = std::floor(price * factor) / factor;
        }
        return true;
    }

    template <typename T>
    static T GetParam(const Config &config, std::string param_name) {
        auto param_value = config.Get<T>(param_name);
        std::cout << param_name << " : " << param_value << std::endl;
        LOG_AUTO(ParamUpdateMsg, param_name, param_value);
        return param_value;
    }

    template<typename T>
    static inline double TradeGetPrice(T* const &ci) {
        return ci->trade.price;
    }

    template<typename T>
    static inline double TradeGetQty(T* const &ci) {
        return ci->trade.qty;
    }

    template<typename T>
    static inline double BookGetBestBidPrice(T* const &ci) {
        return ci->alphaBook->bid(0).price;
    }

    template<typename T>
    static inline double BookGetBestAskPrice(T* const &ci) {
        return ci->alphaBook->ask(0).price;
    }

    template<typename T>
    static inline double BookGetBestBidSize(T* const &ci) {
        return BookGetBidLevel(ci, 0).qty;
    }

    template<typename T>
    static inline double BookGetBestAskSize(T* const &ci) {
        return BookGetAskLevel(ci, 0).qty;
    }

    template<typename T>
    static inline struct PriceLevel BookGetBidLevel(T* const &ci, int level) {
        return ci->alphaBook->bid(level);
    }

    template<typename T>
    static inline struct PriceLevel BookGetAskLevel(T* const &ci, int level) {
        return ci->alphaBook->ask(level);
    }

    template<typename T>
    static inline int32_t BookGetNumBidLevels(T* const &ci) {
        return ci->alphaBook->num_bids();
    }

    template<typename T>
    static inline int32_t BookGetNumAskLevels(T* const &ci) {
        return ci->alphaBook->num_asks();
    }

    template<typename T>
    static inline int32_t BookNumBidLevels(T* const &ci) {
        return ci->alphaBook->num_bids();
    }

    template<typename T>
    static inline int32_t BookNumAskLevels(T* const &ci) {
        return ci->alphaBook->num_asks();
    }

    template<typename T>
    static inline double GetMidPrice(T* const &ci) {
        return (BookGetBestBidPrice(ci) + BookGetBestAskPrice(ci)) / 2;
    }

    template<typename T>
    static inline double roundPriceViaTickSize(double price, T* const &ci) {
        return (double)((int64_t)round(price / ci->symbol_info->prc_tick_size + eps)) * ci->symbol_info->prc_tick_size;
    }

    static inline double roundPriceViaTickSize(double price, double &price_tick) {
        return (double)((int64_t)round(price / price_tick + eps)) * price_tick;
    }

    template<typename T>
    static inline double roundSizeViaQtyTick(double size, T* const &ci) {
        double size_eps = size + ((size >= 0) ? eps : -eps);
        double rounded_size = round(size_eps / ci->symbol_info->qty_tick_size) * ci->symbol_info->qty_tick_size;
        return rounded_size;
    }

    template<typename T>
    static inline double floorSizeViaQtyTick(double size, T* const &ci) {
        double size_eps = size + ((size >= 0) ? eps : -eps);
        double floor_size = floor(size_eps / ci->symbol_info->qty_tick_size) * ci->symbol_info->qty_tick_size;
        return floor_size;
    }

    template<typename T>
    static inline double ceilSizeViaQtyTick(double size, T* const &ci) {
        double size_eps = size + ((size >= 0) ? eps : -eps);
        double rounded_size = ceil(size_eps / ci->symbol_info->qty_tick_size) * ci->symbol_info->qty_tick_size;
        return rounded_size;
    }

    static inline double ceilPrice(double price, double &min_tick) {
        return (ceil(price / min_tick - eps)) * min_tick;
    }

    static inline double floorPrice(double price, double &min_tick) {
        return (floor(price / min_tick + eps)) * min_tick;
    }

    static inline double isWorsePrice(int &sideInt, double price, double price2) {
        return double(sideInt) * price < double(sideInt) * price2;
    }

    static inline double isBetterPrice(int &sideInt, double price, double price2) {
        return double(sideInt) * price > double(sideInt) * price2;
    }

    static void GetCoinSizeFromNotional(StrategyFields &strategy_fields, const double &notional_size, const double &coin_size);

    static void GetInFlightOrderCoin(StrategyFields &strategy_fields, double &bid_inflight_coin, double &ask_inflight_coin);

    static void GetInFlightOrderUsd(StrategyFields &strategy_fields, double &bid_inflight_coin, double &ask_inflight_coin);

    static int GetInFlightOrderCount(StrategyFields &strategy_fields);

    static md::Trade convertOrderUpdateToTrade(Order *order, const OrderStatusUpdate &update, md::Trade &custom_trade);

    static void FillBalance(StrategyFields &strategy_fields, LogicAcctId logic_acct_id, SymId sid, double total, double available, Nanoseconds exch_ts=0);
    static void getFeeRate(double &makerFeeBps, double &takerFeeBps, const std::string mirana_ticker);

    static std::atomic<bool> ForceExitFlag;
    static std::atomic<bool> FullLiquidationFlag;
    static std::atomic<bool> LiquidateRiskFlag;
};
