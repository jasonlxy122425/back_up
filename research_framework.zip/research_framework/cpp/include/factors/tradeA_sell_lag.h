#include "Factor.h"
#include "Ema.h"
#include <cmath>
#include "GaiaCircularBuffer.h"

class TradeASellLagFactor : public FactorInterface
{
public:
    TradeASellLagFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
        lookback = config.Get<int64_t>("lookback");
        last_prc_buffer.setSize(lookback, 0.0);

    };

    virtual std::string gen_name() {;
        return std::string("TradeASellLagFactor") + "@lookback=" + std::to_string(lookback);
    }

    virtual void calculate(const FactorInput& input_data) {
        factor_value = 0.0;
        auto &trade = input_data.cur_contract->trade;
        int64_t exch_ts = trade.exch_ts;
        if (trade.side == Side::SELL){
            if (std::abs(exch_ts - prev_exch_ts) > MinErr){
                last_prc_buffer.push(trade.price);
            }
            else {
                last_prc_buffer[-1] = trade.price;
            }
        }
        if(last_prc_buffer.isFull() != false){
            factor_value = last_prc_buffer.back() - last_prc_buffer.front();
        }
        prev_exch_ts = exch_ts;
        
    };

private:
    int64_t lookback;
    GaiaCircularBuffer<double> last_prc_buffer;
    int64_t prev_exch_ts = 0;
    double last_price = 0.0;
    
};
                              
