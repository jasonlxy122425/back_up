#pragma once

#include "GaiaOrderbookManager.h"
#include "nlohmann/json.hpp"
#include "CommonDefine.h"
#include <unordered_map>
#include <parallel_hashmap/phmap.h>


namespace demeter {
    class DemeterData;
}; // namespace demeter

struct MktDataLatency
{
    int64_t mkt_recv_ts;
    int64_t mkt_exch_ts;
    int64_t mkt_qs_send_ts;
    int64_t mkt_parse_end_ts;
    int64_t mkt_cb_start_ts;
};

struct StrategyLatency
{
    int64_t batch_start_ts;
    int64_t batch_size;
    int64_t gaia_start_ts;
    int64_t demeter_start_ts;
    int64_t predictor_start_ts;
    int64_t risk_start_ts;
    int64_t order_logic_start_ts;
    int64_t hedger_start_ts;

    int64_t gaia_end_ts;
};

struct GLatencyRecord
{
    struct MktDataLatency mkt_data;
};

struct ContractInfo
{
    ContractInfo()
    {
        trade.price = 0;
        max_mkt_qty = 0;
    }

    void setSymbolInfo(SymbolInfo *symbol)
    {
        symbol_info = new SymbolInfo();
        *symbol_info = *symbol;

        symbol_info->mirana_ticker = symbol->mirana_ticker;
        symbol_info->exch_ticker = symbol->exch_ticker;
        symbol_info->md_ticker = symbol->md_ticker;

        if(symbol->exch == Exchange::KUCOIN)
        {
            symbol_info->min_qty = symbol->qty_tick_size;
        }

        max_mkt_qty = symbol_info->max_qty;
        if (!symbol->remark.empty()) {
            max_mkt_qty = symbol_info->max_qty;
            nlohmann::json j = nlohmann::json::parse(symbol->remark);
            if(j.contains("max_mkt_qty")) {
                max_mkt_qty = std::stod(j["max_mkt_qty"].get<std::string>());
            }
        }
        std::cout << "max_mkt_qty: " << max_mkt_qty << std::endl;
    };

    static ContractInfo* GetContractInfo(const std::string& s);
    static ContractInfo* GetContractInfo(SymId sid);

    int logic_acct_id;
    // new local symbol_info due to Kucoin only have qty_tick_size
    SymbolInfo *symbol_info;

    // origin data copied from alphaless
    Trade trade;
    BestQuote quote;
    FlatOrderbookData ob_data;
    Liquidation liquidation;
    Kline kline;
    std::shared_ptr<OrderbookUpdate> ob_update;
    std::shared_ptr<demeter::DemeterData> demeter_data;

    const GaiaOrderbook *alphaBook;

    bool hasBookPopulated;
    bool hasTradePopulated;
    bool hasBestQuotePopulated;
    struct GLatencyRecord latency_record;
    TickEventType update_tick_type;
    bool is_reverse;
    double funding_rate;
    double cur_funding_rate;
    uint64_t last_funding_time = 0;
    uint64_t next_funding_time = 0;
    double makerFeeBps;
    double takerFeeBps;
    double custom_min_notional;
    double custom_max_notional;
    double max_mkt_qty;
};

#define ContractInfoMapType phmap::flat_hash_map<std::string, struct ContractInfo *>
#define SidContractInfoMapType phmap::flat_hash_map<SymId, struct ContractInfo *>
