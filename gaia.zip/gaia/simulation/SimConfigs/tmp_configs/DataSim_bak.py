import pickle
from Default.KronosConfig import *
from Default.DefaultCommonConfig import *

@config_interface
class TagConfig():
    def __init__(self):
        self.configs = []

    def genFactors(self, factor_path):
        with open(factor_path , 'rb') as file:
            factors = pickle.load(file)
        return factors

    def generateParams(self, sim_params, stra_params):
        config = KronosConfig("DataSim")
        config.num_of_book_levels = 20

        # predictor log
        config.predictorConfig.factor_path  = stra_params["factor_path"]
        config.predictorConfig.model_path = stra_params["model_path"]
        config.predictorConfig.factors = self.genFactors(config.predictorConfig.factor_path)
        config.predictorConfig.factors = []

        # orderlogic log
        for key, value in stra_params.items():
            print(key, value)
            setattr(config.orderLogicConfig, key, value)
        config.orderLogicCommonConfig.set_values(notional_size = stra_params["notional_size"],
                                                max_pos_in_clips = stra_params["max_pos_in_clips"],
                                                stop_loss = stra_params["stop_loss"],
                                                mkt_timeout_ns = stra_params["mkt_timeout_ns"],
                                                )

        # sim 
        config.set_sim(mode = 'SIM',
                    start_date = sim_params["start_date"],
                    end_date = sim_params["end_date"],
                    sign_str = sim_params["sign_str"],
                    sign = sim_params["sign"],
                    target_server =  sim_params["target_server"],
                    target_path = "/home/master/Data/md_dump/",
                    sim_engine = 'alphaless',
                    sim_output_engine = 'parquet',
                    sim_output_target = './gaia_orderbook.parquet',

                    )
        # config.simConfig.sim_fee[sim_params["target_exchange"]] = {'taker': sim_params["taker"], 'maker': sim_params["maker"]}
        config.simConfig.set_sim_fee(sim_params["target_exchange"], {'taker': sim_params["taker"], 'maker': sim_params["maker"]})

        config.simConfig.set_sim_latency(sim_params["target_exchange"], "all", {'req_insert_order': sim_params["insert_latency"]})

        config.simConfig.set_sim_order(sim_params["target_exchange"], "all", {'cancel_front_ratio': 0.0,
                                                                              'taker_cross_decay_ratio': 0.0,
                                                                              'trade_cross_policy': 'eq_price_qty',
                                                                              'bbo_cross_policy': 'qty',
                                                                              'use_fill_latency_hint': True,
                                                                              'fill_latency_lead': '0ms',
                                                                              'min_fill_latency': '0ms',
                                                                              'max_fill_latency': '0ms'})

        # 
        config.setSymbol(sim_params["target_instrument"])
        return config 

    def getConfig(self):
        sim_params = {
            "start_date": '20241126',
            "end_date": '20241202',
            "target_server": "tky-kronos-prod-md-az4-01",
            "target_instrument": f"Binance_Spot_BTCFDUSD",
            "target_exchange": f"Bybit",
            "insert_latency": "1ms",
            "maker": -0.00005,
            "taker": 0.00015,
            "sign_str": f"test2",
            "sign": {"test": f"test"},
        }
        stra_params = {
            "factor_path": "/mnt/share/jsc/config/pred/test_btcfdusd/factors.txt",
            "model_path": "/mnt/share/jsc/config/pred/test_btcfdusd/lgb.txt",
            "notional_size": 200,
            "max_pos_in_clips": 1,
            "open_threshold": 0.0,
            "close_threshold": 0.0,
            "min_change_volume": 0.0,
            "stop_loss": -10000000,
            "use_dmm_only": 0,
            "use_log_factor": 0,
            "mkt_timeout_ns": 3000000000,
        }

        sim_params["sign_str"] = "gaia_orderbook"
        config = self.generateParams(sim_params, stra_params)
        self.configs.append(config)
        return self.configs
