#include "Factor.h"
#include "Ema.h"
#include "GaiaCircularBuffer.h"
#include <cmath>

class BookMidBasisFactor : public FactorInterface
{
public:
    BookMidBasisFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
        asst_symbol = config.Get<std::string>("asst_symbol");
        asst_sid = SecMaster::instance().FindSid(asst_symbol);
    };

    virtual std::string gen_name() {
        return std::string("BookMidBasisFactor") + "@asst_symbol=" + asst_symbol;
    }

    virtual void calculate(const FactorInput& input_data) { 
        bool is_orderbook = input_data.cur_contract->update_tick_type == TickEventType::TICK_OB;
        if (is_orderbook) {
            auto &ob = input_data.cur_contract->alphaBook;
            int16_t current_sid = input_data.cur_contract->symbol_info->sid;
            double mid_price = (ob->bid(0).price + ob->ask(0).price)/2.0; 
            if (asst_sid == current_sid) {
                asst_mid_price = mid_price;
            } else {
                target_mid_price = mid_price;
            }
            if (target_mid_price > MinErr && asst_mid_price > MinErr){
                factor_value = 1e4*(target_mid_price - asst_mid_price)/asst_mid_price;
            }
        } 
        else {
            return;
        }
    };


private:
    std::string asst_symbol;
    int16_t current_sid;
    int16_t asst_sid;
    double target_mid_price = 0.0;
    double asst_mid_price = 0.0; 
};  
         