#include "FactorFactory.h"
#include "GaiaUtils.h"
#include "secmaster/sec_master.h"
#include "cancel_imba.h"
#include "cancel_imba_ratio.h"
#include "insert_imba.h"
#include "insert_imba_ratio.h"
#include "match_imba.h"
#include "match_imba_ratio.h"
#include "liquidation_imba.h"
#include "liquidation_imba_ratio.h"
#include "boll_loc.h"
#include "book_ask_queue.h"
#include "book_bias_ratio.h"
#include "book_bias.h"
#include "book_bid_queue.h"
#include "book_imba_ratio.h"
#include "book_num_bids.h"
#include "book_num_asks.h"
#include "book_num_imba.h"
#include "book_queue_imba.h"
#include "book_spread.h"
#include "book_strength_imba.h"
#include "match_ratio_bias.h"
#include "match_strength_imba.h"
#include "mid_ratio.h"
#include "mid_sigma.h"
#include "px_vol_ratio.h"
#include "tick_ts_interval.h"
#include "tick_latency.h"
#include "tick_sid.h"
#include "tick_type.h"
#include "trade_bias.h"
#include "mid_basis.h"
#include "mid_basis_diff.h"
#include "mid_basis_phil.h"
#include "theo_edge.h"
#include "mid_basis_bps.h"
#include "tradeA_last_lag.h"
#include "tradeA_buy_lag.h"
#include "tradeA_sell_lag.h"
#include "tradeA_lag_diff.h"
#include "tradeA_vwap_lag.h"
#include "tradeA_qty_imba.h"
#include "tradeT_qty_imba.h"
#include "tradeA_side.h"
#include "tradeA_buy_sell_ratio.h"
#include "tradeA_large_qty_imba.h"
#include "tradeA_large_buy_ratio.h"
#include "tradeA_large_sell_ratio.h"
#include "tradeA_last_jump.h"
#include "tradeA_last_sigma.h"
#include "tradeA_qty_sigma.h"
#include "tradeA_last_slope.h"
#include "tradeA_vwap_imba.h"
#include "tradeA_buy_age.h"
#include "tradeA_sell_age.h"
#include "tradeA_buy_chg.h"
#include "tradeA_sell_chg.h"
#include "tradeA_buy_counts.h"
#include "tradeA_sell_counts.h"
#include "tradeA_vwap_bias.h"
#include "tradeA_buy_qty.h"
#include "tradeA_sell_qty.h"
#include "tradeA_buy_dis.h"
#include "tradeA_sell_dis.h"
#include "tradeA_mid_dis.h"
#include "tradeA_buy_jump.h"
#include "tradeA_sell_jump.h"
#include "trade_spread.h"
#include "trade_latency.h"
#include "trade_ts_interval.h"
#include "trade_buy_basis.h"
#include "trade_sell_basis.h"
#include "trade_mid_basis.h"
#include "trade_buy_basis_phil.h"
#include "trade_sell_basis_phil.h"
#include "best_qty_imba.h"
#include "best_theo_bias.h"
#include "book_qty_imba.h"
#include "best_mid_lag.h"
#include "best_order_imba.h"
#include "trade_agg_qty.h"
#include "book_trade_bias.h"
#include "book_mid_lag.h"
#include "book_order_imba.h"
#include "book_mid_basis.h"
#include "timer_demo.h"
#include "trade_agg_qty_imba.h"
#include "trade_qty_sum.h"
#include "trade_agg_signed_qty.h"
#include "time_interval_sampler.h"
#include "trade_agg_bias.h"
#include "timer_mid_lag.h"
#include "timer_mid_high_lag.h"
#include "timer_mid_low_lag.h"
#include "timer_mid_boll.h"
#include "timer_mid_sigma.h"
#include "timer_mid_lag_log.h"
#include "trade_agg_buy_ratio.h"
#include "trade_agg_count_bias.h"
#include "trade_agg_bias_on_timer.h"
#include "trade_agg_count_bias_on_timer.h"

void FactorFactory::Register() {
    RegisterFactor<CancelImbaFactor>("CancelImbaFactor");
    RegisterFactor<CancelImbaRatioFactor>("CancelImbaRatioFactor");
    RegisterFactor<InsertImbaFactor>("InsertImbaFactor");
    RegisterFactor<InsertImbaRatioFactor>("InsertImbaRatioFactor");
    RegisterFactor<MatchImbaFactor>("MatchImbaFactor");
    RegisterFactor<MatchImbaRatioFactor>("MatchImbaRatioFactor");
    RegisterFactor<LiquidationImbaFactor>("LiquidationImbaFactor");
    RegisterFactor<LiquidationImbaRatioFactor>("LiquidationImbaRatioFactor");
    RegisterFactor<BollLocFactor>("BollLocFactor");
    RegisterFactor<BookAskQueueFactor>("BookAskQueueFactor");
    RegisterFactor<BookBiasRatioFactor>("BookBiasRatioFactor");
    RegisterFactor<BookBiasFactor>("BookBiasFactor");
    RegisterFactor<BookBidQueueFactor>("BookBidQueueFactor");
    RegisterFactor<BookImbaRatioFactor>("BookImbaRatioFactor");
    RegisterFactor<BookNumAsksFactor>("BookNumAsksFactor");
    RegisterFactor<BookNumBidsFactor>("BookNumBidsFactor");
    RegisterFactor<BookNumImbaFactor>("BookNumImbaFactor");
    RegisterFactor<BookQueueImbaFactor>("BookQueueImbaFactor");
    RegisterFactor<BookSpreadFactor>("BookSpreadFactor");
    RegisterFactor<BookStrengthImbaFactor>("BookStrengthImbaFactor");
    RegisterFactor<MatchRatioBiasFactor>("MatchRatioBiasFactor");
    RegisterFactor<MatchStrengthImbaFactor>("MatchStrengthImbaFactor");
    RegisterFactor<MidRatioFactor>("MidRatioFactor");
    RegisterFactor<MidSigmaFactor>("MidSigmaFactor");
    RegisterFactor<MidBasisFactor>("MidBasisFactor");
    RegisterFactor<MidBasisDiffFactor>("MidBasisDiffFactor");
    RegisterFactor<MidBasisPhilFactor>("MidBasisPhilFactor");
    RegisterFactor<PxVolRatioFactor>("PxVolRatioFactor");
    RegisterFactor<TickLatencyFactor>("TickLatencyFactor");
    RegisterFactor<TickTsIntervalFactor>("TickTsIntervalFactor");
    RegisterFactor<TickSidFactor>("TickSidFactor");
    RegisterFactor<TickTypeFactor>("TickTypeFactor");
    RegisterFactor<TradeBiasFactor>("TradeBiasFactor");
    RegisterFactor<TheoEdgeFactor>("TheoEdgeFactor");
    RegisterFactor<MidBasisBpsFactor>("MidBasisBpsFactor");
    RegisterFactor<TradeALastLagFactor>("TradeALastLagFactor");
    RegisterFactor<TradeABuyLagFactor>("TradeABuyLagFactor");
    RegisterFactor<TradeASellLagFactor>("TradeASellLagFactor");
    RegisterFactor<TradeALagDiffFactor>("TradeALagDiffFactor");
    RegisterFactor<TradeAVwapLagFactor>("TradeAVwapLagFactor");
    RegisterFactor<TradeAQtyImbaFactor>("TradeAQtyImbaFactor");
    RegisterFactor<TradeTQtyImbaFactor>("TradeTQtyImbaFactor");
    RegisterFactor<TradeASideFactor>("TradeASideFactor");
    RegisterFactor<TradeABuySellRatioFactor>("TradeABuySellRatioFactor");
    RegisterFactor<TradeALargeQtyImbaFactor>("TradeALargeQtyImbaFactor");
    RegisterFactor<TradeALargeBuyRatioFactor>("TradeALargeBuyRatioFactor");
    RegisterFactor<TradeALargeSellRatioFactor>("TradeALargeSellRatioFactor");
    RegisterFactor<TradeALastSigmaFactor>("TradeALastSigmaFactor");
    RegisterFactor<TradeALastJumpFactor>("TradeALastJumpFactor");
    RegisterFactor<TradeAQtySigmaFactor>("TradeAQtySigmaFactor");
    RegisterFactor<TradeALastSlopeFactor>("TradeALastSlopeFactor");
    RegisterFactor<TradeAVwapImbaFactor>("TradeAVwapImbaFactor");
    RegisterFactor<TradeABuyAgeFactor>("TradeABuyAgeFactor");
    RegisterFactor<TradeASellAgeFactor>("TradeASellAgeFactor");
    RegisterFactor<TradeABuyChgFactor>("TradeABuyChgFactor");
    RegisterFactor<TradeASellChgFactor>("TradeASellChgFactor");
    RegisterFactor<TradeABuyCountsFactor>("TradeABuyCountsFactor");
    RegisterFactor<TradeASellCountsFactor>("TradeASellCountsFactor");
    RegisterFactor<TradeAVwapBiasFactor>("TradeAVwapBiasFactor");
    RegisterFactor<TradeABuyQtyFactor>("TradeABuyQtyFactor");
    RegisterFactor<TradeASellQtyFactor>("TradeASellQtyFactor");
    RegisterFactor<TradeABuyDisFactor>("TradeABuyDisFactor");
    RegisterFactor<TradeASellDisFactor>("TradeASellDisFactor");
    RegisterFactor<TradeAMidDisFactor>("TradeAMidDisFactor");
    RegisterFactor<TradeABuyJumpFactor>("TradeABuyJumpFactor");
    RegisterFactor<TradeASellJumpFactor>("TradeASellJumpFactor");
    RegisterFactor<TradeSpreadFactor>("TradeSpreadFactor");
    RegisterFactor<TradeLatencyFactor>("TradeLatencyFactor");
    RegisterFactor<TradeTsIntervalFactor>("TradeTsIntervalFactor");
    RegisterFactor<TradeBuyBasisFactor>("TradeBuyBasisFactor");
    RegisterFactor<TradeSellBasisFactor>("TradeSellBasisFactor");
    RegisterFactor<TradeMidBasisFactor>("TradeMidBasisFactor");
    RegisterFactor<TradeBuyBasisPhilFactor>("TradeBuyBasisPhilFactor");
    RegisterFactor<TradeSellBasisPhilFactor>("TradeSellBasisPhilFactor");
    RegisterFactor<BestQtyImbaFactor>("BestQtyImbaFactor");
    RegisterFactor<BestTheoBiasFactor>("BestTheoBiasFactor");
    RegisterFactor<BookQtyImbaFactor>("BookQtyImbaFactor");
    RegisterFactor<BestMidLagFactor>("BestMidLagFactor");
    RegisterFactor<BestOrderImbaFactor>("BestOrderImbaFactor");
    RegisterFactor<TradeAggQtyFactor>("TradeAggQtyFactor");
    RegisterFactor<BookTradeBiasFactor>("BookTradeBiasFactor");
    RegisterFactor<BookMidLagFactor>("BookMidLagFactor");
    RegisterFactor<BookOrderImbaFactor>("BookOrderImbaFactor");
    RegisterFactor<BookMidBasisFactor>("BookMidBasisFactor");
    RegisterFactor<TradeAggQtyImbaFactor>("TradeAggQtyImbaFactor");
    RegisterFactor<TradeQtySumFactor>("TradeQtySumFactor");
    RegisterFactor<TimerDemoFactor>("TimerDemoFactor");
    RegisterFactor<TradeAggSignedQtyFactor>("TradeAggSignedQtyFactor");
    RegisterFactor<TimeIntervalSampler>("TimeIntervalSampler");
    RegisterFactor<TradeAggBiasFactor>("TradeAggBiasFactor");
    RegisterFactor<TimerMidLagFactor>("TimerMidLagFactor");
    RegisterFactor<TimerMidHighLagFactor>("TimerMidHighLagFactor");
    RegisterFactor<TimerMidLowLagFactor>("TimerMidLowLagFactor");
    RegisterFactor<TimerMidBollFactor>("TimerMidBollFactor");
    RegisterFactor<TimerMidSigmaFactor>("TimerMidSigmaFactor");
    RegisterFactor<TimerMidLagLogFactor>("TimerMidLagLogFactor");
    RegisterFactor<TradeAggBuyRatioFactor>("TradeAggBuyRatioFactor");
    RegisterFactor<TradeAggCountBiasFactor>("TradeAggCountBiasFactor");
    RegisterFactor<TradeAggBiasOnTimerFactor>("TradeAggBiasOnTimerFactor");
    RegisterFactor<TradeAggCountBiasOnTimerFactor>("TradeAggCountBiasOnTimerFactor");
}
