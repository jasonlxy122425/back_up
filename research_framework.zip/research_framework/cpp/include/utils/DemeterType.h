#pragma once
#include <string>
#include <cstddef>
#include <vector>

#include <cstring>
#include <math.h>
#include "SystemDefine.h"


namespace demeter {

// first definition of BookOrderType must be 0
enum BookOrderType {
    Insert = 0,
    Cancel,
    Match,
    Liquidation,

    NumBookOrderTypes
};

std::string ToString(BookOrderType type);

// use side num 3 for alphaless Side definition, we only use index Side::Buy - 1 and Side::Sell - 2 
constexpr static size_t SideStartIdx = 3;
constexpr static size_t NumSides = 3;


class GobUpdate {
public:
    GobUpdate() = default;

    GobUpdate(const GobUpdate& other) {
        for(size_t i = 1; i < NumSides; ++i) {
            for(size_t j = 0; j < NumBookOrderTypes; ++j) {
                data_[i][j] = other.data_[i][j];
            }
        }
    }

    void clear() {
        for(size_t i = 1; i < NumSides; ++i) {
            for(size_t j = 0; j < NumBookOrderTypes; ++j) {
                data_[i][j].clear();
            }
        }
    }

    void push_back(GobUpdate &cur_gob_update) {
        for(size_t i = 1; i < NumSides; ++i) {
            for(size_t j = 0; j < NumBookOrderTypes; ++j) {
                data_[i][j].insert(data_[i][j].end(), cur_gob_update.get(i,j).begin(), cur_gob_update.get(i,j).end());
            }
        }
    }

    void pop_front(GobUpdate &cur_gob_update) {
        for(size_t i = 1; i < NumSides; ++i) {
            for(size_t j = 0; j < NumBookOrderTypes; ++j) {
                data_[i][j].erase(data_[i][j].begin(), data_[i][j].begin()+cur_gob_update.get(i,j).size());
            }
        }
    }

    std::vector<double>& get(Side side, BookOrderType type) {
        return get(static_cast<size_t>(side), static_cast<size_t>(type));
    }

    std::vector<double>& get(size_t side, size_t type) {
        return data_[side][type];
    }

    double get_sum(Side side, BookOrderType type) const {
        return get_sum(static_cast<size_t>(side), static_cast<size_t>(type));
    }

    double get_sum(size_t side, size_t type) const {
        double sum = 0;
        for(auto &val : data_[side][type]) {
            sum += val;
        }
        return sum;
    }

private:
    std::vector<double> data_[NumSides][NumBookOrderTypes];
};

class GobUpdateSum {
public:
    GobUpdateSum() {
        memset(sum_, 0, sizeof(sum_));
    }

    void update_for_rolling(const GobUpdate &cur_gob_update, const GobUpdate &last_gob_update) {
        for(size_t i = 1; i < NumSides; ++i) {
            for(size_t j = 0; j < NumBookOrderTypes; ++j) {
                double cur_value = cur_gob_update.get_sum(i,j);
                double prev_value = last_gob_update.get_sum(i,j);
                sum_[i][j] += cur_value;
                sum_[i][j] -= prev_value;
                if(std::fabs(sum_[i][j]) < 1e-13) {
                    sum_[i][j] = 0;
                }
            }
        }
    }

    void reset() {
        for(size_t i = 1; i < NumSides; ++i) {
            for(size_t j = 0; j < NumBookOrderTypes; ++j) {
                sum_[i][j] = 0;
            }
        }
    }

    void add(const GobUpdate &cur_gob_update) {
        for(size_t i = 1; i < NumSides; ++i) {
            for(size_t j = 0; j < NumBookOrderTypes; ++j) {
                double cur_value = cur_gob_update.get_sum(i,j);
                sum_[i][j] += cur_value;
                if(std::fabs(sum_[i][j]) < 1e-13) {
                    sum_[i][j] = 0;
                }
            }
        }
    }

    const double& get(Side side, BookOrderType type) const {
        return sum_[static_cast<size_t>(side)][static_cast<size_t>(type)];
    }

    double& get(Side side, BookOrderType type) {
        return sum_[static_cast<size_t>(side)][static_cast<size_t>(type)];
    }

    const double& get(size_t side, size_t type) const {
        return sum_[side][type];
    }

    double& get(size_t side, size_t type) {
        return sum_[side][type];
    }
private:
    double sum_[NumSides][NumBookOrderTypes];
};

}; // namespace demeter