import os
import sys
import pandas as pd

cur_dir = os.getcwd()
# sys.path.append(f"{cur_dir}/")
# sys.path.append(f"{cur_dir}/ServerInfo")
from ServerInfo import *
from AccountPool import AccountPool
from FileGenerator import *
from get_account_info import *
from architect_utils import get_acct_info

import importlib
import traceback

class ConfigBuilder(object):
    def __init__(self, account_info_path):
        self.account_info_path = account_info_path 
        self.placements = []
        self.file_generator = FileGenerator()

    def dispatchConfig(self, configs):

        all_info_db = get_acct_info()
        all_info_db.rename(columns={"logic_acct_id":"logic_account_id","logic_acct_name":"logic_account_name","host":"machine_name","host_ip":"machine_private_ip"}, inplace=True)
        all_info = getAllAccountInMcp()
        all_info = pd.DataFrame(all_info)
        while len(all_info) <= 0:
            import time
            time.sleep(1)
            all_info = getAllAccountInMcp()
            all_info = pd.DataFrame(all_info)
        for config in configs:
            if hasattr(config, "mode") and config.mode == 'SIM':
                continue
            quoter_account = self.server_acct_pool.get_account(config.quoter_symbol,
                                                                      config.acct_group,
                                                                      config.acct_id,
                                                                      config.sub_tag)
            #if quoter_account['logic_acct'] not in all_info.logic_account_name.values:

            target_info = None
            if quoter_account['logic_acct'] not in all_info.logic_account_name.values:
                if quoter_account['logic_acct'] not in all_info_db.logic_account_name.values:
                    print(f"{quoter_account['logic_acct']} is not in mcp")
                    exit(0)
                else:
                    target_info = all_info_db[all_info_db['logic_account_name']==quoter_account['logic_acct']].copy()
            else:
                target_info = all_info[all_info['logic_account_name']==quoter_account['logic_acct']].copy()
            
            quoter_server = target_info.iloc[0]['machine_name']
            quoter_logic_acct_id = target_info.iloc[0]['logic_account_id']

            if quoter_account.__contains__('ts'):
                config.set_server(quoter_server, ts=quoter_account['ts'])
            else:
                config.set_server(quoter_server)
            config.set_logic_acct(quoter_logic_acct_id, quoter_account['logic_acct'])

            if hasattr(config, "hedgerConfig") and config.hedgerConfig.use_hedger:
                hedger_account = self.server_acct_pool.get_account(config.hedger_symbol,
                                                                      config.acct_group,
                                                                      config.acct_id,
                                                                      config.sub_tag)

                target_info = None
                if hedger_account['logic_acct'] not in all_info.logic_account_name.values:
                    if hedger_account['logic_acct'] not in all_info_db.logic_account_name.values:
                        print(f"{quoter_account['logic_acct']} is not in mcp")
                        exit(0)
                    else:
                        target_info = all_info_db[all_info_db['logic_account_name']==hedger_account['logic_acct']].copy()
                else:
                    target_info = all_info[all_info['logic_account_name']==hedger_account['logic_acct']].copy()

                hedger_logic_acct_id = target_info.iloc[0]['logic_account_id']
                config.set_hedger_logic_acct(hedger_logic_acct_id, hedger_account['logic_acct'])
                hedger_server = target_info.iloc[0]['machine_name']
                hedger_server_ip = target_info.iloc[0]['machine_private_ip']
                if hedger_account.__contains__('ts'):
                    config.set_hedger_server(hedger_server, hedger_server_ip,ts = hedger_account['ts'])
                else:
                    config.set_hedger_server(hedger_server, hedger_server_ip)

    
    def getAllConfigInPath(self, path):
        module_names = [os.path.splitext(p)[0] for p in os.listdir(path) if p.endswith('.py')]
        configs = []
        if path not in sys.path:
            sys.path.append(path)

        for module_name in module_names:
            if 'util' in module_name:
                continue

            print(f"loading {module_name}")
            #importlib.import_module(module_name).TagConfig().getConfig()
            try:
                # 删除旧模块，确保 reload 生效
                if module_name in sys.modules:
                    del sys.modules[module_name]

                module = importlib.import_module(module_name)
                # module = importlib.import_module(module_name)
                if hasattr(module, "TagConfig") == False:
                    # filter out non config file
                    continue
                configs.extend(module.TagConfig().getConfig())
            except:
                print(f"{module_name} in {path} is not valid")
                traceback.print_exc()

        return configs

    def exit_if_not_exist(self, config, attr_str):
        if hasattr(config, attr_str) == False:
            print(f"{attr_str} is required")
            exit(0)
    
    def check_args(self, config):
        self.exit_if_not_exist(config, "order_logic")
        self.exit_if_not_exist(config, "tag")

        if hasattr(config, "mode") and config.mode == 'SIM':
            self.exit_if_not_exist(config, "start_date")
            self.exit_if_not_exist(config, "end_date")
        else:
            self.exit_if_not_exist(config, "acct_group")

    def clear(self, tag):
        os.system(f"rm -rf {self.config_path}")


    def buildWithoutAll(self, tag_module_name = 'all', sub_tag = 'all', acct_id = 'all', config_path="./", source_config_path="./tag_configs"):
        self.config_path = config_path
        self.server_acct_pool = AccountPool(source_config_path, self.account_info_path)
        # print(source_config_path)
        # all_configs = self.getAllConfigInPath(source_config_path)

        # all_configured_sub_tag = [ config.sub_tag for config in all_configs ]

        # self.server_acct_pool.clear_unconfigured_sub_tag(all_configured_sub_tag)
        
        ## dispatch config
        if tag_module_name == 'all':
            configs = self.getAllConfigInPath(source_config_path)
        else:
            print(f"importing {tag_module_name}")
            sys.path.append(source_config_path)
            module = importlib.import_module(tag_module_name)
            configs = module.TagConfig().getConfig()

        filter_configs = []
        for config in configs:
            if sub_tag != 'all' and config.sub_tag != sub_tag:
                continue
            if acct_id != 'all' and config.acct_id != acct_id:
                continue
            filter_configs.append(config)
        
        configs = filter_configs

        self.dispatchConfig(configs)

        for config in configs:
            self.check_args(config)
        
        self.configs = configs
        self.server_configs = self.get_server_configs()

        return self

    def build(self, tag_module_name = 'all', config_path="./", source_config_path="./tag_configs"):
        self.config_path = config_path
        self.server_acct_pool = AccountPool(source_config_path, self.account_info_path)
        # print(source_config_path)
        all_configs = self.getAllConfigInPath(source_config_path)

        all_configured_sub_tag = [ config.sub_tag for config in all_configs ]
        all_configured_id_sub_tag_pair = [ (config.acct_group, config.acct_id, config.sub_tag) for config in all_configs ]
        self.server_acct_pool.clear_unconfigured_sub_tag(all_configured_sub_tag, all_configured_id_sub_tag_pair)
        
        ## dispatch config
        if tag_module_name == 'all':
            configs = all_configs
        else:
            configs = [ config for config in all_configs if config.tag == tag_module_name ]

        self.dispatchConfig(configs)

        for config in configs:
            self.check_args(config)
        
        self.configs = configs
        self.server_configs = self.get_server_configs()

        return self
    
    def get_configs(self) -> list:
        return self.configs
    
    def get_server_configs(self) -> dict:
        server_configs = {}
        for config in self.configs:
            #print(config.machineName, config.quoter_symbol)
            if config.machineName in server_configs:
                server_configs[config.machineName].append(config)
            else:
                server_configs[config.machineName] = [config]
        
        return server_configs

    def get_server_symbols(self) -> dict:
        server_configs = {}
        for config in self.configs:
            if config.machineName in server_configs:
                server_configs[config.machineName].extend(config.reference_symbols)
            else:
                server_configs[config.machineName] = config.reference_symbols
        
        return server_configs
    
    def buildConfigs(self, tag_module_name, config_path="./", source_config_path="./ServerConfigs", model_path_in_prod = ""):
        self.build(tag_module_name, config_path, source_config_path)
        #self.modifyModelPath(model_path_in_prod)
        self.buildConfigsForMachine(config_path)

    def modifyModelPath(self, model_path_in_prod):
        for server, configs in self.server_configs.items():
            for config in configs:
                if hasattr(config.predictorConfig, "model_path") == False:
                    continue

                config.predictorConfig.origin_model_path = config.predictorConfig.model_path
                config.predictorConfig.model_path = f"{model_path_in_prod}/{config.strategy_name}.txt"
        

    def buildConfigsForMachine(self, target_path):

        algo_id_base = 1024
        remote_algo_id_base = 1
        local_remote_algo_id_base = 50

        for server, configs in self.server_configs.items():

            ts_index = {}
            for config in configs:
                if config.ts != -1:
                    ts_index[config.ts] = 0

            os.system(f"rm -rf {target_path}/{server}")
            server_index = 0
            for i, config in enumerate(configs):

                config_file_path = f"{target_path}/{server}"
                server_index +=1
                shm_index = server_index
                tcp_index = server_index

                if len(ts_index) > 0 and config.ts != -1:
                    ts_index[config.ts] += 1
                    shm_index = ts_index[config.ts]
                ## assign algo shm name

                config.local_mw_port = "0"
                config.local_avc_port = "0"
                config.remote_mw_ip = "0"

                if config.quoter_symbol.__contains__('Lighter'):
                    config.use_48bits_order_id = True
                if hasattr(config, "hedgerConfig") and config.hedgerConfig.use_hedger:
                    if config.hedger_symbol.__contains__('Lighter'):
                        config.use_48bits_order_id = True

                if config.mode != 'SIM':
                    #print(server)
                    #print(machine_info_map.get(server))
                    config.algo_name = f"{machine_info_map.get(server)['shm_prefix']}{shm_index}"
                    config.cpu = self.getCpu(server)
                    if hasattr(config, "assistPredictorConfig") and len(config.assistPredictorConfig.factors) > 0:
                        config.assistPredictorConfig.cpu = self.getCpu(server)
                    config.algo_id = algo_id_base + shm_index
                    if config.ts != -1:
                        config.local_mw_port = 12000 + 100*config.ts + shm_index
                        config.local_avc_port = 12500 + 100*config.ts + shm_index
                    else:
                        config.local_mw_port = 12000 +  shm_index
                        config.local_avc_port = 12500 + shm_index
                    if hasattr(config, "hedgerConfig") and config.hedgerConfig.use_hedger:
                        if config.hedgerMachineName == config.machineName:
                            config.algo_id_2 = local_remote_algo_id_base + tcp_index
                        else:
                            config.algo_id_2 = remote_algo_id_base + tcp_index

                        #print(config.hedgerMachineName)
                        #print(machine_info_map.get(config.hedgerMachineName))
                        if machine_info_map.get(config.hedgerMachineName).__contains__('local_mw_ip'):
                            config.remote_mw_ip = machine_info_map.get(config.hedgerMachineName)['local_mw_ip']
                else:
                    config.algo_name = f"SIM_{shm_index}"
                    config.cpu = -1
                    config.algo_id = algo_id_base + shm_index
                    if hasattr(config, "hedgerConfig") and config.hedgerConfig.use_hedger:
                        config.algo_id_2 = remote_algo_id_base + tcp_index

                # print(f"building {config.tag} {config.sub_tag} {config.quoter_symbol} {config.order_logic} {config.predictor} {server}")
                self.file_generator.generateYaml(config, config_file_path, tcp_index)

    def getCpu(self,machine):
        try:
            isolcpu_doc = machine_info_map.get(machine)['cpu']
            ## assign cpu
            isolcpuNumber = -1
            if isolcpu_doc:
                isolcpuNumber = isolcpu_doc["current"]

                interval = isolcpu_doc["interval"]

                if isolcpu_doc["current"] + interval <= isolcpu_doc["end"]:
                    isolcpu_doc["current"] += interval
                else:
                    # assert(False)
                    isolcpu_doc["current"] = isolcpu_doc["start"] + interval

            return isolcpuNumber 

        except:
            return -1
