#include "Factor.h"
#include "Ema.h"
#include <cmath>
#include "GaiaCircularBuffer.h"

class TradeAQtyImbaFactor : public FactorInterface
{
public:
    TradeAQtyImbaFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
        lookback = config.Get<int64_t>("lookback");
        qty_buffer.setSize(lookback, 0.0);
    };

    virtual std::string gen_name() {;
        return std::string("TradeAQtyImbaFactor") + "@lookback=" + std::to_string(lookback);
    }

    virtual void calculate(const FactorInput& input_data) {
        if (input_data.cur_contract->update_tick_type != TickEventType::TICK_TRADE){
            return;
        }
        factor_value = 0.0;
        auto &trade = input_data.cur_contract->trade;
        exch_ts = trade.exch_ts;
        turnover = trade.price * trade.qty;
        this_qty = trade.qty;
        if (trade.side == Side::SELL) {
            this_qty = -trade.qty;
        }

        prev_qty = 0;
        if (exch_ts != prev_exch_ts) {
            if(qty_buffer.isFull()) {
                prev_qty = qty_buffer[0];
                if(prev_qty > MinErr) {
                    buys -= prev_qty;
                } else if (prev_qty < -MinErr) {
                    sells -= -prev_qty;
                }
            }

            if(this_qty > MinErr) {
                buys += this_qty;
            } else if (this_qty < -MinErr) {
                sells += -this_qty;
            }
            qty_buffer.push(this_qty);
        } else {
            double old_qty = qty_buffer[-1];
            double new_qty = this_qty + old_qty;
            if(old_qty > MinErr) {
                buys -= old_qty;
            } else if (old_qty < -MinErr) {
                sells -= -old_qty;
            }
            if(new_qty > MinErr) {
                buys += new_qty;
            } else if (new_qty < -MinErr) {
                sells += -new_qty;
            }
            qty_buffer[-1] += this_qty;
        }

        if(qty_buffer.isFull() != false) {
            if (buys + sells > MinErr) {
                factor_value = (buys - sells)/(buys + sells);
            }
        }
        prev_exch_ts = exch_ts;
    };

    // virtual void calculate(const FactorInput& input_data) {
    //     factor_value = 0.0;
    //     auto &trade = input_data.cur_contract->trade;
    //     int64_t exch_ts = trade.exch_ts;
    //     if (trade.side == Side::BUY){
    //         this_qty = trade.qty;
    //     }
    //     else if (trade.side == Side::SELL){
    //         this_qty = -trade.qty;
    //     }
    //     if (std::abs(exch_ts - prev_exch_ts) > MinErr){
    //         qty_buffer.push(this_qty);
    //     }
    //     else {
    //         qty_buffer[-1] += this_qty;
    //     }

    //     if(qty_buffer.isFull() != false){
    //         double buys = qty_buffer.pos_sum();
    //         double sells = qty_buffer.neg_sum();  
    //         if (buys + sells > MinErr){
    //             factor_value = (buys - sells)/(buys + sells);
    //         }
    //     }
    //     prev_exch_ts = exch_ts;
        
    // };

private:
    int64_t lookback;
    GaiaCircularBuffer<double> qty_buffer;
    int64_t prev_exch_ts = 0;
    double this_qty = 0.0;
    double prev_qty = 0.0;

    int64_t exch_ts;
    double buys = 0.0, sells = 0.0;
    double turnover;
    
};
                              
