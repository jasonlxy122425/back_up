#pragma once

#include <inttypes.h>
#include <unistd.h>
#include <iostream>
#include <iomanip>
#include <unordered_set>
#include <utility>
#include <vector>
#include <queue>
#include <list>
#include <set>
#include <assert.h>
#include <fstream>
#include <sstream>

#include "ContractInfo.h"
#include "CommonDefine.h"
#include "DataPreprocessResult.h"

#define GET_VAR_NAME(x) (char*)(#x)

#define PredValueType double
#define FactorValueType PredValueType
#define FactorOutputType std::unordered_map<std::string, FactorValueType>

struct SignalStruct
{
    void reset(){
        memset(this, 0, sizeof(SignalStruct));
    }

    PredValueType pred_value;
    PredValueType bid_pred_value;
    PredValueType ask_pred_value;
    PredValueType vol_long;
    PredValueType vol_short;
    PredValueType spread;
    PredValueType theo_edge_lower;
    PredValueType theo_edge_upper;
    //
    PredValueType quoter_ema_theo_price;
    PredValueType hedger_ema_theo_price;
    PredValueType hedger_eff_bid_price;
    PredValueType hedger_eff_ask_price;

    SymId sid;
    int64_t recv_ts;
    int64_t push_ts;
    int64_t exch_ts;
    int64_t cb_start_ts;
};

struct PredictorState {
    TickEventType cur_tick_type;
    SymId cur_tick_sid;
    SymId main_sid;

    PreprocessResult *preprocess_result;
    ContractInfoMapType *contract_map;
    SidContractInfoMapType *sid_contract_map;

    struct GLatencyRecord* latency_record;
    SignalStruct signal;
};
