#include "Factor.h"
#include "Ema.h"
#include <cmath>
#include "GaiaCircularBuffer.h"

class TradeASideFactor : public FactorInterface
{
public:
    TradeASideFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
    };

    virtual std::string gen_name() {;
        return std::string("TradeASideFactor");
    }

    virtual void calculate(const FactorInput& input_data) {
        factor_value = 0.0;
        auto &trade = input_data.cur_contract->trade;
        int64_t exch_ts = trade.exch_ts;
        if (trade.side == Side::BUY){
            factor_value = 1.0;
        }
        else if (trade.side == Side::SELL){
            factor_value  = -1.0;
        }
    };

private:
    int64_t prev_exch_ts = 0;
    
};