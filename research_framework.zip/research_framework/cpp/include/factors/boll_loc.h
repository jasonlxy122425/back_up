#include "Factor.h"
#include "Ema.h"
#include "GaiaCircularBuffer.h"
#include <cmath>

class BollLocFactor : public FactorInterface
{
public:
    BollLocFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
        ema_int = config.Get<int64_t>("ema_int");
        lookback = config.Get<int64_t>("lookback");
        ema.init(ema_int);
        mid_buffer.setSize(lookback, 0.0);

    };

    virtual std::string gen_name() {
        return std::string("BollLocFactor") + "@lookback=" + std::to_string(lookback) + "@ema_int=" + std::to_string(ema_int);
    }

    virtual void calculate(const FactorInput& input_data) {
        factor_value = 0.0;
        auto &gob = input_data.cur_contract->alphaBook;
        double mid_price = (gob->bid(0).price + gob->ask(0).price)/2.0;
        mid_buffer.push(mid_price);
        if(mid_buffer.isFull() != false) {
            double mid_std = mid_buffer.std();
            if (std::abs(mid_std) > MinErr)
            {
                factor_value = (mid_price - mid_buffer.mean())/mid_buffer.std();
            }
        } 
        predict();
    };

    void predict() {
        ema.update(factor_value);
        factor_value = ema.get();

    }

private:
    int64_t lookback;
    int64_t ema_int;
    GaiaCircularBuffer<double> mid_buffer;
    Ema ema;
};
                              
