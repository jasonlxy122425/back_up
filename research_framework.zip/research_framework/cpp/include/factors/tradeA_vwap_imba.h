#include "Factor.h"
#include "Ema.h"
#include <cmath>
#include "GaiaCircularBuffer.h"

class TradeAVwapImbaFactor : public FactorInterface
{
public:
    TradeAVwapImbaFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
        lookback = config.Get<int64_t>("lookback");
        amt_buffer.setSize(lookback, 0.0);
        qty_buffer.setSize(lookback, 0.0);
    };

    virtual std::string gen_name() {
        return std::string("TradeAVwapImbaFactor") + "@lookback=" + std::to_string(lookback);
    }

    virtual void calculate(const FactorInput &input_data) {
        factor_value = 0.0;
        auto &trade = input_data.cur_contract->trade;
        int64_t exch_ts = trade.exch_ts;

        this_qty = trade.qty;
        this_amt = trade.price * trade.qty;
        if (trade.side == Side::SELL) {
            this_qty = -trade.qty;
            this_amt = -trade.price * trade.qty;
        }

        if (exch_ts != prev_exch_ts) {
            if (qty_buffer.isFull()) {
                double old_qty = qty_buffer[0];
                double old_amt = amt_buffer[0];
                if(old_qty > MinErr) {
                    buy_qty_total -= old_qty;
                    buy_amt_total -= old_amt;
                } else if (old_qty < -MinErr) {
                    sell_qty_total -= -old_qty;
                    sell_amt_total -= -old_amt;
                }
            }

            if (this_qty > MinErr) {
                buy_qty_total += this_qty;
                buy_amt_total += this_amt;
            } else if (this_qty < -MinErr) {
                sell_qty_total += -this_qty;
                sell_amt_total += -this_amt;
            }

            qty_buffer.push(this_qty);
            amt_buffer.push(this_amt);
        } else {
            double old_qty = qty_buffer[-1];
            double old_amt = amt_buffer[-1];
            double new_qty = this_qty + old_qty;
            double new_amt = this_amt + old_amt;
            if (old_qty > MinErr) {
                buy_qty_total -= old_qty;
                buy_amt_total -= old_amt;
            } else if (old_qty < -MinErr) {
                sell_qty_total -= -old_qty;
                sell_amt_total -= -old_amt;
            }

            if (new_qty > MinErr) {
                buy_qty_total += new_qty;
                buy_amt_total += new_amt;
            } else if (new_qty < -MinErr) {
                sell_qty_total += -new_qty;
                sell_amt_total += -new_amt;
            }
            qty_buffer[-1] += this_qty;
            amt_buffer[-1] += this_amt;
        }

        if (qty_buffer.isFull()) {

            if(buy_amt_total < min_precision) {
                buy_amt_total = 0.0;
                buy_qty_total = 0.0;
            }
            if(sell_amt_total < min_precision) {
                sell_amt_total = 0.0;
                sell_qty_total = 0.0;
            }
            if (buy_qty_total > MinErr && sell_qty_total > MinErr) {
                double buy_vwap = buy_amt_total / buy_qty_total;
                double sell_vwap = sell_amt_total / sell_qty_total;
                factor_value = buy_vwap - sell_vwap;
            }
        }

        prev_exch_ts = exch_ts;
    }

    // virtual void calculate(const FactorInput& input_data) {
    //     factor_value = 0.0;
    //     auto &trade = input_data.cur_contract->trade;
    //     int64_t exch_ts = trade.exch_ts;
    //     if (trade.side == Side::BUY){
    //         this_qty = trade.qty;
    //         this_amt = trade.price*trade.qty;
    //     }
    //     else if (trade.side == Side::SELL){
    //         this_qty = -trade.qty;
    //         this_amt = -trade.price*trade.qty;
    //     }
    //     if (std::abs(exch_ts - prev_exch_ts) > MinErr){
    //         qty_buffer.push(this_qty);
    //         amt_buffer.push(this_amt);
    //     }
    //     else {
    //         qty_buffer[-1] += this_qty;
    //         amt_buffer[-1] += this_amt;
    //     }
    
    //     if(qty_buffer.isFull() != false){
    //         double buy_qty_total = 0.0;
    //         double sell_qty_total = 0.0;
    //         double buy_amt_total = 0.0;
    //         double sell_amt_total = 0.0;
    //         for (int i = 0; i < lookback; i++){
    //             if (qty_buffer[i] > MinErr){
    //                 buy_qty_total += qty_buffer[i];
    //                 buy_amt_total += amt_buffer[i];
    //             }
    //             else if (qty_buffer[i] < -MinErr){
    //                 sell_qty_total -= qty_buffer[i];
    //                 sell_amt_total -= amt_buffer[i];                    
    //             }
    //         }
        
    //         if ((buy_qty_total > MinErr) && ((sell_qty_total > MinErr))){
    //             double buy_vwap = buy_amt_total/buy_qty_total;
    //             double sell_vwap = sell_amt_total/sell_qty_total;
    //             factor_value = buy_vwap - sell_vwap;
    //         }
    //     }
    //     prev_exch_ts = exch_ts;
        
    // };

private:
    int64_t lookback;
    GaiaCircularBuffer<double> qty_buffer;
    GaiaCircularBuffer<double> amt_buffer;
    double this_qty = 0.0;
    double this_amt = 0.0;
    int64_t prev_exch_ts = 0;

    double buy_qty_total = 0.0;
    double sell_qty_total = 0.0;
    double buy_amt_total = 0.0;
    double sell_amt_total = 0.0;

    constexpr static double min_precision = 1e-4;
};
                              
