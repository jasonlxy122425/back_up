import os,sys,argparse,requests
import time
import importlib
import yaml
import multiprocessing

cur_dir = os.getcwd()

config_src_path = f"{cur_dir}/../../gaia_config/configs"
sys.path.append(config_src_path)
sys.path.append(f"{config_src_path}/ServerInfo")

from sim_unit import *
max_process_num = 1

lark_webhook = "https://open.larksuite.com/open-apis/bot/v2/hook/7c604cd6-3ccd-4a21-80a4-10b72bef95af"

def sender(url, msg):
    """
    :param url: webhook地址
    :param msg: 需要发送的消息
    :return:
    """
    payload_message = {
        "msg_type": "text",
        "content": {
            "text": msg,
        }
    }
    headers = {'Content-Type': 'application/json'}
    requests.request("POST", url, headers=headers, data=json.dumps(payload_message))

def compileGaia(compile : bool, add_so_path : str = '', sim_units : list = []):
    if compile:
        output_engine = None
        sim_engine = None
        for unit in sim_units:
            if sim_engine is None:
                sim_engine = unit.data['config'].simConfig.sim_engine
            if hasattr(unit.data['config'], "sim_output_engine"):
                output_engine = unit.data['config'].sim_output_engine
                break
            else:
                #print("no output engine")
                pass

        extra_flags = ""
        if sim_engine is not None and (sim_engine == "as" or sim_engine == "as_prod"):
            print("[building as ...]")
            sim_use_al_flag = ""
            if sim_engine == "as":
                sim_use_al_flag = "SIM_USE_AL=YES"
            ret = os.system(f"cd ../../algostation/cpp ; make clean ; make {sim_use_al_flag} -j4")
            #ret = os.system(f"cd ../../algostation/cpp ; make SIM_USE_AL=YES -j4")
            if ret != 0:
                print(f"Error: failed build in as")
                exit(0)
            extra_flags += "USE_AS=YES"

        if add_so_path != '':
            print(add_so_path)
            for path in add_so_path.split(','):
                if '/' not in path:
                    path = f"../../{path}"
                print(f"[building in {path} ...]")
                ret = os.system(f"cd {path} ; make {extra_flags} -j4")
                if ret != 0:
                    print(f"Error: failed build in {path}")
                    exit(0)
                print(f"build {path} done ...")

        print("[building libpredictor ...]")
        ret = os.system(f"cd ../../research_framework/cpp ; make {extra_flags} -j4")
        if ret != 0:
            print(f"Error: failed build in libpredictor")
            exit(0)
        print("[build libpredictor done ...]")
        print("[building gaia ...]")
        flags = ""
        if output_engine is not None:
            flags += "OUTPUT_DATA=YES"
        
        flags += f" {extra_flags}"
        if sim_engine is not None and sim_engine == "as":
            flags += " SIM_USE_AL=YES"


        print(f"cd ../strategy/ ; make SIM=YES {flags} -j4")
        ret = os.system(f"cd ../strategy/ ; make SIM=YES {flags} -j4")
        if ret != 0:
            print(f"Error: failed build in gaia")
            exit(0)
        print("build gaia done ...")
    return 

border = "-"*25

def run(configs : str, output_path : str, compile : bool = False, add_so_path : str = '', notify : bool = False):
    
    sim_units = []

    bin_path = f"{os.path.abspath('.')}/../strategy/build/gaia_bin_sim"
    for config in configs.split(','):
        sim_units.extend(SimUnitBuilder.buildSimUnit(config, output_path, bin_path))

    print(f"{border} compile start {border}")

    compileGaia(compile, add_so_path, sim_units)

    print(f"{border} compile end {border}")

    start = time.time()
    print(f"{border} start sim proces num : {max_process_num} {border}")
    pool = multiprocessing.Pool(processes=int(max_process_num))

    for unit in sim_units:
        pool.apply_async(unit.run, ())
        # pool.apply(unit.run, ())
        # unit.run()

    pool.close()
    pool.join()

    print(f"{border} end sim {border}")
    end = time.time()
    print(f"sim cost : {end - start}s")

    if notify:
        sender(lark_webhook, f"sim_task : {[ os.path.basename(config) for config in configs.split(',')]} done,sim cost : {end - start}s ")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='parallel run simulation day by day')
    parser.add_argument('-c','--config_path', type=str, help='simulation config path, split by , ')
    parser.add_argument('-o','--output_path', type=str, default="./sim_output", help='output path')
    parser.add_argument('-compile', '--compile', action='store_true', help='if need to compile')
    parser.add_argument('-p_num', '--process_num', type=int, default=10, help='multi process num')
    parser.add_argument('-so_path', '--additional_so_path', type=str, default='', help='additional so path(split by ,)')
    parser.add_argument('-notify', '--notify', action='store_true', help='if need to notify')

    args = parser.parse_args()

    max_process_num = args.process_num
    run(args.config_path, args.output_path, args.compile, args.additional_so_path, args.notify)
