#include "Factor.h"
#include "Ema.h"


class BookNumBidsFactor : public FactorInterface
{
public:
    BookNumBidsFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
    };

    virtual std::string gen_name() {
        return std::string("BookNumBidsFactor");
    }

    virtual void calculate(const FactorInput& input_data) {
        auto &gob = input_data.cur_contract->alphaBook;
        double num_bids = gob->num_bids();
        factor_value = num_bids;
    };


private:
};
                              
