#include "OrderLogic.h"

int64_t GOrderOp::cancel_interval = 100;
bool GOrderOp::round_for_hyperliquid = false;

void OrderLogic::InitLogic(const Config& _config)
{
    std::cout << "init order logic config " << std::endl;
    auto config = _config.Get<Config>("order_logic_config");
    auto common_config_yml = config.Get<Config>("common");

    common_config.max_pos_in_clips = GaiaUtils::GetParam<int32_t>(common_config_yml, "max_pos_in_clips");
    common_config.notional_size = GaiaUtils::GetParam<double>(common_config_yml, "notional_size");
    common_config.custom_coin_size = GaiaUtils::GetParam<double>(common_config_yml, "custom_coin_size");
    common_config.use_full_liquidation = GaiaUtils::GetParam<bool>(common_config_yml, "use_full_liquidation");
    common_config.use_market_order_for_liq = GaiaUtils::GetParam<bool>(common_config_yml, "use_market_order_for_liq");
    common_config.use_reduceonly_for_liq = GaiaUtils::GetParam<bool>(common_config_yml, "use_reduceonly_for_liq");
    common_config.liquidate_take_bp = GaiaUtils::GetParam<double>(common_config_yml, "liquidate_take_bp");
    common_config.liquidate_max_notional = GaiaUtils::GetParam<double>(common_config_yml, "liquidate_max_notional");
    common_config.liquidate_min_notional = GaiaUtils::GetParam<double>(common_config_yml, "liquidate_min_notional");
    common_config.stop_loss = GaiaUtils::GetParam<double>(common_config_yml, "stop_loss");
    common_config.stop_loss_duration = ONE_SECOND_IN_NANOS * GaiaUtils::GetParam<double>(common_config_yml, "stop_loss_duration_sec");
    common_config.stop_loss_use_unrealized = GaiaUtils::GetParam<bool>(common_config_yml, "stop_loss_use_unrealized");
    common_config.stop_loss_use_drawdown = GaiaUtils::GetParam<bool>(common_config_yml, "stop_loss_use_drawdown");
    common_config.mkt_timeout_ns = GaiaUtils::GetParam<int64_t>(common_config_yml, "mkt_timeout_ns");

    common_config.use_reduce_only_mode = GaiaUtils::GetParam<bool>(common_config_yml, "use_reduce_only_mode");

    common_config.use_fr_check = GaiaUtils::GetParam<bool>(common_config_yml, "use_fr_check");
    common_config.reduce_only_minute_before_fr = 60 * 1000000000L * GaiaUtils::GetParam<int64_t>(common_config_yml, "reduce_only_minute_before_fr");
    common_config.reduce_only_minute_after_fr = 60 * 1000000000L * GaiaUtils::GetParam<int64_t>(common_config_yml, "reduce_only_minute_after_fr");
    common_config.reduce_only_param_multi = GaiaUtils::GetParam<double>(common_config_yml, "reduce_only_param_multi");

    try {
        common_config.use_balance_limit_mode = GaiaUtils::GetParam<bool>(common_config_yml,"use_balance_limit_mode");
        common_config.balance_limit_recovery_sec = GaiaUtils::GetParam<int64_t>(common_config_yml, "balance_limit_recovery_sec");
    } catch(...) {
        common_config.use_balance_limit_mode = false;
    }

    common_config.rate_limit_duration_ms = GaiaUtils::GetParam<int64_t>(common_config_yml, "rate_limit_duration_ms");

    this->Init(_config);

    int64_t cancel_interval_ms = 100;
    try {
        cancel_interval_ms = GaiaUtils::GetParam<int64_t>(common_config_yml, "cancel_interval_ms");
    } catch(...) {
        cancel_interval_ms = 100;
    }

    bool round_for_hyperliquid = false;
    try {
        round_for_hyperliquid = GaiaUtils::GetParam<bool>(common_config_yml, "round_for_hyperliquid");
    } catch(...) {
        round_for_hyperliquid = false;
    }
    GOrderOp::setCancelInterval(cancel_interval_ms);
    GOrderOp::setRoundForHyperliquid(round_for_hyperliquid);

    std::cout << "order logic version: " << version << std::endl;
    std::cout << "init order logic config done" << std::endl;
}

void OrderLogic::ProcessBeforeRiskCheck(StrategyFields &strategy_fields) {
    GaiaUtils::GetCoinSizeFromNotional(strategy_fields, common_config.notional_size, common_config.custom_coin_size);
    strategy_fields.max_pos_coin = (double)common_config.max_pos_in_clips * strategy_fields.order_size_coin;
    strategy_fields.max_pos_usd = (double)common_config.max_pos_in_clips * common_config.notional_size;
}

void OrderLogic::RiskCheckLogic(StrategyFields& strategy_fields) {
    int64_t now = GaiaUtils::GetSysTimestamp();

    double total_pnl = strategy_fields.sym_risk.total_pnl;
    if (!common_config.stop_loss_use_unrealized) {
        // only use realized pnl to calculate stop loss
        total_pnl = strategy_fields.sym_risk.total_realized_pnl;
    }

    double max_pnl = strategy_fields.sym_risk.max_pnl;
    if (!common_config.stop_loss_use_drawdown) {
        // only calculate stop loss based on 0
        max_pnl = 0;
    }

    // enter Stop Loss
    if(total_pnl - max_pnl < common_config.stop_loss) {
        if(strategy_fields.sym_risk.stop_loss_first_trigger_ts == 0) {
            strategy_fields.sym_risk.stop_loss_first_trigger_ts = now;
        } else if(now - strategy_fields.sym_risk.stop_loss_first_trigger_ts >= common_config.stop_loss_duration) {
            std::cout << "Risk Check: stop loss , total_pnl: " << strategy_fields.sym_risk.total_pnl << ","
                        << "total_realized_pnl: " << strategy_fields.sym_risk.total_realized_pnl << ","
                        << "max_pnl: " << strategy_fields.sym_risk.max_pnl << ","
                        << "unrealized_pnl: " << strategy_fields.sym_risk.unrealized_pnl << ","
                        << "realized_pnl: " << strategy_fields.sym_risk.realized_pnl << ","
                        << "first_trigger_ts:" << strategy_fields.sym_risk.stop_loss_first_trigger_ts << ","
                        << "now:" << now
                        << "stop_loss: " << common_config.stop_loss
                        << std::endl;
            strategy_fields.setStrategyMode(StrategyMode::RiskExitMode, "stop loss");
        }
    } else {
        strategy_fields.sym_risk.stop_loss_first_trigger_ts = 0;
    }

    ContractInfo *contract_info = strategy_fields.contract_info;

    // enter BalanceLimitMode
#ifndef SIM_MODE
    if(common_config.use_balance_limit_mode && strategy_fields.current_mode != StrategyMode::BalanceLimitMode && contract_info->symbol_info->exch == Exchange::BINANCE) {
        if(contract_info->is_reverse || contract_info->symbol_info->mirana_ticker.find("_Spot_") != std::string::npos) {
            if(strategy_fields.order_size_coin / strategy_fields.sym_risk.leverage > strategy_fields.sym_risk.avail_balance) {
                std::string msg = fmt::format("Risk Check: order size coin > avail balance, order size coin: {}, leverage: {}, avail balance: {}", strategy_fields.order_size_coin, strategy_fields.sym_risk.leverage, strategy_fields.sym_risk.avail_balance);
                strategy_fields.setStrategyMode(StrategyMode::BalanceLimitMode, msg);
                strategy_fields.last_balance_limit_ts = now;
            }
        } else {
            // linearswap
            if(strategy_fields.order_size_usd  / strategy_fields.sym_risk.leverage > strategy_fields.sym_risk.avail_balance) {
                std::string msg = fmt::format("Risk Check: order size usd > avail balance, order size usd: {}, leverage: {}, avail balance: {}", strategy_fields.order_size_usd, strategy_fields.sym_risk.leverage, strategy_fields.sym_risk.avail_balance);
                strategy_fields.setStrategyMode(StrategyMode::BalanceLimitMode, msg);
                strategy_fields.last_balance_limit_ts = now;
            }
        }
    }
#endif
}

bool OrderLogic::fullLiquidateSingleStrategy(StrategyFields &strategy_fields) {
    double bid_flight_coin = 0;
    double ask_flight_coin = 0;
    GaiaUtils::GetInFlightOrderCoin(strategy_fields, bid_flight_coin, ask_flight_coin);

    if(bid_flight_coin + ask_flight_coin > eps)
    {
        CancelAllOnSide(strategy_fields, true, true);
        std::cout << __FUNCTION__ << ", bid flight coin: " << bid_flight_coin
                                    << ", ask flight coin: " << ask_flight_coin << std::endl;
        OrderManager::OrderMap orderMap = strategy_fields.order_manager->orders();
        // alphaless order map
        for (auto &pair : orderMap)
        {
            uint64_t client_order_id = pair.first;
            std::cout << " flight order id:  " << client_order_id
                    << ",order status: " << pair.second->order_status()
                    << ",cancel status: " << pair.second->cancel_status()
                    << ",leaves_qty:" << pair.second->leaves_qty() << std::endl;
        }
        return false;
    }
    PositionOffset offset = PositionOffset::UNKNOWN;
    if(common_config.use_reduceonly_for_liq)
    {
        offset = PositionOffset::CLOSE;
    }

    ContractInfo *main_contract = strategy_fields.contract_info;
    double baseCoinSum = strategy_fields.sym_risk.symbol_risk;

    double liq_price;
    Side liq_side;
    double liq_size = baseCoinSum / main_contract->symbol_info->multiplier;
    if (main_contract->is_reverse) {
        liq_size = baseCoinSum * GaiaUtils::GetMidPrice(main_contract) / main_contract->symbol_info->multiplier;
    }
    if(baseCoinSum > eps)
    {
        liq_side = Side::SELL;
        double best_bid_price = main_contract->quote.best_bid.price;
        liq_price = best_bid_price * (1 - common_config.liquidate_take_bp / ONE_BASE_POINT);

    }
    else if(baseCoinSum < -eps)
    {
        liq_side = Side::BUY;
        double best_ask_price = main_contract->quote.best_ask.price;
        liq_price = best_ask_price * (1 + common_config.liquidate_take_bp / ONE_BASE_POINT);
        liq_size = -liq_size;
    }

    liq_price = GaiaUtils::roundPriceViaTickSize(liq_price, main_contract->symbol_info->prc_tick_size);

    double min_notional = std::max(common_config.liquidate_min_notional, main_contract->symbol_info->min_notional);
    double max_notional = common_config.liquidate_max_notional;

    double exchange_max_size = main_contract->symbol_info->max_qty;
    double exchange_min_size = main_contract->symbol_info->min_qty;

    double max_size = 0;
    double min_size = 0;
    if(main_contract->is_reverse) {
        max_size = std::min(exchange_max_size, max_notional / main_contract->symbol_info->multiplier);
        min_size = std::max(exchange_min_size, min_notional / main_contract->symbol_info->multiplier);
    } else {
        max_size = std::min(exchange_max_size, max_notional / liq_price / main_contract->symbol_info->multiplier);
        min_size = std::max(exchange_min_size, min_notional / liq_price / main_contract->symbol_info->multiplier);
    }
    max_size = GaiaUtils::floorSizeViaQtyTick(max_size, main_contract);
    min_size = GaiaUtils::floorSizeViaQtyTick(min_size, main_contract);
    // std::cout << __FUNCTION__ << ",liq_size: " << liq_size << ",max_size: " << max_size  << ",min_size:" << min_size << std::endl;
    std::cout << "symbol: " << main_contract->symbol_info->mirana_ticker << ", baseCoinSum: " << baseCoinSum << std::endl;


    while(liq_size > max_size)
    {
        liq_size = GaiaUtils::floorSizeViaQtyTick(liq_size, main_contract);
        GOrderState* new_order_state = GOrderOp::InsertOrder(strategy_fields, liq_price, max_size, liq_side, OrderType::LIMIT, TimeInForce::IOC, offset);
        if(new_order_state == nullptr)
        {
            strategy_fields.setStrategyMode(StrategyMode::ExitMode, "InsertOrder failed");
            return true;
        }
        liq_size -= max_size;
    }

    if(liq_size < min_size) {
        return true;
    }

    liq_size = GaiaUtils::floorSizeViaQtyTick(liq_size, main_contract);
    GOrderState* new_order_state = GOrderOp::InsertOrder(strategy_fields, liq_price, liq_size, liq_side, OrderType::LIMIT, TimeInForce::IOC, offset);

    std::cout << "liq_send_order " << new_order_state->ts_order->client_order_id().value << std::endl;
    if(new_order_state == nullptr)
    {
        strategy_fields.setStrategyMode(StrategyMode::ExitMode, "InsertOrder failed");
        return false;
    }

    return false;
}

void OrderLogic::FullLiquidation(StrategyFields &strategy_fields)
{
    if(!common_config.use_full_liquidation) return;

    bool full_liq_ret = fullLiquidateSingleStrategy(strategy_fields);

    if(full_liq_ret)
    {
        std::cout << __FUNCTION__ << ", Full Liquidation Over" << std::endl;
        strategy_fields.setStrategyMode(StrategyMode::ExitMode, "Full Liquidation Over");
    }
}

void OrderLogic::CancelAllOnSide(struct StrategyFields &strategy_fields, bool cancelBid, bool cancelAsk)
{
    for(auto &orderState_iter : strategy_fields.order_state_map)
    {
        if(orderState_iter.second->ts_order->side() == Side::BUY && cancelBid)
        {
            GOrderOp::CancelOrder(orderState_iter.second);
        }

        if(orderState_iter.second->ts_order->side() == Side::SELL && cancelAsk)
        {
            GOrderOp::CancelOrder(orderState_iter.second);
        }
    }
}

void OrderLogic::LiquidateRisk(StrategyFields &strategy_fields, double &baseCoinSum)
{
    ContractInfo *main_contract = strategy_fields.contract_info;

    double bid_flight_coin = 0;
    double ask_flight_coin = 0;
    GaiaUtils::GetInFlightOrderCoin(strategy_fields, bid_flight_coin, ask_flight_coin);

    if(bid_flight_coin + ask_flight_coin > eps)
    {
        CancelAllOnSide(strategy_fields, true, true);
        std::cout << __FUNCTION__ << ", bid flight coin: " << bid_flight_coin
                                    << ", ask flight coin: " << ask_flight_coin << std::endl;
        OrderManager::OrderMap orderMap = strategy_fields.order_manager->orders();
        // alphaless order map
        for (auto &pair : orderMap)
        {
            uint64_t client_order_id = pair.first;
            std::cout << " flight order id:  " << client_order_id
                    << ",order status: " << pair.second->order_status()
                    << ",cancel status: " << pair.second->cancel_status()
                    << ",leaves_qty:" << pair.second->leaves_qty() << std::endl;
        }
        return;
    }

    if(baseCoinSum < eps && baseCoinSum > -eps)
    {
        std::cout << __FUNCTION__ << ", LiquidateRisk Over" << std::endl;
        strategy_fields.setStrategyMode(StrategyMode::ExitMode, "LiquidateRisk Over");
        return;
    }

    PositionOffset offset = PositionOffset::UNKNOWN;
    if(common_config.use_reduceonly_for_liq)
    {
        offset = PositionOffset::CLOSE;
    }

    double liq_price;
    Side liq_side;
    double liq_size = baseCoinSum / main_contract->symbol_info->multiplier;
    if(main_contract->is_reverse) {
        liq_size = baseCoinSum * GaiaUtils::GetMidPrice(main_contract) / main_contract->symbol_info->multiplier;
    }
    if(baseCoinSum > eps)
    {
        liq_side = Side::SELL;
        double best_bid_price = main_contract->quote.best_bid.price;
        liq_price = best_bid_price * (1 - common_config.liquidate_take_bp / ONE_BASE_POINT);
    }
    else if(baseCoinSum < -eps)
    {
        liq_side = Side::BUY;
        double best_ask_price = main_contract->quote.best_ask.price;
        liq_price = best_ask_price * (1 + common_config.liquidate_take_bp / ONE_BASE_POINT);
        liq_size = -liq_size;
    }
    liq_price = GaiaUtils::roundPriceViaTickSize(liq_price, main_contract->symbol_info->prc_tick_size);


    double min_notional = std::max(common_config.liquidate_min_notional, main_contract->symbol_info->min_notional);
    double max_notional = common_config.liquidate_max_notional;

    double exchange_max_size = main_contract->symbol_info->max_qty;
    double exchange_min_size = main_contract->symbol_info->min_qty;

    double max_size = 0;
    double min_size = 0;
    if(main_contract->is_reverse) {
        max_size = std::min(exchange_max_size, max_notional / main_contract->symbol_info->multiplier);
        min_size = std::max(exchange_min_size, min_notional / main_contract->symbol_info->multiplier);
    } else {
        max_size = std::min(exchange_max_size, max_notional / liq_price / main_contract->symbol_info->multiplier);
        min_size = std::max(exchange_min_size, min_notional / liq_price / main_contract->symbol_info->multiplier);
    }

    max_size = GaiaUtils::floorSizeViaQtyTick(max_size, main_contract);
    min_size = GaiaUtils::floorSizeViaQtyTick(min_size, main_contract);


    while(liq_size > max_size)
    {
        std::cout << "LiquidationRisk: liq_size: "<< max_size << ", price: " << liq_price << std::endl;
        GOrderState* new_order_state = GOrderOp::InsertOrder(strategy_fields, liq_price, max_size, liq_side, OrderType::LIMIT, TimeInForce::IOC, offset);
        if(new_order_state == nullptr)
        {
            strategy_fields.setStrategyMode(StrategyMode::ExitMode, "InsertOrder failed");
            return;
        }
        liq_size -= max_size;
    }

    if(liq_size < min_size)
    {
        std::cout << __FUNCTION__ << ", LiquidateRisk Over" << std::endl;
        strategy_fields.setStrategyMode(StrategyMode::ExitMode, "LiquidateRisk Over");
        return;
    }


    liq_size = GaiaUtils::floorSizeViaQtyTick(liq_size, main_contract);
    std::cout << "LiquidationRisk: liq_size: "<< liq_size << ", price: " << liq_price << std::endl;
    GOrderState* new_order_state = GOrderOp::InsertOrder(strategy_fields, liq_price, liq_size, liq_side, OrderType::LIMIT, TimeInForce::IOC, offset);
    if(new_order_state == nullptr)
    {
        strategy_fields.setStrategyMode(StrategyMode::ExitMode, "InsertOrder failed");
        return;
    }
}
