#pragma once
#include "CommonDefine.h"
#include "SystemDefine.h"
#include "PredictorFactory.h"
#include "GAssistThread.h"
#include "TradeIdFilter.h"
#include "DataPreprocessor.h"
#include <vector>
#include <set>

class GAssistCalculator {
public:
    enum TradeMode {
        ONLY_PUBLIC,
        ONLY_DMM,
        HYBRID
    };
    struct Options {
        Options() {
            quoter_sid = INVALID_SYM_ID;
            useTrade = true;
            useOrderbook = true;
            useBestquote = true;
            useLiquidation = true;
            useKline = true;
            useFundingrate = true;
            useDmmTrade = true;
            predictor_trade_mode = TradeMode::HYBRID;
            useBatchMode = false;
        }
        bool useTrade;
        bool useOrderbook;
        bool useBestquote;
        bool useLiquidation;
        bool useKline;
        bool useFundingrate;
        bool useDmmTrade;
        TradeMode predictor_trade_mode;
        bool useBatchMode;
        SymId quoter_sid;
    };

    GAssistCalculator(Strategy *main_strategy, const Config &_config, Options _option = Options())
        : main_strategy_(main_strategy), config_(_config), option_(_option) {
        predictor_ = PredictorFactory::generatePredictor(config_.Get<Config>("assist_predictor_config").Get<std::string>("predictor_code"));
        assist_thread_ = nullptr;


        for (auto &refSymbols : config_.Get<std::vector<std::string>>("assist_reference_symbols")) {
            auto contract_info = ContractInfo::GetContractInfo(refSymbols);
            SymId sid = contract_info->symbol_info->sid;
            assist_sids_.insert(sid);
            last_trades_in_batch_[sid] = nullptr;
            sid_contract_map_[sid] = contract_info;
            contract_map_[contract_info->symbol_info->mirana_ticker] = contract_info;
        }

        quoter_sid_ = option_.quoter_sid;
        auto quoter_contract_info = ContractInfo::GetContractInfo(quoter_sid_);
        sid_contract_map_[quoter_sid_] = quoter_contract_info;
        contract_map_[quoter_contract_info->symbol_info->mirana_ticker] = quoter_contract_info;
        assist_sids_.insert(quoter_sid_);
        last_trades_in_batch_[quoter_sid_] = nullptr;
        for (auto sid : assist_sids_) {
            sids_.push_back(sid);
        }
        ob_manager_.InitBooks(sids_);
        for (auto sid : sids_) {
            sid_contract_map_[sid]->alphaBook = &ob_manager_.Get(sid);
        }

        InitDataPreprocessor(config_.Get<Config>("common_config").Get<std::vector<Config>>("data_preprocessor_config"));

        PredictorState *predictor_state = new PredictorState();
        predictor_state->contract_map = &contract_map_;
        predictor_state->sid_contract_map = &sid_contract_map_;
        predictor_state->preprocess_result = data_preprocessor_->GetResultPtr();
        predictor_->setState(predictor_state);

        std::cout << "useTrade: " << option_.useTrade << ", useOrderbook: " << option_.useOrderbook
                  << ", useBestquote: " << option_.useBestquote << ", useLiquidation: " << option_.useLiquidation
                  << ", useKline: " << option_.useKline << ", useFundingrate: " << option_.useFundingrate << std::endl;

        if(!option_.useOrderbook) {
            allBooksPopulated = true;
            ob_manager_.set_num_book_levels(1);
            ob_manager_.set_max_level(1);
        }

        if(!option_.useTrade) {
            allTradePopulated = true;
        }

        if(!option_.useBestquote) {
            allBestQuotePopulated = true;
        }
    }

    void InitDataPreprocessor(const std::vector<Config>& config) {
        std::cout << "=============================================== data preprocessor init start ===================================================" << std::endl;
        data_preprocessor_ = std::make_unique<PreprocessorCenter>(config);
        std::cout << "=============================================== data preprocessor init done ===================================================" << std::endl;
    }

    virtual ~GAssistCalculator() {
        if(assist_thread_) {
            assist_thread_->Stop();
        }
    }

    void Init() {
        predictor_->Init(config_, config_.Get<Config>("assist_predictor_config"));
    }

    void StartThread() {
#ifndef SIM_MODE
        int cpu = config_.Get<Config>("assist_predictor_config").Get<int>("cpu", -1);
        std::cout << "start assist thread, cpu_id: " << cpu << std::endl;
        std::string shm_name = config_.Get<Config>("assist_predictor_config").Get<std::string>("shm");
        assist_thread_ = std::make_unique<GAssistThread>(this, shm_name, cpu);
        assist_thread_->set_symbols(sids_);
        assist_thread_->set_batch_mode(option_.useBatchMode);
        assist_thread_->Run();
        std::cout << "start assist thread done " << std::endl;
#endif
    }

    void OnMdBatch(const std::vector<const md::Message *> &batch) {
        size_t batch_size = batch.size();
        for (size_t i = 0; i < batch_size; ++i) {
            const md::Message *msg = batch[i];
            if (assist_sids_.find(msg->sid) == assist_sids_.end()) continue;

            switch(msg->msg_type) {
                case md::MessageType::TRADE:
                {
                    if (!option_.useTrade) break;
                    const md::Trade &cur_trade = *static_cast<const md::Trade *>(msg);
                    md::Trade* &last_trade = last_trades_in_batch_[cur_trade.sid];

                    bool reach_final_trade = ((i + 1) >= batch_size || batch[i + 1]->msg_type != md::MessageType::TRADE || batch[i + 1]->sid != cur_trade.sid);
                    bool need_merge = (last_trade != nullptr && last_trade->side == cur_trade.side && std::abs(last_trade->price - cur_trade.price) < eps);
                    if(need_merge) {
                        last_trade->qty += cur_trade.qty;
                        last_trade->exch_ts = cur_trade.exch_ts;
                        last_trade->recv_ts = cur_trade.recv_ts;
                        last_trade->qs_send_ts = cur_trade.qs_send_ts;
                        last_trade->parser_end_ts = cur_trade.parser_end_ts;
                        last_trade->cb_start_ts = cur_trade.cb_start_ts;
                    }

                    if (reach_final_trade) {
                        if(last_trade == nullptr) {
                            // const_cast<md::Trade&>(cur_trade).cb_start_ts = GaiaUtils::GetRealSysTimestamp();
                            OnTrade(cur_trade);
                        } else {
                            if(need_merge) {
                                // last_trade->cb_start_ts = GaiaUtils::GetRealSysTimestamp();
                                OnTrade(*last_trade);
                            } else {
                                // last_trade->cb_start_ts = GaiaUtils::GetRealSysTimestamp();
                                OnTrade(*last_trade);
                                // const_cast<md::Trade&>(cur_trade).cb_start_ts = GaiaUtils::GetRealSysTimestamp();
                                OnTrade(cur_trade);
                            }
                            last_trade = nullptr; // reset trade after processing
                        }
                    } else {
                        if(last_trade == nullptr) {
                            last_trade = const_cast<md::Trade *>(&cur_trade);
                        } else {
                            if (!need_merge) {
                                // last_trade->cb_start_ts = GaiaUtils::GetRealSysTimestamp();
                                OnTrade(*last_trade);
                                last_trade = const_cast<md::Trade *>(&cur_trade);
                            }
                        }
                    }
                    break;
                }
                case md::MessageType::ORDERBOOK:
                {
                    if (!option_.useOrderbook) break;

                    const md::FlatOrderbook &ob_msg = *static_cast<const md::FlatOrderbook *>(msg);
                    if (i + 1 < batch_size && batch[i + 1]->msg_type == md::MessageType::ORDERBOOK && batch[i + 1]->sid == msg->sid) {
                        break;
                    }
                    // const_cast<md::FlatOrderbook&>(ob_msg).cb_start_ts = GaiaUtils::GetRealSysTimestamp();
                    OnOrderbook(ob_msg);
                    break;
                }
                case md::MessageType::BEST_QUOTE:
                {
                    const md::BestQuote &bq_msg = *static_cast<const md::BestQuote *>(msg);
                    if (i + 1 < batch_size && batch[i + 1]->msg_type == md::MessageType::BEST_QUOTE && batch[i + 1]->sid == msg->sid) {
                        break;
                    }

                    // const_cast<md::BestQuote&>(bq_msg).cb_start_ts = GaiaUtils::GetRealSysTimestamp();
                    OnBestQuote(bq_msg);
                    break;
                }
                case md::MessageType::LIQUIDATION:
                {
                    if(!option_.useLiquidation) break;
                    const md::Liquidation &liq_msg = *static_cast<const md::Liquidation *>(msg);
                    // const_cast<md::Liquidation&>(liq_msg).cb_start_ts = GaiaUtils::GetRealSysTimestamp();
                    OnLiquidation(liq_msg);
                    break;
                }
                case md::MessageType::KLINE:
                {
                    if(!option_.useKline) break;
                    const md::Kline &kline_msg = *static_cast<const md::Kline *>(msg);
                    // const_cast<md::Kline&>(kline_msg).cb_start_ts = GaiaUtils::GetRealSysTimestamp();
                    OnKline(kline_msg);
                    break;
                }
                default:
                break;
            }
        }
    }

    void OnTrade(const md::Trade &trade) {
        if (!option_.useTrade) return;
        if(G_UNLIKELY(!option_.useDmmTrade && trade.src == Source::DMM)) return;
        if (assist_sids_.find(trade.sid) == assist_sids_.end()) return;
        if (option_.predictor_trade_mode == TradeMode::ONLY_DMM) {
            if (trade.src != Source::DMM) return; // only process DMM trades
        } else if (option_.predictor_trade_mode == TradeMode::ONLY_PUBLIC) {
            if (trade.src == Source::DMM) return; // only process public trades
        }
        if(predictor_ == nullptr) return;
        // TradeIdFilter &t_filter = trade_filter_map[trade.sid];
        // if (sid_contract_map_[trade.sid]->symbol_info->exch != Exchange::BITGET && t_filter.isDuplicateTrade(trade)) {
        //     return;
        // }

        ob_manager_.OnTrade(trade);
        sid_contract_map_[trade.sid]->trade = trade;
        UpdateLatency(trade);
        sid_contract_map_[trade.sid]->update_tick_type = TickEventType::TICK_TRADE;
        sid_contract_map_[trade.sid]->hasTradePopulated = true;

        CalculatePredictor(TickEventType::TICK_TRADE, trade.sid, &sid_contract_map_[trade.sid]->latency_record);
    }

    void OnOrderbook(const md::FlatOrderbook &ob) {
        if (!option_.useOrderbook) return;
        if (predictor_ == nullptr) return;

        if (assist_sids_.find(ob.sid) == assist_sids_.end()) return;
        ob_manager_.OnOrderbook(ob);

        UpdateLatency(ob);
        sid_contract_map_[ob.sid]->update_tick_type = TickEventType::TICK_OB;

        sid_contract_map_[ob.sid]->hasBookPopulated = true;

        CalculatePredictor(TickEventType::TICK_OB, ob.sid, &sid_contract_map_[ob.sid]->latency_record);
    }

    void OnBestQuote(const md::BestQuote &quote) {
        if (!option_.useBestquote) return;
        if (predictor_ == nullptr) return;
        if (assist_sids_.find(quote.sid) == assist_sids_.end()) return;
        ob_manager_.OnBestQuote(quote);
        sid_contract_map_[quote.sid]->quote = quote;

        UpdateLatency(quote);
        sid_contract_map_[quote.sid]->update_tick_type = TickEventType::TICK_BBO;

        sid_contract_map_[quote.sid]->hasBestQuotePopulated = true;

        CalculatePredictor(TickEventType::TICK_BBO, quote.sid, &sid_contract_map_[quote.sid]->latency_record);
    }

    void OnLiquidation(const md::Liquidation &liquidation) {
        if (!option_.useLiquidation) return;
        if (assist_sids_.find(liquidation.sid) == assist_sids_.end()) return;
        if (predictor_ == nullptr) return;
        ob_manager_.OnLiquidation(liquidation);
        sid_contract_map_[liquidation.sid]->liquidation = liquidation;

        UpdateLatency(liquidation);
        sid_contract_map_[liquidation.sid]->update_tick_type = TickEventType::TICK_LIQUIDATION;

        CalculatePredictor(TickEventType::TICK_LIQUIDATION, liquidation.sid, &sid_contract_map_[liquidation.sid]->latency_record);
    }

    void OnKline(const md::Kline &kline) {
        if(!option_.useKline) return;
        if (assist_sids_.find(kline.sid) == assist_sids_.end()) return;
        if (predictor_ == nullptr) return;
        sid_contract_map_[kline.sid]->kline = kline;

        UpdateLatency(kline);
        sid_contract_map_[kline.sid]->update_tick_type = TickEventType::TICK_KLINE;

        CalculatePredictor(TickEventType::TICK_KLINE, kline.sid, &sid_contract_map_[kline.sid]->latency_record);
    }

    void OnTimer() {
        int64_t now = GaiaUtils::GetSysTimestamp();
        predictor_->OnTimer(now);
    }

    void OnTimer(int64_t &now) {
        predictor_->OnTimer(now);
    }

private:

    G_INLINE void UpdateLatency(const Message &msg) {
        sid_contract_map_[msg.sid]->latency_record.mkt_data = {
            .mkt_recv_ts = msg.recv_ts,
            .mkt_exch_ts = msg.exch_ts,
            .mkt_qs_send_ts = msg.qs_send_ts,
            .mkt_parse_end_ts = msg.parser_end_ts,
            .mkt_cb_start_ts = msg.cb_start_ts
        };
    }

    G_INLINE void CalculatePredictor(const TickEventType &tick_type, const SymId &sid, GLatencyRecord *latency_record) {
        if(!IsReady()) return;

        data_preprocessor_->Process(sid_contract_map_[sid], tick_type, latency_record);
        predictor_->CalculatePredictor(tick_type, sid, latency_record, quoter_sid_);
        PushSignal();
    }

    bool IsReady() {
#ifdef SIM_MODE
        return true;
#endif
        bool prev_all_book_populated = allBooksPopulated;
        bool prev_all_trade_populated = allTradePopulated;
        bool prev_all_bq_populated = allBestQuotePopulated;
        if (!allBooksPopulated) {
            allBooksPopulated = true;
            for (const auto & entry: sid_contract_map_) {
                if (!entry.second->hasBookPopulated) {
                    allBooksPopulated = false;
                    std::cout << "assist "<< entry.second->symbol_info->mirana_ticker << " book not populated yet ..." << std::endl;
                }
            }
        }

        if (!allTradePopulated) {
            allTradePopulated = true;
            for (const auto & entry: sid_contract_map_) {
                if (!entry.second->hasTradePopulated) {
                    allTradePopulated = false;
                    std::cout << "assist " << entry.second->symbol_info->mirana_ticker << " trade not populated yet ..." << std::endl;
                }
            }
        }

        if (!allBestQuotePopulated) {
            allBestQuotePopulated = true;
            for (const auto & entry: sid_contract_map_) {
                if (!entry.second->hasBestQuotePopulated) {
                    allBestQuotePopulated = false;
                    std::cout << "assist " << entry.second->symbol_info->mirana_ticker << " quote not populated yet ..." << std::endl;
                }
            }
        }

        if ((allBooksPopulated) && (allTradePopulated) && (allBestQuotePopulated)) {
            return true;
        }

        return false;
    }

    G_INLINE void PushSignal() {
        auto &signal = predictor_->getState().signal;
#ifdef SIM_MODE
        main_strategy_->OnUserMsg(reinterpret_cast<const uint8_t*>(&signal), sizeof(signal));
#else
        signal.push_ts = GaiaUtils::GetRealSysTimestamp();
        main_strategy_->PushUserMsg(reinterpret_cast<const uint8_t*>(&signal), sizeof(signal));
#endif
    }

    Config config_;
    Options option_;
    SymId quoter_sid_ = 0;
    Strategy *main_strategy_ = nullptr;
    Predictor *predictor_ = nullptr;

    std::unique_ptr<GAssistThread> assist_thread_;
    std::vector<SymId> sids_;
    std::unique_ptr<PreprocessorCenter> data_preprocessor_;
    phmap::flat_hash_set<SymId> assist_sids_;
    phmap::flat_hash_map<SymId, md::Trade*> last_trades_in_batch_;

    phmap::flat_hash_map<SymId, TradeIdFilter> trade_filter_map;

    GaiaOrderbookManager ob_manager_;

    ContractInfoMapType contract_map_;
    SidContractInfoMapType sid_contract_map_;

    bool allBooksPopulated = false;
    bool allTradePopulated = false;
    bool allBestQuotePopulated = false;
};
