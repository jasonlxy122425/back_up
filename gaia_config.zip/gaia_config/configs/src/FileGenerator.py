import sys, os
sys.path.append("../")
sys.path.append("../ServerConfigs")
sys.path.append("../ServerInfo")
from ServerInfo import *
from FileBuilder import *
class FileGenerator:
    def __init__(self):
        self.file_builder = FileBuilder()
        

    def generateYaml(self, config, config_path, index):
        content = ""

        content = self.file_builder.build(config)
        os.system(f"mkdir -p {config_path}")
        os.system(f"chmod 777 {config_path}")
        with open(f"{config_path}/{config.strategy_name}.yml", 'w') as file:
            file.write(content)
        os.system(f"chmod 777 {config_path}/{config.strategy_name}.yml")