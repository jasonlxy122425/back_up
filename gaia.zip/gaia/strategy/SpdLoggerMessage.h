#pragma once
#include <string>
#include <iomanip>
#include <iostream>
#include <string.h>
#include "CommonDefine.h"
#include "ContractInfo.h"
#include "LogPool.h"

#include "nlohmann/json.hpp"

template <typename T>
struct is_double_or_float
{
    operator bool() { return false; }
};
template <>
struct is_double_or_float<double>
{
    operator bool() { return true; }
};
template <>
struct is_double_or_float<float>
{
    operator bool() { return true; }
};

class SpdLoggerMessageBase {
public:
    virtual ~SpdLoggerMessageBase() {}
    std::string toString() {
        nlohmann::ordered_json header;
        header = {
            {"log_ts_str" , log_ts_str},
            {"tag" , tag},
            {"sub_tag" , sub_tag},
            {"log_ts" , log_ts},
            {"update_ts" , update_ts},
        };
        write();
        header.merge_patch(ret);

        return header.dump();
    }

    void recycle() {
        ret.clear();
        log_ts_str.clear();
        log_ts = 0;
        update_ts = 0;
        memset(tag, 0, sizeof(tag));
        memset(sub_tag, 0, sizeof(sub_tag));
        
        recycle_impl();
    }

    virtual void write() = 0;
    virtual void recycle_impl() = 0;

    std::string log_ts_str;
    int64_t log_ts;
    int64_t update_ts;
    char    tag[64];
    char    sub_tag[64];
    nlohmann::ordered_json ret;

protected:
    std::string removeTrailingZeros(const std::string& num) {
        int i = num.length() - 1;
        
        while (i >= 0 && num[i] == '0') {
            --i;
        }
        
        if (i < 0) {
            return "0";
        } else {
            return num.substr(0, i + 1);
        }
    }

    template <typename T>
    std::string tostring(const T &v)
    {
        if (is_double_or_float<T>())
        {
            char buf[64];
            snprintf(buf, sizeof(buf), "%.15f", v);

            std::string buf_str = buf;
            return std::move(removeTrailingZeros(buf_str));
        }
        else
        {
            std::stringstream ss;
            ss << v;
            return ss.str();
        }
    }
};

template<typename Derived>
class SpdLoggerMessage : public SpdLoggerMessageBase {
public:
    void write() override {
        static_cast<Derived*>(this)->writeLog();
    }

    void recycle_impl() override {
        GlobalMessagePool<Derived>::instance().release(static_cast<Derived*>(this));
    }
    virtual void writeLog() = 0;
};

template<typename T, typename... Args>
T* getSpdLoggerMessage(Args&&... args) {
    auto* msg = getLogMessage<T>();
    new(msg) T(std::forward<Args>(args)...);
    return msg;
}



class PositionHedgingMessage : public SpdLoggerMessage<PositionHedgingMessage>
{
public:
    PositionHedgingMessage(
        const char *_mirana_ticker, const char *_hedger_mirana_ticker,
        const int &_logic_acct_id, const int &_hedger_logic_acct_id,
        const uint64_t &_hedge_order_id, const double &_hedge_price,
        const double &_hedge_qty, const int &_hedge_sign,
        const double &_base_coin_sum, const double &_bid_in_flight_coin, const double &_ask_in_flight_coin)
        : logic_acct_id(_logic_acct_id), hedger_logic_acct_id(_hedger_logic_acct_id),
            hedge_order_id(_hedge_order_id), hedge_price(_hedge_price),
            hedge_qty(_hedge_qty), hedge_sign(_hedge_sign),
            base_coin_sum(_base_coin_sum), bid_in_flight_coin(_bid_in_flight_coin), ask_in_flight_coin(_ask_in_flight_coin)
    {
        strcpy(mirana_ticker, _mirana_ticker);
        strcpy(hedger_mirana_ticker, _hedger_mirana_ticker);
    }

    virtual void writeLog()
    {
        ret = { 
            {"msg_type", "PositionHedging"},
            {"symbol" , std::string(mirana_ticker)},
            {"hedge_symbol" , std::string(hedger_mirana_ticker)},
            {"hedge_logic_acct_id" , hedger_logic_acct_id},
            {"hedge_order_id" , hedge_order_id},
            {"hedge_price" , tostring(hedge_price)},
            {"hedge_qty" , tostring(hedge_qty)},
            {"hedge_side" , hedge_sign},
            {"base_coin_sum" , tostring(base_coin_sum)},
            {"bid_in_flight_coin" , tostring(bid_in_flight_coin)},
            {"ask_in_flight_coin" , tostring(ask_in_flight_coin)}
        };
    }

private:
    char mirana_ticker[128];
    char hedger_mirana_ticker[128];
    int logic_acct_id;
    int hedger_logic_acct_id;
    uint64_t hedge_order_id;
    double hedge_price;
    double hedge_qty;
    int hedge_sign;
    double base_coin_sum;
    double bid_in_flight_coin;
    double ask_in_flight_coin;
};

class TradeHedgingMessage : public SpdLoggerMessage<TradeHedgingMessage>
{
public:
    TradeHedgingMessage(const char *_mirana_ticker, const char *_hedger_mirana_ticker,
                        const int &_logic_acct_id, const int &_hedger_logic_acct_id,
                        const double &_fill_qty, const double &_fill_price, const int &_quote_sign,
                        const char *_quote_trade_id, const uint64_t &_quote_order_id,
                        const uint64_t &_hedge_order_id, const double &_hedge_qty,
                        const double &_hedge_price, const int &_hedge_sign) : logic_acct_id(_logic_acct_id), hedger_logic_acct_id(_hedger_logic_acct_id),
                                                                              fill_qty(_fill_qty), fill_price(_fill_price), quote_sign(_quote_sign),
                                                                              quote_order_id(_quote_order_id),
                                                                              hedge_order_id(_hedge_order_id), hedge_qty(_hedge_qty),
                                                                              hedge_price(_hedge_price), hedge_sign(_hedge_sign)
    {
        strcpy(mirana_ticker, _mirana_ticker);
        strcpy(hedger_mirana_ticker, _hedger_mirana_ticker);
        strcpy(quote_trade_id, _quote_trade_id);
    }

    virtual void writeLog()
    {
        ret = {
            {"msg_type" , "TradeHedging"},
            {"symbol" , mirana_ticker},
            {"hedge_symbol" , hedger_mirana_ticker},
            {"logic_acct_id" , logic_acct_id},
            {"hedge_logic_acct_id" , hedger_logic_acct_id},
            {"quote_fill_qty" , tostring(fill_qty)},
            {"quote_fill_price" , tostring(fill_price)},
            {"quote_fill_sign" , quote_sign},
            {"quote_trade_id" , quote_trade_id},
            {"quote_order_id" , quote_order_id},
            {"hedge_order_id" , hedge_order_id},
            {"hedge_qty" , tostring(hedge_qty)},
            {"hedge_price" , tostring(hedge_price)},
            {"hedge_sign" , hedge_sign}
        };
        
    }

private:
    char mirana_ticker[128];
    char hedger_mirana_ticker[128];
    int logic_acct_id;
    int hedger_logic_acct_id;
    double fill_qty;
    double fill_price;
    int quote_sign;
    char quote_trade_id[128];
    uint64_t quote_order_id;
    uint64_t hedge_order_id;
    double hedge_qty;
    double hedge_price;
    int hedge_sign;
};

class SendReplaceOrderMessage : public SpdLoggerMessage<SendReplaceOrderMessage>
{
public:
    SendReplaceOrderMessage(const int64_t &_now, const GLatencyRecord &latency_record, const TickEventType &_tick_type, const char *_mirana_ticker, const char *_tick_mirana_ticker, const int &_logic_acct_id,
                            const uint64_t &_order_id, const double &_price, const double &_qty,
                            const int &_sign, const int &_tif, const int &_strategy_order_type,
                            const double &_bid_price, const double &_ask_price, const double &_bid_size, const double &_ask_size,
                            bool _is_replace = false, const double &_origin_price=0, const double &_origin_size=0) 
                            : logic_acct_id(_logic_acct_id),
                            order_id(_order_id), price(_price), qty(_qty), sign(_sign), tif(_tif), strategy_order_type(_strategy_order_type),
                            bid_price(_bid_price), ask_price(_ask_price),
                            bid_size(_bid_size), ask_size(_ask_size),
                            is_replace(_is_replace),origin_price(_origin_price),
                            origin_size(_origin_size),send_or_replace_time(_now),
                            tick_type(_tick_type)
    {
        strcpy(mirana_ticker, _mirana_ticker);
        strcpy(tick_mirana_ticker, _tick_mirana_ticker);
        mkt_exch_ts = latency_record.mkt_data.mkt_exch_ts;
        mkt_recv_ts = latency_record.mkt_data.mkt_recv_ts;
        mkt_qs_send_ts = latency_record.mkt_data.mkt_qs_send_ts;
        mkt_parse_end_ts = latency_record.mkt_data.mkt_parse_end_ts;
        mkt_cb_start_ts = latency_record.mkt_data.mkt_cb_start_ts;
    }

    virtual void writeLog()
    {
        std::string msg_type = "SendOrder";
        if (is_replace)
             msg_type = "ReplaceOrder";

        ret = { 
            {"msg_type", msg_type},
            {"symbol", mirana_ticker},
            {"cur_tick_symbol", tick_mirana_ticker},
            {"logic_acct_id", logic_acct_id},
            {"client_order_id", order_id},
            {"price", tostring(price)},
            {"qty", tostring(qty)},
            {"side", sign},
            {"tif", tif},
            {"stra_order_type", strategy_order_type},
            {"bid", tostring(bid_price)},
            {"ask", tostring(ask_price)},
            {"bz", tostring(bid_size)},
            {"az", tostring(ask_size)},
            {"send_or_replace_time", tostring(send_or_replace_time)},
            {"mkt_exch_ts", tostring(mkt_exch_ts)},
            {"mkt_recv_ts", tostring(mkt_recv_ts)},
            {"mkt_qs_send_ts", tostring(mkt_qs_send_ts)},
            {"mkt_parse_end_ts", tostring(mkt_parse_end_ts)},
            {"mkt_cb_start_ts", tostring(mkt_cb_start_ts)},
            {"tick_type", tostring(tick_type)}
        };

        if(is_replace)
        {
            ret["origin_price"] = tostring(origin_price);
            ret["origin_size"] = tostring(origin_size);
        }

        
    }

private:
    char mirana_ticker[128];
    char tick_mirana_ticker[128];
    int logic_acct_id;
    uint64_t order_id;
    double price;
    double qty;
    int sign;
    int tif;
    int strategy_order_type;
    double bid_price;
    double bid_size;
    double ask_price;
    double ask_size;
    bool is_replace;

    double origin_price;
    double origin_size;

    int64_t send_or_replace_time;
    int64_t mkt_exch_ts;
    int64_t mkt_recv_ts;
    int64_t mkt_qs_send_ts;
    int64_t mkt_parse_end_ts;
    int64_t mkt_cb_start_ts;

    TickEventType tick_type;
};

class SendReplaceOrderFailedMessage : public SpdLoggerMessage<SendReplaceOrderFailedMessage>
{
public:
    SendReplaceOrderFailedMessage(const int64_t &_now, const char *_mirana_ticker,
                                const int &_logic_acct_id,
                                const uint64_t &_order_id, const double &_price, const double &_qty,
                                const int &_sign,
                                const double &_bid_price, const double &_ask_price, const double &_bid_size, const double &_ask_size,
                                bool _is_replace = false, const double &_origin_price=0, const double &_origin_size=0) 
                                : logic_acct_id(_logic_acct_id),
                                order_id(_order_id), price(_price), qty(_qty), sign(_sign),
                                bid_price(_bid_price), ask_price(_ask_price),
                                bid_size(_bid_size), ask_size(_ask_size),
                                is_replace(_is_replace),origin_price(_origin_price),
                                origin_size(_origin_size),send_or_replace_time(_now)
    {
        strcpy(mirana_ticker, _mirana_ticker);
    }

    virtual void writeLog()
    {
        std::string msg_type = "SendOrderFailed";
        if (is_replace)
             msg_type = "ReplaceOrderFailed";

        ret = {
            {"msg_type", msg_type},
            {"symbol", mirana_ticker},
            {"logic_acct_id", logic_acct_id},
            {"client_order_id", order_id},
            {"price", tostring(price)},
            {"qty", tostring(qty)},
            {"side", sign},
            {"bid", tostring(bid_price)},
            {"ask", tostring(ask_price)},
            {"bz", tostring(bid_size)},
            {"az", tostring(ask_size)},
            {"send_or_replace_time", tostring(send_or_replace_time)},
        };

        if(is_replace)
        {
            ret["origin_price"] = tostring(origin_price);
            ret["origin_size"] = tostring(origin_size);
        }
    }

private:
    char mirana_ticker[128];
    int logic_acct_id;
    uint64_t order_id;
    double price;
    double qty;
    int sign;
    double bid_price;
    double bid_size;
    double ask_price;
    double ask_size;
    bool is_replace;

    double origin_price;
    double origin_size;

    int64_t send_or_replace_time;

};

class CancelMessage : public SpdLoggerMessage<CancelMessage>
{
public:
    CancelMessage(const int64_t &_now, const ContractInfo *current_contract, const ContractInfo *target_contract, const uint64_t &_client_order_id, const int cancel_order_type, bool _failed = false)
    :client_order_id(_client_order_id), cancel_time(_now),
    recv_ts(current_contract->latency_record.mkt_data.mkt_qs_send_ts),
    exch_ts(current_contract->latency_record.mkt_data.mkt_parse_end_ts),
    cb_start_ts(current_contract->latency_record.mkt_data.mkt_cb_start_ts),
    target_exch_ts(target_contract->latency_record.mkt_data.mkt_exch_ts),
    target_recv_ts(target_contract->latency_record.mkt_data.mkt_recv_ts),
    cancel_order_type(cancel_order_type),
    failed(_failed)
    {
        strcpy(target_symbol, target_contract->symbol_info->mirana_ticker.data());
        strcpy(current_symbol, current_contract->symbol_info->mirana_ticker.data());
    }

    virtual void writeLog()
    {
        ret = { 
            {"msg_type", "CancelOrder"},
            {"symbol", target_symbol},
            {"cur_tick_symbol", current_symbol},
            {"client_order_id", client_order_id},
            {"recv_ts", recv_ts},
            {"exch_ts", exch_ts},
            {"cb_start_ts", cb_start_ts},
            {"target_recv_ts", target_recv_ts},
            {"target_exch_ts", target_exch_ts},
            {"cancel_order_type", cancel_order_type},
            {"cancel_time", cancel_time}
        };

        if(failed) {
            ret["msg_type"] = "CancelOrderFailed";
        }
    }

private:
    uint64_t client_order_id;
    char target_symbol[128];
    char current_symbol[128];
    int64_t cancel_time;
    int64_t recv_ts;
    int64_t exch_ts;
    int64_t cb_start_ts;
    int64_t target_recv_ts;
    int64_t target_exch_ts;
    int cancel_order_type;
    bool failed;
};


class SampleLoggerMessage : public SpdLoggerMessage<SampleLoggerMessage>
{
public:
    SampleLoggerMessage(const double &_d, const int &_i) : sample_d(_d), sample_i(_i) {}
    virtual void writeLog()
    {
        ret = { 
            {"msg_type", "Sample"},
        };
        
    }

private:
    double sample_d;
    int64_t sample_i;
};

class ExecMessage : public SpdLoggerMessage<ExecMessage>
{
public:
    ExecMessage(int e, const char *_event_str, const double &_pred_value, const double &_exec_bid_price,
                const double &_exec_ask_price,
                const int64_t &_exec_ts, int64_t _synthetic_fill_ts, const uint64_t &_order_id,
                const char *_exch_order_id,
                const char *_trade_id, int _err_code,
                const int &_logic_acct_id, const char *_mirana_ticker, const uint32_t &_sid, const double &_symbol_risk,
                int _has_synthetic_filled, double _synthetic_fill_trigger_leaves_qty,
                const int &_signInt, const double &_fill_price, const double &_fee, int _fee_sid,
                int _remain_order_rate, const double &_fill_qty,
                const int64_t &_exec_exch_ts, const int &_strategy_order_type)
                : 
                event(e), pred_value(_pred_value), bid_price(_exec_bid_price), ask_price(_exec_ask_price),
                exec_ts(_exec_ts), synthetic_fill_ts(_synthetic_fill_ts), order_id(_order_id),
                err_code(_err_code), logic_acct_id(_logic_acct_id), sid(_sid),
                symbol_risk(_symbol_risk), has_synthetic_filled(_has_synthetic_filled),
                synthetic_fill_trigger_leaves_qty(_synthetic_fill_trigger_leaves_qty), signInt(_signInt), fill_price(_fill_price),
                fee(_fee), fee_sid(_fee_sid), remain_order_rate(_remain_order_rate), fill_qty(_fill_qty), exec_exch_ts(_exec_exch_ts), strategy_order_type(_strategy_order_type)
    {
        strcpy(event_str, _event_str);
        strcpy(trade_id, _trade_id);
        strcpy(exch_order_id, _exch_order_id);
        strcpy(mirana_ticker, _mirana_ticker);
    }

    ExecMessage(int e, const char *_event_str, const double &_pred_value, const double &_exec_bid_price,
                const double &_exec_ask_price,
                const int64_t &_exec_ts, int64_t _synthetic_fill_ts, const uint64_t &_order_id, std::string_view _trade_id, std::string_view _exch_order_id, int _err_code,
                const int &_logic_acct_id, const char *_mirana_ticker, const uint32_t &_sid, const double &_symbol_risk,
                int _has_synthetic_filled, double _synthetic_fill_trigger_leaves_qty,
                const int &_signInt, const double &_fill_price, const double &_fee, int _fee_sid,
                int _remain_order_rate, const double &_fill_qty,
                const int64_t &_exec_exch_ts, const int &_strategy_order_type):
                ExecMessage(e, _event_str, _pred_value, _exec_bid_price, _exec_ask_price,
                _exec_ts, _synthetic_fill_ts, _order_id, _trade_id.data(), _exch_order_id.data(), _err_code,
                _logic_acct_id, _mirana_ticker, _sid, _symbol_risk,
                _has_synthetic_filled, _synthetic_fill_trigger_leaves_qty,
                _signInt, _fill_price, _fee, _fee_sid, _remain_order_rate, _fill_qty, _exec_exch_ts, _strategy_order_type) {}

    virtual void writeLog()
    {
        ret = { 
            {"msg_type", "Exec"},
            {"event", (int)event},
            {"event_str", event_str},
            {"pred_value", tostring(pred_value)},
            {"bid", tostring(bid_price)},
            {"ask", tostring(ask_price)},
            {"exec_ts", exec_ts},
            {"exec_exch_ts", exec_exch_ts},
            {"synthetic_fill_ts", synthetic_fill_ts},
            {"client_order_id", order_id},
            {"trade_id", trade_id},
            {"exch_order_id", exch_order_id},
            {"err_code", err_code},
            {"logic_acct_id", logic_acct_id},
            {"symbol", mirana_ticker},
            {"sid", sid},
            {"sym_risk", symbol_risk},
            {"has_synthetic_filled", has_synthetic_filled},
            {"synthetic_fill_trigger_leaves_qty", tostring(synthetic_fill_trigger_leaves_qty)},
            {"side", signInt},
            {"fill_price", tostring(fill_price)},
            {"fill_qty", tostring(fill_qty)},
            {"fee", tostring(fee)},
            {"fee_sid", fee_sid},
            {"remain_order_rate", tostring(remain_order_rate)},
            {"stra_order_type", strategy_order_type}
        };
    }

private:
    int event;
    char event_str[64];
    double pred_value;
    double bid_price;
    double ask_price;
    int64_t exec_ts;
    int64_t synthetic_fill_ts;
    uint64_t order_id;
    char trade_id[128];
    char exch_order_id[128];
    int err_code;
    int logic_acct_id;
    char mirana_ticker[128];
    uint32_t sid;
    double symbol_risk;
    int has_synthetic_filled;
    double synthetic_fill_trigger_leaves_qty;
    int signInt;
    double fill_price;
    double fee;
    int fee_sid;
    int remain_order_rate;
    double fill_qty;
    int64_t exec_exch_ts;
    int strategy_order_type;
};

class OnQryBalanceMessage : public SpdLoggerMessage<OnQryBalanceMessage>
{
public:
    OnQryBalanceMessage(const int &_logic_acct_id, const uint32_t &_sid, const char *_symbol,
                    const char *_coin, const int &_error_code, const double &_available, const double &_frozen,
                    const double &_total, const double &_unrealized, const double &_realized)
                    :logic_acct_id(_logic_acct_id),sid(_sid),error_code(_error_code),
                    available(_available), frozen(_frozen), total(_total),
                    unrealized_pnl(_unrealized), realized_pnl(_realized)
    {
        strcpy(mirana_ticker, _symbol);
        strcpy(coin, _coin);
    }

    virtual void writeLog()
    {
        ret = { 
            {"msg_type", "OnQryBalance"},
            {"logic_acct_id", logic_acct_id},
            {"sid", sid},
            {"symbol", mirana_ticker},
            {"coin", coin},
            {"err_code", error_code},
            {"available", tostring(available)},
            {"frozen", tostring(frozen)},
            {"total", tostring(total)},
            {"unrealized_pnl", tostring(unrealized_pnl)},
            {"realized_pnl", tostring(realized_pnl)}
        };

        
    }

private:
    int logic_acct_id;
    uint32_t sid;
    char mirana_ticker[128];
    char coin[48];
    int error_code;
    double available;
    double frozen;
    double total;
    double unrealized_pnl;
    double realized_pnl;
};

class OnQryWalletMessage : public SpdLoggerMessage<OnQryWalletMessage>
{
public:
    OnQryWalletMessage(const int &_logic_acct_id, const uint32_t &_sid, const char* _coin,
                        const int &_err_code, const double &_maint_margin, const double &_initial_margin,
                        const double &_margin_used)
                        : logic_acct_id(_logic_acct_id), sid(_sid),err_code(_err_code),
                        maint_margin(_maint_margin),initial_margin(_initial_margin),
                        margin_used(_margin_used)
                        {
                            strcpy(coin, _coin);
                        }

    virtual void writeLog()
    {
        ret = { 
            {"msg_type", "OnQryWallet"},
            {"logic_acct_id", logic_acct_id},
            {"sid", sid},
            {"coin", coin},
            {"err_code", err_code},
            {"maint_margin", tostring(maint_margin)},
            {"initial_margin", tostring(initial_margin)},
            {"margin_used", tostring(margin_used)}
        };

        
    }

private:
    int logic_acct_id;
    uint32_t sid;
    char coin[48];
    int err_code;
    double maint_margin;
    double initial_margin;
    double margin_used;
};

class OnQryPositionMessage : public SpdLoggerMessage<OnQryPositionMessage>
{
public:
    OnQryPositionMessage(const int &_logic_acct_id, const uint32_t &_sid, const int _err_code,
                        const double &_cum_realized_pnl, const double &_unrealized_pnl,
                        const double &_leverage, const double &_liq_price,
                        const double &_pos_size, const double &_position_mm,
                        const double &_avg_entry_price, const bool &_is_last)
                        :logic_acct_id(_logic_acct_id),sid(_sid),err_code(_err_code),
                        cum_realized_pnl(_cum_realized_pnl),unrealized_pnl(_unrealized_pnl),
                        leverage(_leverage), liq_price(_liq_price),pos_size(_pos_size),
                        position_mm(_position_mm),avg_entry_price(_avg_entry_price),is_last(_is_last)
                        {
                        }
    
    virtual void writeLog()
    {
        ret = { 
            {"msg_type", "OnQryPosition"},
            {"sid", sid},
            {"err_code", err_code},
            {"cum_realized_pnl", tostring(cum_realized_pnl)},
            {"unrealized_pnl", tostring(unrealized_pnl)},
            {"leverage", leverage},
            {"liq_price", tostring(liq_price)},
            {"pos_size", tostring(pos_size)},
            {"position_mm", tostring(position_mm)},
            {"avg_entry_price", tostring(avg_entry_price)},
            {"is_last", is_last}
        };

        
    }

private:
    int logic_acct_id;
    uint32_t sid;
    int err_code;
    double cum_realized_pnl;
    double unrealized_pnl;
    double leverage;
    double liq_price;
    double pos_size;
    double position_mm;
    double avg_entry_price;
    bool   is_last;
};

class OnQryOpenOrderMessage : public SpdLoggerMessage<OnQryOpenOrderMessage>
{
public:
    OnQryOpenOrderMessage(const uint64_t &_client_order_id):client_order_id(_client_order_id)
    {
    }

    virtual void writeLog()
    {
        ret = { 
            {"msg_type", "OnQryOpenOrder"},
            {"client_order_id", client_order_id}
        };

        
    }

private:
    uint64_t client_order_id;
};

class OnFundingRateMessage : public SpdLoggerMessage<OnFundingRateMessage>
{
public:
    OnFundingRateMessage(const uint32_t &_sid, const char *_mirana_ticker, const double & _funding_rate,
                        const uint64_t &_next_funding_time, const double &_cur_funding_rate)
                        : sid(_sid),funding_rate(_funding_rate),next_funding_time(_next_funding_time),
                        cur_funding_rate(_cur_funding_rate)
    {
        strcpy(mirana_ticker, _mirana_ticker);
    }

    virtual void writeLog()
    {
        ret = { 
            {"msg_type", "OnFundingRate"},
            {"symbol", mirana_ticker},
            {"funding_rate", tostring(funding_rate)},
            {"next_funding_time", next_funding_time},
            {"cur_funding_rate", tostring(cur_funding_rate)}
        };
    }

private:
    uint32_t sid;
    char mirana_ticker[128];
    double funding_rate;
    uint64_t next_funding_time;
    double cur_funding_rate;
};

class OnReconPositionMessage : public SpdLoggerMessage<OnReconPositionMessage>
{
public:
    OnReconPositionMessage(const int &_logic_acct_id, const uint32_t &_sid,
                            const double &_avg_entry_price, const double &_cum_realized_pnl,
                            const double &_unrealized_pnl, const double &_pos_size)
                            :logic_acct_id(_logic_acct_id),sid(_sid),avg_entry_price(_avg_entry_price),
                            cum_realized_pnl(_cum_realized_pnl),unrealized_pnl(_unrealized_pnl),
                            pos_size(_pos_size)
                            {}

    virtual void writeLog()
    {

        ret = { 
            {"msg_type", "OnReconPosition"},
            {"logic_acct_id", logic_acct_id},
            {"avg_entry_price", tostring(avg_entry_price)},
            {"cum_realized_pnl", tostring(cum_realized_pnl)},
            {"unrealized_pnl", tostring(unrealized_pnl)},
            {"pos_size", tostring(pos_size)}
        };

        
    }

private:
    int logic_acct_id;
    uint32_t sid;
    double avg_entry_price;
    double cum_realized_pnl;
    double unrealized_pnl;
    double pos_size;

};

class OnReconBalanceMessage : public SpdLoggerMessage<OnReconBalanceMessage>
{
public:
    OnReconBalanceMessage(const int &_logic_acct_id, const char *_coin, const double &_frozen,
                            const double &_available, const double &_total)
                            :logic_acct_id(_logic_acct_id), frozen(_frozen),
                            available(_available), total(_total)
                            {
                                strcpy(coin, _coin);
                            }

    virtual void writeLog()
    {
        ret = { 
            {"msg_type", "OnReconBalance"},
            {"logic_acct_id", logic_acct_id},
            {"coin", coin},
            {"frozen", tostring(frozen)},
            {"available", tostring(available)},
            {"total", tostring(total)}
        };

        
    }

private:
    int logic_acct_id;
    char coin[48];
    double frozen;
    double available;
    double total;
};

class OnBalanceUpdateMessage : public SpdLoggerMessage<OnBalanceUpdateMessage>
{
public:
    OnBalanceUpdateMessage(const int &_logic_acct_id, const uint32_t &_sid, const char *_coin,
                            const int &_err_code, const double &_available, const double &_frozen,
                            const double &_total, const double &_unrealized_pnl, const double &_realized_pnl)
                            :logic_acct_id(_logic_acct_id), sid(_sid),err_code(_err_code),
                            available(_available),frozen(_frozen), total(_total),
                            unrealized_pnl(_unrealized_pnl),realized_pnl(_realized_pnl)
    {
        strcpy(coin, _coin);
    }

    virtual void writeLog()
    {
        ret = { 
            {"msg_type", "OnBalanceUpdate"},
            {"logic_acct_id", logic_acct_id},
            {"sid", sid},
            {"coin", coin},
            {"err_code", err_code},
            {"available", tostring(available)},
            {"frozen", tostring(frozen)},
            {"total", tostring(total)},
            {"unrealized_pnl", tostring(unrealized_pnl)},
            {"realized_pnl", tostring(realized_pnl)}
        };

        
    }

private:
    int logic_acct_id;
    uint32_t sid;
    char coin[48];
    int err_code;
    double available;
    double frozen;
    double total;
    double unrealized_pnl;
    double realized_pnl;
};

class StrategyModeChangeMsg : public SpdLoggerMessage<StrategyModeChangeMsg>
{
public:
    StrategyModeChangeMsg(StrategyMode _prev_mode, StrategyMode _cur_mode, std::string _reason)
    :prev_mode(_prev_mode),cur_mode(_cur_mode)
    {
        strcpy(reason, _reason.c_str());
    }

    virtual void writeLog()
    {
        ret = { 
            {"msg_type", "StrategyModeChange"},
            {"prev_mode", prev_mode},
            {"cur_mode", cur_mode},
            {"reason", reason},
        };
        
    }

private:
    StrategyMode prev_mode;
    StrategyMode cur_mode;
    char reason[256];
};

class SyntheticFillMsg : public SpdLoggerMessage<SyntheticFillMsg>
{
public:
    SyntheticFillMsg(const char *_trade_id, const uint64_t &_client_order_id, const double &_sym_risk_before,
                    const double &_sym_risk_after, const double &trade_price, const double &trade_qty,
                    const int &_trade_side_int, const int64_t &_synthetic_fill_ts, const double &_synthetic_fill_qty,
                    const double &_synthetic_fill_price, const double &_synthetic_fill_triggered_leaves_qty,
                    const int &_order_side_int, const double &_order_price, const double &_order_qty)
    {
        strcpy(trade_id, _trade_id);
    }

    virtual void writeLog()
    {
        ret = { 
            {"msg_type", "SyntheticFilled"},
            {"trade_id", trade_id},
            {"client_order_id", client_order_id},
            {"sym_risk_before", tostring(sym_risk_before)},
            {"sym_risk_after", tostring(sym_risk_after)},
            {"fill_price", tostring(trade_price)},
            {"fill_qty", tostring(trade_qty)},
            {"fill_side", trade_side_int},
            {"synthetic_filled_ts", synthetic_fill_ts},
            {"synthetic_filled_qty", tostring(synthetic_fill_qty)},
            {"synthetic_filled_price", tostring(synthetic_fill_price)},
            {"synthetic_fill_leaves_qty", tostring(synthetic_fill_triggered_leaves_qty)},
            {"order_side", order_side_int},
            {"order_price", tostring(order_price)},
            {"order_qty", tostring(order_qty)}
        };

        
    }

private:
    char trade_id[128];
    uint64_t client_order_id;
    double sym_risk_before;
    double sym_risk_after;
    double trade_price;
    double trade_qty;
    int    trade_side_int; 
    int64_t synthetic_fill_ts;
    double  synthetic_fill_qty;
    double  synthetic_fill_price;
    double  synthetic_fill_triggered_leaves_qty;
    int     order_side_int;
    double  order_price;
    double  order_qty;
};

class SyntheticFillFalseFillMsg : public SpdLoggerMessage<SyntheticFillFalseFillMsg>
{
public:
    SyntheticFillFalseFillMsg(const double &_order_filled_qty, const uint64_t &_client_order_id,
                              const double &_order_leaves_qty, const int64_t &_synthetic_filled_ts,
                              const double &_synthetic_fill_triggered_leaves_qty,
                              const double &_leaves_qty, const double &_order_qty,
                              const double &_order_cum_fill_qty, const int &_logic_acct_id)
                              :order_filled_qty(_order_filled_qty), client_order_id(_client_order_id),
                              order_leaves_qty(_order_leaves_qty), synthetic_filled_ts(_synthetic_filled_ts),
                              synthetic_fill_triggered_leaves_qty(_synthetic_fill_triggered_leaves_qty),
                              leaves_qty(_leaves_qty),order_qty(_order_qty),order_cum_fill_qty(_order_cum_fill_qty),
                              logic_acct_id(_logic_acct_id)
    {}

    virtual void writeLog()
    {
        ret = { 
            {"msg_type", "SyntheticFillFalseFill"},
            {"fill_qty", order_filled_qty},
            {"client_order_id", client_order_id},
            {"leaves_qty", tostring(order_leaves_qty)},
            {"synthetic_filled_ts", synthetic_filled_ts},
            {"synthetic_fill_leaves_qty", tostring(synthetic_fill_triggered_leaves_qty)},
            {"ts_leaves_qty", tostring(leaves_qty)},
            {"ts_qty", tostring(order_qty)},
            {"ts_cum_fill_qty", tostring(order_cum_fill_qty)},
            {"logic_acct_id", logic_acct_id}
        };

        
    }

private:
    double order_filled_qty;
    uint64_t client_order_id;
    double order_leaves_qty;
    int64_t synthetic_filled_ts;
    double synthetic_fill_triggered_leaves_qty;
    double leaves_qty;
    double order_qty;
    double order_cum_fill_qty;
    int logic_acct_id;
};


class PositionUpdateMsg : public SpdLoggerMessage<PositionUpdateMsg>
{
public:
    PositionUpdateMsg(const char *_mirana_ticker, const int &_logic_acct_id, const double &_fill_qty,
                      const double &_fill_price, const int &_fill_side_int, const double &_fill_fee,
                      const double &_avg_entry_price, const double &_symbol_risk,
                      const double &_unrealized_pnl, const double &_realized_pnl,
                      const double &_max_pnl)
    :logic_acct_id(_logic_acct_id), fill_qty(_fill_qty), fill_price(_fill_price),
    fill_side_int(_fill_side_int), fill_fee(_fill_fee), avg_entry_price(_avg_entry_price),
    symbol_risk(_symbol_risk), unrealized_pnl(_unrealized_pnl), realized_pnl(_realized_pnl),
    max_pnl(_max_pnl)
    {
        strcpy(mirana_ticker, _mirana_ticker);
    }

    virtual void writeLog()
    {
        ret = { 
            {"msg_type", "PositionUpdate"},
            {"symbol", mirana_ticker},
            {"logic_acct_id", logic_acct_id},
            {"fill_price", tostring(fill_price)},
            {"fill_qty", tostring(fill_qty)},
            {"fill_side", fill_side_int},
            {"fill_fee_bps", tostring(fill_fee*10000)},
            {"avg_entry_price", tostring(avg_entry_price)},
            {"symbol_risk", tostring(symbol_risk)},
            {"unrealized_pnl", tostring(unrealized_pnl)},
            {"realized_pnl", tostring(realized_pnl)},
            {"total_pnl", tostring(unrealized_pnl + realized_pnl)},
            {"max_pnl", tostring(max_pnl)}
        };

        
    }

private:
    char mirana_ticker[128];
    int  logic_acct_id;
    double fill_qty;
    double fill_price;
    int    fill_side_int;
    double fill_fee;
    double avg_entry_price;
    double symbol_risk;
    double unrealized_pnl;
    double realized_pnl;
    double max_pnl;
};

class StrategySnapshotMsg : public SpdLoggerMessage<StrategySnapshotMsg>
{
public:
    StrategySnapshotMsg(const std::string &_symbol, const StrategyMode &_mode,
                        const StrategySnapshot& _snapshot)
    :snapshot(_snapshot)
    {
        strcpy(symbol, _symbol.c_str());
        strcpy(mode, getStrategyModeStr(_mode).c_str());
    }

    virtual void writeLog()
    {
        ret = {
            {"msg_type", "StrategySnapshot"},
            {"symbol", symbol},
            {"mode", mode},
            {"reason", snapshot.mode_change_reason},
            {"last_insert_replace_ts", snapshot.last_insert_or_replace_ts},
        };

        
    }

private:
    char             symbol[128];
    char             mode[64];
    StrategySnapshot snapshot;
};

class StrategyBalanceMsg : public SpdLoggerMessage<StrategyBalanceMsg>
{
public:
    StrategyBalanceMsg(const std::string &_symbol, const double &_total, const double &_available, const int64_t _balance_ts):
    total(_total), available(_available), balance_ts(_balance_ts)
    {
        strcpy(symbol, _symbol.c_str());
    }

    virtual void writeLog()
    {
        ret = {
            {"msg_type", "StrategyBalance"},
            {"symbol", symbol},
            {"total", total},
            {"available", available},
            {"balance_ts", balance_ts},
        };
    }

private:
    char             symbol[128];
    double           total;
    double           available;
    int64_t          balance_ts;
};

class ParamUpdateMsg : public SpdLoggerMessage<ParamUpdateMsg>
{
public:
    template<class T>
    ParamUpdateMsg(std::string _param, T _value)
    {
        strcpy(param, _param.c_str());
        strcpy(value, tostring(_value).c_str());
    }

    virtual void writeLog()
    {
        ret = { 
            {"msg_type", "ParamUpdate"},
            {"param", param},
            {"value", value}
        };
    }

private:
    char param[128];
    char value[128];
};

class OrderNumMsg : public SpdLoggerMessage<OrderNumMsg>
{
public:
    OrderNumMsg(std::unordered_map<std::string, double> &_output, const int64_t &_recv_ts, const double &_num_send_order, const double &_num_cancel_order)
    {
        saved_output = _output;
        recv_ts = _recv_ts;
        num_send_order = _num_send_order;
        num_cancel_order = _num_cancel_order;
    }

    virtual void writeLog()
    {
        ret = { 
            {"msg_type", "OrderNum"},
            {"recv_ts", tostring(recv_ts)},
            {"num_send_order", tostring(num_send_order)},
            {"num_cancel_order", tostring(num_cancel_order)},
        };


        for (auto &it : saved_output) {
            ret[it.first] = tostring(it.second);
        }
    }

private:
    std::unordered_map<std::string, double> saved_output;
    int64_t recv_ts;
    double num_send_order, num_cancel_order;
};

class CustomMsg : public  SpdLoggerMessage<CustomMsg>
{
public:
    CustomMsg(const std::string &_msg_type, const std::string &_msg) {
        msg_type = _msg_type;
        msg = _msg;
    }

    virtual void writeLog() {
        ret = {
            {"msg_type", msg_type},
            {"msg", msg}
        };
    }

private:
    std::string msg_type;
    std::string msg;
};

class LatencyMsg : public SpdLoggerMessage<LatencyMsg>
{
public:
    LatencyMsg(bool _is_insert, const std::string &_symbol, const std::string &_cur_symbol,
            int type, const GLatencyRecord &_latency_record, const StrategyLatency &_st_latency,
            bool _is_signal_update, const uint32_t &_signal_sid,
            const int64_t &_signal_recv_ts, const int64_t &_signal_push_ts, const int64_t &_signal_exch_ts, const int64_t &_signal_cb_start_ts) {
        is_insert = _is_insert;
        strcpy(symbol, _symbol.c_str());
        strcpy(cur_symbol, _cur_symbol.c_str());
        is_signal_update = _is_signal_update;
        this->type = type;
        latency_record = _latency_record;
        st_latency = _st_latency;
        signal_sid = _signal_sid;
        signal_recv_ts = _signal_recv_ts;
        signal_push_ts = _signal_push_ts;
        signal_exch_ts = _signal_exch_ts;
        signal_cb_start_ts = _signal_cb_start_ts;
    }

    virtual void writeLog() {
        int64_t recv_ts = latency_record.mkt_data.mkt_recv_ts;
        int64_t exch_ts = latency_record.mkt_data.mkt_exch_ts;
        int64_t parse_end_ts = latency_record.mkt_data.mkt_parse_end_ts;
        int64_t cb_start_ts = latency_record.mkt_data.mkt_cb_start_ts;
        if (type == int(TickEventType::TICK_SIGNAL)) {
            recv_ts = signal_recv_ts;
            exch_ts = signal_exch_ts;
            parse_end_ts = signal_push_ts;
            cb_start_ts = signal_cb_start_ts;
        }
        ret = {
            {"msg_type", "LatencyMsg"},
            {"is_signal_update", is_signal_update},
            {"is_insert", is_insert},
            {"symbol", symbol},
            {"cur_symbol", cur_symbol},
            {"type", type},
            {"signal_sid", signal_sid},
            {"recv_ts", latency_record.mkt_data.mkt_recv_ts},
            {"exch_ts", latency_record.mkt_data.mkt_exch_ts},
            {"parse_end_ts", latency_record.mkt_data.mkt_parse_end_ts},
            {"cb_start_ts", latency_record.mkt_data.mkt_cb_start_ts},
            {"batch_start_ts", st_latency.batch_start_ts},
            {"batch_size", st_latency.batch_size},
            {"gaia_start_ts", st_latency.gaia_start_ts},
            {"predictor_start_ts", st_latency.predictor_start_ts},
            {"risk_start_ts", st_latency.risk_start_ts},
            {"order_logic_start_ts", st_latency.order_logic_start_ts},
            {"hedger_start_ts", st_latency.hedger_start_ts},
            {"gaia_end_ts", st_latency.gaia_end_ts}
        };
    }

private:
    char symbol[128];
    char cur_symbol[128];
    bool is_signal_update;
    bool is_insert;
    int type;
    uint32_t signal_sid;
    int64_t signal_recv_ts;
    int64_t signal_push_ts;
    int64_t signal_exch_ts;
    int64_t signal_cb_start_ts;
    GLatencyRecord latency_record;
    StrategyLatency st_latency;
};

class WarmupMsg : public SpdLoggerMessage<WarmupMsg> {
public:
    WarmupMsg(const std::string &_symbol, const uint64_t &_client_order_id, const double &_price, const double &_size, const int64_t &_ts)
    {
        strcpy(symbol, _symbol.c_str());
        price = _price;
        size = _size;
        ts = _ts;
        client_order_id = _client_order_id;
    }

    virtual void writeLog() {
        ret = {
            {"msg_type", "WarmupMsg"},
            {"symbol", symbol},
            {"client_order_id", client_order_id},
            {"price", price},
            {"size", size},
            {"ts", ts}
        };
    }
private:
    char symbol[128];
    uint64_t client_order_id;
    double price;
    double size;
    int64_t ts;
};
