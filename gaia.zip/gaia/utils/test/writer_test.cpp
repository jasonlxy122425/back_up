#include "data_writer.h"

using namespace alphaless;
using namespace alphaless::md;

int main() {
	Config config = Config::LoadFile("./test.yml");	
	auto writer_ = DataWriter::CreateDataWriter(config.Get<Config>("data_writer"), nullptr);
	GaiaOrderbook ob;
	BestQuote bbo;
	writer_->OnBestQuote(bbo, ob);
}
