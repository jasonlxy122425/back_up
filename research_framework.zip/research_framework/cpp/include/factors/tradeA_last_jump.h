#include "Factor.h"
#include "Ema.h"
#include <cmath>
#include "GaiaCircularBuffer.h"

class TradeALastJumpFactor : public FactorInterface
{
public:
    TradeALastJumpFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
        ema_int = config.Get<int64_t>("ema_int");
        lookback = config.Get<int64_t>("lookback");
        threshold = config.Get<double>("threshold");
        ema.init(ema_int);
        last_prc_buffer.setSize(lookback, 0.0);
        prev_exch_ts = 0;

    };

    virtual std::string gen_name() {;
        return std::string("TradeALastJumpFactor")  + '@' + std::to_string(threshold) + '@' + std::to_string(lookback) + '@' + std::to_string(ema_int);
    }

    virtual void calculate(const FactorInput& input_data) {
        factor_value = 0.0;
        auto &trade = input_data.cur_contract->trade;
        int64_t exch_ts = trade.exch_ts;
        if (std::abs(exch_ts - prev_exch_ts) > MinErr){
            if (last_price > MinErr){
                last_prc_buffer.push(last_price);
            }
        }
        last_price = trade.price;
        if(last_prc_buffer.isFull() != false){
            double last_std = last_prc_buffer.std();
            if (last_std > MinErr){
                double z_score = (last_price - last_prc_buffer.mean())/last_std;
                if (z_score >= threshold){
                    factor_value = 1.0;
                }
                else if (z_score <= -threshold){
                    factor_value = -1.0;
                }
                else {
                    factor_value = 0.0;
                }
            }
        }
        ema.update(factor_value);
        factor_value = ema.get();
        prev_exch_ts = exch_ts;
        
    };

private:
    int64_t ema_int;
    Ema ema;
    int64_t lookback;
    GaiaCircularBuffer<double> last_prc_buffer;
    int64_t prev_exch_ts;
    double threshold;
    double last_price = 0.0;
    
};
                              
