#pragma once

#include "Predictor.h"
#include "GaiaModel.h"
#include "arb/PriceEmaByTime.h"

#include <ostream>

class LeadLagPredictorImpl : public Predictor
{
public:
    LeadLagPredictorImpl(){};

    std::ofstream of;
    int count = 0;
    virtual void Init(const Config &_conf, const Config &_pred_conf){
        std::cout << "init Kronos Predictor config" << std::endl;
        auto orderConfig = _conf.Get<Config>("order_logic_config");
        auto commonConfig = orderConfig.Get<Config>("common");

        auto conf = _conf.Get<Config>("predictor_config");

        quoter_symbol = GaiaUtils::GetParam<std::string>(conf, "quoter_symbol");
        quoter_sid = (*state->contract_map)[quoter_symbol]->symbol_info->sid;

        auto factors_conf = conf.Get<std::vector<Config>>("factors");

        if (_pred_conf.TryGet<Config>("factors")) {
            // initialize factor input
            factor_input.preprocess_result = state->preprocess_result;

            auto factors_conf = _pred_conf.Get<std::vector<Config>>("factors");
            factor_manager_.Init(&factor_timer, state->sid_contract_map);
            // use memory managed by FactorManager
            factor_manager_.InitMemoryForFactors(factors_conf);
        }

        int factor_num = 0;
        for(auto f_conf : factors_conf) {
            ++factor_num;
            std::string name = GaiaUtils::GetParam<std::string>(f_conf, "factor_name");
            std::string symbol = GaiaUtils::GetParam<std::string>(f_conf, "symbol");
            auto sid = (*state->contract_map)[symbol]->symbol_info->sid;
            FactorInterface* factor = factor_manager_.CreateFactorInstance(name, sid, f_conf);
            factors[sid].push_back(factor);
            std::cout << "add factor: " << factor->get_name() << ", sid:" << sid << std::endl;
            try {
                std::string asst_symbol = GaiaUtils::GetParam<std::string>(f_conf, "asst_symbol");
                auto asst_sid = (*state->contract_map)[asst_symbol]->symbol_info->sid;
                factors[asst_sid].push_back(factor);
                std::cout << "add factor: " << factor->get_name() << ", asst_sid:" << asst_sid << std::endl;
            } catch(...) {
            }
            sorted_factors.push_back(factor);
        }

        auto model_path = GaiaUtils::GetParam<std::string>(conf, "model_path");

        if(factor_num > 0) {
            auto model_type = GaiaUtils::GetParam<std::string>(conf, "model_type");
            model.LoadModel(model_type);
            model.Init(model_path, factor_num, conf);
        }
        factor_values.resize(factor_num, 0.0);
        for (size_t i = 0; i < sorted_factors.size(); ++i) {
            sorted_factors[i]->SetFactorOutput(&(factor_values[i]));
        }
        model_output.resize(1);
        model_output_len = 1;

        pred_alpha = GaiaUtils::GetParam<double>(conf, "pred_alpha");
        use_assist = GaiaUtils::GetParam<bool>(conf, "use_assist");
        use_price_ema = GaiaUtils::GetParam<bool>(conf, "use_price_ema");
        if (use_assist) {
            assist_price_tag = GaiaUtils::GetParam<int64_t>(conf, "assist_price_tag");
            assist_symbol = GaiaUtils::GetParam<std::string>(conf, "assist_symbol");
            assist_sid = (*state->contract_map)[assist_symbol]->symbol_info->sid;
            theo_level = GaiaUtils::GetParam<int64_t>(conf, "theo_level");
        }
        else {
            assist_price_tag = true;
            assist_symbol = "";
            assist_sid = 0;
            theo_level = 1;
        }

        if (use_price_ema) {
            exp_base = GaiaUtils::GetParam<int64_t>(conf, "exp_base");
        }
        else {
            exp_base = 60;
        }

        Config tmp_conf;
        tmp_conf.Set("interval_ns", 5000000);
        tmp_conf.Set("exp_base", exp_base);
        target_mid_price_ema.Init(tmp_conf);
        assist_mid_price_ema.Init(tmp_conf);
    };

    virtual void getFactors(FactorOutputType &output) {

        output.clear();
        // for(auto& [sid, factors] : factors) {
        //     for(FactorInterface* factor : factors) {
        //         output[factor->get_name()] = factor->get_value();
        //     }
        // }

        output["target_bid"] = target_bid;
        output["target_ask"] = target_ask;
        output["target_bz"] = target_bz;
        output["target_az"] = target_az;
        output["assist_bid"] = assist_bid;
        output["assist_ask"] = assist_ask;
        output["assist_bz"] = assist_bz;
        output["assist_az"] = assist_az;
        output["target_mid_ema"] = target_mid_ema;
        output["assist_mid_ema"] = assist_mid_ema;
        output["price_mid_ema"] = price_mid_ema;
        output["assist_theo"] = assist_theo;
        output["pred"] = state->signal.pred_value;
        ////////////// for analysis only, should be commented when trading /////////////
        output["target_bid_10"] = target_bid_10;
        output["target_bz_10"] = target_bz_10;
        output["target_ask_10"] = target_ask_10;
        output["target_az_10"] = target_az_10;
        output["target_theo_10"] = target_theo_10;
        output["target_bid_30"] = target_bid_30;
        output["target_bz_30"] = target_bz_30;
        output["target_ask_30"] = target_ask_30;
        output["target_az_30"] = target_az_30;
        output["target_theo_30"] = target_theo_30;
        output["target_bid_50"] = target_bid_50;
        output["target_bz_50"] = target_bz_50;
        output["target_ask_50"] = target_ask_50;
        output["target_az_50"] = target_az_50;
        output["target_theo_50"] = target_theo_50;
        output["target_bid_100"] = target_bid_100;
        output["target_bz_100"] = target_bz_100;
        output["target_ask_100"] = target_ask_100;
        output["target_az_100"] = target_az_100;
        output["target_theo_100"] = target_theo_100;
        output["target_bid_150"] = target_bid_150;
        output["target_bz_150"] = target_bz_150;
        output["target_ask_150"] = target_ask_150;
        output["target_az_150"] = target_az_150;
        output["target_theo_150"] = target_theo_150;
        output["target_bid_200"] = target_bid_200;
        output["target_bz_200"] = target_bz_200;
        output["target_ask_200"] = target_ask_200;
        output["target_az_200"] = target_az_200;
        output["target_theo_200"] = target_theo_200;
        output["target_bid_300"] = target_bid_300;
        output["target_bz_300"] = target_bz_300;
        output["target_ask_300"] = target_ask_300;
        output["target_az_300"] = target_az_300;
        output["target_theo_300"] = target_theo_300;
        output["assist_bid_10"] = assist_bid_10;
        output["assist_bz_10"] = assist_bz_10;
        output["assist_ask_10"] = assist_ask_10;
        output["assist_az_10"] = assist_az_10;
        output["assist_theo_10"] = assist_theo_10;
        output["assist_bid_30"] = assist_bid_30;
        output["assist_bz_30"] = assist_bz_30;
        output["assist_ask_30"] = assist_ask_30;
        output["assist_az_30"] = assist_az_30;
        output["assist_theo_30"] = assist_theo_30;
        output["assist_bid_50"] = assist_bid_50;
        output["assist_bz_50"] = assist_bz_50;
        output["assist_ask_50"] = assist_ask_50;
        output["assist_az_50"] = assist_az_50;
        output["assist_theo_50"] = assist_theo_50;
        output["assist_bid_100"] = assist_bid_100;
        output["assist_bz_100"] = assist_bz_100;
        output["assist_ask_100"] = assist_ask_100;
        output["assist_az_100"] = assist_az_100;
        output["assist_theo_100"] = assist_theo_100;
        output["assist_bid_150"] = assist_bid_150;
        output["assist_bz_150"] = assist_bz_150;
        output["assist_ask_150"] = assist_ask_150;
        output["assist_az_150"] = assist_az_150;
        output["assist_theo_150"] = assist_theo_150;
        output["assist_bid_200"] = assist_bid_200;
        output["assist_bz_200"] = assist_bz_200;
        output["assist_ask_200"] = assist_ask_200;
        output["assist_az_200"] = assist_az_200;
        output["assist_theo_200"] = assist_theo_200;
        output["assist_bid_300"] = assist_bid_300;
        output["assist_bz_300"] = assist_bz_300;
        output["assist_ask_300"] = assist_ask_300;
        output["assist_az_300"] = assist_az_300;
        output["assist_theo_300"] = assist_theo_300;
        ///////////////////////////////////////////////////////////////////////////////
    }


    void getFactorValue() {
        // factor_values.clear();
        // for (FactorInterface* factor : sorted_factors) {
        //     factor_values.push_back(factor->get_value());
        // }
    }

    void predict(int64_t cur_time) {
        log_time_cur = cur_time;
        getFactorValue();
        if(factor_values.size()>0) {
            model.Calculate(factor_values, model_output, model_output_len);
            state->signal.pred_value = pred_alpha*model_output[0];//
        }
        else {
            state->signal.pred_value = 0;
        }
    }

    void Calculate() override {
        for(FactorInterface* factor : factors[state->cur_tick_sid]) {
            factor->calculate(factor_input);
        }
        predict(state->latency_record->mkt_data.mkt_recv_ts);
        
        if (use_assist) {
            ContractInfo *target_contract = (*state->contract_map)[quoter_symbol];
            ContractInfo *assist_contract = (*state->contract_map)[assist_symbol];

            target_bid = GaiaUtils::BookGetBestBidPrice(target_contract);
            target_ask = GaiaUtils::BookGetBestAskPrice(target_contract);
            target_bz = GaiaUtils::BookGetBestBidSize(target_contract);
            target_az = GaiaUtils::BookGetBestAskSize(target_contract);
            assist_bid = GaiaUtils::BookGetBestBidPrice(assist_contract);
            assist_ask = GaiaUtils::BookGetBestAskPrice(assist_contract);
            assist_bz = GaiaUtils::BookGetBestBidSize(assist_contract);
            assist_az = GaiaUtils::BookGetBestAskSize(assist_contract);
            target_bz = target_contract->alphaBook->bid(0).qty;
            target_az = target_contract->alphaBook->ask(0).qty;
            assist_bz = assist_contract->alphaBook->bid(0).qty;
            assist_az = assist_contract->alphaBook->ask(0).qty;
            target_trade_price = GaiaUtils::TradeGetPrice(target_contract);
            assist_trade_price = GaiaUtils::TradeGetPrice(assist_contract);
            target_mid = (target_bid+target_ask)/2;
            assist_mid = (assist_bid+assist_ask)/2;

            CalTheo(assist_contract, theo_level, theo_assist_bto, theo_assist_bid, theo_assist_bz, theo_assist_ato, theo_assist_ask, theo_assist_az, assist_theo);
            // std::cout << theo_assist_bto << " " << theo_assist_bid << " " << theo_assist_bz << std::endl;
            // std::cout << theo_assist_ato << " " << theo_assist_ask << " " << theo_assist_az << std::endl;
            // std::cout << assist_theo << std::endl;

            //////////// for analysis only, should be commented when trading /////////////
            CalTheo(assist_contract, 10, theo_assist_bto, assist_bid_10, assist_bz_10, theo_assist_ato, assist_ask_10, assist_az_10, assist_theo_10);
            CalTheo(assist_contract, 30, theo_assist_bto, assist_bid_30, assist_bz_30, theo_assist_ato, assist_ask_30, assist_az_30, assist_theo_30);
            CalTheo(assist_contract, 50, theo_assist_bto, assist_bid_50, assist_bz_50, theo_assist_ato, assist_ask_50, assist_az_50, assist_theo_50);
            CalTheo(assist_contract, 100, theo_assist_bto, assist_bid_100, assist_bz_100, theo_assist_ato, assist_ask_100, assist_az_100, assist_theo_100);
            CalTheo(assist_contract, 150, theo_assist_bto, assist_bid_150, assist_bz_150, theo_assist_ato, assist_ask_150, assist_az_150, assist_theo_150);
            CalTheo(assist_contract, 200, theo_assist_bto, assist_bid_200, assist_bz_200, theo_assist_ato, assist_ask_200, assist_az_200, assist_theo_200);
            CalTheo(assist_contract, 300, theo_assist_bto, assist_bid_300, assist_bz_300, theo_assist_ato, assist_ask_300, assist_az_300, assist_theo_300);
            CalTheo(target_contract, 10, theo_target_bto, target_bid_10, target_bz_10, theo_target_ato, target_ask_10, target_az_10, target_theo_10);
            CalTheo(target_contract, 30, theo_target_bto, target_bid_30, target_bz_30, theo_target_ato, target_ask_30, target_az_30, target_theo_30);
            CalTheo(target_contract, 50, theo_target_bto, target_bid_50, target_bz_50, theo_target_ato, target_ask_50, target_az_50, target_theo_50);
            CalTheo(target_contract, 100, theo_target_bto, target_bid_100, target_bz_100, theo_target_ato, target_ask_100, target_az_100, target_theo_100);
            CalTheo(target_contract, 150, theo_target_bto, target_bid_150, target_bz_150, theo_target_ato, target_ask_150, target_az_150, target_theo_150);
            CalTheo(target_contract, 200, theo_target_bto, target_bid_200, target_bz_200, theo_target_ato, target_ask_200, target_az_200, target_theo_200);
            CalTheo(target_contract, 300, theo_target_bto, target_bid_300, target_bz_300, theo_target_ato, target_ask_300, target_az_300, target_theo_300);
            //////////////////////////////////////////////////////////////////////////////


            if (use_price_ema) {
                if (state->cur_tick_sid == quoter_sid) {
                    factor_input.current_time = state->latency_record->mkt_data.mkt_recv_ts;
                    factor_input.price = target_mid;
                    target_mid_price_ema.calculate(factor_input);
                    factor_input.price = assist_mid;
                    assist_mid_price_ema.calculate(factor_input);
                }
                target_mid_ema = target_mid_price_ema.get_value();
                assist_mid_ema = assist_mid_price_ema.get_value();
                price_mid_ema = target_mid_ema - assist_mid_ema;
            }
            else {
                price_mid_ema = 0.0;
            }

            if (assist_price_tag==0) {
                state->signal.pred_value = ((assist_mid*(1+state->signal.pred_value/10000)+price_mid_ema)/target_mid-1)*10000;
            }
            else if (assist_price_tag==1) {
                state->signal.pred_value = ((assist_trade_price*(1+state->signal.pred_value/10000)+price_mid_ema)/target_mid-1)*10000;
            }
            else if (assist_price_tag==2) {
                state->signal.pred_value = ((assist_theo*(1+state->signal.pred_value/10000)+price_mid_ema)/target_mid-1)*10000;
                // state->signal.pred_value = ((assist_theo + price_mid_ema)/target_mid-1)*10000;
            }
        }

    }


    void CalBidDeepPriceSize(const ContractInfo* contract, const int level, double &turnover, double &price, double &size) {
        price = 0;
        size = 0;
        turnover = 0; 

        int book_level = GaiaUtils::BookGetNumBidLevels(contract);
        for (int i = 0; i < book_level; i++) {
            size += contract->alphaBook->bid(i).qty;
            turnover += contract->alphaBook->bid(i).qty*contract->alphaBook->bid(i).price;
            if (i == level-1) {
                if (size > eps) {
                    price = turnover/size;
                }
                break;
            }
        }

        if (level > book_level) {
            if (size > eps) {
                price = turnover/size;
            }
        }
    }

    void CalAskDeepPriceSize(const ContractInfo* contract, const int &level, double &turnover, double &price, double &size) {
        price = 0;
        size = 0;
        turnover = 0; 

        int book_level = GaiaUtils::BookGetNumAskLevels(contract);
        for (int i = 0; i < book_level; i++) {
            size += contract->alphaBook->ask(i).qty;
            turnover += contract->alphaBook->ask(i).qty*contract->alphaBook->ask(i).price;
            if (i == level-1) {
                if (size > eps) {
                    price = turnover/size;
                }
                break;
            }
        }

        if (level > book_level) {
            if (size > eps) {
                price = turnover/size;
            }
        }
    }


    void CalTheo(const ContractInfo* contract, const int &level, double &bto, double &bid, double &bz, double &ato, double &ask, double &az, double &theo) {
        CalBidDeepPriceSize(contract, level, bto, bid, bz);
        CalAskDeepPriceSize(contract, level, ato, ask, az);
        theo = (bid*az+ask*bz)/(bz+az);
    }


private:
    FactorOutputType output;

    GaiaModel model;
    bool use_model;
    FactorManager factor_manager_;

    std::string    quoter_symbol;
    SymId          quoter_sid;

    bool use_assist;
    bool use_price_ema;
    int64_t assist_price_tag;              // 0: mid price,  1: trade price,  2: theo price
    int64_t exp_base;
    std::string    assist_symbol;
    SymId          assist_sid;
    double pred_alpha;
    int64_t theo_level;

    PriceEmaByTime target_mid_price_ema;
    PriceEmaByTime assist_mid_price_ema;

    std::vector<double> factor_values;
    std::vector<double> model_output;
    int64_t             model_output_len;
    std::unordered_map<SymId, std::vector<FactorInterface*>> factors;
    std::vector<FactorInterface*> sorted_factors;

    double theo_target_bto, theo_target_bid, theo_target_bz, theo_target_ato, theo_target_ask, theo_target_az;
    double theo_assist_bto, theo_assist_bid, theo_assist_bz, theo_assist_ato, theo_assist_ask, theo_assist_az;
    double target_theo, assist_theo;
    double target_bid, target_ask, target_bz, target_az, target_trade_price, assist_bid, assist_ask, assist_bz, assist_az, assist_trade_price;
    double target_mid, assist_mid, target_mid_ema, assist_mid_ema, price_mid_ema;
    int64_t log_time_cur, log_time_last;
    double target_bid_10, target_ask_10, target_bz_10, target_az_10, target_theo_10;
    double target_bid_30, target_ask_30, target_bz_30, target_az_30, target_theo_30;
    double target_bid_50, target_ask_50, target_bz_50, target_az_50, target_theo_50;
    double target_bid_100, target_ask_100, target_bz_100, target_az_100, target_theo_100;
    double target_bid_150, target_ask_150, target_bz_150, target_az_150, target_theo_150;
    double target_bid_200, target_ask_200, target_bz_200, target_az_200, target_theo_200;
    double target_bid_300, target_ask_300, target_bz_300, target_az_300, target_theo_300;
    double assist_bid_10, assist_ask_10, assist_bz_10, assist_az_10, assist_theo_10;
    double assist_bid_30, assist_ask_30, assist_bz_30, assist_az_30, assist_theo_30;
    double assist_bid_50, assist_ask_50, assist_bz_50, assist_az_50, assist_theo_50;
    double assist_bid_100, assist_ask_100, assist_bz_100, assist_az_100, assist_theo_100;
    double assist_bid_150, assist_ask_150, assist_bz_150, assist_az_150, assist_theo_150;
    double assist_bid_200, assist_ask_200, assist_bz_200, assist_az_200, assist_theo_200;
    double assist_bid_300, assist_ask_300, assist_bz_300, assist_az_300, assist_theo_300;
};
