#pragma once
#include "DemeterType.h"
#include <array>
#include <memory>


namespace demeter {

struct DemeterData {
    DemeterData() {
    }

    // raw data interface
    const GobUpdate& GetGobUpdate() const {
        // return sampler_->getGobUpdate();
        return gob_update_;
    }

    GobUpdate& GetGobUpdate() {
        // return sampler_->getGobUpdate();
        return gob_update_;
    }

    double GetGobUpdateSum(size_t side, size_t type) {
        // return sampler_->getGobUpdateSum(side, type);
        return gob_update_sum_.get(side,type);
    }

    double GetGobUpdateSum(Side side, BookOrderType type) {
        // return sampler_->getGobUpdateSum(side, type);
        return gob_update_sum_.get(side,type);
    }

    // merged data
    GobUpdate gob_update_; // gob_update of all buffered
    GobUpdateSum gob_update_sum_;
};

} // namespace demeter