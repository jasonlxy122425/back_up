machine_info_map = {
    "ali-hk-d-kronos-prod-tradeserver-05": {"ts_ip":"192.168.52.25",
                                             "cpu": {"start": 6, "end": 26, "current": 8, "interval": 2}, "shm_prefix": "kronos_arb_"},

    "ali-hk-d-kronos-prod-tradeserver-10": {"ts_ip":"192.168.32.153",
                                             "cpu": {"start": 6, "end": 26, "current": 8, "interval": 2}, "shm_prefix": "kronos_arb_"},

    "ali-hk-d-kronos-prod-tradeserver-06": {"ts_ip":"192.168.52.24",
                                             "cpu": {"start": 6, "end": 26, "current": 8, "interval": 2}, "shm_prefix": "kronos_arb_"},

    "ali-hk-d-kronos-prod-tradeserver-11": {"ts_ip":"192.168.32.146",
                                             "cpu": {"start": 6, "end": 26, "current": 8, "interval": 2}, "shm_prefix": "kronos_arb_"},

    "ali-hk-d-kronos-prod-md-01": {"ts_ip":"192.168.52.5",
                                             "cpu": {"start": 2, "end": 8, "current": 6, "interval": 2}, "shm_prefix": "kronos_arb_"},

    "tky-kronos-prod-md-az4-01": {"ts_ip":"10.234.165.54",
                                             "cpu": {"start": 1, "end": 4, "current": 4, "interval": 1}, "shm_prefix": "kronos_arb_"},

    "sgp-kronos-prod-md-az2-01": {"ts_ip":"10.230.164.224",
                                             "cpu": {"start": 1, "end": 4, "current": 4, "interval": 1}, "shm_prefix": "kronos_arb_"},


    "sgp-az2-kronos-prod-tradeserver-03": {"ts_ip":"10.230.164.242",
                                         "cpu": {"start": 3, "end": 13, "current": 4, "interval": 1}, "shm_prefix": "kronos_arb_",
                                           "local_mw_ip":"10.237.36.150"},

    "sgp-az2-kronos-prod-tradeserver-04": {"ts_ip":"10.230.164.178",
                                         "cpu": {"start": 3, "end": 13, "current": 4, "interval": 1}, "shm_prefix": "kronos_arb_"},

    "sgp-az2-kronos-prod-tradeserver-05": {"ts_ip":"10.230.164.172",
                                         "cpu": {"start": 3, "end": 13, "current": 4, "interval": 1}, "shm_prefix": "kronos_arb_"},

    "sgp-az2-kronos-prod-tradeserver-10": {"ts_ip":"10.230.164.232",
                                         "cpu": {"start": 3, "end": 13, "current": 4, "interval": 1}, "shm_prefix": "kronos_arb_"},

    "sgp-az2-kronos-prod-tradeserver-11": {"ts_ip":"10.230.164.184",
                                         "cpu": {"start": 3, "end": 13, "current": 4}, "shm_prefix": "kronos_arb_"},

    "sgp-az2-kronos-prod-tradeserver-12": {"ts_ip":"10.230.164.197",
                                         "cpu": {"start": 3, "end": 13, "current": 4}, "shm_prefix": "kronos_arb_"},

    "sgp-az2-kronos-prod-tradeserver-13": {"ts_ip":"10.230.164.157",
                                         "cpu": {"start": 3, "end": 13, "current": 4, "interval": 1}, "shm_prefix": "kronos_arb_",
                                           "local_mw_ip":"10.237.36.147"},

    "sgp-az2-kronos-prod-tradeserver-14": {"ts_ip":"10.230.164.175",
                                         "cpu": {"start": 3, "end": 13, "current": 4, "interval": 1}, "shm_prefix": "kronos_arb_",
                                           "local_mw_ip":"10.237.36.167"},

    "sgp-az2-kronos-prod-tradeserver-15": {"ts_ip":"10.232.24.179",
                                         "cpu": {"start": 3, "end": 6, "current": 4, "interval": 1}, "shm_prefix": "kronos_arb_"},

    "tky-az4-kronos-prod-tradeserver-oldvpc-07": {"ts_ip":"10.34.0.214",
                                         "cpu": {"start": 3, "end": 13, "current": 4, "interval": 1}, "shm_prefix": "kronos_arb_",
                                           "local_mw_ip":"10.139.10.70"},

    "tky-az4-kronos-prod-tradeserver-oldvpc-23": {"ts_ip":"10.34.0.116",
                                         "cpu": {"start": 3, "end": 13, "current": 4, "interval": 1}, "shm_prefix": "kronos_arb_"},

    "tky-az1-kronos-prod-tradeserver-oldvpc-07": {"ts_ip":"10.34.46.46",
                                         "cpu": {"start": 3, "end": 13, "current": 4, "interval": 1}, "shm_prefix": "kronos_arb_",
                                           "local_mw_ip":"10.139.10.220"},

    "tky-az1-kronos-prod-tradeserver-oldvpc-23": {"ts_ip":"10.34.46.69",
                                         "cpu": {"start": 3, "end": 13, "current": 4, "interval": 1}, "shm_prefix": "kronos_arb_"},

    "tky-az4-kronos-prod-tradeserver-oldvpc-10": {"ts_ip":"10.34.0.47",
                                         "cpu": {"start": 3, "end": 13, "current": 4, "interval": 1}, "shm_prefix": "kronos_arb_"},

    "tky-az4-kronos-prod-tradeserver-oldvpc-11": {"ts_ip":"10.34.0.124",
                                         "cpu": {"start": 3, "end": 13, "current": 4, "interval": 1}, "shm_prefix": "kronos_arb_"},
    "tky-az4-kronos-prod-tradeserver-oldvpc-18": {"ts_ip":"10.34.0.165",
                                         "cpu": {"start": 3, "end": 13, "current": 4, "interval": 1}, "shm_prefix": "kronos_arb_"},
    "tky-az4-kronos-prod-tradeserver-oldvpc-24": {"ts_ip":"10.34.0.36",
                                         "cpu": {"start": 3, "end": 27, "current": 4, "interval": 1}, "shm_prefix": "kronos_arb_"},

    "tky-az4-kronos-prod-tradeserver-oldvpc-25": {"ts_ip":"10.34.0.35",
                                         "cpu": {"start": 3, "end": 13, "current": 4, "interval": 1}, "shm_prefix": "kronos_arb_",
                                         "local_mw_ip":"10.139.10.99"},

    "tky-az4-kronos-prod-tradeserver-oldvpc-26": {"ts_ip":"10.34.0.226",
                                         "cpu": {"start": 3, "end": 13, "current": 4, "interval": 1}, "shm_prefix": "kronos_arb_"},


    "tky-az4-kronos-prod-tradeserver-04": {"ts_ip":"10.234.165.80",
                                         "cpu": {"start": 3, "end": 13, "current": 4, "interval": 1}, "shm_prefix": "kronos_arb_",
                                           "local_mw_ip":"10.235.37.88"},

    "tky-az4-kronos-prod-tradeserver-oldvpc-04": {"ts_ip":"10.34.48.189",
                                         "cpu": {"start": 3, "end": 13, "current": 4, "interval": 1}, "shm_prefix": "kronos_arb_",
                                           "local_mw_ip":"10.139.10.95"},

    "tky-az4-kronos-prod-tradeserver-oldvpc-05": {"ts_ip":"10.34.0.17",
                                         "cpu": {"start": 3, "end": 40, "current": 4, "interval": 1}, "shm_prefix": "kronos_arb_",
                                           "local_mw_ip":"10.139.10.105"},

    "sgp-az2-kronos-prod-tradeserver-01": {"ts_ip":"10.230.164.248",
                                         "cpu": {"start": 3, "end": 40, "current": 4, "interval": 1}, "shm_prefix": "kronos_arb_",
                                           "local_mw_ip":"10.237.36.143"},

    "tky-az4-kronos-prod-tradeserver-01": {"ts_ip":"10.234.165.8",
                                         "cpu": {"start": 3, "end": 32, "current": 4}, "shm_prefix": "kronos_arb_",},
    "ali-hk-d-kronos-prod-tradeserver-01": {"ts_ip":"192.168.52.48",
                                         "cpu": {"start": 6, "end": 82, "current": 8, "interval": 2}, "shm_prefix": "kronos_arb_",},

    "ali-hk-d-kronos-prod-tradeserver-02": {"ts_ip":"192.168.52.55",
                                         "cpu": {"start": 6, "end": 82, "current": 8, "interval": 2}, "shm_prefix": "kronos_arb_",},

    "ali-hk-d-kronos-prod-tradeserver-03": {"ts_ip":"192.168.52.17",
                                         "cpu": {"start": 6, "end": 28, "current": 8}, "shm_prefix": "kronos_arb_",},

    "ali-hk-d-kronos-prod-tradeserver-08": {"ts_ip":"192.168.52.6",
                                         "cpu": {"start": 6, "end": 28, "current": 8}, "shm_prefix": "kronos_arb_",},

    "ali-hk-d-kronos-prod-tradeserver-09": {"ts_ip":"192.168.43.245",
                                         "cpu": {"start": 6, "end": 28, "current": 8}, "shm_prefix": "kronos_arb_",},

    "lon-az1-kronos-prod-tradeserver-01": {"ts_ip":"10.233.24.18",
                                         "cpu": {"start": 3, "end": 14, "current": 4, "interval": 1}, "shm_prefix": "kronos_arb_",},

    "sgp-az2-kronos-prod-tradeserver-02": {"ts_ip":"10.230.164.163",
                                         "cpu": {"start": 3, "end": 40, "current": 4, "interval": 1}, "shm_prefix": "kronos_arb_",},

    "tky-az4-kronos-prod-tradeserver-oldvpc-01": {"ts_ip":"10.34.0.112",
                                         "cpu": {"start": 3, "end": 40, "current": 4, "interval": 1}, "shm_prefix": "kronos_arb_",},


    "tky-az4-kronos-prod-tradeserver-oldvpc-06": {"ts_ip":"10.34.48.88",
                                         "cpu": {"start": 3, "end": 13, "current": 4, "interval": 1}, "shm_prefix": "kronos_arb_"},

    "tky-az4-kronos-prod-tradeserver-oldvpc-27": {"ts_ip":"10.34.48.97",
                                         "cpu": {"start": 3, "end": 13, "current": 4, "interval": 1}, "shm_prefix": "kronos_arb_"},

    "tky-az4-kronos-prod-tradeserver-oldvpc-21": {"ts_ip":"10.34.48.83",
                                         "cpu": {"start": 3, "end": 13, "current": 4, "interval": 1}, "shm_prefix": "kronos_arb_"},

    "tky-az4-kronos-prod-01": {"ts_ip":"10.234.165.116",
                                         "cpu": {"start": 3, "end": 14, "current": 4, "interval": 1}, "shm_prefix": "kronos_arb_"},
}

microwave_config = [
    {
        "from": "sg",
        "to": "tky",
        "udp_tunnel_host": "10.87.0.86",
        "udp_tunnel_port": 36000,
        "udp_port": 36100,
        "multi_link": True
    },
    {
        "from": "tky",
        "to": "sg",
        "udp_tunnel_host": "10.87.64.104",
        "udp_tunnel_port": 36000,
        "udp_port": 36100,
        "multi_link": True
    },
    {
        "from": "tky",
        "to": "ali-hk",
        #"udp_tunnel_host": "10.89.18.6",
        "udp_tunnel_host": "10.89.26.6",
        "udp_tunnel_port": 37000,
        "udp_port": 36100
    },
    {
        "from": "ali-hk",
        "to": "tky",
        "udp_tunnel_host": "10.89.82.2",
        "udp_tunnel_port": 38000,
        "udp_port": 36100
    }
]
