#include "Factor.h"
#include "Ema.h"
#include <cmath>
#include "GaiaCircularBuffer.h"

class TradeALagDiffFactor : public FactorInterface
{
public:
    TradeALagDiffFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
        lookback = config.Get<int64_t>("lookback");
        buy_prc_buffer.setSize(lookback, 0.0);
        sell_prc_buffer.setSize(lookback, 0.0);
        prev_exch_ts = 0;

    };

    virtual std::string gen_name() {;
        return std::string("TradeALagDiffFactor") + "@lookback=" + std::to_string(lookback);
    }

    virtual void calculate(const FactorInput& input_data) {
        factor_value = 0.0;
        auto &trade = input_data.cur_contract->trade;
        int64_t exch_ts = trade.exch_ts;
        if (trade.side == Side::BUY){
            if (std::abs(exch_ts - prev_exch_ts) > MinErr){
                buy_prc_buffer.push(trade.price);
            }
            else {
                buy_prc_buffer[-1] = trade.price;
            }
        }
        else if (trade.side == Side::SELL){
            if (std::abs(exch_ts - prev_exch_ts) > MinErr){
                sell_prc_buffer.push(trade.price);
            }
            else {
                sell_prc_buffer[-1] = trade.price;
            }
        }
        if ((buy_prc_buffer.isFull() != false) && (sell_prc_buffer.isFull() != false)){
            double buy_lag = buy_prc_buffer[-1] - buy_prc_buffer[0];
            double sell_lag = sell_prc_buffer[-1] - sell_prc_buffer[0];
            factor_value = buy_lag - sell_lag;
        }
        prev_exch_ts = exch_ts;
        
    };

private:
    int64_t lookback;
    GaiaCircularBuffer<double> buy_prc_buffer;
    GaiaCircularBuffer<double> sell_prc_buffer;
    int64_t prev_exch_ts = 0;
    double last_price = 0.0;
    
};
                             