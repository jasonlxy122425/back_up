#include "Factor.h"
#include "Ema.h"
#include <cmath>
#include "GaiaCircularBuffer.h"

class TradeSpreadFactor : public FactorInterface
{
public:
    TradeSpreadFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");

    };

    virtual std::string gen_name() {;
        return std::string("TradeSpreadFactor");
    }

    virtual void calculate(const FactorInput& input_data) {
        double prc_tick_size = input_data.cur_contract->symbol_info->prc_tick_size;
        auto &trade = input_data.cur_contract->trade;
        if (trade.side == Side::BUY){
            last_ask_price = trade.price;
        }
        else if (trade.side == Side::SELL){
            last_bid_price = trade.price;
        }
        if (last_bid_price > MinErr && last_ask_price > MinErr){
            factor_value = (last_ask_price - last_bid_price);
        }
        else {
            factor_value = prc_tick_size;
        }
        
    };

private:
    double last_bid_price = 0.0;
    double last_ask_price = 0.0;
    
};
                              
