#include "Factor.h"
#include "Ema.h"
#include <cmath>

class MidBasisBpsFactor : public FactorInterface
{
public:
    MidBasisBpsFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
        asst_symbol = config.Get<std::string>("asst_symbol");
        ema_int = config.Get<int64_t>("ema_int");
        asst_sid = SecMaster::instance().FindSid(asst_symbol);
        ema.init(ema_int);

    };

    virtual std::string gen_name() {;
        return std::string("MidBasisBpsFactor") + '@' + std::to_string(ema_int) + '@' + asst_symbol;
    }

    virtual void calculate(const FactorInput& input_data) {
        factor_value = 0.0;
        int16_t this_sid = input_data.cur_contract->symbol_info->sid;
        auto &gob = input_data.cur_contract->alphaBook;
        double mid_price = (gob->bid(0).price + gob->ask(0).price)/2.0;
        if (std::fabs(asst_sid - this_sid) < MinErr){
            asst_mid_price = mid_price;
        }
        else {
            target_mid_price = mid_price;
        }
        if (target_mid_price > MinErr && asst_mid_price > MinErr){
            factor_value = (asst_mid_price/target_mid_price-1)*10000;
        }
        ema.update(factor_value);
        factor_value = ema.get();
    };


private:
    int64_t ema_int;
    Ema ema;
    std::string asst_symbol;
    int16_t asst_sid;
    double target_mid_price = 0.0;
    double asst_mid_price = 0.0;
};
                              
