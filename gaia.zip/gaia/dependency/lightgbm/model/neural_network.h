# pragma once
# include <iostream>
# include <fstream>
# include <vector>
# include <cmath>
# include "./base_model.h"
# include "../common/CompilerSpecific.h"
# include "../thirdparty/rapidjson/document.h"
# include "../thirdparty/rapidjson/error/en.h"
# include "../thirdparty/rapidjson/istreamwrapper.h"
# include <eigen3/Eigen/Dense>

static constexpr size_t READ_BUFFER_SIZE = 65535;

class BPNN : public BaseModel
{
private:
    size_t depth_ = 0; // depth without the input layer
    size_t input_layer_size_ = 0;
    std::vector<Eigen::MatrixXd> weight_;
    std::vector<Eigen::VectorXd> bias_;
    std::vector<double(*)(double)> activation_;

public:
    BPNN():BaseModel(){};
    ~BPNN() override = default;
    bool init(const rapidjson::Document & d) override
    {
        // Load x_std
        if (UNLIKELY(!d.HasMember("x_std")))
        {
            std::cout << "json file doesn't have x_std" << std::endl;
            return false;
        }
        std::vector<double> x_std;
        auto x_std_j = d["x_std"].GetArray()[0].GetArray();
        for(unsigned int i = 0; i < x_std_j.Size(); ++i){
            x_std.push_back(x_std_j[i].GetDouble());
        }
        size_t x_size = x_std.size();
        // Load net weights
        if (UNLIKELY(!d.HasMember("weights")))
        {
            std::cout << "json file doesn't have weights" << std::endl;
            return false;
        }
        std::vector<size_t> layer_size;
        auto net_weights = d["weights"].GetObject();
        // activation function
        auto activation_array = net_weights["activation"].GetArray();
        depth_ = activation_array.Size();
        assert(depth_ != 0);
        for (const auto& obj : activation_array)
        {
            const char* func_name = obj.GetString();
            if (strcmp(func_name, "relu") == 0)
            {
                activation_.push_back(Relu);
            }
            else if (strcmp(func_name, "linear") == 0)
            {
                activation_.push_back(Linear);
            }
            else if (strcmp(func_name, "tanh") == 0)
            {
                activation_.push_back(Tanh);
            }
            else if (strcmp(func_name, "sigmoid") == 0)
            {
                activation_.push_back(Sigmoid);
            }
            else
            {
                std::cout << "activation function not supported: " << func_name << std::endl;
                return false;
            }
        }

        // bias vectors
        if (UNLIKELY(!net_weights.HasMember("bias")))
        {
            std::cout << "net_weights doesn't have bias matrix" << std::endl;
            return false;
        }
        auto bias_array = net_weights["bias"].GetArray();
        if (bias_array.Size() != depth_)
        {
            std::cout << "incorrect depth for bias, got " << bias_array.Size()
                      << " but should be " << depth_ << std::endl;
            return false;
        }
        for (const auto& obj : bias_array)
        {
            auto vector = obj.GetArray();
            size_t c_size = vector.Size();
            layer_size.push_back(c_size);
            Eigen::VectorXd b_v(c_size);
            size_t c_idx = 0;
            for (const auto& ele : vector)
            {
                b_v(c_idx) = ele.GetDouble();
                c_idx++;
            }
            bias_.push_back(b_v);
        }

        // weight matrix
        if (UNLIKELY(!net_weights.HasMember("weight")))
        {
            std::cout << "net_weights doesn't have weight matrix" << std::endl;
            return false;
        }
        auto weight_array = net_weights["weight"].GetArray();
        if (weight_array.Size() != depth_)
        {
            std::cout << "incorrect depth for weight, got " << weight_array.Size()
                      << " but should be " << depth_ << std::endl;
            return false;
        }
        size_t layer = 0;
        for (const auto & obj : weight_array)
        {
            auto matrix = obj.GetArray();
            size_t r_size = matrix.Size();
            if (input_layer_size_ == 0) // input layer size should be the row size of first weight matrix
            {
                input_layer_size_ = r_size;
                if (r_size != x_size)
                {
                    std::cout << "first layer row size is  " << r_size << ", but x_std size is " << x_size << "\n";
                    return false;
                }
            }
            size_t c_size = matrix[0].Size();
            if (layer_size[layer] != c_size)
            {
                std::cout << "incorrect layer size for layer " << layer << ", got " << c_size
                          << " but should be " << layer_size[layer] << std::endl;
                return false;
            }

            Eigen::MatrixXd w_m(r_size, c_size);
            size_t r_idx = 0;
            for (const auto& row : matrix)
            {
                size_t c_idx = 0;
                for (const auto& ele : row.GetArray())
                {
                    w_m(r_idx, c_idx) = ele.GetDouble();
                    if(layer == 0)
                    {
                        if (x_std[r_idx] == 0.0)
                        {
                            std::cout << "The " << r_idx << " element of x_std is 0.\n";
                            return false;
                        }
                        w_m(r_idx, c_idx) /= x_std[r_idx];
                    }
                    c_idx++;
                }
                r_idx++;
            }
            weight_.push_back(w_m);
            layer++;
        }
        return true;
    }

    void calculate(const std::vector<double>& input, std::vector<double> & output) override
    {
        assert(output.empty());
        assert(input.size() == input_layer_size_);

        Eigen::VectorXd i_v(input_layer_size_);
        for (size_t i = 0; i != input_layer_size_; ++i)
        {
            i_v(i) = input[i];
        }

        Eigen::VectorXd o_v;
        for (size_t l = 0; l != depth_; ++l)
        {
            calculateForLayer(i_v, l, o_v);
            i_v = o_v;
        }

        for (int i = 0; i != o_v.size(); ++i)
        {
            output.push_back(o_v(i));
        }
    }

private:
    ALWAYS_INLINE void calculateForLayer(const Eigen::VectorXd& i_v, size_t layer, Eigen::VectorXd& o_v)
    {
        o_v = weight_[layer].transpose() * i_v + bias_[layer];
        for (int i = 0; i != o_v.size(); ++i)
        {
            o_v(i) = activation_[layer](o_v(i));
        }
    }

    // relu function: x <= 0 : y = 0; x > 0 : y = x;
    static double Relu(double x)
    {
        return x <= 0 ? 0 : x;
    }

    // linear function: y = x;
    static double Linear(double x)
    {
        return x;
    }

    // tanh function;
    static double Tanh(double x)
    {
        return std::tanh(x);
    }

    // sigmoid function;
    static double Sigmoid(double x)
    {
        return 1.0 / (1 + std::exp(-x));
    }
};
