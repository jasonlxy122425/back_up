#include "Factor.h"
#include "Ema.h"
#include "GaiaCircularBuffer.h"
#include <cmath>

class BookStrengthImbaFactor : public FactorInterface
{
public:
    BookStrengthImbaFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
        max_depth = config.Get<int64_t>("max_depth");
        lookback = config.Get<int64_t>("lookback");
        imba_buffer.setSize(lookback, 0.0);
    };

    virtual std::string gen_name() {
        return std::string("BookStrengthImbaFactor") + '@' + std::to_string(max_depth) + '@' + std::to_string(lookback);
    }

    virtual void calculate(const FactorInput& input_data) {
        factor_value = 0.0;
        auto &ob = input_data.cur_contract->alphaBook;
        int64_t num_bids = ob->num_bids();
        int64_t num_asks = ob->num_asks();
        double tmp_bid = 0.0;
        double tmp_ask = 0.0;
        for (int i = 0; i < max_depth; i++){
            if (i < num_bids){
                tmp_bid += ob->bid(i).qty;
            }
            if (i < num_asks){
                tmp_ask += ob->ask(i).qty;
            }           

        }
        imba_buffer.push(tmp_bid - tmp_ask);
        if(imba_buffer.isFull() != false){
            double imba_std = imba_buffer.std();
            if (imba_std > MinErr){
                factor_value = imba_buffer.mean()/imba_std;
            }

        }
    };


private:
    int64_t max_depth;
    int64_t lookback;
    GaiaCircularBuffer<double> imba_buffer;
};
                              
