#include "Factor.h"
#include "Ema.h"
#include <cmath>
#include "GaiaCircularBuffer.h"
#include "GaiaUtils.h"

class TradeAggCountBiasOnTimerFactor : public FactorInterface
{
public:
    TradeAggCountBiasOnTimerFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
        timer_interval_ms = config.Get<int64_t>("timer_interval_ms");
        RegisterTimer(timer_interval_ms*1e6L);
    };

    virtual std::string gen_name() {;
        return std::string("TradeAggCountBiasOnTimerFactor") + "@timer_interval_ms=" + std::to_string(timer_interval_ms);
    }

    virtual void calculate(const FactorInput& input_data) {
        auto agg_trade = input_data.preprocess_result->GetAggTrade(input_data.cur_contract->symbol_info->sid);
        if (!agg_trade.has_value()){
            return;
        } 
        else {
            auto &trade = agg_trade.value();
            if (trade.side == Side::BUY){
                total_buy_qty += trade.count;
            }
            else if (trade.side == Side::SELL){
                total_sell_qty += trade.count;
            }
        }
    };
    void OnTimer() override {
        if (total_buy_qty > eps || total_sell_qty > eps){
            factor_value = (total_buy_qty - total_sell_qty)/(total_buy_qty + total_sell_qty);
        }
        else {
            factor_value = 0.0;
            
        }
        total_buy_qty = 0.0;
        total_sell_qty = 0.0;
    }

private:
    int64_t timer_interval_ms;
    bool is_on_timer = false;
    double total_buy_qty = 0.0;
    double total_sell_qty = 0.0;
};
                              
