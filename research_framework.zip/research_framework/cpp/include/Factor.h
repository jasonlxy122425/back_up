#pragma once
#include "ContractInfo.h"
#include "utils/DemeterData.h"
#include "DataPreprocessResult.h"
#include "FactorTimer.h"
#include <cmath>
#include <iostream>
#include <fstream>

struct FactorInput
{
    ContractInfo *cur_contract;
    PreprocessResult *preprocess_result;

    double price;
    double qty;
    int64_t current_time;
    double micro_price;
};

class FactorInterface
{
public:
    void Init(Config &config, FactorTimer* factor_timer, SidContractInfoMapType *sid_contract_info_map) {
        std::string symbol = config.Get<std::string>("symbol");
        factor_timer_ = factor_timer;
        sid_contract_info_map_ = sid_contract_info_map;
        this->Init(config);
    }
    virtual void Init(Config &config) {};
    virtual std::string gen_name() = 0;

    void Calculate(const FactorInput& _input_data) {
        this->calculate(_input_data);
        *factor_output = factor_value;
    };
    virtual void calculate(const FactorInput& input_data) {};

    void OnTimerBase() {
        this->OnTimer();
        *factor_output = factor_value;
    };
    virtual void OnTimer() {};

    std::string get_name() {
        if (factor_name == "") {
            factor_name = this->gen_name() + '@' + symbol;
        }
        return factor_name;
    };

    void set_symbol(const std::string &_symbol) { symbol = _symbol; };
    double get_value(){ return factor_value; };
    double get_prev_value() { return prev_factor_value; };

    void SetFactorOutput(double *output) {
        factor_output = output;
    };

protected:
    int64_t last_time = 0;
    double factor_value = 0;
    double prev_factor_value = 0;

    FactorTimer* factor_timer_;

    SidContractInfoMapType *sid_contract_info_map_;
    // factor output ptr, memory is managed by Predictor
    double *factor_output;

    std::string symbol;
    std::string factor_name = "";
    void RegisterTimer(Nanoseconds interval) {
        auto func = [this]() {
            this->OnTimerBase();
        };
        factor_timer_->Add(0, interval, std::move(func));
    }

    ContractInfo* GetContractInfo(const std::string &symbol) {
        return (*sid_contract_info_map_)[SecMaster::instance().FindSid(symbol)];
    }

    ContractInfo* GetContractInfo(const SymId &sid) {
        return (*sid_contract_info_map_)[sid];
    }
};
