#pragma once

#include "parallel_hashmap/phmap.h"
#include "TickSampler.h"
#include "FixedIntervalSampler.h"
#include "DemeterType.h"

namespace demeter {


class SamplerLayer {
public:
    void Init(SymId sid, std::string sampler_type, int sample_num) {
        if(samplers_.find(sid) != samplers_.end()) return;

        std::cout << "DemeterDataManager init sid: " << sid << ", sampler_type: " << sampler_type << std::endl;
        samplers_[sid] = createSampler(sampler_type, sample_num);
        if(sampler_type == "fixed_interval") {
            sample_interval_ms = sample_num;
            fixed_sample_sids_[sid] = sample_interval_ms;
            next_sample_ts = 0;
            need_sample_[sid] = false;
        } else {
            need_sample_[sid] = true;
        }
        
    }

    void Update(const GaiaOrderbook &order_book, ContractInfo *contract) {
        auto sid = contract->symbol_info->sid;

        if(need_sample_[sid]) {
            // std::cout << "sample point" << std::endl;
            for(auto fs_sid : fixed_sample_sids_) {
                samplers_[fs_sid.first]->Sample();
            }
        }

        samplers_[sid]->Update(order_book, contract);

        /*
        std::cout << "sid: " << sid << "," << contract->update_tick_type << ","
                  << "bid: " << order_book.bid(0).price << "," << order_book.bid(0).qty << ","
                  << "ask: " << order_book.ask(0).price << "," << order_book.ask(0).qty << ","
                  << "trade_price: " << contract->trade.price << ", qty: " << contract->trade.qty << std::endl;
        

        for(size_t i = 1; i < NumSides; ++i) {
            for(size_t j = 0; j < NumBookOrderTypes; ++j) {
                auto gob_values = samplers_[sid]->GetDemeterData()->GetGobUpdate().get(i,j);
                std::cout << i << "-" << j << ":[";
                for(size_t i = 0; i < gob_values.size(); ++i) {
                    if(i > 0) std::cout << ",";
                    std::cout << gob_values[i];
                }
                std::cout << "]" << std::endl;
            }
        }
        for(size_t i = 1; i < NumSides; ++i) {
            for(size_t j = 0; j < NumBookOrderTypes; ++j) {
                std::cout << i << "-" << j << ":";
                std::cout << samplers_[sid]->GetDemeterData()->gob_update_sum_.get(i,j) << std::endl;
            }
        }
        */
    }

    void Sample(Nanoseconds now) {
        bool _sample = false;

        if(next_sample_ts == 0) next_sample_ts = now + sample_interval_ms * 1000000L;
        if(now >= next_sample_ts) {
            next_sample_ts += sample_interval_ms * 1000000L;
            _sample = true;
        }

        for(auto f_sid : fixed_sample_sids_) {
            need_sample_[f_sid.first] = _sample;
        }
    }
    

    bool isTickSample(SymId sid) { return fixed_sample_sids_.find(sid) == fixed_sample_sids_.end(); }
    bool needSample(SymId sid) { 
        return need_sample_[sid];
    }

    std::shared_ptr<DemeterData> GetDemeterData(SymId sid) {return samplers_[sid]->GetDemeterData();}

private:

    std::shared_ptr<SamplerBase> createSampler(std::string sampler_type, int sample_num) {
        if(sampler_type == "tick") return std::shared_ptr<SamplerBase>(std::make_shared<TickSampler>(sample_num));
        else if(sampler_type == "fixed_interval") return std::shared_ptr<SamplerBase>(std::make_shared<FixedIntervalSampler>());
        else std::cout << "cannot find sampler for type: " << sampler_type << std::endl;

        abort();
    }

    phmap::flat_hash_map<SymId, std::shared_ptr<SamplerBase>> samplers_;

    phmap::flat_hash_map<SymId, bool> need_sample_;
    Nanoseconds next_sample_ts = 0;
    Nanoseconds sample_interval_ms = 0;
    std::unordered_map<SymId, int64_t> fixed_sample_sids_;
};

}; // namespace demeter
