#include "Factor.h"
#include "Ema.h"
#include <cmath>

class BookQueueImbaFactor : public FactorInterface
{
public:
    BookQueueImbaFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
        max_depth = config.Get<int64_t>("max_depth");
    };

    virtual std::string gen_name() {;
        return std::string("BookQueueImbaFactor") + "@max_depth=" + std::to_string(max_depth);
    }

    virtual void calculate(const FactorInput& input_data) {
        auto &gob = input_data.cur_contract->alphaBook;
        int64_t num_bids = gob->num_asks();
        int64_t num_asks = gob->num_bids();
        double bid_total = 0.0;
        double ask_total = 0.0;
        for (int i = 0; i < num_bids; i++){
            if (i >= max_depth){
                break;
            }
            bid_total += gob->bid(i).qty;
        }
        for (int i = 0; i < num_asks; i++){
            if (i >= max_depth){
                break;
            }
            ask_total += gob->ask(i).qty;
        }
        double ratio_bid = gob->bid(0).qty/bid_total;
        double ratio_ask = gob->ask(0).qty/ask_total;
        factor_value = ratio_bid - ratio_ask;
    };


private:
    int64_t max_depth;
};
                              
