#pragma once
#include "Factor.h"
#include "FactorTimer.h"
#include "ContractInfo.h"

// raw new
using FactorCreator = std::function<FactorInterface*()>;
// placement new
using FactorCreatorAt = std::function<FactorInterface*(void*)>;

struct FactorInfo {
    std::string name;
    FactorCreator creator;
    FactorCreatorAt creator_at;
    size_t factor_size;
};

class FactorFactory {
public:
    FactorFactory() {}
    ~FactorFactory() {}

    void Register();

    template<typename FactorType>
    void RegisterFactor(const std::string& factor_name) {
        auto factor_creator = []() -> FactorInterface* {
            return new FactorType();
        };

        auto factor_creator_at = [](void *mem) -> FactorInterface* {
            return new(mem) FactorType();
        };

        FactorInfo info;
        info.name = factor_name;
        info.creator = factor_creator;
        info.creator_at = factor_creator_at;
        info.factor_size = sizeof(FactorType);
        factor_infos_[factor_name] = info;
    }

    FactorInfo& GetFactorInfo(const std::string& factor_name) {
        auto it = factor_infos_.find(factor_name);
        if (it != factor_infos_.end()) {
            return it->second;
        }
        std::cerr << "Factor not found: " << factor_name << std::endl;
        abort();
    }

private:
    std::unordered_map<std::string, FactorInfo> factor_infos_;
};