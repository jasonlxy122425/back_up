import pickle
from Default.KronosConfig import *
from Default.DefaultCommonConfig import *

@config_interface
class TagConfig():
    def __init__(self):
        self.configs = []

    def genFactors(self, factor_path):
        with open(factor_path , 'rb') as file:
            factors = pickle.load(file)
        return factors

    def generateParams(self, sim_params, stra_params):
        config = KronosConfig("output_factors")
        config.num_of_book_levels = 25
        config.predictor = "Kronos"

        config.commonConfig.set_values(use_orderbook=True,
                                         use_bestquote=True,
                                         use_trade=True,
                                         use_liquidation=True,
                                         use_fundingrate=True)
        # predictor log
        config.predictorConfig.demeter_sample_num = stra_params["demeter_sample_size"]
        config.predictorConfig.factor_path  = stra_params["factor_path"]
        config.predictorConfig.model_path = stra_params["model_path"]
        config.predictorConfig.demeter_sample_type = stra_params["demeter_sample_type"]
        if stra_params["to_generate_factors"]:
            config.predictorConfig.factors = self.genFactors(config.predictorConfig.factor_path)
            config.predictorConfig.factors = config.predictorConfig.factors[90:110].copy()
        else:
            config.predictorConfig.factors = []

        # orderlogic log
        for key, value in stra_params.items():
            print(key, value)
            setattr(config.orderLogicConfig, key, value)
        sim_output_engine = "parquet"
        if stra_params["to_output_gob"] is None:
            sim_output_engine = None
        # sim 
        config.set_sim(mode = 'SIM',
                    start_date = sim_params["start_date"],
                    end_date = sim_params["end_date"],
                    sign_str = sim_params["sign_str"],
                    target_server =  sim_params["target_server"],
                    #target_path = "/home/master/Data/md_dump/",
                    sim_engine = 'alphaless',
                    sim_output_engine = sim_output_engine,
                    sim_output_target = './gaia_orderbook.parquet',
                    sim_output_factors = stra_params["to_output_factors"],
                    sim_output_sample_count = stra_params["output_sample_size"],

                    )

        config.setSymbol(sim_params["target_instrument"])
        return config 

    def getConfig(self):
        sim_params = {
            "start_date": '20250508',
            "end_date": '20250508',
            "target_exchange": f"Binance",
            "target_instrument": f"Binance_LinearSwap_BTCUSDT",
            #"target_server": "tky-kronos-prod-md-az4-01",
            "target_server": "tky-az4-kronos-prod-tradeserver-06",
        }
        stra_params = {
            "to_generate_factors": False,
            "to_output_factors": False,
            "to_output_gob": True,
            "demeter_sample_type": "tick",
            "demeter_sample_size": 0,
            "output_sample_size": 0,
            "factor_path":"",
            "model_path":"",
            "custom_order_logic": "LeadLag",
            "stop_loss": -50,
            "mkt_timeout_ns": 3000000000,
            "quote_qty": 0.001,
            "theo_alpha": 0.0,
            "theo_gamma": 1.0,
            "init_var":0.0,
            "var_ewma":0.95,
            "theo_buffer_len": 20000,
            "sigma_alpha": 0.0,
            "sigma_beta": 0.0,
            "sigma_base": 1.0,
            "pos_pen_intercept": 1.0,
            "pos_pen_coef": 0.0,
            "pos_pen_lowerbound": 1.0,
            "quote_range":10,
            "queue_front_cancel":100000,
            "min_edge_cancel": -100,
            "min_edge_entry_take": 10000,
            "min_edge_entry_make": 10000,
            "min_edge_exit": 0,
            "pred_floor": -100,
            "take_price_bps":1,
            "improve_tick_num": 30,
            "improve_spread_ratio": 0,
            "make_only_close": True,
            "ob_time_diff_edge": -100,
            "custom_min_notional": 8
        }
        for instrument_name in [f"Binance_LinearSwap_BTCUSDT",]:
            sim_params["target_instrument"] = instrument_name
            sim_params["sign_str"] = "gaia_orderbook_{}_{}".format(stra_params["demeter_sample_size"], stra_params["output_sample_size"])
            config = self.generateParams(sim_params, stra_params)
            self.configs.append(config)
        return self.configs
