import datetime
from sim_utils import *

class DataSource:
    def __init__(self):
        self.saved_data_file = {}
        
    def getDataFiles(self, key, config):

        data_files = set()
        if hasattr(config, "reference_symbols") == False:
            print("have no reference_symbols ")

        reference_symbols = config.reference_symbols
        if hasattr(config, "assist_reference_symbols"):
            md_symbols = list(set(reference_symbols + config.assist_reference_symbols))
        else:
            md_symbols = reference_symbols


        start = datetime.date(int(config.start_date[0:4]), int(config.start_date[4:6]), int(config.start_date[-2:]))
        end = datetime.date(int(config.end_date[0:4]), int(config.end_date[4:6]), int(config.end_date[-2:]))

        data_key = f"{config.start_date}-{config.end_date}-{'/'.join(md_symbols)}-{config.target_server}"
        if self.saved_data_file.__contains__(data_key):
            return self.saved_data_file[data_key]
        print(f"find data file for symbols: {data_key}")

        target_exch = config.quoter_symbol.split("_")[0]
        st = start
        d_delta = datetime.timedelta(days=1)
        while st <= end:
            date = st.strftime('%Y%m%d')
            # print(date)
            for mirana_ticker in md_symbols:
                # print(mirana_ticker)
                exch = mirana_ticker.split("_")[0]
                type = mirana_ticker.split("_")[1]
                symbol = "_".join(mirana_ticker.split("_")[2:])
                md_dump_file, md_dump_file_dmm = findMdDumpFiles(date, target_exch, exch, type, symbol, config.simConfig.sim_engine, config.target_server, config.target_path)
                if md_dump_file is None:
                    print(f"error: cannot find data file for {mirana_ticker} {date}")
                    exit(0)
                else:
                    # print(md_dump_file)
                    data_files.add(md_dump_file)
                    if md_dump_file_dmm is not None:
                        data_files.add(md_dump_file_dmm)

            st += d_delta

        print(f"using below data files for {data_key}")
        print(list(data_files))
        self.saved_data_file[data_key] = list(data_files)
        return list(data_files)
