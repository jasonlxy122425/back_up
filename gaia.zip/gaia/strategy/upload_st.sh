server=$1

ssh master@${server} "mkdir -p /home/master/strategy/libs"
scp build/gaia_bin master@${server}:/home/master/strategy/bin/
scp ../libs/* master@${server}:/home/master/strategy/libs/
