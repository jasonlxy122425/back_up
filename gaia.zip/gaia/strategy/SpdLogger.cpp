#include "SpdLogger.h"
#include <random>
#include <sstream>
#include <cstring>
#include "SpdLoggerMessage.h"
#include "GaiaUtils.h"

bool Logger::only_log_exec = false;

std::shared_ptr<spdlog::logger> Logger::logger_;
std::unique_ptr<Logger::SpdLoggerQueue> Logger::log_queue_ = nullptr;
std::atomic<bool> Logger::log_running_ = false;
std::atomic<bool> Logger::change_file_;

std::string Logger::tag = "unknown";
std::string Logger::sub_tag = "unknown";
std::string Logger::log_name = "log.txt";

void Logger::Init(std::string _log_name) {
    log_name = _log_name;
    Logger::Init();
}

void Logger::setTag(std::string _tag, std::string _sub_tag) {
    tag = _tag;
    sub_tag = _sub_tag;
}

void Logger::saveState(SpdLoggerMessageBase *_msg) {
    _msg->update_ts = GaiaUtils::GetSysTimestamp();
}

void Logger::Init() {
    change_file_ = true;

    std::cout << log_name << std::endl;
    auto daily_sink = std::make_shared<spdlog::sinks::daily_file_sink_mt>(log_name, 0, 0);
    logger_ = std::make_shared<spdlog::logger>("logger", std::move(daily_sink));
    logger_->set_pattern("%v");
    logger_->flush_on(spdlog::level::trace);

    log_queue_ = std::make_unique<Logger::SpdLoggerQueue>();

    while(log_running_) ;
    log_running_ = true;
    change_file_ = false;
    // std::thread log_thread(LogThread);
    // log_thread.detach();
    std::thread optimized_log_thread(OptimizedLogThread);
    optimized_log_thread.detach();
}

std::shared_ptr<spdlog::logger> Logger::GetLogger() {
    return logger_;
}

void Logger::LogThread() {
    // std::string log_str;
    // bool pop_ret;

    // SpdLoggerMessage *msg_ptr;
    // while(!change_file_) {
    //     pop_ret = log_queue_->tryPop([&](auto *header) {
    //         msg_ptr = *reinterpret_cast<SpdLoggerMessage**>(header + 1);
    //         strcpy(msg_ptr->tag, tag.c_str());
    //         strcpy(msg_ptr->sub_tag, sub_tag.c_str());
    //         int64_t log_ts = GaiaUtils::GetSysTimestamp();
    //         msg_ptr->log_ts = log_ts;
    //         msg_ptr->log_ts_str = GaiaUtils::NanoTimestampToString(log_ts);

    //         std::string msg_str = msg_ptr->toString();
    //         if(only_log_exec && msg_ptr->ret["msg_type"] != "Exec") {
    //             return;
    //         }
    //         logger_->info(msg_str);

    //     });
    //     if(pop_ret) delete msg_ptr;
    //     if(!pop_ret) usleep(100);
    // }
    // log_running_ = false;
}

void Logger::OptimizedLogThread() {
    std::string log_str;
    bool pop_ret;

    SpdLoggerMessageBase *msg_ptr;
    while(!change_file_) {
        pop_ret = log_queue_->tryPop([&](auto *header) {
            msg_ptr = *reinterpret_cast<SpdLoggerMessageBase**>(header + 1);
            strcpy(msg_ptr->tag, tag.c_str());
            strcpy(msg_ptr->sub_tag, sub_tag.c_str());
            int64_t log_ts = GaiaUtils::GetSysTimestamp();
            msg_ptr->log_ts = log_ts;
            msg_ptr->log_ts_str = GaiaUtils::NanoTimestampToString(log_ts);

            std::string msg_str = msg_ptr->toString();
            if(only_log_exec && msg_ptr->ret["msg_type"] != "Exec") {
                return;
            }
            logger_->info(msg_str);
        }
        );

        if(pop_ret) {
            auto* recyclable_msg = dynamic_cast<SpdLoggerMessageBase*>(msg_ptr);
            if(recyclable_msg) {
                recyclable_msg->recycle();
            } else {
                delete msg_ptr;
            }
        }
        if(!pop_ret) usleep(100);
    }
    log_running_ = false;
}
