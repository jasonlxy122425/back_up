#include "Factor.h"
#include "Ema.h"
#include <cmath>

class BookTradeBiasFactor : public FactorInterface
{
public:
    BookTradeBiasFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
        ewma_int = config.Get<int64_t>("ewma_int");
        ewma_decay = ewma_int/100.0;
    };

    virtual std::string gen_name() {;
        return std::string("BookTradeBiasFactor") + "@ewma_int=" + std::to_string(ewma_int);
    }

    virtual void calculate(const FactorInput& input_data) {
        bool is_orderbook = input_data.cur_contract->update_tick_type == TickEventType::TICK_OB;
        bool is_trade = input_data.cur_contract->update_tick_type == TickEventType::TICK_TRADE;
        if (is_trade) {
            auto &trade = input_data.cur_contract->trade;
            if (trade.side == Side::BUY) {
                buy_qty += trade.qty;
            } 
            else if (trade.side == Side::SELL) {
                sell_qty += trade.qty;
            }
        }
        if (is_orderbook) {
            double tmp_value = buy_qty - sell_qty;
            factor_value = ewma_decay*factor_value + (1.0 - ewma_decay)*tmp_value;
            buy_qty = 0.0;
            sell_qty = 0.0;
        }
    };


private:
    int64_t ewma_int;
    double ewma_decay = 0.0;
    double buy_qty = 0.0;
    double sell_qty = 0.0;
};
                              
