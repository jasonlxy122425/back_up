# gaia_config
## config test
cd gaia_config/configs
./genConfig -t KronosSim -s ../../gaia/simulation/SimConfigs/ -c ./