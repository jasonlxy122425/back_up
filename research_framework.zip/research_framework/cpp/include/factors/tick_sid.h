#include "Factor.h"
#include "Ema.h"


class TickSidFactor : public FactorInterface
{
public:
    TickSidFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
    };

    virtual std::string gen_name() {
        return std::string("TickSidFactor");
    }

    virtual void calculate(const FactorInput& input_data) {
        factor_value = input_data.cur_contract->symbol_info->sid;
    };
};
                              