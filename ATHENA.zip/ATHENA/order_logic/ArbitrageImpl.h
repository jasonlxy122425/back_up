#pragma once
#include <cstdlib>
#include "OrderLogic.h"
#include "GaiaUtils.h"
#include "SpdLogger.h"
#include "FactorMsg.h"
#include "Predictor.h"
#include "SystemDefine.h"
#include "ArbitrageHedger.h"

struct ArbConfig {
    // edge
    double min_edge_bp;
    double edge_range_bp;
    double bottom_edge_bp;
    double range_deep_bp;
    // double vol_edge_weight;
    // double vol_edge_range_weight;
    // double vol_max_entry_weight;
    // double vol_max_exit_weight;
    double vol_max_cap;
    double vol_min_cap;

    double range_place_percentile;

    int32_t max_level_on_side;

    double max_edge_entry_bp;
    double max_edge_exit_bp;

    bool use_replace;

    double max_tolerance_size_ratio;
    bool use_log_factor;

    // filter
    double theo_edge_lower_filter;
    double theo_edge_upper_filter;
    double spread_filter;

    // risk

    double custom_max_notional = 1e8L;
    double custom_min_notional = 0;

    int32_t warm_up_ticks = 5000;

    bool funding_rate_mode = false;
    bool buy_only = false;
    bool sell_only = false;

    bool futures_spot_arb_mode = false;

};

class ArbitrageImpl : public OrderLogic {
public:
    struct OrderLevel
    {
        double upper;
        double lower;
        double price;
        GOrderState *orderState = nullptr;
    };

    std::vector<OrderLevel> bid_order_levels;
    std::vector<OrderLevel> ask_order_levels;

    SymId hedger_sid;
    std::unordered_map<SymId, int32_t> warmup_ticks_map;
    bool warmup_done = false;
    FactorOutputType output;

    bool first_data_after_init = false;

    ArbConfig config;
    int64_t last_risk_print_ts = 0;
    ArbitrageHedger* hedger = nullptr;

    ArbitrageImpl(){
        hedger = new ArbitrageHedger();
    }

    Hedger* getHedger() override {
        return hedger;
    }

    void Init(const Config& _conf)
    {
        version = "arb_1.1.1";

        std::cout << "init Arbitrage config" << std::endl;
        auto conf = _conf.Get<Config>("order_logic_config");
        // read config

        config.custom_max_notional = GaiaUtils::GetParam<double>(conf, "custom_max_notional");
        config.custom_min_notional = GaiaUtils::GetParam<double>(conf, "custom_min_notional");

        config.min_edge_bp = GaiaUtils::GetParam<double>(conf, "min_edge_bp");
        config.edge_range_bp = GaiaUtils::GetParam<double>(conf, "edge_range_bp");
        config.bottom_edge_bp = GaiaUtils::GetParam<double>(conf, "bottom_edge_bp");
        config.range_deep_bp = GaiaUtils::GetParam<double>(conf, "range_deep_bp");
        // config.vol_edge_weight = GaiaUtils::GetParam<double>(conf, "vol_edge_weight");
        // config.vol_edge_range_weight = GaiaUtils::GetParam<double>(conf, "vol_edge_range_weight");
        // config.vol_max_entry_weight = GaiaUtils::GetParam<double>(conf, "vol_max_entry_weight");
        // config.vol_max_exit_weight = GaiaUtils::GetParam<double>(conf, "vol_max_exit_weight");
        config.vol_max_cap = GaiaUtils::GetParam<double>(conf, "vol_max_cap");
        config.vol_min_cap = GaiaUtils::GetParam<double>(conf, "vol_min_cap");

        config.range_place_percentile = GaiaUtils::GetParam<double>(conf, "range_place_percentile");

        config.max_level_on_side = GaiaUtils::GetParam<int32_t>(conf, "max_level_on_side");
        config.max_level_on_side = std::max(config.max_level_on_side, 1);

        config.max_edge_entry_bp = GaiaUtils::GetParam<double>(conf, "max_edge_entry_bp");
        config.max_edge_exit_bp = GaiaUtils::GetParam<double>(conf, "max_edge_exit_bp");

        config.use_replace = GaiaUtils::GetParam<bool>(conf, "use_replace");
        config.max_tolerance_size_ratio = GaiaUtils::GetParam<double>(conf, "max_tolerance_size_ratio");
        config.use_log_factor =  GaiaUtils::GetParam<int64_t>(conf, "use_log_factor");

        config.theo_edge_lower_filter = GaiaUtils::GetParam<double>(conf, "theo_edge_lower_filter");
        config.theo_edge_upper_filter = GaiaUtils::GetParam<double>(conf, "theo_edge_upper_filter");
        config.spread_filter = GaiaUtils::GetParam<double>(conf, "spread_filter");

        config.warm_up_ticks = GaiaUtils::GetParam<int32_t>(conf, "warm_up_ticks");

        try {
            config.funding_rate_mode = GaiaUtils::GetParam<bool>(conf, "funding_rate_mode");
            config.buy_only = GaiaUtils::GetParam<bool>(conf, "buy_only");
            config.sell_only = GaiaUtils::GetParam<bool>(conf, "sell_only");
        } catch(...) {
            config.funding_rate_mode = false;
        }

        try {
            config.futures_spot_arb_mode = GaiaUtils::GetParam<bool>(conf, "futures_spot_arb_mode");
            std::string hedger_symbol = GaiaUtils::GetParam<std::string>(conf, "hedger_symbol");
            hedger_sid = SecMaster::instance().FindSid(hedger_symbol);
        } catch(...) {
            config.futures_spot_arb_mode = false;
        }

        // init
        if(bid_order_levels.size() < config.max_level_on_side);
            bid_order_levels.resize(config.max_level_on_side);

        if(ask_order_levels.size() < config.max_level_on_side);
            ask_order_levels.resize(config.max_level_on_side);
        
        first_data_after_init = true;
    };

    G_INLINE void RiskCheck(StrategyFields &strategy_fields)
    {
        auto &risk_check_result = strategy_fields.risk_check_result;
        bool allow_process_bid = true;
        bool allow_process_ask = true;

        if(first_data_after_init)
        {
            allow_process_bid = false;
            allow_process_ask = false;
            first_data_after_init = false;
        }

        ContractInfo* mainContract = strategy_fields.contract_info;
        // main sid fields
        if(strategy_fields.current_mode == StrategyMode::ReduceOnlyMode)
        {
            double mid_p = GaiaUtils::BookGetBestBidPrice(mainContract) + GaiaUtils::BookGetBestAskPrice(mainContract) / 2;
            if(mainContract->is_reverse) {
                if (strategy_fields.sym_risk.symbol_risk * mid_p  >= -mainContract->symbol_info->min_qty * mainContract->symbol_info->multiplier ||
                    strategy_fields.sym_risk.symbol_risk * mid_p  >= -config.custom_min_notional)
                {
                    // std::cout << "Risk Check: symbol_risk >= -min_qty," << strategy_fields.sym_risk.symbol_risk << "," << mainContract->symbol_info->min_qty << std::endl;
                    allow_process_bid = false;
                }

                if (strategy_fields.sym_risk.symbol_risk * mid_p  <= mainContract->symbol_info->min_qty * mainContract->symbol_info->multiplier ||
                    strategy_fields.sym_risk.symbol_risk * mid_p  <= config.custom_min_notional)
                {
                    // std::cout << "Risk Check: symbol_risk <= min_qty," << strategy_fields.sym_risk.symbol_risk << "," << mainContract->symbol_info->min_qty << std::endl;
                    allow_process_ask = false;
                }

            } else {

                if( strategy_fields.sym_risk.symbol_risk >= -mainContract->symbol_info->min_qty * mainContract->symbol_info->multiplier ||
                    strategy_fields.sym_risk.symbol_risk >= -config.custom_min_notional / mid_p )
                {
                    // std::cout << "Risk Check: symbol_risk >= -min_qty," << strategy_fields.sym_risk.symbol_risk << "," << mainContract->symbol_info->min_qty << std::endl;
                    allow_process_bid = false;
                }
                
                if(strategy_fields.sym_risk.symbol_risk <= mainContract->symbol_info->min_qty * mainContract->symbol_info->multiplier ||
                    strategy_fields.sym_risk.symbol_risk <= config.custom_min_notional / mid_p)
                {
                    // std::cout << "Risk Check: symbol_risk <= min_qty," << strategy_fields.sym_risk.symbol_risk << "," << mainContract->symbol_info->min_qty << std::endl;
                    allow_process_ask = false;
                }
            }

            if(!common_config.use_fr_check && !allow_process_bid && !allow_process_ask) strategy_fields.setStrategyMode(StrategyMode::NormalExitMode, "Reduce Only Done");
            if(common_config.use_reduce_only_mode && !allow_process_bid && !allow_process_ask) strategy_fields.setStrategyMode(StrategyMode::NormalExitMode, "Reduce Only Done");
        }

        if(strategy_fields.current_mode == StrategyMode::RateLimitMode)
        {
            allow_process_bid = false;
            allow_process_ask = false;
        }

        if(strategy_fields.current_mode == StrategyMode::BalanceLimitMode)
        {
            allow_process_bid = false;
            allow_process_ask = false;
        }

        if(strategy_fields.signal.bid_pred_value < eps)
        {
            std::cout << "Risk Check: bid pred value < eps" << std::endl;
            allow_process_bid = false;
        }

        if(strategy_fields.signal.ask_pred_value < eps)
        {
            std::cout << "Risk Check: ask pred value < eps" << std::endl;
            allow_process_ask = false;
        }

        // theo edge filter
        if (strategy_fields.signal.theo_edge_upper > config.theo_edge_upper_filter) {
            allow_process_bid = false;
        }
        if (strategy_fields.signal.theo_edge_upper < -config.theo_edge_upper_filter) {
            allow_process_ask = false;
        }
        if (strategy_fields.signal.theo_edge_lower < config.theo_edge_lower_filter) {
            allow_process_bid = false;
        }
        if (strategy_fields.signal.theo_edge_lower > -config.theo_edge_lower_filter) {
            allow_process_ask = false;
        }
        // spread filter
        if (strategy_fields.signal.spread > config.spread_filter) {
            allow_process_bid = false;
            allow_process_ask = false;
        }

        if(strategy_fields.signal.bid_pred_value >= strategy_fields.signal.ask_pred_value)
        {
            std::cout << "Risk Check : bid signal >= ask signal, bid signal:" << strategy_fields.signal.bid_pred_value << ","
                    << "ask signal:" << strategy_fields.signal.ask_pred_value << "," << std::endl;
            allow_process_bid = false;
            allow_process_ask = false;
        }

        // warmup ticks
        bool all_warmup = true;
        for(auto &warmup_tick : warmup_ticks_map) {
            if(warmup_tick.second < config.warm_up_ticks) {
                all_warmup = false;
            }
        }
        if(warmup_ticks_map.size() < 1) all_warmup = false;

        if(!all_warmup) {
            allow_process_bid = false;
            allow_process_ask = false;
        } else if (!warmup_done) {
            std::cout << "warmup done, ";
            for (auto &warmup_tick : warmup_ticks_map) {
                std::cout << warmup_tick.first << ":" << warmup_tick.second << ",";
            }
            std::cout << std::endl;
            warmup_done = true;
        }

        // funding rate mode
        if(config.funding_rate_mode) {
            allow_process_bid = false;
            allow_process_ask = false;
            if(config.buy_only) allow_process_bid = true;
            if(config.sell_only) allow_process_ask = true;
        }

        if(!allow_process_bid) risk_check_result.allow_process_bid = false;
        if(!allow_process_ask) risk_check_result.allow_process_ask = false;

    }

    G_INLINE void CalculateEdge(StrategyFields &strategy_fields, double &placeBidPrice, double &placeAskPrice, const int64_t &recv_ts)
    {
        double adjust_min_edge_bp = config.min_edge_bp;
        double adjust_max_edge_entry_bp = config.max_edge_entry_bp;
        double adjust_max_edge_exit_bp = config.max_edge_exit_bp;
        // double vol_edge_weight = config.vol_edge_weight;
        // double vol_max_entry_weight = config.vol_max_entry_weight;
        // double vol_max_exit_weight = config.vol_max_exit_weight;

        if(strategy_fields.current_mode == StrategyMode::ReduceOnlyMode)
        {
            adjust_min_edge_bp = config.min_edge_bp * common_config.reduce_only_param_multi;
            adjust_max_edge_entry_bp = config.max_edge_entry_bp * common_config.reduce_only_param_multi;
            adjust_max_edge_exit_bp = config.max_edge_exit_bp * common_config.reduce_only_param_multi;
            // vol_edge_weight = config.vol_edge_weight * common_config.reduce_only_param_multi;
            // vol_max_entry_weight = config.vol_max_entry_weight * common_config.reduce_only_param_multi;
            // vol_max_exit_weight = config.vol_max_exit_weight * common_config.reduce_only_param_multi;
        }

        double symbol_risk = strategy_fields.sym_risk.symbol_risk;
        ContractInfo* mainContract = strategy_fields.contract_info;

        mainContract->custom_min_notional = config.custom_min_notional;
        mainContract->custom_max_notional = config.custom_max_notional;

        double bidPrice = GaiaUtils::BookGetBestBidPrice(mainContract);
        double askPrice = GaiaUtils::BookGetBestAskPrice(mainContract);
        double mid_price = (bidPrice + askPrice)/2;
        
        // edge bp from config
        double bid_edge_bp = 0;
        double ask_edge_bp = 0;

        // position edge
        double pos_coin = symbol_risk;
        double bidPositionEdgeBp = 0, askPositionEdgeBp = 0;
        double bidVolPosEdge = 0, askVolPosEdge = 0;
        double pos_ratio = std::max(-1.0, std::min(1.0, (pos_coin / strategy_fields.max_pos_coin )));
        if(pos_coin < -eps)
        {
            bidPositionEdgeBp = pos_ratio * adjust_max_edge_exit_bp;
            askPositionEdgeBp = pos_ratio * adjust_max_edge_entry_bp;
        }
        else if(pos_coin > eps)
        {
            bidPositionEdgeBp = pos_ratio * adjust_max_edge_entry_bp;
            askPositionEdgeBp = pos_ratio * adjust_max_edge_exit_bp;
        }


        bid_edge_bp += bidPositionEdgeBp;
        ask_edge_bp -= askPositionEdgeBp;

        bid_edge_bp += adjust_min_edge_bp;
        ask_edge_bp += adjust_min_edge_bp;

        // vol edge
        double vol_long = strategy_fields.signal.vol_long;
        double vol_edge_bp = 0;
        if (vol_long > config.vol_min_cap) {
            vol_edge_bp = vol_long - config.vol_min_cap;
        }
        if (vol_edge_bp > config.vol_max_cap) {
            vol_edge_bp = config.vol_max_cap;
        }
        bid_edge_bp -= vol_edge_bp;
        ask_edge_bp -= vol_edge_bp;

        placeBidPrice = GaiaUtils::roundPriceViaTickSize(placeBidPrice * ( 1 - bid_edge_bp / ONE_BASE_POINT), mainContract);
        placeAskPrice = GaiaUtils::roundPriceViaTickSize(placeAskPrice * ( 1 + ask_edge_bp / ONE_BASE_POINT), mainContract);
        double placeBidPriceBottom = GaiaUtils::roundPriceViaTickSize(placeBidPrice * ( 1 - config.bottom_edge_bp / ONE_BASE_POINT), mainContract);
        double placeAskPriceBottom = GaiaUtils::roundPriceViaTickSize(placeAskPrice * ( 1 + config.bottom_edge_bp / ONE_BASE_POINT), mainContract);

        // // vol edge bp
        // placeBidPrice = placeBidPrice - vol_edge_weight * vol_long;
        // placeAskPrice = placeAskPrice + vol_edge_weight * vol_long;
        // vol pos edge bp
        placeBidPrice = placeBidPrice - bidVolPosEdge;
        placeAskPrice = placeAskPrice - askVolPosEdge;

        placeBidPrice = std::min(placeBidPriceBottom, placeBidPrice);
        placeAskPrice = std::max(placeAskPriceBottom, placeAskPrice);
    }

    void Process(TickEventType _cur_tick_type, const SymId &_cur_tick_sid, StrategyFields &strategy_fields)
    {
        RiskCheck(strategy_fields);

        int64_t now = (*strategy_fields.sid_contract_map)[_cur_tick_sid]->latency_record.mkt_data.mkt_recv_ts;

        double placeBidPrice = strategy_fields.signal.bid_pred_value;
        double placeAskPrice = strategy_fields.signal.ask_pred_value;
        CalculateEdge(strategy_fields, placeBidPrice, placeAskPrice, now);


        warmup_ticks_map[_cur_tick_sid] += 1;

        if(strategy_fields.risk_check_result.allow_process_bid)
        {
            Quoting(strategy_fields, placeBidPrice, 1);
        } else {
            CancelAllOnSide(strategy_fields, true, false);
        }

        if(strategy_fields.risk_check_result.allow_process_ask)
        {
            Quoting(strategy_fields, placeAskPrice, -1);
        } else {
            CancelAllOnSide(strategy_fields, false, true);
        }
    }

    void OnOrderClosed(GOrderState* order_state)
    {
        if(order_state->ts_order->side() == Side::BUY) {
            for(auto &order_level : bid_order_levels)
            {
                if(order_level.orderState == order_state) {
                    order_level.orderState = nullptr;
                }
            }
        }
        else{
            for(auto &order_level : ask_order_levels)
            {
                if(order_level.orderState == order_state) {
                    order_level.orderState = nullptr;
                }
            }
        }
    }

    G_INLINE void getOrdersSizeInFlight(StrategyFields& strategy_fields, double &bidSizeInFlight, double &askSizeInFlight)
    {
        for(auto orderStateIter : strategy_fields.order_state_map)
        {
            auto &orderState = orderStateIter.second;

            if(orderState->ts_order->side() == Side::BUY)
            {
                bidSizeInFlight += orderState->ts_order->leaves_qty();
            }
            else if(orderState->ts_order->side() == Side::SELL)
            {
                askSizeInFlight += orderState->ts_order->leaves_qty();
            }
        }
    }

    G_INLINE void Quoting(StrategyFields& strategy_fields, double placePrice, int sideInt)
    {
        double adjust_edge_range_bp = config.edge_range_bp;
        // double vol_edge_weight = config.vol_edge_weight;
        // double vol_edge_range_weight = config.vol_edge_range_weight;

        if(strategy_fields.current_mode == StrategyMode::ReduceOnlyMode)
        {
            // vol_edge_weight = config.vol_edge_weight * common_config.reduce_only_param_multi;
            strategy_fields.max_pos_coin = 0;
        }

        std::vector<OrderLevel> *order_levels = &bid_order_levels;
        if(sideInt == -1) order_levels = &ask_order_levels;

        ContractInfo* &main_contract  = strategy_fields.contract_info;
        double bid_price = GaiaUtils::BookGetBestBidPrice(main_contract);
        double ask_price = GaiaUtils::BookGetBestAskPrice(main_contract);
        double mid_price = (bid_price + ask_price) / 2;

        double price_tick = main_contract->symbol_info->prc_tick_size;
        double min_qty = main_contract->symbol_info->min_qty;
        double min_notional = std::max(main_contract->symbol_info->min_notional, config.custom_min_notional);
        double max_notional = std::min(main_contract->symbol_info->max_qty * main_contract->symbol_info->multiplier * mid_price, config.custom_max_notional);
        if(main_contract->is_reverse) {
            min_notional = std::max(min_notional, min_qty * main_contract->symbol_info->multiplier);
            max_notional = std::min(main_contract->symbol_info->max_qty * main_contract->symbol_info->multiplier, config.custom_max_notional);
        }
        double min_coin = min_notional / mid_price;

        double range_deep_price = config.range_deep_bp / ONE_BASE_POINT * mid_price;

        // do not allow take or improve price
        if(sideInt == 1)
        {
            if (placePrice > bid_price) placePrice = bid_price;
        }
        else
        {
            if (placePrice < ask_price) placePrice = ask_price;
        }


        double bound_close_to_best = placePrice * (1 + 0.5 * sideInt * adjust_edge_range_bp / ONE_BASE_POINT);
        double bound_far_from_best = placePrice * (1 - 0.5 * sideInt * adjust_edge_range_bp / ONE_BASE_POINT);

        // std::cout << "lowerBound: " << bound_far_from_best << ",upperBound: " << bound_close_to_best << std::endl;
        if(sideInt == 1)
        {
            bound_far_from_best = GaiaUtils::ceilPrice(bound_far_from_best, price_tick);
            bound_close_to_best = GaiaUtils::floorPrice(bound_close_to_best, price_tick);
        }
        else
        {
            bound_far_from_best = GaiaUtils::floorPrice(bound_far_from_best, price_tick);
            bound_close_to_best = GaiaUtils::ceilPrice(bound_close_to_best, price_tick);
        }



        // std::cout << "bid flight size: " << bidSizeInFlight << ", ask flight size: " << askSizeInFlight << std::endl;
        

        double pos_risk_coin = strategy_fields.sym_risk.symbol_risk;
        double max_submit_size = GaiaUtils::roundSizeViaQtyTick((strategy_fields.max_pos_coin - sideInt * pos_risk_coin) / main_contract->symbol_info->multiplier , main_contract);
        if(main_contract->is_reverse) {
            max_submit_size = GaiaUtils::roundSizeViaQtyTick((strategy_fields.max_pos_coin - sideInt * pos_risk_coin) * mid_price / main_contract->symbol_info->multiplier, main_contract);
            // double pos_risk_usd = strategy_fields.sym_risk.contract_usd_risk;
            // max_submit_size = GaiaUtils::roundSizeViaQtyTick((strategy_fields.max_pos_usd - sideInt * pos_risk_usd) / main_contract->symbol_info->multiplier, main_contract);
        }

        if (config.futures_spot_arb_mode && sideInt == -1) {
            if(main_contract->symbol_info->product_type == ProductType::SPOT) {
                if(strategy_fields.sym_risk.symbol_risk <= min_coin) {
                    max_submit_size = 0;
                    return;
                } else {
                    max_submit_size = GaiaUtils::floorSizeViaQtyTick(strategy_fields.sym_risk.symbol_risk / main_contract->symbol_info->multiplier, main_contract);
                }
            }
        }
        if (config.futures_spot_arb_mode && sideInt == 1) {
            if((*strategy_fields.sid_contract_map)[hedger_sid]->symbol_info->product_type == ProductType::SPOT) {
                StrategyFields &hedger_fields = (*strategy_fieldsMap)[hedger_sid];
		        double hedger_pos_coin = hedger_fields.sym_risk.symbol_risk;
                if(hedger_pos_coin > -min_coin) {
                    max_submit_size = 0;
                    return;
                } else {
                    max_submit_size = GaiaUtils::floorSizeViaQtyTick(hedger_pos_coin / main_contract->symbol_info->multiplier, main_contract);
                    if(main_contract->is_reverse) {
                        max_submit_size = GaiaUtils::floorSizeViaQtyTick(hedger_fields.sym_risk.contract_usd_risk / main_contract->symbol_info->multiplier, main_contract);
                    }

                }
            }
        }

        double bidSizeInFlight = 0, askSizeInFlight = 0;
        getOrdersSizeInFlight(strategy_fields, bidSizeInFlight, askSizeInFlight);
        if(sideInt == 1)
        {
            max_submit_size -= bidSizeInFlight;
        }
        else
        {
            max_submit_size -= askSizeInFlight;
        }

        // In BalanceLimitMode, we do not submit orders
        if(strategy_fields.current_mode == StrategyMode::BalanceLimitMode) {
            max_submit_size = 0;
        }

        /*
        std::cout << "pos_risk_coin : " << pos_risk_coin << ", max_submit_size: " << max_submit_size 
        << ", max_submit_coin: " << (strategy_fields.max_pos_coin - sideInt * pos_risk_coin) 
        << ", multiplier: " << main_contract->symbol_info->multiplier
        << ", qty_tick: " << main_contract->symbol_info->qty_tick_size << std::endl;
        */

        int max_levels = std::max(1, config.max_level_on_side);

        // convert size_coin to exchange size
        double final_place_size = strategy_fields.order_size_coin / main_contract->symbol_info->multiplier;
        if(main_contract->is_reverse) {
            final_place_size = strategy_fields.order_size_coin * mid_price / main_contract->symbol_info->multiplier;
        }
        double order_size_in_market = 0;
        int index = 0;
        for(index = 0; index < max_levels; ++index)    //for(index = max_levels-1; index > -1; --index)
        {
            // std::cout << "index: " << index << std::endl;
            double bound_far_from_best_level = bound_far_from_best - sideInt * index * (range_deep_price);
            double bound_close_to_best_level = bound_close_to_best - sideInt * index * (range_deep_price);
            // std::cout << "lowerBound: " << bound_far_from_best << ",upperBound: " << bound_close_to_best << std::endl;

            double level_price_in_range =  bound_far_from_best_level + (bound_close_to_best_level - bound_far_from_best_level) * config.range_place_percentile;

            level_price_in_range = GaiaUtils::roundPriceViaTickSize(level_price_in_range, price_tick);
            // std::cout << "level_price_in_range: " << level_price_in_range << std::endl;

            OrderLevel &order_level = (*order_levels)[index];
            bool need_cancel = false, need_insert = false, need_force_cancel = false;

            // std::cout << "final_place_size: " <<  final_place_size << ", order_size_in_market: " << order_size_in_market << std::endl;
            final_place_size = std::max(0.0, std::min(final_place_size, max_submit_size - order_size_in_market));

            if(strategy_fields.current_mode == StrategyMode::ReduceOnlyMode)
            {
                if((max_submit_size - order_size_in_market - final_place_size) <= min_qty ||
                (max_submit_size - order_size_in_market - final_place_size) * level_price_in_range * main_contract->symbol_info->multiplier <= min_notional)
                {
                    final_place_size = max_submit_size - order_size_in_market;
                }
            }

            if(order_level.orderState != nullptr && order_level.orderState->ts_order->leaves_qty() > eps)
            {
                if(GaiaUtils::isWorsePrice(sideInt, order_level.orderState->ts_order->price(), bound_far_from_best_level)
                || GaiaUtils::isBetterPrice(sideInt, order_level.orderState->ts_order->price(), bound_close_to_best_level))
                {
                    // std::cout << "need cancel, price: " << order_level.orderState->ts_order->price()
                    //             << " ,bidSignal: " << strategy_fields.signal.bid_pred_value
                    //             << " ,askSignal: " << strategy_fields.signal.ask_pred_value
                    //             << " ,placePrice: " << placePrice
                    //             << " ,upperBound: " << bound_close_to_best
                    //             << " ,lowerBound: " << bound_far_from_best << std::endl;
                    need_cancel = true;
                }

            }
            else if(order_level.orderState == nullptr)
            {
                need_insert = true;
            }


            if(need_cancel)
            {
                if(config.use_replace && need_force_cancel==false)
                {
                    // GOrderOp::ReplaceOrder(order_level.orderState, level_price_in_range, order_level.orderState->ts_order->qty());
                    ReplaceOrder(order_level.orderState, level_price_in_range, order_level.orderState->ts_order->qty(), strategy_fields);
                }
                else
                {
                    // std::cout << "real cancel" << std::endl;
                    GOrderOp::CancelOrder(order_level.orderState);
                }
            }

            if(need_insert) {
                final_place_size = GaiaUtils::roundSizeViaQtyTick(final_place_size, main_contract);

                // std::cout << "final_place_size: " << final_place_size << ","
                //             << "level_price_in_range: " << level_price_in_range << std::endl;
                double placeNotional = final_place_size * level_price_in_range * main_contract->symbol_info->multiplier;
                if(main_contract->is_reverse) {
                    placeNotional = final_place_size * main_contract->symbol_info->multiplier;
                }
                if(placeNotional < min_notional || placeNotional > max_notional)
                {
                    if(main_contract->latency_record.mkt_data.mkt_recv_ts - last_risk_print_ts > 1000000000L) {
                        std::cout << "Risk Check: place notional invalid, placeNotional: " << placeNotional << ","
                                    << "max_notional: " << max_notional << ","
                                    << "min_notional: " << min_notional << std::endl;
                        last_risk_print_ts = main_contract->latency_record.mkt_data.mkt_recv_ts;
                    }
                    continue;
                }
                if(final_place_size < eps || final_place_size < min_qty) continue;

                GOrderState* new_order_state = InsertOrder(strategy_fields, level_price_in_range, final_place_size, sideInt == 1? Side::BUY : Side::SELL, OrderType::LIMIT, TimeInForce::PO, index+1);
                if(new_order_state == nullptr)
                {
                    strategy_fields.setStrategyMode(StrategyMode::ExitMode, "InsertOrder failed");
                    return;
                }
                order_level.orderState = new_order_state;

                order_size_in_market += final_place_size;
            }
        }

    }

    GOrderState* InsertOrder(StrategyFields& strategy_fields, double &price, double &size, Side side, OrderType type, TimeInForce tif, int strategy_order_type) 
    {
        GOrderState* new_order_state = GOrderOp::InsertOrder(strategy_fields, price, size, side, type, tif, PositionOffset::UNKNOWN, strategy_order_type);

        // log
        if (config.use_log_factor > 0) {
            ContractInfo* &main_contract  = strategy_fields.contract_info; 
            output.clear();
            strategy_fields.predictor->getFactors(output);
            output["client_order_id"] = new_order_state->ts_order->client_order_id().value;
            // Logger::PushLog(new FactorMsg(output,main_contract->symbol_info->mirana_ticker.c_str()));
            LOG_AUTO(FactorMsg, output, main_contract->symbol_info->mirana_ticker.c_str());
        }

        return new_order_state;
    }

    bool ReplaceOrder(GOrderState* orderState, double price, double size, StrategyFields& strategy_fields) 
    {
        bool replace_ret = GOrderOp::ReplaceOrder(orderState, price, size);

        // log
        if (replace_ret) {
            // output.clear();
            // strategy_fields.predictor->getFactors(output);
            // output["client_order_id"] = orderState->ts_order->client_order_id().value;
            // Logger::PushLog(new FactorMsg(output));
        }    

        return replace_ret;
    }
};
