#pragma once
#include "GaiaUtils.h"

class TradeIdFilter
{
public:
    TradeIdFilter()
    {
        trade_timeout_ns = 10 * 1000L * 1000L * 1000L;
        min_receive_ns = 0;
    }

    bool isMaskedPrivate(const md::Trade &trade)
    {
        return (std::abs(trade.qty - 0.0001) < eps) && (trade.private_fill == 1);
    }

    bool isNumber(const std::string& str) {
        for (char const &c : str) {
            if (!std::isdigit(c)) {
                return false;
            }
        }
        return true;
    }

    #ifdef USE_AS
    std::string convertTradeId(const char *trade_id) {
        std::string trade_id_str(trade_id);
        return trade_id_str;
    }
    #else
    std::string convertTradeId(const char *trade_id) {
        std::string trade_id_str(trade_id);
        if (isNumber(trade_id_str)) {
            return trade_id_str;
        }

        return std::to_string(md::lowband::MsgConverter::HashOfTradeId(trade_id));
    }
    #endif

    /*
    // data: 1 public trade , n private trade
    */
    bool isDuplicateTrade(const md::Trade &trade)
    {
        if (trade.recv_ts < min_receive_ns)
            return false;

        std::string trade_id = convertTradeId(trade.trade_id);
        bool duplicate_flag = true;
        bool canFindInMap = trade_id_map.find(trade_id) != trade_id_map.end();
        if (canFindInMap)
        {
            if (isMaskedPrivate(trade_id_map[trade_id]))
            {
                if (isMaskedPrivate(trade))
                {
                    duplicate_flag = true;
                }
                else
                {
                    trade_id_map[trade_id].qty = trade.qty;
                    duplicate_flag = false;
                }
            }
            else
            {
                duplicate_flag = true;
            }
        }
        else
        {
            trade_id_map[trade.trade_id] = trade;
            trade_queue.push(trade);
            duplicate_flag = false;
        }

        checkTradeTimeOut(trade.recv_ts);

        return duplicate_flag;
    }

    std::unordered_map<std::string, md::Trade> trade_id_map;
    std::queue<md::Trade> trade_queue;

private:
    Nanoseconds min_receive_ns;
    Nanoseconds trade_timeout_ns;

    void checkTradeTimeOut(const Nanoseconds &now)
    {
        min_receive_ns = now - trade_timeout_ns;
        while (!trade_queue.empty() && trade_queue.front().recv_ts < min_receive_ns)
        {
            trade_id_map.erase(trade_queue.front().trade_id);
            trade_queue.pop();
        }
    }
};
