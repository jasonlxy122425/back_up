#pragma once

#include <parallel_hashmap/phmap.h>
#include "ContractInfo.h"

/*
auto agg_trade = input_data.preprocess_result->GetAggTrade(input_data.cur_contract->symbol_info->sid);
if (!agg_trade.has_value()){
    std::cout << "no agg trade" << std::endl;
    return;
} else {
    double price = agg_trade->price;
    double qty = agg_trade->qty;
}
目前的数据中如果为非trade数据，或者本条trade用于聚合等待时， agg_trade.has_value()返回false，表示此时没有agg_trade，需要返回.
反之可以直接使用。
agg_trade中的recv_ts exch_ts均为最后一条聚合trade的数据
*/

struct PreprocessResult {
    std::optional<Trade> GetAggTrade(SymId sid) {
        return agg_trade[sid];
    }

    void SetAggTrade(SymId sid, std::optional<Trade> trade) {
        agg_trade[sid] = trade;
    }

private:
    phmap::flat_hash_map<SymId, std::optional<Trade>> agg_trade;
};