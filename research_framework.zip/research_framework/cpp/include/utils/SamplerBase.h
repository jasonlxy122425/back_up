#pragma once

#include "utils/GaiaCircularBuffer.h"
#include "GaiaOrderbook.h"
#include "GobUpdateBuilder.h"
#include "DemeterType.h"

#include <memory>
#include <deque>

namespace demeter {

class SamplerBase {
public:
    SamplerBase() {
        demeter_data_ = std::make_shared<DemeterData>();
    }
    ~SamplerBase() {}

    virtual bool Update(const GaiaOrderbook &order_book, ContractInfo *contract) = 0;
    virtual void Sample() {};

    std::shared_ptr<DemeterData> GetDemeterData() {return demeter_data_;};

protected:
    // builder
    GobUpdateBuilder<GobUpdate> builder_;

    void clear() {
        demeter_data_->gob_update_.clear();
        demeter_data_->gob_update_sum_.reset();
    }
private:
    std::shared_ptr<DemeterData> demeter_data_;
};

}; // namespace demeter
