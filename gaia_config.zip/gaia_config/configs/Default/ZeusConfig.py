from Default.DefaultConfigInterface import *

class HedgerConfig:
    def __init__(self):
        self.open_threshold_bps = 5
        self.offset_bps = 2
        self.use_hedger = True
        self.round_for_hyperliquid = True
        self.hedger_symbol = ""
        self.hedger_logic_acct_id = ""
        self.use_market_order_for_hedge = False
        self.hedge_take_bp = 200
        self.mkt_timeout_ns = 300000000
        self.quoter_hedger_mkt_recv_diff_ns = 1000000000
        self.hedger_ref_quoter_price_ratio = 1
        self.net_pos_risk_ratio = 1.1
        self.custom_hedge_min_notional = 5
        self.custom_hedge_max_notional = 50000
        self.custom_pos_hedge_max_notional = 50000
        self.hedge_interval_second_in_exit = 30
        self.hedge_interval_ns_in_disconnect = 500000000
        self.exit_ns_in_disconnect = 15000000000
    
class PredictorConfig:
    def __init__(self):
        self.quoter_symbol = ""
        self.hedger_symbol = ""
        self.quote_coin_ref_symbol = ""
        self.quote_coin_ref_mode = 0 # 1:multi, -1: divide, 0: inactive
        self.hedger_ref_quoter_price_ratio = 1
        self.calculate_interval_ns = 5000000
        self.decay_rate_base_ns = 1000000000
        self.exp_base_num = 30
        self.exp_base_num_price = 30
        self.exp_base_num_notional = 1
        self.stdExp_long_interval = 5000000
        self.stdExp_long_base = 60
        self.stdExp_short_interval = 5000000
        self.stdExp_short_base = 30
        self.stdExp_shortSpike_interval = 5000000
        self.stdExp_shortSpike_base = 10
        self.theo_edge_lower_level = 1
        self.theo_edge_upper_level = 10

class OrderLogicConfig:
    def __init__(self):
        self.hedger_symbol = ""
        self.custom_min_notional = 5
        self.custom_max_notional = 50000
        self.min_edge_bp = 20
        self.edge_range_bp = 20
        self.bottom_edge_bp = 0
        self.max_edge_entry_bp = 0
        self.max_edge_exit_bp = 0
        self.vol_edge_weight = 0
        self.vol_edge_range_weight = 0
        self.vol_max_entry_weight = 0
        self.vol_max_exit_weight = 0
        self.vol_max_cap = 0
        self.vol_min_cap = 10000
        self.theo_edge_lower_filter = -10000
        self.theo_edge_upper_filter = 10000
        self.spread_filter = 10000
        self.sigma_filter = 0
        self.range_place_percentile = 0.5
        self.range_deep_bp = 20
        self.max_level_on_side = 1
        self.use_replace = False
        self.use_log_factor = False
        self.max_tolerance_size_ratio = 1.1
        self.mkt_timeout_ns = 500000000
        self.bottom_edge_bp = 0

        self.warm_up_ticks = 1000

        self.funding_rate_mode = False
        self.buy_only = False
        self.sell_only = False

        self.futures_spot_arb_mode = False
        self.use_log_factor = 0

@add_default_config
class ZeusConfig():
    def __init__(self):
        self.hedgerConfig = HedgerConfig()
        self.predictorConfig = PredictorConfig()
        self.orderLogicConfig = OrderLogicConfig()
        self.order_logic = "Zeus"
        self.predictor = "Arbitrage"
    
    def setSymbol(self, quoter_symbol, hedger_symbol):
        self.predictorConfig.quoter_symbol = quoter_symbol
        self.predictorConfig.hedger_symbol = hedger_symbol
        self.hedgerConfig.hedger_symbol = hedger_symbol

        self.orderLogicConfig.hedger_symbol = hedger_symbol
        self.reference_symbols = [quoter_symbol, hedger_symbol]
        if self.predictorConfig.quote_coin_ref_mode != 0 and self.predictorConfig.quote_coin_ref_symbol != '':
            self.reference_symbols.append(self.predictorConfig.quote_coin_ref_symbol)
