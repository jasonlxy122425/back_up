#pragma once
#include "OrderLogic.h"
#include "GaiaUtils.h"
#include "SpdLogger.h"
#include "SpdLoggerMessage.h"
#include "Predictor.h"
#include "GaiaCircularBuffer.h"
#include <cmath>
#include "KronosFactorMsg.h"

struct KronosConfig 
{
    double custom_min_notional;
    bool use_debug_msg;

    // theo
    double theo_gamma;
    double theo_alpha;
    int64_t theo_level;

    // pred
    bool use_pred;
    double pred_beta;

    // ewma std
    double std_ewma_interval;
    double std_ewma_exp_base;
    double sigma_threshold;
    double sigma_alpha;
    double sigma_beta;
    double sigma_dis_cap;

    // edge
    double entry_bps;
    double exit_bps;
    double cancel_entry_bps;
    double cancel_exit_bps;
    double pos_entry_dis_bps;
    double pos_exit_dis_bps;

    //
    double pred_edge_entry_threshold;
    double pred_edge_exit_threshold;
    double pred_edge_entry_cancel_threshold;
    double pred_edge_exit_cancel_threshold;
    double sigma_entry_threshold;

    int64_t mid_buffer_len1;
    int64_t mid_buffer_len2;
    int64_t mid_buffer_len3;
};  

class KronosImpl : public OrderLogic {
public:
    struct OrderLevel
    {
        double upper;
        double lower;
        double price;
        GOrderState *orderState = nullptr;
    };

    std::vector<OrderLevel> bid_order_levels;
    std::vector<OrderLevel> ask_order_levels;

    FactorOutputType output;


    KronosConfig config;
    // init
    int64_t num_ticks = 0;
    double prc_tick_size = 0.0;
    double qty_tick_size = 0.0;

    // sigma
    double time_ratio = 0.0, var_decay_rate = 0.0, time_decay_rate = 0.0;
    double price_diff = 0.0, std_price_ewma = 0.0, std_var_ewma = 0.0, std_sigma = 0.0;
    int64_t last_std_update_time = 0, std_ewma_num = 0;
    double sigma;
    double sigma_adj;
    double sigma_factor = 1;
 
    //
    double min_qty;

    double pred_value, theo, theo_pred, buy_pred_value, sell_pred_value;
    double buyOrderTotalCount, sellOrderTotalCount, net_pos_coin;
    double buy_entry_dis=0, sell_entry_dis=0, buy_exit_dis=0, sell_exit_dis=0, buy_pos_dis=0, sell_pos_dis=0, buy_pred_dis=0, sell_pred_dis=0, cancel_entry_dis=0, cancel_exit_dis=0;
    double quote_qty, buy_quote_qty, sell_quote_qty, max_pos, q_pos;
    bool buyOKCond, sellOKCond;
    bool buy_pred_entry_filter, sell_pred_entry_filter, buy_pred_exit_filter, sell_pred_exit_filter;
    bool sigma_entry_filter;
    double buy_price, sell_price, buy_entry_price, sell_entry_price, buy_exit_price, sell_exit_price;

    Side trade_side;
    double best_bid_price, best_ask_price, best_bid_qty, best_ask_qty, mid_price, spread, trade_price, trade_qty;
    double bto_deep, bid_deep, bz_deep, ato_deep, ask_deep, az_deep;
    double bto_queue, bid_queue, bz_queue, ato_queue, ask_queue, az_queue;

    GaiaCircularBuffer<double> mid_buffer1;
    GaiaCircularBuffer<double> mid_buffer2;
    GaiaCircularBuffer<double> mid_buffer3;
    int64_t last_mid_buffer_update_time = 0;
    double mid_buffer_ret1 = 0.0, mid_buffer_ret2 = 0.0, mid_buffer_ret3 = 0.0;

    KronosImpl(){}

    void Init(const Config& _conf)
    {
        version = "kronos_1.0.0";

        std::cout << "init Kronos config" << std::endl;
        auto conf = _conf.Get<Config>("order_logic_config");

        // read config
        config.custom_min_notional = GaiaUtils::GetParam<double>(conf, "custom_min_notional");
        config.use_debug_msg = GaiaUtils::GetParam<int64_t>(conf, "use_debug_msg") == 0 ? false : true;

        // theo
        config.theo_gamma = GaiaUtils::GetParam<double>(conf, "theo_gamma");
        config.theo_alpha = GaiaUtils::GetParam<double>(conf, "theo_alpha");
        config.theo_level = GaiaUtils::GetParam<int64_t>(conf, "theo_level");

        // pred
        config.use_pred = GaiaUtils::GetParam<bool>(conf, "use_pred");
        config.pred_beta = GaiaUtils::GetParam<double>(conf, "pred_beta");

        // ewma std
        config.std_ewma_interval = GaiaUtils::GetParam<double>(conf, "std_ewma_interval");
        config.std_ewma_exp_base = GaiaUtils::GetParam<double>(conf, "std_ewma_exp_base");
        config.sigma_threshold = GaiaUtils::GetParam<double>(conf, "sigma_threshold");
        config.sigma_alpha = GaiaUtils::GetParam<double>(conf, "sigma_alpha");
        config.sigma_beta = GaiaUtils::GetParam<double>(conf, "sigma_beta");
        config.sigma_dis_cap = GaiaUtils::GetParam<double>(conf, "sigma_dis_cap");

        // edge
        config.entry_bps = GaiaUtils::GetParam<double>(conf, "entry_bps");
        config.exit_bps = GaiaUtils::GetParam<double>(conf, "exit_bps");
        config.cancel_entry_bps = GaiaUtils::GetParam<double>(conf, "cancel_entry_bps");
        config.cancel_exit_bps = GaiaUtils::GetParam<double>(conf, "cancel_exit_bps");
        config.pos_entry_dis_bps = GaiaUtils::GetParam<double>(conf, "pos_entry_dis_bps");
        config.pos_exit_dis_bps = GaiaUtils::GetParam<double>(conf, "pos_exit_dis_bps");

        //
        config.pred_edge_entry_threshold = GaiaUtils::GetParam<double>(conf, "pred_edge_entry_threshold");
        config.pred_edge_exit_threshold = GaiaUtils::GetParam<double>(conf, "pred_edge_exit_threshold");
        config.pred_edge_entry_cancel_threshold = GaiaUtils::GetParam<double>(conf, "pred_edge_entry_cancel_threshold");
        config.pred_edge_exit_cancel_threshold = GaiaUtils::GetParam<double>(conf, "pred_edge_exit_cancel_threshold");
        config.sigma_entry_threshold = GaiaUtils::GetParam<double>(conf, "sigma_entry_threshold");

        // mid buffer
        config.mid_buffer_len1 = GaiaUtils::GetParam<int64_t>(conf, "mid_buffer_len1");
        config.mid_buffer_len2 = GaiaUtils::GetParam<int64_t>(conf, "mid_buffer_len2");
        config.mid_buffer_len3 = GaiaUtils::GetParam<int64_t>(conf, "mid_buffer_len3");
        mid_buffer1.setSize(config.mid_buffer_len1, 0.0);
        mid_buffer2.setSize(config.mid_buffer_len2, 0.0);
        mid_buffer3.setSize(config.mid_buffer_len3, 0.0);
    };


    bool RiskCheck(StrategyFields &strategy_fields)
    {

        return true;
    }

    void Process(TickEventType _cur_tick_type, const SymId &_cur_tick_sid, StrategyFields &strategy_fields)
    {
        // get book&trade information
        ContractInfo* &main_contract  = strategy_fields.contract_info;
        auto &trade = main_contract->trade;
        // get book&trade information
        best_bid_price = GaiaUtils::BookGetBestBidPrice(main_contract);
        best_ask_price = GaiaUtils::BookGetBestAskPrice(main_contract);
        best_bid_qty = GaiaUtils::BookGetBestBidSize(main_contract);
        best_ask_qty = GaiaUtils::BookGetBestAskSize(main_contract);
        mid_price = (best_bid_price + best_ask_price)/2.0;
        spread = best_ask_price - best_bid_price;
        trade_side = trade.side;
        trade_price = trade.price;
        trade_qty = trade.qty;
        prc_tick_size = main_contract->symbol_info->prc_tick_size;
        qty_tick_size = main_contract->symbol_info->qty_tick_size;
        min_qty = std::max(main_contract->symbol_info->min_qty, config.custom_min_notional/mid_price/main_contract->symbol_info->multiplier);

        // test mid return
        if ((_cur_tick_sid == main_contract->symbol_info->sid) && (main_contract->latency_record.mkt_data.mkt_exch_ts > last_mid_buffer_update_time + 0.5*1e9)) {
            mid_buffer1.push(mid_price);
            mid_buffer2.push(mid_price);
            mid_buffer3.push(mid_price);
            last_mid_buffer_update_time = main_contract->latency_record.mkt_data.mkt_exch_ts;
        }
        if (mid_buffer1.isFull()) {
            mid_buffer_ret1 = (mid_price/mid_buffer1.front()-1)*10000;
        }
        if (mid_buffer2.isFull()) {
            mid_buffer_ret2 = (mid_price/mid_buffer2.front()-1)*10000;
        }
        if (mid_buffer3.isFull()) {
            mid_buffer_ret3 = (mid_price/mid_buffer3.front()-1)*10000;
        }

        
        // update sigma
        if ((_cur_tick_sid == main_contract->symbol_info->sid) && (main_contract->latency_record.mkt_data.mkt_exch_ts > last_std_update_time + config.std_ewma_interval*1e9)) {
            if (std_ewma_num < MinErr) {
                std_var_ewma = 0.0;
                std_price_ewma = mid_price;
                sigma = 0.0;
            }
            else {
                time_ratio = (main_contract->latency_record.mkt_data.mkt_exch_ts - last_std_update_time) / (double)(1000000000);
                time_decay_rate = std::exp(-time_ratio / config.std_ewma_exp_base);
                var_decay_rate = 1 - time_decay_rate;
                price_diff = mid_price - std_price_ewma;
                std_var_ewma = time_decay_rate * (std_var_ewma + (var_decay_rate * (price_diff * price_diff)));
                std_price_ewma = time_decay_rate * (std_price_ewma - mid_price) + mid_price;
                sigma = std::sqrt(std_var_ewma)/std_price_ewma*1e4;
            }

            last_std_update_time = main_contract->latency_record.mkt_data.mkt_exch_ts;
            std_ewma_num += 1;
        }
        sigma_adj = sigma - config.sigma_threshold;
        if (sigma_adj < 0) {
            sigma_adj = 0;
        }
        sigma_factor = config.sigma_beta*std::exp(sigma_adj*config.sigma_alpha);
        if (sigma_factor > config.sigma_dis_cap) {
            sigma_factor = config.sigma_dis_cap;
        }

        // main logic
        // pos and orders
        net_pos_coin = strategy_fields.sym_risk.symbol_risk/main_contract->symbol_info->multiplier;
        max_pos = strategy_fields.max_pos_coin/main_contract->symbol_info->multiplier;
        quote_qty = strategy_fields.order_size_coin/main_contract->symbol_info->multiplier;
        q_pos = 0.0;
        buyOrderTotalCount = 0.0;
        sellOrderTotalCount = 0.0;
        for(auto orderStateIter : strategy_fields.order_state_map) {
            auto &orderState = orderStateIter.second;
            if(orderState->ts_order->side() == Side::BUY) {
                buyOrderTotalCount += orderState->ts_order->qty();
            }
            else if(orderState->ts_order->side() == Side::SELL) {
                sellOrderTotalCount += orderState->ts_order->qty();
            }
        }

        // pred and edge
        if (config.use_pred) {
            pred_value = strategy_fields.signal.pred_value;
            CalBidDeepPriceSize(main_contract, config.theo_level, bto_deep, bid_deep, bz_deep);
            CalAskDeepPriceSize(main_contract, config.theo_level, ato_deep, ask_deep, az_deep);
            theo_pred = computeGATheo(bid_deep, ask_deep, bz_deep, az_deep, trade_price);
            double mid_deep = (bid_deep+ask_deep)/2.0;
            buy_pred_value = pred_value;
            sell_pred_value = pred_value;
        }
        else {
            CalBidDeepPriceSize(main_contract, config.theo_level, bto_deep, bid_deep, bz_deep);
            CalAskDeepPriceSize(main_contract, config.theo_level, ato_deep, ask_deep, az_deep);
            theo_pred = computeGATheo(bid_deep, ask_deep, bz_deep, az_deep, trade_price);
            double mid_deep = (bid_deep+ask_deep)/2.0;
            pred_value = (theo_pred-bid_deep)/(ask_deep-bid_deep)-0.5;
            if (sigma > MinErr) {
                if (mid_buffer_ret1 > 0) {
                    buy_pred_value = log(1+abs(mid_buffer_ret1/sigma));
                    sell_pred_value = log(1+abs(mid_buffer_ret1/sigma));
                }
                else {
                    buy_pred_value = -log(1+abs(mid_buffer_ret1/sigma));
                    sell_pred_value = -log(1+abs(mid_buffer_ret1/sigma));
                }
            }else{
                buy_pred_value = 0.0;
                sell_pred_value = 0.0;
            }
            // buy_pred_value = (theo_pred-bid_deep)/(ask_deep-bid_deep)-0.5;
            // sell_pred_value = (theo_pred-bid_deep)/(ask_deep-bid_deep)-0.5;
        }


        if (net_pos_coin > -MinErr) {
            buy_pos_dis = net_pos_coin/quote_qty*config.pos_entry_dis_bps;
            sell_pos_dis = -net_pos_coin/quote_qty*config.pos_exit_dis_bps;
        }
        else {
            buy_pos_dis = net_pos_coin/quote_qty*config.pos_exit_dis_bps;
            sell_pos_dis = -net_pos_coin/quote_qty*config.pos_entry_dis_bps;
        }
        buy_entry_dis = (config.entry_bps+buy_pos_dis)*mid_price/1e4*sigma_factor;
        sell_entry_dis = (config.entry_bps+sell_pos_dis)*mid_price/1e4*sigma_factor;
        buy_exit_dis = (config.exit_bps+buy_pos_dis)*mid_price/1e4;  //*sigma_factor
        sell_exit_dis = (config.exit_bps+sell_pos_dis)*mid_price/1e4;  //*sigma_factor
        cancel_entry_dis = (config.cancel_entry_bps/1e4)*mid_price; //*sigma_factor
        cancel_exit_dis = (config.cancel_exit_bps/1e4)*mid_price; //*sigma_factor
        buy_pred_dis = config.pred_beta*pred_value*best_bid_price/1e4; // *sigma_factor
        sell_pred_dis = config.pred_beta*pred_value*best_ask_price/1e4; // *sigma_factor
        buy_entry_price = best_bid_price-buy_entry_dis+buy_pred_dis;
        sell_entry_price = best_ask_price+sell_entry_dis+sell_pred_dis;
        buy_exit_price = best_bid_price-buy_exit_dis+buy_pred_dis;
        sell_exit_price = best_ask_price+sell_exit_dis+sell_pred_dis;
        buy_entry_price = std::min(buy_entry_price, best_bid_price);
        sell_entry_price = std::max(sell_entry_price, best_ask_price);
        buy_exit_price = std::min(buy_exit_price, best_bid_price);
        sell_exit_price = std::max(sell_exit_price, best_ask_price);
        buy_entry_price = GaiaUtils::roundPriceViaTickSize(buy_entry_price, main_contract);
        sell_entry_price = GaiaUtils::roundPriceViaTickSize(sell_entry_price, main_contract);
        buy_exit_price = GaiaUtils::roundPriceViaTickSize(buy_exit_price, main_contract);
        sell_exit_price = GaiaUtils::roundPriceViaTickSize(sell_exit_price, main_contract);


        // cancel logic
        for(auto orderStateIter : strategy_fields.order_state_map)
        {
            auto &orderState = orderStateIter.second;
            double order_price = orderState->ts_order->price();
            double order_qty = orderState->ts_order->qty();
            double stra_order_type = orderState->strategy_order_type;
            if(orderState->ts_order->side() == Side::BUY)
            {
                // price cond
                bool price_entry_dis_cond = abs(buy_entry_price - order_price) > cancel_entry_dis - eps;
                bool price_exit_dis_cond = abs(buy_exit_price - order_price) > cancel_exit_dis - eps;
                bool pred_entry_filter_cond = buy_pred_value < config.pred_edge_entry_cancel_threshold;
                bool pred_exit_filter_cond = buy_pred_value < config.pred_edge_exit_cancel_threshold;
                bool price_dis_cond = (price_entry_dis_cond && stra_order_type == 1) || (price_exit_dis_cond && stra_order_type == 0);
                bool pred_filter_cond = (pred_entry_filter_cond && stra_order_type == 1) || (pred_exit_filter_cond && stra_order_type == 0);

                if (price_dis_cond || pred_filter_cond){
                    if (price_dis_cond) {
                        orderState->cancel_order_type = 1;
                    }
                    else if (pred_filter_cond) {
                        orderState->cancel_order_type = 2;
                    }
                    GOrderOp::CancelOrder(orderState);
                }
            
            }
            else if(orderState->ts_order->side() == Side::SELL)
            {
                // price cond
                bool price_entry_dis_cond = abs(order_price - sell_entry_price) > cancel_entry_dis - eps;
                bool price_exit_dis_cond = abs(order_price - sell_exit_price) > cancel_exit_dis - eps;
                bool pred_entry_filter_cond = sell_pred_value > -config.pred_edge_entry_cancel_threshold;
                bool pred_exit_filter_cond = sell_pred_value > -config.pred_edge_exit_cancel_threshold;
                bool price_dis_cond = (price_entry_dis_cond && stra_order_type == 1) || (price_exit_dis_cond && stra_order_type == 0);
                bool pred_filter_cond = (pred_entry_filter_cond && stra_order_type == 1) || (pred_exit_filter_cond && stra_order_type == 0); //

                if (price_dis_cond || pred_filter_cond){
                    if (price_dis_cond) {
                        orderState->cancel_order_type = 1;
                    }
                    else if (pred_filter_cond) {
                        orderState->cancel_order_type = 2;
                    }
                    GOrderOp::CancelOrder(orderState);
                }
            }
        }

        // pos and order filter
        buyOKCond = true;
        if (strategy_fields.current_mode == StrategyMode::ReduceOnlyMode) {
            if (net_pos_coin >= -min_qty) {
                buyOKCond = false;
            }
        }
        else if (buyOrderTotalCount > eps) {
            buyOKCond = false;
        }
        sellOKCond = true;
        if (strategy_fields.current_mode == StrategyMode::ReduceOnlyMode) {
            if (net_pos_coin <= min_qty) {
                sellOKCond = false;
            }
        }
        else if (sellOrderTotalCount > eps) {
            sellOKCond = false;
        }
        if(common_config.use_reduce_only_mode && !buyOKCond && !sellOKCond) strategy_fields.setStrategyMode(StrategyMode::NormalExitMode, "Reduce Only Done");


        if (common_config.use_reduce_only_mode && buyOKCond) {
            quote_qty = std::min(quote_qty, -(buyOrderTotalCount + net_pos_coin));
        }
        else if (common_config.use_reduce_only_mode && sellOKCond) {
            quote_qty = std::min(quote_qty, -(sellOrderTotalCount - net_pos_coin));
        }

        // pred and edge filter
        buy_pred_entry_filter = buy_pred_value > config.pred_edge_entry_threshold;
        sell_pred_entry_filter = sell_pred_value < -config.pred_edge_entry_threshold;
        buy_pred_exit_filter = buy_pred_value > config.pred_edge_exit_threshold;
        sell_pred_exit_filter = sell_pred_value < -config.pred_edge_exit_threshold;
        sigma_entry_filter = sigma > config.sigma_entry_threshold;

        // buy_side 
        if (buyOKCond){
            // buy entry
            if ((net_pos_coin > -MinErr) && buy_pred_entry_filter && sigma_entry_filter) { //
                buy_quote_qty = quote_qty;
                buy_quote_qty = std::min(buy_quote_qty, max_pos-(buyOrderTotalCount + net_pos_coin));
                buy_quote_qty = GaiaUtils::floorSizeViaQtyTick(buy_quote_qty, main_contract);
                if (buy_quote_qty > min_qty - MinErr) {
                    buy_price = buy_entry_price;
                    q_pos = best_bid_qty;
                    Buy(strategy_fields, buy_price, buy_quote_qty, buyOrderTotalCount, net_pos_coin, max_pos, q_pos, TimeInForce::PO, 1);
                }
            }
            // buy exit
            else if ((net_pos_coin < -MinErr) && buy_pred_exit_filter) {//
                buy_quote_qty = quote_qty;
                buy_quote_qty = std::min(buy_quote_qty, -net_pos_coin);
                // buy_quote_qty = std::min(buy_quote_qty, max_pos-(buyOrderTotalCount + net_pos_coin));
                buy_quote_qty = GaiaUtils::floorSizeViaQtyTick(buy_quote_qty, main_contract);
                if (buy_quote_qty > min_qty - MinErr) {
                    buy_price = buy_exit_price;
                    q_pos = best_bid_qty;
                    Buy(strategy_fields, buy_price, buy_quote_qty, buyOrderTotalCount, net_pos_coin, max_pos, q_pos, TimeInForce::PO, 0);
                }
            }
        } 
        // sell_side
        if (sellOKCond){
            // sell entry
            if ((net_pos_coin < MinErr) && sell_pred_entry_filter && sigma_entry_filter) { // 
                sell_quote_qty = quote_qty;
                sell_quote_qty = std::min(sell_quote_qty, max_pos-(sellOrderTotalCount - net_pos_coin));
                sell_quote_qty = GaiaUtils::floorSizeViaQtyTick(sell_quote_qty, main_contract);
                if (sell_quote_qty > min_qty - MinErr) {
                    sell_price = sell_entry_price;
                    q_pos = best_ask_qty;
                    Sell(strategy_fields, sell_price, sell_quote_qty, sellOrderTotalCount, net_pos_coin, max_pos, q_pos, TimeInForce::PO, 1);
                }
            }
            // sell exit
            else if ((net_pos_coin > MinErr) && sell_pred_exit_filter) {//
                sell_quote_qty = quote_qty;
                sell_quote_qty = std::min(sell_quote_qty, net_pos_coin);
                // sell_quote_qty = std::min(sell_quote_qty, max_pos-(sellOrderTotalCount - net_pos_coin));
                sell_quote_qty = GaiaUtils::floorSizeViaQtyTick(sell_quote_qty, main_contract);
                if (sell_quote_qty > min_qty - MinErr) {
                    sell_price = sell_exit_price;
                    q_pos = best_ask_qty;
                    Sell(strategy_fields, sell_price, sell_quote_qty, sellOrderTotalCount, net_pos_coin, max_pos, q_pos, TimeInForce::PO, 0);
                }
            }
        }

        num_ticks += 1;
        if (config.use_debug_msg && (_cur_tick_sid == main_contract->symbol_info->sid)){
            output.clear();
            output["pred_value"] = pred_value;
            output["theo_pred"] = theo_pred;
            output["mid_price"] = mid_price;
            output["buy_entry_price"] = buy_entry_price;
            output["sell_entry_price"] = sell_entry_price;
            output["buy_exit_price"] = buy_exit_price;
            output["sell_exit_price"] = sell_exit_price;
            output["buy_pred_value"] = buy_pred_value;
            output["sell_pred_value"] = sell_pred_value;
            output["net_pos_coin"] = net_pos_coin;
            output["sigma"] = sigma;
            output["sigma_factor"] = sigma_factor;
            output["mid_buffer_ret1"] = mid_buffer_ret1;
            output["mid_buffer_ret2"] = mid_buffer_ret2;
            output["mid_buffer_ret3"] = mid_buffer_ret3;
            output["bid"] = best_bid_price;
            output["bz"] = best_bid_qty;
            output["ask"] = best_ask_price;
            output["az"] = best_ask_qty;
            output["bid_deep"] = bid_deep;
            output["ask_deep"] = ask_deep;
            output["bz_deep"] = bz_deep;
            output["az_deep"] = az_deep;
            output["debug"] = 1;
            output["cur_tick_type"] = _cur_tick_type;
            output["cur_tick_sid"] = _cur_tick_sid; 
            output["trade_price"] = trade_price;
            output["trade_qty"] = trade_qty;
            if (trade_side == Side::BUY) {
                output["trade_side"] = 1;
            }
            else if (trade_side == Side::SELL) {
                output["trade_side"] = -1;
            }
	        auto cur_contract_info = (*strategy_fields.sid_contract_map)[strategy_fields.cur_tick_sid];
            LOG_AUTO(KronosFactorMsg, output, main_contract->symbol_info->mirana_ticker.c_str(),
                                            cur_contract_info->latency_record.mkt_data.mkt_recv_ts,
                                            cur_contract_info->latency_record.mkt_data.mkt_exch_ts);
        }
    }



    void Buy(StrategyFields& strategy_fields, double &price, double &qty, double &buyOrderTotalCount, double &cur_pos_coin, double &max_pos, double &q_pos, TimeInForce tif, double stra_order_type)
    {
        ContractInfo* &main_contract  = strategy_fields.contract_info;
        double buy_total_risk = buyOrderTotalCount + cur_pos_coin;
        if (buy_total_risk <= max_pos){
            price = roundTickSize(price, main_contract->symbol_info->prc_tick_size);
            qty = roundTickSize(qty, main_contract->symbol_info->qty_tick_size);
            GOrderState* new_order_state = GOrderOp::InsertOrder(strategy_fields, price, qty, Side::BUY, OrderType::LIMIT, tif, PositionOffset::UNKNOWN, stra_order_type);
            new_order_state->queue_front_pos = q_pos;

            output.clear();
            output["client_order_id"] = new_order_state->ts_order->client_order_id().value;
            output["pred_value"] = pred_value;
            output["theo_pred"] = theo_pred;
            output["buy_entry_price"] = buy_entry_price;
            output["sell_entry_price"] = sell_entry_price;
            output["buy_exit_price"] = buy_exit_price;
            output["sell_exit_price"] = sell_exit_price;
            output["buy_pred_value"] = buy_pred_value;
            output["sell_pred_value"] = sell_pred_value;
            output["net_pos_coin"] = net_pos_coin;
            output["sigma"] = sigma;
            output["sigma_factor"] = sigma_factor;
            output["mid_buffer_ret1"] = mid_buffer_ret1;
            output["mid_buffer_ret2"] = mid_buffer_ret2;
            output["mid_buffer_ret3"] = mid_buffer_ret3;
            output["bid"] = best_bid_price;
            output["ask"] = best_ask_price;
            output["bz"] = best_bid_qty;
            output["az"] = best_ask_qty;
            output["bid_deep"] = bid_deep;
            output["ask_deep"] = ask_deep;
            output["bz_deep"] = bz_deep;
            output["az_deep"] = az_deep;
            output["trade_price"] = trade_price;
            output["trade_qty"] = trade_qty;
            if (trade_side == Side::BUY) {
                output["trade_side"] = 1;
            }
            else if (trade_side == Side::SELL) {
                output["trade_side"] = -1;
            }
	        auto cur_contract_info = (*strategy_fields.sid_contract_map)[strategy_fields.cur_tick_sid];
            LOG_AUTO(KronosFactorMsg, output, main_contract->symbol_info->mirana_ticker.c_str(),
                                            cur_contract_info->latency_record.mkt_data.mkt_recv_ts,
                                            cur_contract_info->latency_record.mkt_data.mkt_exch_ts);
        }
    }

    void Sell(StrategyFields& strategy_fields, double &price, double &qty, double &sellOrderTotalCount, double &cur_pos_coin, double &max_pos, double &q_pos, TimeInForce tif, double stra_order_type)
    {
        ContractInfo* &main_contract  = strategy_fields.contract_info;
        double sell_total_risk = sellOrderTotalCount - cur_pos_coin;
        if (sell_total_risk <= max_pos){
            price = roundTickSize(price, main_contract->symbol_info->prc_tick_size);
            qty = roundTickSize(qty, main_contract->symbol_info->qty_tick_size);
            GOrderState* new_order_state = GOrderOp::InsertOrder(strategy_fields, price, qty, Side::SELL, OrderType::LIMIT, tif, PositionOffset::UNKNOWN, stra_order_type);
            new_order_state->queue_front_pos = q_pos;

            output.clear();
            output["client_order_id"] = new_order_state->ts_order->client_order_id().value;
            output["pred_value"] = pred_value;
            output["theo_pred"] = theo_pred;
            output["buy_entry_price"] = buy_entry_price;
            output["sell_entry_price"] = sell_entry_price;
            output["buy_exit_price"] = buy_exit_price;
            output["sell_exit_price"] = sell_exit_price;
            output["buy_pred_value"] = buy_pred_value;
            output["sell_pred_value"] = sell_pred_value;
            output["net_pos_coin"] = net_pos_coin;
            output["sigma"] = sigma;
            output["sigma_factor"] = sigma_factor;
            output["mid_buffer_ret1"] = mid_buffer_ret1;
            output["mid_buffer_ret2"] = mid_buffer_ret2;
            output["mid_buffer_ret3"] = mid_buffer_ret3;
            output["bid"] = best_bid_price;
            output["ask"] = best_ask_price;
            output["bz"] = best_bid_qty;
            output["az"] = best_ask_qty;
            output["bid_deep"] = bid_deep;
            output["ask_deep"] = ask_deep;
            output["bz_deep"] = bz_deep;
            output["az_deep"] = az_deep;
            output["trade_price"] = trade_price;
            output["trade_qty"] = trade_qty;
            if (trade_side == Side::BUY) {
                output["trade_side"] = 1;
            }
            else if (trade_side == Side::SELL) {
                output["trade_side"] = -1;
            }
	        auto cur_contract_info = (*strategy_fields.sid_contract_map)[strategy_fields.cur_tick_sid];
            LOG_AUTO(KronosFactorMsg, output, main_contract->symbol_info->mirana_ticker.c_str(),
                                            cur_contract_info->latency_record.mkt_data.mkt_recv_ts,
                                            cur_contract_info->latency_record.mkt_data.mkt_exch_ts);
        }
    }

    double roundTickSize(double input, double tick_size) {
        double rounded_input = std::round(input / tick_size) * tick_size;
        return rounded_input;
    }

    double computeGATheo(double best_bid_price, double best_ask_price, double best_bid_qty, double best_ask_qty,  double trade_price)
    {
        double bid_qty = best_bid_qty;
        double ask_qty = best_ask_qty;
        double alpha = config.theo_alpha;
        if (bid_qty > MinErr && ask_qty > MinErr){
            bid_qty = std::pow(best_bid_qty, config.theo_gamma);
            ask_qty = std::pow(best_ask_qty, config.theo_gamma);
        }
        double theo = (1.0 - alpha)*(bid_qty*best_ask_price + ask_qty*best_bid_price)/(bid_qty + ask_qty) + alpha*trade_price;
        return theo;
    }


    void CalBidDeepPriceSize(const ContractInfo* contract, const int level, double &turnover, double &price, double &size) {
        price = 0;
        size = 0;
        turnover = 0; 

        int book_level = GaiaUtils::BookGetNumBidLevels(contract);
        for (int i = 0; i < book_level; i++) {
            size += contract->alphaBook->bid(i).qty;
            turnover += contract->alphaBook->bid(i).qty*contract->alphaBook->bid(i).price;
            if (i == level-1) {
                if (size > eps) {
                    price = turnover/size;
                }
                break;
            }
        }

        if (level > book_level) {
            if (size > eps) {
                price = turnover/size;
            }
        }
    }

    void CalAskDeepPriceSize(const ContractInfo* contract, const int &level, double &turnover, double &price, double &size) {
        price = 0;
        size = 0;
        turnover = 0; 

        int book_level = GaiaUtils::BookGetNumAskLevels(contract);
        for (int i = 0; i < book_level; i++) {
            size += contract->alphaBook->ask(i).qty;
            turnover += contract->alphaBook->ask(i).qty*contract->alphaBook->ask(i).price;
            if (i == level-1) {
                if (size > eps) {
                    price = turnover/size;
                }
                break;
            }
        }

        if (level > book_level) {
            if (size > eps) {
                price = turnover/size;
            }
        }
    }

    void CalBidDeepPrice(const ContractInfo* contract, const double amount, double &price) {
        price = 0;
        double turnover = 0; 

        int book_level = GaiaUtils::BookGetNumBidLevels(contract);
        for (int i = 0; i < book_level; i++) {
            turnover += contract->alphaBook->bid(i).qty*contract->alphaBook->bid(i).price*contract->symbol_info->multiplier;
            if (turnover >= amount) {
                price = contract->alphaBook->bid(i).price;
                break;
            }
        }
    }

    void CalAskDeepPrice(const ContractInfo* contract, const double amount, double &price) {
        price = 0;
        double turnover = 0; 

        int book_level = GaiaUtils::BookGetNumAskLevels(contract);
        for (int i = 0; i < book_level; i++) {
            turnover += contract->alphaBook->ask(i).qty*contract->alphaBook->ask(i).price*contract->symbol_info->multiplier;
            if (turnover >= amount) {
                price = contract->alphaBook->ask(i).price;
                break;
            }
        }
    }


    void FindBidDeepPrice(const ContractInfo* contract, const double price, int &level) {
        int book_level = GaiaUtils::BookGetNumBidLevels(contract);
        for (int i = 0; i < book_level; i++) {
            if (contract->alphaBook->bid(i).price <= price) {
                level = i;
                return;
            }
        }
        level = book_level;
    }

    void FindAskDeepPrice(const ContractInfo* contract, const double price, int &level) {
        int book_level = GaiaUtils::BookGetNumAskLevels(contract);
        for (int i = 0; i < book_level; i++) {
            if (contract->alphaBook->ask(i).price >= price) {
                level = i;
                return;
            }
        }
        level = book_level;
    }





    };
