class DataPreprocessorConfig:
    def __init__(self):
        self.preprocessors = []

    def set_values(self, config={}):
        for preprocessor in self.preprocessors:
            ## if name is already in the list, return
            if preprocessor['name'] == config['name']:
                return

        ## if name is not in the list, add it
        self.preprocessors.append(config)

class CommonConfig:
    def __init__(self):
        self.set_default_values()
    
    def set_default_values(self, use_synthetic_fill=False,
                                 use_qry_pos_result=True,
                                 is_margin_trading=False,
                                 use_batch_mode = False,
                                 only_log_exec=False,
                                 use_fullliq_in_riskexit=False,
                                 use_initial_pos_coin = False,
                                 use_qry_pos_monitor = False,
                                 valid_pos_max_sec = 30,
                                 abnormal_duration_sec = 180,
                                 initial_pos_coin = {},
                                 predictor_trade_mode = 'hybrid', # options: only_dmm, only_public, other: hybrid
                                 use_orderbook=True,
                                 use_bestquote=True,
                                 use_trade=True,
                                 use_liquidation=True,
                                 use_fundingrate=True,
                                 use_kline=True,
                                 use_dmm_trade=True,
                                 data_preprocessor_config=[]):

        self.use_synthetic_fill = use_synthetic_fill
        self.use_qry_pos_result = use_qry_pos_result
        self.is_margin_trading = is_margin_trading
        self.use_batch_mode = use_batch_mode
        self.only_log_exec = only_log_exec
        self.use_fullliq_in_riskexit = use_fullliq_in_riskexit
        self.use_initial_pos_coin = use_initial_pos_coin
        self.use_qry_pos_monitor = use_qry_pos_monitor
        self.valid_pos_max_sec = valid_pos_max_sec
        self.abnormal_duration_sec = abnormal_duration_sec
        self.initial_pos_coin = initial_pos_coin
        self.predictor_trade_mode = predictor_trade_mode
        self.use_orderbook = use_orderbook
        self.use_bestquote = use_bestquote
        self.use_trade = use_trade
        self.use_liquidation = use_liquidation
        self.use_fundingrate = use_fundingrate
        self.use_kline = use_kline
        self.use_dmm_trade = use_dmm_trade
        self.data_preprocessor_config = data_preprocessor_config

    def set_values(self, **kwargs):
        for key in kwargs:
            if hasattr(self, key) == False:
                print(f"{key} is not a valid attribute")
                exit(0)
            setattr(self, key, kwargs[key])

class OrderLogicCommonConfig:
    def __init__(self):
        self.set_default_values()
    
    def set_default_values(self,
                    use_synthetic_fill=False,
                    notional_size=100,
                    custom_coin_size = 0.01,
                    max_pos_in_clips=3,
                    stop_loss=-50000,
                    stop_loss_duration_sec=15,
                    stop_loss_use_unrealized = True,
                    stop_loss_use_drawdown = True,
                    use_full_liquidation=True,
                    use_market_order_for_liq=False,
                    liquidate_take_bp=200,
                    liquidate_max_notional=50000,
                    liquidate_min_notional=5,
                    use_reduce_only_mode=False,
                    use_fr_check=False,
                    reduce_only_minute_before_fr=20,
                    reduce_only_minute_after_fr=10,
                    reduce_only_param_multi=1,
                    use_reduceonly_for_liq=False,
                    cancel_interval_ms=100,
                    round_for_hyperliquid =False,
                    mkt_timeout_ns = 300000000,
                    use_balance_limit_mode=False,
                    balance_limit_recovery_sec=5,
                    rate_limit_duration_ms=0):

        self.use_synthetic_fill = use_synthetic_fill
        self.notional_size = notional_size
        self.custom_coin_size = custom_coin_size
        self.max_pos_in_clips = max_pos_in_clips
        self.stop_loss = stop_loss
        self.stop_loss_duration_sec = stop_loss_duration_sec
        self.stop_loss_use_unrealized = stop_loss_use_unrealized
        self.stop_loss_use_drawdown = stop_loss_use_drawdown
        self.use_full_liquidation = use_full_liquidation
        self.use_market_order_for_liq = use_market_order_for_liq
        self.liquidate_take_bp = liquidate_take_bp
        self.liquidate_max_notional = liquidate_max_notional
        self.liquidate_min_notional = liquidate_min_notional
        self.use_reduce_only_mode = use_reduce_only_mode
        self.use_fr_check = use_fr_check
        self.reduce_only_minute_before_fr = reduce_only_minute_before_fr
        self.reduce_only_minute_after_fr = reduce_only_minute_after_fr
        self.reduce_only_param_multi = reduce_only_param_multi
        self.use_reduceonly_for_liq = use_reduceonly_for_liq
        self.cancel_interval_ms = cancel_interval_ms
        self.round_for_hyperliquid = round_for_hyperliquid
        self.mkt_timeout_ns = mkt_timeout_ns
        self.use_balance_limit_mode = use_balance_limit_mode
        self.balance_limit_recovery_sec = balance_limit_recovery_sec
        self.rate_limit_duration_ms = rate_limit_duration_ms

    def set_values(self, **kwargs):
        for key in kwargs:
            if hasattr(self, key) == False:
                print(f"{key} is not a valid attribute")
                exit(0)
            setattr(self, key, kwargs[key])
