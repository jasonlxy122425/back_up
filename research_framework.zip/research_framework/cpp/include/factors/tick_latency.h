#include "Factor.h"
#include "Ema.h"


class TickLatencyFactor : public FactorInterface
{
public:
    TickLatencyFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");

    };

    virtual std::string gen_name() {
        return std::string("TickLatencyFactor");
    }

    virtual void calculate(const FactorInput& input_data) {
        factor_value = 0.0;
        int64_t exch_ts = input_data.cur_contract->alphaBook->exch_ts();
        int64_t recv_ts = input_data.cur_contract->latency_record.mkt_data.mkt_recv_ts;
        factor_value = std::log(recv_ts - exch_ts + 1.0);
    };
};
                              