#pragma once

#include "PredictorGeneral.h"
#include "GaiaUtils.h"
#include "SystemDefine.h"
#include <memory>
#include <parallel_hashmap/phmap.h>
#include "DataPreprocessResult.h"

class DataPreprocessorInterface {
public:
    virtual ~DataPreprocessorInterface() = default;
    virtual void Init(const Config& config) {}
    
    virtual void Process(ContractInfo* contract, const TickEventType& tick_type,
                                        GLatencyRecord* latency_record, PreprocessResult* result) = 0;
};

class PreprocessorCenter {
public:
    PreprocessorCenter(const std::vector<Config>& config);
    
    void Process(ContractInfo* contract, const TickEventType& cur_tick_type,
                                   GLatencyRecord* latency_record);

    PreprocessResult* GetResultPtr() {
        return &result_;
    }
private:
    std::vector<std::unique_ptr<DataPreprocessorInterface>> preprocessors_;
    PreprocessResult result_;
    
    void AddPreprocessor(std::unique_ptr<DataPreprocessorInterface> preprocessor) {
        preprocessors_.push_back(std::move(preprocessor));
    }

    class DataPreprocessorFactory {
    public:
        static std::unique_ptr<DataPreprocessorInterface> Create(const std::string& name);
    };
};
