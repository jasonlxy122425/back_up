#ifndef __COMMON_DEFINE_H__
#define __COMMON_DEFINE_H__
#include "SystemDefine.h"

#define eps 1e-12
#define MinErr 1e-12

#define ONE_MILLI_IN_NANOS 1000000L
#define ONE_SECOND_IN_NANOS 1000000000L
#define ONE_DAY_IN_SECONDS 24 * 60 * 60L

#define ONE_BASE_POINT (double)10000

#define SIGN(a) (a < 0 ? -1 : 1)

#define G_INLINE __attribute__((always_inline)) inline
#define G_LIKELY(x) __builtin_expect(!!(x), 1)
#define G_UNLIKELY(x) __builtin_expect(!!(x), 0)

enum StrategyMode
{
    NormalMode = 1,
    ReduceOnlyMode = 2,
    BalanceLimitMode = 3,
    RateLimitMode = 4,
    UnknownMode = 49,

    LiquidateRiskMode = 50,
    FullLiquidationMode = 51,

    AbnormalPosMode = 52,

    NormalExitMode = 98,
    ExitMode = 99,
    RiskExitMode = 100,
    DisconnectMode = 101,

};

inline std::string getStrategyModeStr(const StrategyMode &mode)
{
    std::string mode_str = "Unknown";
    switch(mode) {
        case StrategyMode::UnknownMode:
        mode_str = "UnknownMode";
        break;
        case StrategyMode::NormalMode:
        mode_str = "NormalMode";
        break;
        case StrategyMode::BalanceLimitMode:
        mode_str = "BalanceLimitMode";
        break;
        case StrategyMode::RateLimitMode:
        mode_str = "RateLimitMode";
        break;
        case StrategyMode::AbnormalPosMode:
        mode_str = "AbnormalPosMode";
        break;
        case StrategyMode::LiquidateRiskMode:
        mode_str = "LiquidateRiskMode";
        break;
        case StrategyMode::FullLiquidationMode:
        mode_str = "FullLiquidationMode";
        break;
        case StrategyMode::ReduceOnlyMode:
        mode_str = "ReduceOnlyMode";
        break;
        case StrategyMode::NormalExitMode:
        mode_str = "NormalExitMode";
        break;
        case StrategyMode::ExitMode:
        mode_str = "ExitMode";
        break;
        case StrategyMode::RiskExitMode:
        mode_str = "RiskExitMode";
        break;
        case StrategyMode::DisconnectMode:
        mode_str = "DisconnectMode";
        break;
        default:
        break;
    }
    return mode_str;
}

struct StrategySnapshot
{
    int64_t last_insert_or_replace_ts = 0;
    char mode_change_reason[128];
};

enum TickEventType
{
    TICK_NONE = 0,            // No Update
    TICK_BBO= 1,              // Best Bid Offer
    TICK_OB = 2,              // Any Bid Offer
    TICK_TRADE = 4,           // Trades
    TICK_OB_UPDATE = 8,       // orderbook update
    TICK_LIQUIDATION = 16,    // liquidation
    TICK_KLINE = 32,          // kline
    TICK_SIGNAL = 64,         // signal update
    TICK_WARMUP = 128,         // warmup update
    TICK_ERROR = 256,         // Error on processing update
    TICK_ALL = 0xFFFF         // No filter
};

inline TickEventType ToTickEventType(MessageType type) {
    switch(type) {
        case MessageType::BEST_QUOTE:
            return TickEventType::TICK_BBO;
        case MessageType::ORDERBOOK:
            return TickEventType::TICK_OB;
        case MessageType::TRADE:
            return TickEventType::TICK_TRADE;
        case MessageType::ORDERBOOK_UPDATE:
            return TickEventType::TICK_OB_UPDATE;
        case MessageType::LIQUIDATION:
            return TickEventType::TICK_LIQUIDATION;
        case MessageType::KLINE:
            return TickEventType::TICK_KLINE;
        case MessageType::FUNDING_RATE:
            return TickEventType::TICK_NONE; // Funding rate is not a tick event
        default:
            return TickEventType::TICK_NONE;
    }
}
#endif
