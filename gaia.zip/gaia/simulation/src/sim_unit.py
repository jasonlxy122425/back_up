import datetime, os, sys, importlib, hashlib, shutil, json, yaml, copy
from sim_utils import *
from data_source import *

cur_dir = os.getcwd()
config_src_path = f"{cur_dir}/../../gaia_config/configs/src"
sys.path.append(config_src_path)
from FileGenerator import *

class SimUnit:
    def __init__(self, config, output_path, bin_path):
        if hasattr(config, "start_date") == False or hasattr(config, "end_date") == False:
            print("error: cannot find start_date or end_date in config")
            exit(0)
        self.data = {}
        self.data['config'] = config

        if hasattr(config, "sign_str") == False:
            print("error: cannot find sign_str in config")
            exit(0)

        date_str = f"{config.start_date}_{config.end_date}"
        if config.simConfig.sim_data_mode == 'split_by_day':
            self.data['target_path'] = f"{output_path}/{config.tag}/{config.quoter_symbol}/{config.sign_str}/{date_str}"
        else:
            self.data['target_path'] = f"{output_path}/{config.tag}/{config.quoter_symbol}/{config.sign_str}/{date_str}"

        self.data['bin_path'] = bin_path
        self.data['lib_path'] = f"{cur_dir}/../libs"
        self.data['alphaless_lib_path'] = f"{cur_dir}/../../alphaless-cpp/lib"
        if hasattr(config, 'predictorConfig') and hasattr(config.predictorConfig, 'model_path'):
            self.data['model_path'] = config.predictorConfig.model_path
            print(f"data['model_path']: {self.data['model_path']}")

        self.file_generator = FileGenerator()


    def setMdDumpFile(self, data_files : list):
        self.data['data_files'] = data_files

    def setDataFile(self, config_path):
        with open(config_path, 'r') as f:
            data = yaml.load(f, Loader=yaml.FullLoader)
        data['strategy']['log_path'] = "./" 
        data['md_data'] = []
        for data_file in self.data['data_files']:
            data['md_data'].append({
                "path": data_file,
                "latency": "0us"
            })
        
        with open(config_path, 'w') as f:
            content = yaml.dump(data, sort_keys=False)
            f.write(content)

    def run(self):

        ## prepare output dir
        try:
            shutil.rmtree(self.data['target_path'])
        except:
            pass

        os.system(f"mkdir -p {self.data['target_path']}")

        ## generate config
        self.file_generator.generateYaml(self.data['config'], self.data['target_path'], 0)

        config_name = f"{self.data['config'].strategy_name}.yml"
        self.setDataFile(f"{self.data['target_path']}/{config_name}")

        ## copy binary
        # print(f"cp {self.data['bin_path']} {self.data['target_path']}")
        '''
        ret = os.system(f"cp {self.data['bin_path']} {self.data['target_path']}")
        if ret != 0:
            print("error: copy binary failed")
            return
        '''

        ## gen sign file
        with open(f"{self.data['target_path']}/sign.txt",'w') as f:
            f.write(json.dumps(self.data['config'].sign))
        
        ## copy model file
        if self.data.get('model_path') != None and self.data.get('model_path') != "":
            ret = os.system(f"cp {self.data['model_path']} {self.data['target_path']}/")
            if ret != 0:
                print("error: copy model file failed")
                return
        
        ## copy library
        '''
        ret = os.system(f"cp {os.path.dirname(self.data['bin_path'])}/../../../alphaless-cpp/lib/libalphaless.so {self.data['target_path']}")
        if ret != 0:
            print("error: copy library failed")
            return

        ret = os.system(f"cp {self.data['lib_path']}/*.so* {self.data['target_path']}")
        if ret != 0:
            print("error: copy order logic library failed")
            return
        '''

        bin_name = os.path.basename(self.data['bin_path'])

        alphaless_lib_path = self.data['alphaless_lib_path']
        gaia_lib_path = self.data['lib_path']
        config = self.data['config']
        print(f"{config.tag} {config.quoter_symbol} {config.sign_str} start")

        
        '''
        print(f"cd {self.data['target_path']} ; " \
                  f"export LD_LIBRARY_PATH=./:/usr/local/lib64:/usr/local/lib ; " \
                  f"./{bin_name} ./{config_name} > output.log 2>&1")
        '''
        std_out_path = 'output.log'
        if config.commonConfig.only_log_exec == True:
            std_out_path = '/dev/null'
        ret = os.system(f"cd {self.data['target_path']} ; " \
                f"export LD_LIBRARY_PATH=/usr/local/lib64:/usr/local/lib:{alphaless_lib_path}:{gaia_lib_path} ; " \
                  f"{self.data['bin_path']} ./{config_name} > {std_out_path} 2>&1"
                  )

        # if ret != 0:
        #     config = self.data['config']
        #     print(f"error:  run failed , {config.tag} {config.mirana_ticker} {config.sign}")
        #     return
            

        print(f"{config.tag} {config.quoter_symbol} {config.sign_str} successfully done")
        

        
    
class SimUnitBuilder:
    @classmethod
    def buildSimUnit(cls, config_path : str, output_path : str, bin_path : str):
        config_dir = os.path.dirname(config_path)
        config_file_name = os.path.splitext(os.path.basename(config_path))[0]
        sys.path.append(config_dir)

        print(f"using config:{config_path}")

        sim_module = importlib.import_module(config_file_name)
        configs = sim_module.TagConfig().getConfig()
        try:
            sim_module = importlib.import_module(config_file_name)
            configs = sim_module.TagConfig().getConfig()
        except Exception as e:
            print(f"import {config_file_name} error, {e}")
            exit(0)
        

        sim_units = []
        ds = DataSource()
        for config in configs:
            units = SimUnitBuilder.build(ds,config, output_path, bin_path) 

            sim_units.extend(units)

        return sim_units

    @classmethod
    def build(cls, ds, config, output_path, bin_path):
        units = []
        if config.simConfig.sim_data_mode == 'split_by_day':
            start_date = datetime.datetime.strptime(config.start_date, "%Y%m%d")
            end_date = datetime.datetime.strptime(config.end_date, "%Y%m%d")
            while start_date <= end_date:
                new_config = copy.deepcopy(config)
                new_config.start_date = start_date.strftime("%Y%m%d")
                new_config.end_date = start_date.strftime("%Y%m%d")
                unit = SimUnit(new_config, output_path, bin_path)
                unit.setMdDumpFile(ds.getDataFiles(new_config.strategy_name, new_config))
                units.append(unit)
                start_date += datetime.timedelta(days=1)
        else:
            unit = SimUnit(config, output_path, bin_path)
            unit.setMdDumpFile(ds.getDataFiles(config.strategy_name, config))
            units.append(unit)

        return units
            
