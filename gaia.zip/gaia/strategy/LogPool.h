#pragma once
#include <vector>
#include <mutex>
#include <memory>
#include <atomic>
#include <thread>
#include <queue>
#include <cstdlib>  // for std::aligned_alloc and std::free
#include <mutex>    // for std::once_flag and std::call_once
#include <iostream>

template<typename T>
class ThreadLocalPool;

// Global shared memory pool for cross-thread recycling
template<typename T>
class GlobalMessagePool {
private:
    constexpr static size_t G_DEFAULT_POOL_SIZE = 64;
    std::mutex pool_mutex;
    std::queue<void*> free_queue;  // 存储原始内存而不是构造的对象
    std::atomic<bool> initialized_{false};
    
    template<typename U> friend class ThreadLocalPool;
    
public:
    GlobalMessagePool() {
    }
    
    ~GlobalMessagePool() {
        // 清理预分配的内存
        while (!free_queue.empty()) {
            std::free(free_queue.front());
            free_queue.pop();
        }
    }
    
    static GlobalMessagePool& instance() {
        static GlobalMessagePool pool;
        return pool;
    }
    
    // 预热函数：预分配内存池
    void warmup() {
        if (initialized_.exchange(true)) {
            return; // 已经预热过了
        }
        
        std::lock_guard<std::mutex> lock(pool_mutex);
        // 预分配原始内存，不调用构造函数
        for (size_t i = 0; i < G_DEFAULT_POOL_SIZE; ++i) {
            free_queue.push(std::aligned_alloc(alignof(T), sizeof(T)));
        }
    }
    
    void* acquire() {
        // 确保已经预热
        if (!initialized_.load()) {
            warmup();
        }
        
        std::lock_guard<std::mutex> lock(pool_mutex);
        if (free_queue.empty()) {
            free_queue.push(std::aligned_alloc(alignof(T), sizeof(T)));
        }
        void* ptr = free_queue.front();
        free_queue.pop();
        return ptr;
    }
    
    void release(T* obj) {
        std::lock_guard<std::mutex> lock(pool_mutex);
        // 显式调用析构函数，但不释放内存
        obj->~T();
        free_queue.push(static_cast<void*>(obj));
    }
};

// Thread-local cache with batch allocation
template<typename T>
class ThreadLocalPool {
private:
    static constexpr size_t G_BATCH_SIZE = 16;
    std::vector<void*> local_cache;  // 存储原始内存指针

public:
    ~ThreadLocalPool() {
        // Return unused memory to global pool
        auto& global_pool = GlobalMessagePool<T>::instance();
        for (auto* ptr : local_cache) {
            // 这些内存从未构造过对象，直接返回原始内存
            std::lock_guard<std::mutex> lock(global_pool.pool_mutex);
            global_pool.free_queue.push(ptr);
        }
    }
    
    void* acquire() {
        if (local_cache.empty()) {
            // Batch refill from global pool
            for (int i = 0; i < G_BATCH_SIZE; i++) {
                local_cache.push_back(GlobalMessagePool<T>::instance().acquire());
            }
        }

        void* ptr = local_cache.back();
        local_cache.pop_back();
        return ptr;
    }
};

// Thread-local pools for fast allocation
template<typename T>
T* getLogMessage() {
    thread_local ThreadLocalPool<T> local_pool;
    return static_cast<T*>(local_pool.acquire());
}

void warmupLogPools();
