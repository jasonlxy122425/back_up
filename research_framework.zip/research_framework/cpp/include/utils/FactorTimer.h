#pragma once

#include <functional>
#include <limits>
#include <memory>
#include <queue>
#include <vector>
#include "CommonDefine.h"

class FactorTimer {
  public:
    using CallbackFunc = std::function<void()>;

    // Run func at the specified time
    void Add(Nanoseconds start_tm, CallbackFunc func) {
        Add(start_tm, 0, 0, std::move(func));
    }

    // Run func at a fixed interval, starting at start_tm
    void Add(Nanoseconds start_tm, Nanoseconds interval, CallbackFunc func) {
        Add(start_tm, interval, std::numeric_limits<Nanoseconds>::max(), std::move(func));
    }

    // Run func at a fixed interval, starting at start_tm and ending at end_tm
    void Add(Nanoseconds start_tm, Nanoseconds interval, Nanoseconds end_tm, CallbackFunc func) {
        if (interval > 0) {
            if (end_tm > tm_) {
                auto cb = std::make_shared<Callback>();
                cb->next_tm = start_tm;
                cb->interval = interval;
                cb->end_tm = end_tm;
                cb->func = std::move(func);
                Add(std::move(cb));
            }
        } else if (start_tm > tm_) {
            auto cb = std::make_shared<Callback>();
            cb->next_tm = start_tm;
            cb->func = std::move(func);
            queue_.push(std::move(cb));
        }
    }

    int Update(Nanoseconds now) {
        int count = 0;
        tm_ = now;
        while (!queue_.empty() && queue_.top()->next_tm <= tm_) {
            auto cb = queue_.top();
            queue_.pop();
            cb->func();
            ++count;
            if (cb->interval > 0) {
                Add(std::move(cb));
            }
        }
        return count;
    }

    Nanoseconds tm() const {
        return tm_;
    }

  private:
    struct Callback {
        Nanoseconds next_tm;
        Nanoseconds interval = 0;
        Nanoseconds end_tm;
        CallbackFunc func;
    };

    struct CmpCallback {
        bool operator()(const std::shared_ptr<Callback> &cb1, const std::shared_ptr<Callback> &cb2) {
            return cb1->next_tm > cb2->next_tm;
        }
    };

    Nanoseconds tm_ = 0;
    std::priority_queue<std::shared_ptr<Callback>, std::vector<std::shared_ptr<Callback>>,
        CmpCallback>
        queue_;

    void Add(std::shared_ptr<Callback> cb) {
        if (cb->interval <= 0) return;
        if (cb->next_tm <= tm_) {
            cb->next_tm = cb->next_tm + (tm_ - cb->next_tm + cb->interval) / cb->interval * cb->interval;
        }
        if (cb->next_tm <= cb->end_tm) {
            queue_.push(std::move(cb));
        }
    }
};