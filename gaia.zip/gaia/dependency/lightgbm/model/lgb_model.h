//
// Created by Hongjian Han on 8/28/22.
//
# pragma once
# include <iostream>
# include <fstream>
# include <vector>
# include <cmath>
# include "./base_model.h"
# include "../common/CompilerSpecific.h"
# include "../c_api.h"

class LGB : public BaseModel {
private:
    std::vector<double> x_std_ = {};
    long unsigned int input_size_ = 0;
    FastConfigHandle fc_handle_ = nullptr;
    std::string model_dir_ = std::string("None");
    double *out_result = nullptr;

public:
    LGB() : BaseModel() {};

    ~LGB() override = default;

    void get_model_dir(const std::string & dir) override
    {
        model_dir_ = dir;
    }

    bool init(const rapidjson::Document &d) override
    {
        // Load x_std
        if (UNLIKELY(!d.HasMember("x_std")))
        {
            std::cout << "json file doesn't have x_std" << std::endl;
            return false;
        }
        auto x_std_j = d["x_std"].GetArray()[0].GetArray();
        for(unsigned int i = 0; i < x_std_j.Size(); ++i){
            x_std_.push_back(x_std_j[i].GetDouble());
        }
        input_size_ = x_std_.size();
        int tmp;
        int p = 1;
        BoosterHandle handle;
        tmp = LGBM_BoosterCreateFromModelfile(model_dir_.c_str(), &p, &handle);
        if (tmp != 0)
        {
            std::cout << "Load lgb model txt file failed." << std::endl;
            return false;
        }
        int temp_init = LGBM_BoosterPredictForMatSingleRowFastInit(
                handle,
                C_API_PREDICT_NORMAL,
                0,
                -1,
                C_API_DTYPE_FLOAT64,
                input_size_,
                "None",
                &fc_handle_,
                nullptr
        );
        if (temp_init != 0)
        {
            std::cout << "LGBM_BoosterPredictForMatSingleRowFastInit failed." << std::endl;
            return false;
        }
        return true;
    }

    void calculate(const std::vector<double>& input, std::vector<double> & output) override
    {
        assert(output.empty());
        assert(input.size() == input_size_);
        std::vector<double> i_v = {};
        for (size_t i = 0; i != input_size_; ++i)
        {
            i_v.push_back(input[i] / x_std_[i]);
        }
        auto *in_p = i_v.data();
        int64_t out_len;
        out_result = output.data();
        LGBM_BoosterPredictForMatSingleRowFast(
            fc_handle_,
            in_p,
            &out_len,
            out_result
        );
    }
};
