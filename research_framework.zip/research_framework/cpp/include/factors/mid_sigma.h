#include "Factor.h"
#include "Ema.h"
#include "GaiaCircularBuffer.h"
#include <cmath>

class MidSigmaFactor : public FactorInterface
{
public:
    MidSigmaFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
        lookback = config.Get<int64_t>("lookback");
        mid_buffer.setSize(lookback, 0.0);
        var_ewma = config.Get<double>("var_ewma");
        ewma_var = 0.0;
    };

    virtual std::string gen_name() {
        return std::string("MidSigmaFactor") + '@' + std::to_string(lookback) + '@' + std::to_string(var_ewma);
    }

    virtual void calculate(const FactorInput& input_data) {
        factor_value = 0.0;
        auto &gob = input_data.cur_contract->alphaBook;
        double px_tick_size = input_data.cur_contract->symbol_info->prc_tick_size;
        double mid_price = (gob->bid(0).price + gob->ask(0).price)/2.0;
        mid_buffer.push(mid_price);
        if(mid_buffer.isFull() != false){
            double mid_diff = mid_buffer.back() - mid_buffer.front();
            ewma_var = var_ewma*ewma_var + (1.0 - var_ewma)*std::pow(mid_diff, 2);
            factor_value = std::sqrt(ewma_var/lookback/px_tick_size);
        }
    };


private:
    double var_ewma;
    double ewma_var;
    int64_t lookback;
    GaiaCircularBuffer<double> mid_buffer;
};
                              
