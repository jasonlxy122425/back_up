#include <pybind11/pybind11.h>
#include <pybind11/stl.h>
#include <pybind11/numpy.h>
#include "alphaless/md/messages.h"


namespace py = pybind11;
void InitMd(py::module m) {
    using namespace alphaless;
    using namespace alphaless::md;

  py::enum_<MessageType>(m, "MessageType")
      .value("UNKNOWN", MessageType::UNKNOWN)
      .value("ORDERBOOK", MessageType::ORDERBOOK)
      .value("TRADE", MessageType::TRADE)
      .value("FUNDING_RATE", MessageType::FUNDING_RATE)
      .value("BEST_QUOTE", MessageType::BEST_QUOTE)
      .value("STATS_24H", MessageType::STATS_24H)
      .value("MARK_PRICE", MessageType::MARK_PRICE)
      .value("INDEX_PRICE", MessageType::INDEX_PRICE)
      .value("GREEKS", MessageType::GREEKS)
      .value("FLASH_RAW", MessageType::FLASH_RAW)
      .value("ORDERBOOK_UPDATE", MessageType::ORDERBOOK_UPDATE)
      .value("SETTLEMENT_PRICE", MessageType::SETTLEMENT_PRICE)
      .value("KLINE", MessageType::KLINE)
      .value("STATUS_UPDATE", MessageType::STATUS_UPDATE);

  py::enum_<Source>(m, "Source")
      .value("UNKNOWN", Source::UNKNOWN)
      .value("EXCHANGE", Source::EXCHANGE)
      .value("FLASH", Source::FLASH)
      .value("EXCHANGE_SIM", Source::EXCHANGE_SIM)
      .value("DMM", Source::DMM);


  py::enum_<Side>(m, "Side")
      .value("BUY", Side::BUY)
      .value("SELL", Side::SELL)
      .value("UNKNOWN", Side::UNKNOWN);

  py::class_<Message>(m, "Message")
      .def_readwrite("msg_type", &Message::msg_type, "alphaless.md.MessageType: msg type")
      .def_readwrite("recv_ts", &Message::recv_ts, "int: local receive timestamp in nanoseconds")
      .def_readwrite("exch_ts", &Message::exch_ts, "int: exchange timestamp in nanoseconds")
      .def_readwrite("sid", &Message::sid, "int: sid")
      .def_readwrite("src", &Message::src, "alphaless.md.Source: src");

  py::class_<Trade, Message>(m, "Trade")
       .def(py::init<>())
      .def_readwrite("side", &Trade::side, "alphaless.Side: taker side")
      .def_readwrite("price", &Trade::price, "float: price")
      .def_readwrite("qty", &Trade::qty, "float: qty")
      .def("set_trade_id", &Trade::set_trade_id, "func: set trade id");

  PYBIND11_NUMPY_DTYPE(PriceLevel, price, qty);
  py::class_<PriceLevel>(m, "PriceLevel")
      .def_readwrite("price", &PriceLevel::price, "float: price")
      .def_readwrite("qty", &PriceLevel::qty, "float: qty");

  py::class_<FlatOrderbookHead>(m, "FlatOrderbookHead")
       .def(py::init<>())
      .def_readwrite("seq_id", &FlatOrderbookHead::seq_id, "int: seq id")
      .def_readwrite("recv_ts", &FlatOrderbookHead::recv_ts, "int: local receive timestamp in nanoseconds")
      .def_readwrite("exch_ts", &FlatOrderbookHead::exch_ts, "int: exchange timestamp in nanoseconds")
      .def_readwrite("sid", &FlatOrderbookHead::sid, "int: sid")
      .def_readwrite("src", &FlatOrderbookHead::src, "alphaless.md.Source: src");
    py::class_<FlatOrderbookBase<500>, FlatOrderbookHead>(m, "FlatOrderbookBase500")
        .def(py::init<>())
        .def("bid", &FlatOrderbookBase<500>::bid)
        .def("ask", &FlatOrderbookBase<500>::ask)
        .def_readwrite("num_bids", &FlatOrderbookBase<500>::num_bids, "int: the number of bid levels")
        .def_readwrite("num_asks", &FlatOrderbookBase<500>::num_asks, "int: the number of ask levels")
        .def("byte_size", &FlatOrderbookBase<500>::byte_size)
        .def("bid_data", [](FlatOrderbookBase<500> &self) {
            return py::array_t<PriceLevel>(
                {self.num_bids},  // shape
                {sizeof(PriceLevel)},  // stride
                self.bid_data(),  // data pointer
                py::cast(&self)  // base object
            );
        })
        .def("ask_data", [](FlatOrderbookBase<500> &self) {
            return py::array_t<PriceLevel>(
                {self.num_asks},  // shape
                {sizeof(PriceLevel)},  // stride
                self.ask_data(),  // data pointer
                py::cast(&self)  // base object
            );
        });
  // clang-format off
  py::class_<FlatOrderbook>(m, "FlatOrderbook")
      .def_readwrite("num_bids", &FlatOrderbook::num_bids, "int: the number of bid levels")
      .def_readwrite("num_asks", &FlatOrderbook::num_asks, "int: the number of ask levels")
      .def_readwrite("seq_id", &FlatOrderbook::seq_id, "int: seq id")
      .def("bid", &FlatOrderbook::bid)
      .def("ask", &FlatOrderbook::ask);

  py::class_<FlatOrderbookData, FlatOrderbookBase<500>>(m, "FlatOrderbookData")
       .def(py::init<>())
      .def_readwrite("recv_ts", &FlatOrderbookData::recv_ts, "int: local receive timestamp in nanoseconds")
      .def_readwrite("exch_ts", &FlatOrderbookData::exch_ts, "int: exchange timestamp in nanoseconds")
      .def_readwrite("sid", &FlatOrderbookData::sid, "int: sid")
      .def_readwrite("src", &FlatOrderbookData::src, "alphaless.md.Source: src")
      .def("get_view", &FlatOrderbookData::get_view, py::return_value_policy::reference, "alphaless.md.FlatOrderbook: get view")
      .def("CopyFrom", &FlatOrderbookData::CopyFrom, "void: copy from book view")
      .def_readwrite("num_bids", &FlatOrderbookData::num_bids, "int: the number of bid levels")
      .def_readwrite("num_asks", &FlatOrderbookData::num_asks, "int: the number of ask levels")
      .def_readwrite("seq_id", &FlatOrderbookData::seq_id, "int: seq id")
      .def("bid", &FlatOrderbookData::bid)
      .def("ask", &FlatOrderbookData::ask)
      .def("bid_data", [](FlatOrderbookData &self) {
            return py::array_t<PriceLevel>(
                {self.num_bids},  // shape
                {sizeof(PriceLevel)},  // stride
                self.bid_data(),  // data pointer
                py::cast(&self)  // base object
            );
        })
      .def("ask_data", [](FlatOrderbookData &self) {
            return py::array_t<PriceLevel>(
                {self.num_asks},  // shape
                {sizeof(PriceLevel)},  // stride
                self.ask_data(),  // data pointer
                py::cast(&self)  // base object
            );
        });

//    py::class_<FlatOrderbookData>(m, "FlatOrderbookData")
//        .def(py::init<>())
//        .def("get_view", &FlatOrderbookData::get_view, "alphaless.md.FlatOrderbook: get view")
//        .def("CopyFrom", &FlatOrderbookData::CopyFrom, "void: copy from book view");

  py::class_<BestQuote, Message>(m, "BestQuote")
       .def(py::init<>())
      .def_readwrite("best_bid", &BestQuote::best_bid, "alphaless.md.PriceLevel: best bid")
      .def_readwrite("best_ask", &BestQuote::best_ask, "alphaless.md.PriceLevel: best ask")
      .def_readwrite("seq_id", &BestQuote::seq_id, "int: seq id");
};