#pragma once
#include <Factor.h>


class PriceEmaByTime : public FactorInterface
{
public:
    PriceEmaByTime(){}
    void Init(Config &config)
    {
        interval_ns = config.Get<int64_t>("interval_ns");
        exp_base = config.Get<double>("exp_base");
    }
    virtual std::string gen_name() {
        return std::string("PriceEmaByTime")+ '@' + std::to_string(interval_ns) + '@' + std::to_string(exp_base);
    }

    virtual void calculate(const FactorInput& input_data)
    {
        if(last_time == 0) {
            factor_value = input_data.price;
            last_time = input_data.current_time;

        }else if(input_data.current_time - last_time > interval_ns){
            double time_ratio = (input_data.current_time - last_time) / (double)(1000000000);
            double time_decay_rate = std::exp(-time_ratio / exp_base);

            prev_factor_value = factor_value;
            factor_value = time_decay_rate * (factor_value - input_data.price) + input_data.price;

            last_time = input_data.current_time;
        }
    }

private:
    int64_t interval_ns;
    int64_t exp_base;
};
