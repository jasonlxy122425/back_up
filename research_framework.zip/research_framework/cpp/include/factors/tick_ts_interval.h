#include "Factor.h"
#include "Ema.h"


class TickTsIntervalFactor : public FactorInterface
{
public:
    TickTsIntervalFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");

    };

    virtual std::string gen_name() {
        return std::string("TickTsIntervalFactor");
    }

    virtual void calculate(const FactorInput& input_data) {
        factor_value = 0.0;
        int64_t recv_ts = input_data.cur_contract->latency_record.mkt_data.mkt_recv_ts;
        if (prev_recv_ts > MinErr){
            factor_value = std::log(recv_ts - prev_recv_ts + 1.0);            
        }
        prev_recv_ts = recv_ts;
    };

private:
    int64_t prev_recv_ts = 0;
};
                              