import pickle
from Default.KronosConfig import *
from Default.DefaultCommonConfig import *

@config_interface
class TagConfig():
    def __init__(self):
        self.configs = []

    def genFactors(self, factor_path):
        with open(factor_path , 'rb') as file:
            factors = pickle.load(file)
        return factors

    def generateParams(self, sim_params, stra_params):
        config = KronosConfig("output_factors")
        config.num_of_book_levels = 25

        # predictor log
        config.predictorConfig.demeter_sample_num = stra_params["demeter_sample_size"]
        config.predictorConfig.factor_path  = stra_params["factor_path"]
        config.predictorConfig.model_path = stra_params["model_path"]
        config.predictorConfig.demeter_sample_type = stra_params["demeter_sample_type"]
        if stra_params["to_generate_factors"]:
            config.predictorConfig.factors = self.genFactors(config.predictorConfig.factor_path)
        else:
            config.predictorConfig.factors = []

        # orderlogic log
        for key, value in stra_params.items():
            print(key, value)
            setattr(config.orderLogicConfig, key, value)
        sim_output_engine = "parquet"
        if stra_params["to_output_gob"] is None:
            sim_output_engine = None
        # sim 
        config.set_sim(mode = 'SIM',
                    start_date = sim_params["start_date"],
                    end_date = sim_params["end_date"],
                    sign_str = sim_params["sign_str"],
                    target_server =  sim_params["target_server"],
                    #target_path = "/home/master/Data/md_dump/",
                    sim_engine = 'alphaless',
                    sim_output_engine = sim_output_engine,
                    sim_output_target = './gaia_orderbook.parquet',
                    sim_output_factors = stra_params["to_output_factors"],
                    sim_output_sample_count = stra_params["output_sample_size"],

                    )

        config.setSymbol(sim_params["target_instrument"])
        return config 

    def getConfig(self):
        sim_params = {
            "start_date": '20250225',
            "end_date": '20250225',
            "target_exchange": f"Bybit",
            "target_instrument": f"Bybit_LinearSwap_BTCUSDT",
            "target_server": "sgp-kronos-prod-md-az2-01",
        }
        stra_params = {
            "to_generate_factors": True,
            "to_output_factors": True,
            "to_output_gob": True,
            "demeter_sample_type": "tick",
            "demeter_sample_size": 100,
            "output_sample_size": 10,
            "factor_path": "/mnt/share/jsc/config/pred/test/factors2.txt",
            "model_path": "",
            "mkt_timeout_ns": 3000000000,
        }
        for instrument_name in [f"Bybit_LinearSwap_BTCUSDT",]:
            sim_params["target_instrument"] = instrument_name
            sim_params["sign_str"] = "gaia_orderbook_{}_{}".format(stra_params["demeter_sample_size"], stra_params["output_sample_size"])
            config = self.generateParams(sim_params, stra_params)
            self.configs.append(config)
        return self.configs
