#pragma once

#include "Predictor.h"
// #include "FactorFactory.h"
#include "GaiaModel.h"
#include <iostream>

class KronosGeneralPredictorImpl : public Predictor
{
public:
    KronosGeneralPredictorImpl(){};

    std::ofstream of;
    int count = 0;
    // PredictorConfig
    virtual void Init(const Config &_conf, const Config &_pred_conf) {
        std::cout << "init Kronos General Predictor config" << std::endl;
        auto orderConfig = _conf.Get<Config>("order_logic_config");
        auto commonConfig = orderConfig.Get<Config>("common");

        quoter_symbol = GaiaUtils::GetParam<std::string>(_pred_conf, "quoter_symbol");
        auto &contract_map = (*state->contract_map);
        for (auto &entry : contract_map) {
            std::cout << "mirana_ticker: " << entry.first 
                      << ", sid: " << entry.second->symbol_info->sid 
                      << ", exch: " << entry.second->symbol_info->exch 
                      << std::endl;
        }
        quoter_sid = (*state->contract_map)[quoter_symbol]->symbol_info->sid;

        auto factors_conf = _pred_conf.Get<std::vector<Config>>("factors");
        if (_pred_conf.TryGet<Config>("factors")) {
            // initialize factor input
            factor_input.preprocess_result = state->preprocess_result;

            auto factors_conf = _pred_conf.Get<std::vector<Config>>("factors");
            factor_manager_.Init(&factor_timer, state->sid_contract_map);
            // use memory managed by FactorManager
            factor_manager_.InitMemoryForFactors(factors_conf);
        }

        int factor_num = 0;
        for(auto f_conf : factors_conf) {
            ++factor_num;
            std::string name = GaiaUtils::GetParam<std::string>(f_conf, "factor_name");

            // FactorInterface* factor = FactorFactory::CreateFactor(name, f_conf);
            std::string symbol = GaiaUtils::GetParam<std::string>(f_conf, "symbol");
            auto sid = (*state->contract_map)[symbol]->symbol_info->sid;
            FactorInterface* factor = factor_manager_.CreateFactorInstance(name, sid, f_conf);

            factors[sid].push_back(factor);
            std::cout << "add factor: " << factor->get_name() << ", sid:" << sid << std::endl;

            try {
                std::string asst_symbol = GaiaUtils::GetParam<std::string>(f_conf, "asst_symbol");
                auto asst_sid = (*state->contract_map)[asst_symbol]->symbol_info->sid;
                factors[asst_sid].push_back(factor);
                std::cout << "add factor: " << factor->get_name() << ", asst_sid:" << asst_sid << std::endl;
            } catch(...) {
            }

            sorted_factors.push_back(factor);
        }

        main_signal_weight = _pred_conf.Get<double>("main_signal_weight");
        assist_signal_weight = _pred_conf.Get<double>("assist_signal_weight");

        factor_values.resize(factor_num, 0.0);
        for (size_t i = 0; i < sorted_factors.size(); ++i) {
            sorted_factors[i]->SetFactorOutput(&(factor_values[i]));
        }

        auto model_type = GaiaUtils::GetParam<std::string>(_pred_conf, "model_type");
        auto model_path = GaiaUtils::GetParam<std::string>(_pred_conf, "model_path");

        use_model = true;
        if(model_type == "lgb" && model_path.empty()) use_model = false;
        if(factor_num == 0) use_model = false;

        if(use_model) {
            model.LoadModel(model_type);
	        model.Init(model_path, factor_num, _pred_conf);
        }
        model_output.resize(1, 0.0);
        model_output_len = 1;
    };

    void CalculateAssistSignal(SignalStruct &output_signal, const SignalStruct &assist_signal) override {
        output_signal.pred_value = main_signal_weight * state->signal.pred_value + assist_signal_weight * assist_signal.pred_value;
    }

    virtual void getFactors(FactorOutputType &_output) {
        _output.clear();
        for (FactorInterface* factor : sorted_factors) {
            _output[factor->get_name()] = factor->get_value();
        }
    }

    inline void predict(int64_t& cur_time) {
        if(!use_model) return;
        log_time_cur = cur_time;
        model.Calculate(factor_values, model_output, model_output_len);
        state->signal.pred_value = model_output[0];
    }

    // entrance
    void Calculate() override {
        if(factor_values.size() <= 0) return;
        for(FactorInterface* &factor : factors[state->cur_tick_sid]) {
            factor->Calculate(factor_input);
        }

        predict(state->latency_record->mkt_data.mkt_recv_ts);
    }

private:
    GaiaModel model;
    bool use_model;
    FactorManager factor_manager_;

    std::string    quoter_symbol;
    SymId          quoter_sid;

    std::vector<double> factor_values;
    std::vector<double> model_output;
    int64_t             model_output_len;
    // std::unordered_map<SymId, std::vector<FactorInterface*>> factors;
    phmap::flat_hash_map<SymId, std::vector<FactorInterface*>> factors; // for fast access by sid
    std::vector<FactorInterface*> sorted_factors;

    double quoter_bid, quoter_ask, quoter_bz, quoter_az, quoter_mid;
    double bid, ask, bz, az;
    double quoter_bid_turnover, quoter_ask_turnover, quoter_bz_total, quoter_az_total;
    double quoter_bid_5, quoter_bid_10, quoter_bid_20, quoter_bid_30, quoter_bid_40, quoter_bid_50;
    double quoter_ask_5, quoter_ask_10, quoter_ask_20, quoter_ask_30, quoter_ask_40, quoter_ask_50;
    double quoter_bz_5, quoter_bz_10, quoter_bz_20, quoter_bz_30, quoter_bz_40, quoter_bz_50;
    double quoter_az_5, quoter_az_10, quoter_az_20, quoter_az_30, quoter_az_40, quoter_az_50;
    int num_bid_levels, num_ask_levels;
    int64_t log_time_cur, log_time_last;
    double trade_amt_cum, trade_qty_cum;

    double main_signal_weight = 1.0; // default weight for main signal, can be set by derived class
    double assist_signal_weight = 0.0; // default weight for sub signal, can be set by derived class
};
