#include "Factor.h"
#include "Ema.h"
#include <cmath>
#include "GaiaCircularBuffer.h"

class TradeAMidDisFactor : public FactorInterface
{
public:
    TradeAMidDisFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
        lookback = config.Get<int64_t>("lookback");
        last_prc_buffer.setSize(lookback, 0.0);
    };

    virtual std::string gen_name() {;
        return std::string("TradeAMidDisFactor") + "@lookback=" + std::to_string(lookback);
    }

    virtual void calculate(const FactorInput& input_data) {
        factor_value = 0.0;
        auto &trade = input_data.cur_contract->trade;
        exch_ts = trade.exch_ts;

        if (trade.side == Side::BUY) {
            last_ask = trade.price;
        } else if (trade.side == Side::SELL) {
            last_bid = trade.price;
        }

        if ((last_ask > MinErr) && (last_bid > MinErr)) {
            double mid_price = (last_bid + last_ask)/2.0;
            double old_price = last_prc_buffer.isFull() ? last_prc_buffer[0] : 0.0;
            double prev_price = last_prc_buffer.size() > 0 ? last_prc_buffer[-1] : mid_price;
            
            if (exch_ts != prev_exch_ts) {
                if (last_prc_buffer.isFull() && last_prc_buffer.size() > 1) {
                    dis_total -= std::abs(old_price - last_prc_buffer[1]);
                }
                
                if (last_prc_buffer.size() > 0) {
                    dis_total += std::abs(mid_price - prev_price);
                }
                
                last_prc_buffer.push(mid_price);
            } else {
                if (last_prc_buffer.size() > 1) {
                    double old_diff = std::abs(prev_price - last_prc_buffer[-2]);
                    double new_diff = std::abs(mid_price - last_prc_buffer[-2]);
                    dis_total = dis_total - old_diff + new_diff;
                }
                
                last_prc_buffer[-1] = mid_price;
            }
            
            if (last_prc_buffer.isFull()) {
                if (dis_total > MinErr) {
                    factor_value = (last_prc_buffer[-1] - last_prc_buffer[0]) / dis_total;
                }
            }
        }
        
        prev_exch_ts = exch_ts;
    };

    // virtual void calculate(const FactorInput& input_data) {
    //     factor_value = 0.0;
    //     auto &trade = input_data.cur_contract->trade;
    //     int64_t exch_ts = trade.exch_ts;
    //     if (trade.side == Side::BUY){
    //         last_ask = trade.price;
    //     }
    //     else if (trade.side == Side::SELL){
    //         last_bid = trade.price;
    //     }
    //     if ((last_ask > MinErr) && (last_bid > MinErr)){
    //         double mid_price = (last_bid + last_ask)/2.0;
    //         if (std::abs(exch_ts - prev_exch_ts) > MinErr){
    //             last_prc_buffer.push(mid_price);
    //         }
    //         else {
    //             last_prc_buffer[-1] = mid_price;
    //         }
    //     }
    //     if(last_prc_buffer.isFull() != false){
    //         double dis_total = 0.0;
    //         for (int i=1; i < lookback; i++){
    //             dis_total += std::abs(last_prc_buffer[-i] - last_prc_buffer[-i-1]);
    //         }
    //         if (dis_total > MinErr){
    //             factor_value = (last_prc_buffer[-1] - last_prc_buffer[0])/dis_total;
    //         }
    //     }
    //     prev_exch_ts = exch_ts;
        
    // };

private:
    int64_t lookback;
    GaiaCircularBuffer<double> last_prc_buffer;
    int64_t prev_exch_ts = 0;
    double last_bid = 0.0;
    double last_ask = 0.0;

    int64_t exch_ts = 0;
    double dis_total = 0;
};
                              
