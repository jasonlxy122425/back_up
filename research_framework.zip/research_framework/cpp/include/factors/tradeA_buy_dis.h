#include "Factor.h"
#include "Ema.h"
#include <cmath>
#include "GaiaCircularBuffer.h"

class TradeABuyDisFactor : public FactorInterface
{
public:
    TradeABuyDisFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
        lookback = config.Get<int64_t>("lookback");
        last_prc_buffer.setSize(lookback, 0.0);
    };

    virtual std::string gen_name() {;
        return std::string("TradeABuyDisFactor") + "@lookback=" + std::to_string(lookback);
    }

    virtual void calculate(const FactorInput& input_data) {
        factor_value = 0.0;
        auto &trade = input_data.cur_contract->trade;
        exch_ts = trade.exch_ts;

        if (trade.side == Side::BUY) {
            old_price = last_prc_buffer.isFull() ? last_prc_buffer[0] : 0.0;
            prev_price = last_prc_buffer.size() > 0 ? last_prc_buffer[-1] : trade.price;

            if (exch_ts != prev_exch_ts) {
                if (last_prc_buffer.isFull()) {
                    prc_diff_sum -= std::abs(old_price - last_prc_buffer[1]);
                }

                double new_diff = std::abs(trade.price - prev_price);
                prc_diff_sum += new_diff;

                last_prc_buffer.push(trade.price);
            } else {
                if (last_prc_buffer.size() > 1) {
                    double old_diff = std::abs(last_prc_buffer[-1] - last_prc_buffer[-2]);
                    double new_diff = std::abs(trade.price - last_prc_buffer[-2]);
                    prc_diff_sum = prc_diff_sum - old_diff + new_diff;
                }
                last_prc_buffer[-1] = trade.price;
            }

        }

        if (last_prc_buffer.isFull()) {
            factor_value = prc_diff_sum;
        }

        prev_exch_ts = exch_ts;
    }

    // virtual void calculate(const FactorInput& input_data) {
    //     factor_value = 0.0;
    //     auto &trade = input_data.cur_contract->trade;
    //     int64_t exch_ts = trade.exch_ts;
    //     if (trade.side == Side::BUY){
    //         if (std::abs(exch_ts - prev_exch_ts) > MinErr){
    //             last_prc_buffer.push(trade.price);
    //         }
    //         else {
    //             last_prc_buffer[-1] = trade.price;
    //         }
    //     }
    //     if(last_prc_buffer.isFull() != false){
    //         for (int i=1; i < lookback; i++){
    //             factor_value += std::abs(last_prc_buffer[-i] - last_prc_buffer[-i-1]);
    //         }
    //     }
    //     prev_exch_ts = exch_ts;
        
    // };

private:
    int64_t lookback;
    GaiaCircularBuffer<double> last_prc_buffer;
    int64_t prev_exch_ts = 0;
    double last_price = 0.0;

    int64_t exch_ts = 0;
    double prc_diff_sum = 0.0;
    double old_price, prev_price;
};
                              
