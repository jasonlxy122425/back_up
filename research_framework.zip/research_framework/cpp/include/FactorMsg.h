#pragma once
#include "PredictorGeneral.h"

class FactorMsg : public SpdLoggerMessage<FactorMsg>
{
public:
    FactorMsg(FactorOutputType &_output, const std::string &_symbol)
    {
        saved_output = _output;
        symbol = _symbol;
    }
    FactorMsg(FactorOutputType &_output, const int64_t &_recv_ts, const int64_t &_exch_ts)
    {
        saved_output = _output;
        recv_ts = _recv_ts;
        exch_ts = _exch_ts;
    }

    virtual void writeLog()
    {
        ret = {
            {"msg_type", "Factors"},
            {"symbol", symbol},
            {"recv_ts", tostring(recv_ts)},
            {"exch_ts", tostring(exch_ts)}
        };


        for (auto &it : saved_output) {
            ret[it.first] = tostring(it.second);
        }
    }

private:
    FactorOutputType saved_output;
    int64_t recv_ts,exch_ts;
    std::string symbol;
};
