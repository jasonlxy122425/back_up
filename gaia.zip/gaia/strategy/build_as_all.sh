cp ../libs/prod_as/*.so ../libs/
cd ../../algostation/cpp/ ; make clean ; make -j10; cd -
cd ../../ATHENA ; make USE_AS=YES -j4 ; cd -
cd ../../ZEUS ; make USE_AS=YES -j4 ; cd -
cd ../../APOLLO ; make USE_AS=YES -j4 ; cd -
cd ../../Kronos-cpp ; make USE_AS=YES -j4 ; cd -
cd ../../research_framework/cpp ; make USE_AS=YES -j4 ; cd -
make -j8 USE_AS=YES

cd ../libs/ ; cp libathena.so prod_as/ ; cp libkronos.so prod_as/ ; cp libzeus.so prod_as/ ; cp libapollo.so prod_as/ ; cp libpredictor.so prod_as/ ; cd -
cp build/gaia_bin /mnt/share/shared_files/deploy/gaia/
cp ../libs/prod_as/lib* /mnt/share/shared_files/deploy/gaia/

