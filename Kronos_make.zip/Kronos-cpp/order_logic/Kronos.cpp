#include "OrderLogicDef.h"
#include "KronosImpl.h"


STANDARD_ORDER_LOGIC_DEFINITION(Kronos, KronosImpl)
