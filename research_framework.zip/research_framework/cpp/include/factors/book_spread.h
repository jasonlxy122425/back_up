#include "Factor.h"
#include "Ema.h"


class BookSpreadFactor : public FactorInterface
{
public:
    BookSpreadFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
        ema_int = config.Get<int64_t>("ema_int");
        ema.init(ema_int);
    };

    virtual std::string gen_name() {
        return std::string("BookSpreadFactor") + '@' +  std::to_string(ema_int);
    }

    virtual void calculate(const FactorInput& input_data) {
        factor_value = 0.0;
        auto &gob = input_data.cur_contract->alphaBook;
        double spread = gob->ask(0).price - gob->bid(0).price;
        ema.update(spread);
        factor_value = ema.get();

    };


private:
    int64_t ema_int;
    Ema ema;
};
                              
