#include "LogPool.h"
#include "SpdLoggerMessage.h"


void warmupLogPools() {
    // trading
    GlobalMessagePool<ExecMessage>::instance().warmup();
    GlobalMessagePool<CancelMessage>::instance().warmup();
    GlobalMessagePool<SendReplaceOrderMessage>::instance().warmup();
    GlobalMessagePool<SendReplaceOrderFailedMessage>::instance().warmup();
    
    // qry
    GlobalMessagePool<OnQryPositionMessage>::instance().warmup();
    GlobalMessagePool<OnQryBalanceMessage>::instance().warmup();
    GlobalMessagePool<OnQryOpenOrderMessage>::instance().warmup();
    GlobalMessagePool<OnReconBalanceMessage>::instance().warmup();
    
    // strategy
    GlobalMessagePool<StrategySnapshotMsg>::instance().warmup();
    GlobalMessagePool<StrategyBalanceMsg>::instance().warmup();
    GlobalMessagePool<StrategyModeChangeMsg>::instance().warmup();
    GlobalMessagePool<PositionUpdateMsg>::instance().warmup();
    
    // hedger
    GlobalMessagePool<TradeHedgingMessage>::instance().warmup();
    GlobalMessagePool<PositionHedgingMessage>::instance().warmup();
    
    // other
    GlobalMessagePool<LatencyMsg>::instance().warmup();
    GlobalMessagePool<CustomMsg>::instance().warmup();
    GlobalMessagePool<SyntheticFillMsg>::instance().warmup();
    GlobalMessagePool<SyntheticFillFalseFillMsg>::instance().warmup();
    GlobalMessagePool<ParamUpdateMsg>::instance().warmup();
}