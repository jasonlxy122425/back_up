#include <pybind11/pybind11.h>
#include <pybind11/stl.h>
#include "GaiaOrderbook.h"
#include "GaiaOrderbookManager.h"
#include "alphaless/secmaster/sec_master.h"  // 确保包含 SecMaster 的头文件

namespace py = pybind11;

extern void InitMd(py::module m);

PYBIND11_MODULE(gaia_orderbook, m) {
    InitMd(m.def_submodule("md"));

    py::class_<GaiaOrderbookBase<SmartGaiabookTraits>>(m, "GaiaOrderbookBase")
        .def(py::init<>())
        .def("bids", &GaiaOrderbookBase<SmartGaiabookTraits>::bids)
        .def("asks", &GaiaOrderbookBase<SmartGaiabookTraits>::asks)
        .def("num_bids", &GaiaOrderbookBase<SmartGaiabookTraits>::num_bids)
        .def("num_asks", &GaiaOrderbookBase<SmartGaiabookTraits>::num_asks)
        .def("bid", &GaiaOrderbookBase<SmartGaiabookTraits>::bid)
        .def("ask", &GaiaOrderbookBase<SmartGaiabookTraits>::ask)
        ;

    // 绑定 GaiaOrderbook 类
    py::class_<GaiaOrderbook, GaiaOrderbookBase<SmartGaiabookTraits>>(m, "GaiaOrderbook")
        .def(py::init<>())
        .def("exch_ts", &GaiaOrderbook::exch_ts)
        .def("seq_id", &GaiaOrderbook::seq_id)
        ;

    // 绑定 GaiaOrderbookManager 类
    py::class_<GaiaOrderbookManagerT<GaiaOrderbook>>(m, "GaiaOrderbookManager")
        .def(py::init<>())
        .def("Get", &GaiaOrderbookManagerT<GaiaOrderbook>::Get, py::return_value_policy::reference)
        .def("OnOrderbook", &GaiaOrderbookManagerT<GaiaOrderbook>::OnOrderbook, py::return_value_policy::reference)
        .def("OnTrade", &GaiaOrderbookManagerT<GaiaOrderbook>::OnTrade, py::return_value_policy::reference)
        .def("OnBestQuote", &GaiaOrderbookManagerT<GaiaOrderbook>::OnBestQuote, py::return_value_policy::reference)
        ;
}