#include "ContractInfo.h"
#include "SystemDefine.h"
#include "GaiaUtils.h"

ContractInfo* ContractInfo::GetContractInfo(const std::string& s) {
    const SymbolInfo *symbol = GaiaUtils::getSecMasterSymbol(s);
    SymId sid = symbol->sid;

    return GetContractInfo(sid);
}

ContractInfo* ContractInfo::GetContractInfo(SymId sid) {
    double makerFeeBps = 0;
    double takerFeeBps = 0;
    auto symbol = GaiaUtils::getSecMasterSymbol(sid);
    GaiaUtils::getFeeRate(makerFeeBps, takerFeeBps, symbol->mirana_ticker);

    struct ContractInfo *contract_info = new ContractInfo();

    contract_info->setSymbolInfo(const_cast<SymbolInfo*>(symbol));
    contract_info->is_reverse = false;
    contract_info->hasTradePopulated = false;
    contract_info->hasBookPopulated = false;
    contract_info->hasBestQuotePopulated = false;
    contract_info->makerFeeBps = makerFeeBps;
    contract_info->takerFeeBps = takerFeeBps;
    contract_info->demeter_data = nullptr;

    if (symbol->mirana_ticker.find("InverseSwap") != std::string::npos) {
        contract_info->is_reverse = true;
    }

    return contract_info;
}