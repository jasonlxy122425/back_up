#include "parquet_writer.h"
#include <arrow/api.h>
#include <arrow/io/api.h>
#include <parquet/arrow/writer.h>
#include <parquet/arrow/reader.h>
#include <parquet/exception.h>
#include <iostream>

ParquetWriter::~ParquetWriter() {
    if (writer_) {
        FlushRows();
        auto ret = writer_->Close();
        std::cout << "parquet file closed" << std::endl;
    }
}

template<typename T>
void ParquetWriter::AddColumn(std::string_view col, T type) {
    // std::cout << "adding column: " << col << ", idx:" << idx_ << std::endl;
    // PARQUET_THROW_NOT_OK(schema_->AddField(idx_, arrow::field(col.data(), type)));
    fields_.push_back(arrow::field(col.data(), type));
    column_idx_[col.data()] = idx_;
    idx_++;
}

void ParquetWriter::FlushRows() {
    if (cur_row_size_ == 0) return;

    arrow::ArrayVector arrays;
    for(size_t i = 0; i < columns_.size(); ++i) {
        std::shared_ptr<arrow::Array> array;
        PARQUET_THROW_NOT_OK(columns_[i]->Finish(&array));
        arrays.push_back(array);
        // std::cout << "Column " << i << " has " << array->length() << " elements" << std::endl;
    }
    std::shared_ptr<arrow::RecordBatch> batch = arrow::RecordBatch::Make(schema_, cur_row_size_, arrays);
    PARQUET_THROW_NOT_OK(writer_->WriteRecordBatch(*batch));
    for(auto &builder : columns_) {
        builder->Reset();
    }

    cur_row_size_ = 0;
}

void ParquetWriter::Initialize(const Config config) {
    std::cout << "Initializing Parquet writer" << std::endl;
    batch_size_ = 16*10240;
    cur_row_size_ = 0;
    config_ = config;
    file_name_ = config.Get<std::string>("file_path");
    zone_ = config.Get<std::string>("zone");

    AddColumn("exch_ts", arrow::int64());
    AddColumn("recv_ts", arrow::int64());
    AddColumn("seq_id", arrow::int64());
    AddColumn("cur_exch_ts", arrow::int64());
    AddColumn("cur_seq_id", arrow::int64());
    if(write_latency) {
        AddColumn("qs_send_ts", arrow::int64());
        AddColumn("cb_start_ts", arrow::int64());
        AddColumn("gaia_start_ts", arrow::int64());
        AddColumn("demeter_start_ts", arrow::int64());
        AddColumn("predictor_start_ts", arrow::int64());
        AddColumn("risk_start_ts", arrow::int64());
        AddColumn("order_logic_start_ts", arrow::int64());
        AddColumn("hedger_start_ts", arrow::int64());
        AddColumn("gaia_end_ts", arrow::int64());
    }
    AddColumn("symbol", arrow::utf8());
    AddColumn("sid", arrow::int64());
    AddColumn("src", arrow::int16());
    AddColumn("type", arrow::int16());
    AddColumn("updated_by_cur_tick", arrow::int16());
    AddColumn("zone", arrow::utf8());
    if(write_orderbook) {
    	AddColumn("num_bids", arrow::int32());
    	AddColumn("num_asks", arrow::int32());
    	AddColumn("ask_price", arrow::list(arrow::float64()));
    	AddColumn("ask_qty", arrow::list(arrow::float64()));
    	AddColumn("bid_price", arrow::list(arrow::float64()));
    	AddColumn("bid_qty", arrow::list(arrow::float64()));
    }
    if(write_ob_l1) {
        AddColumn("ob_best_bid_price", arrow::float64());
        AddColumn("ob_best_bid_qty", arrow::float64());
        AddColumn("ob_best_ask_price", arrow::float64());
        AddColumn("ob_best_ask_qty", arrow::float64());
    }
    AddColumn("trade_price", arrow::float64());
    AddColumn("trade_qty", arrow::float64());
    AddColumn("trade_side", arrow::int16());
    AddColumn("trade_id", arrow::utf8());
    if(write_origin_quote) {
        AddColumn("best_bid_price", arrow::float64());
        AddColumn("best_bid_qty", arrow::float64());
        AddColumn("best_ask_price", arrow::float64());
        AddColumn("best_ask_qty", arrow::float64());
    }

    if(write_kline) {
        AddColumn("kline_interval", arrow::utf8());
        AddColumn("kline_start_ts", arrow::int64());
        AddColumn("kline_end_ts", arrow::int64());
        AddColumn("kline_closed", arrow::int16());
        AddColumn("kline_open_price", arrow::float64());
        AddColumn("kline_close_price", arrow::float64());
        AddColumn("kline_high_price", arrow::float64());
        AddColumn("kline_low_price", arrow::float64());
        AddColumn("kline_volume", arrow::float64());
        AddColumn("kline_quote_volume", arrow::float64());
        AddColumn("kline_num_trades", arrow::int32());
        AddColumn("kline_taker_buy_volume", arrow::float64());
        AddColumn("kline_taker_buy_quote_volume", arrow::float64());
    }

    if(demeter_data_manager_ != nullptr && write_demeter) {
        std::string buy_str = "Buy";
        std::string sell_str = "Sell";
        for(size_t i = 0; i < demeter::BookOrderType::NumBookOrderTypes; ++i) {
            AddColumn(buy_str + "_" + demeter::ToString(static_cast<demeter::BookOrderType>(i)), arrow::list(arrow::float64()));
            AddColumn(sell_str + "_" + demeter::ToString(static_cast<demeter::BookOrderType>(i)), arrow::list(arrow::float64()));

            AddColumn(buy_str + "_" + demeter::ToString(static_cast<demeter::BookOrderType>(i)) + "_sum", arrow::float64());
            AddColumn(sell_str + "_" + demeter::ToString(static_cast<demeter::BookOrderType>(i)) + "_sum", arrow::float64());
        }
    }

    if(predictor_) {
        factors_.clear();
        if(write_factors) {
            predictor_->getFactors(factors_);
            for(auto &factor : factors_) {
                AddColumn(factor.first, arrow::float64());
            }
        }
        AddColumn("predictor_value", arrow::float64());
        AddColumn("main_predictor_value", arrow::float64());
        AddColumn("assist_predictor_value", arrow::float64());
    }

    schema_ = arrow::schema(fields_);

    columns_.resize(schema_->num_fields());
    for (int i = 0; i < schema_->num_fields(); ++i) {
        columns_[i] = arrow::MakeBuilder(schema_->field(i)->type()).ValueOrDie();
    }

    parquet::WriterProperties::Builder builder;
    builder.max_row_group_length(batch_size_);
    std::shared_ptr<parquet::WriterProperties> props = builder.build();
    outfile_ = arrow::io::FileOutputStream::Open(file_name_).ValueOrDie();

    // pool = arrow::MemoryPool::CreateLimited(6 * 1024 * 1024 * 1024);
    pool = arrow::MemoryPool::CreateDefault();
    //auto result = parquet::arrow::FileWriter::Open(*schema_, arrow::default_memory_pool(), outfile_, props);
    auto result = parquet::arrow::FileWriter::Open(*schema_, pool.get(), outfile_, props);
    PARQUET_THROW_NOT_OK(result.status());
    writer_ = std::move(result).ValueOrDie();
}


void ParquetWriter::WriteData(const GaiaOrderbook &gaia_ob, SymId sid, double price, double qty,
                           Side side,std::string trade_id, double bid_price, double bid_qty,
                           double ask_price, double ask_qty,
                           const md::Kline &kline,
                           Message *msg, int64_t seq_id) {
   
    PARQUET_THROW_NOT_OK(dynamic_cast<arrow::Int64Builder*>(columns_[column_idx_["recv_ts"]].get())->Append(msg->recv_ts));
    PARQUET_THROW_NOT_OK(dynamic_cast<arrow::Int64Builder*>(columns_[column_idx_["exch_ts"]].get())->Append(gaia_ob.exch_ts()));
    PARQUET_THROW_NOT_OK(dynamic_cast<arrow::Int64Builder*>(columns_[column_idx_["seq_id"]].get())->Append(gaia_ob.seq_id()));
    PARQUET_THROW_NOT_OK(dynamic_cast<arrow::Int64Builder*>(columns_[column_idx_["cur_exch_ts"]].get())->Append(msg->exch_ts));
    PARQUET_THROW_NOT_OK(dynamic_cast<arrow::Int64Builder*>(columns_[column_idx_["cur_seq_id"]].get())->Append(seq_id));
    if(write_latency) {
        PARQUET_THROW_NOT_OK(dynamic_cast<arrow::Int64Builder*>(columns_[column_idx_["qs_send_ts"]].get())->Append(msg->qs_send_ts));
        PARQUET_THROW_NOT_OK(dynamic_cast<arrow::Int64Builder*>(columns_[column_idx_["cb_start_ts"]].get())->Append(msg->cb_start_ts));
        PARQUET_THROW_NOT_OK(dynamic_cast<arrow::Int64Builder*>(columns_[column_idx_["gaia_start_ts"]].get())->Append(latency_->gaia_start_ts));
        PARQUET_THROW_NOT_OK(dynamic_cast<arrow::Int64Builder*>(columns_[column_idx_["demeter_start_ts"]].get())->Append(latency_->demeter_start_ts));
        PARQUET_THROW_NOT_OK(dynamic_cast<arrow::Int64Builder*>(columns_[column_idx_["predictor_start_ts"]].get())->Append(latency_->predictor_start_ts));
        PARQUET_THROW_NOT_OK(dynamic_cast<arrow::Int64Builder*>(columns_[column_idx_["risk_start_ts"]].get())->Append(latency_->risk_start_ts));
        PARQUET_THROW_NOT_OK(dynamic_cast<arrow::Int64Builder*>(columns_[column_idx_["order_logic_start_ts"]].get())->Append(latency_->order_logic_start_ts));
        PARQUET_THROW_NOT_OK(dynamic_cast<arrow::Int64Builder*>(columns_[column_idx_["hedger_start_ts"]].get())->Append(latency_->hedger_start_ts));
        PARQUET_THROW_NOT_OK(dynamic_cast<arrow::Int64Builder*>(columns_[column_idx_["gaia_end_ts"]].get())->Append(latency_->gaia_end_ts));
    }
    PARQUET_THROW_NOT_OK(dynamic_cast<arrow::StringBuilder*>(columns_[column_idx_["symbol"]].get())->Append(SecMaster::instance().GetSymbol(sid)->mirana_ticker));
    PARQUET_THROW_NOT_OK(dynamic_cast<arrow::Int64Builder*>(columns_[column_idx_["sid"]].get())->Append(sid));
    PARQUET_THROW_NOT_OK(dynamic_cast<arrow::Int16Builder*>(columns_[column_idx_["src"]].get())->Append(int16_t(msg->src)));
    PARQUET_THROW_NOT_OK(dynamic_cast<arrow::Int16Builder*>(columns_[column_idx_["type"]].get())->Append(int16_t(ToTickEventType(msg->msg_type))));
    PARQUET_THROW_NOT_OK(dynamic_cast<arrow::Int16Builder*>(columns_[column_idx_["updated_by_cur_tick"]].get())->Append(int16_t(gaia_ob.updated_by_cur_tick())));
    PARQUET_THROW_NOT_OK(dynamic_cast<arrow::StringBuilder*>(columns_[column_idx_["zone"]].get())->Append(zone_));

    auto append_list_values = [&](const std::string& col_name, auto get_value, int num_values) {
        auto& builder = columns_[column_idx_[col_name]];
        auto list_builder = dynamic_cast<arrow::ListBuilder*>(builder.get());
        auto value_builder = dynamic_cast<arrow::DoubleBuilder*>(list_builder->value_builder());
        PARQUET_THROW_NOT_OK(list_builder->Append());
        for (int i = 0; i < num_values; ++i) {
            PARQUET_THROW_NOT_OK(value_builder->Append(get_value(i)));
        }
    };
    if(write_orderbook) {
        PARQUET_THROW_NOT_OK(dynamic_cast<arrow::Int32Builder*>(columns_[column_idx_["num_bids"]].get())->Append(num_bids_));
        PARQUET_THROW_NOT_OK(dynamic_cast<arrow::Int32Builder*>(columns_[column_idx_["num_asks"]].get())->Append(num_asks_));

        append_list_values("ask_price", [&](int i) { return gaia_ob.ask(i).price; }, gaia_ob.num_asks());
        append_list_values("ask_qty", [&](int i) { return gaia_ob.ask(i).qty; }, gaia_ob.num_asks());
    	append_list_values("bid_price", [&](int i) { return gaia_ob.bid(i).price; }, gaia_ob.num_bids());
        append_list_values("bid_qty", [&](int i) { return gaia_ob.bid(i).qty; }, gaia_ob.num_bids());
    }

    if(write_ob_l1) {
        PARQUET_THROW_NOT_OK(dynamic_cast<arrow::DoubleBuilder*>(columns_[column_idx_["ob_best_bid_price"]].get())->Append(gaia_ob.bid(0).price));
        PARQUET_THROW_NOT_OK(dynamic_cast<arrow::DoubleBuilder*>(columns_[column_idx_["ob_best_bid_qty"]].get())->Append(gaia_ob.bid(0).qty));
        PARQUET_THROW_NOT_OK(dynamic_cast<arrow::DoubleBuilder*>(columns_[column_idx_["ob_best_ask_price"]].get())->Append(gaia_ob.ask(0).price));
        PARQUET_THROW_NOT_OK(dynamic_cast<arrow::DoubleBuilder*>(columns_[column_idx_["ob_best_ask_qty"]].get())->Append(gaia_ob.ask(0).qty));
    }

    PARQUET_THROW_NOT_OK(dynamic_cast<arrow::DoubleBuilder*>(columns_[column_idx_["trade_price"]].get())->Append(price));
    PARQUET_THROW_NOT_OK(dynamic_cast<arrow::DoubleBuilder*>(columns_[column_idx_["trade_qty"]].get())->Append(qty));
    PARQUET_THROW_NOT_OK(dynamic_cast<arrow::Int16Builder*>(columns_[column_idx_["trade_side"]].get())->Append(int16_t(side)));
    PARQUET_THROW_NOT_OK(dynamic_cast<arrow::StringBuilder*>(columns_[column_idx_["trade_id"]].get())->Append(trade_id));

    if(write_origin_quote) {
        PARQUET_THROW_NOT_OK(dynamic_cast<arrow::DoubleBuilder*>(columns_[column_idx_["best_bid_price"]].get())->Append(bid_price));
        PARQUET_THROW_NOT_OK(dynamic_cast<arrow::DoubleBuilder*>(columns_[column_idx_["best_bid_qty"]].get())->Append(bid_qty));
        PARQUET_THROW_NOT_OK(dynamic_cast<arrow::DoubleBuilder*>(columns_[column_idx_["best_ask_price"]].get())->Append(ask_price));
        PARQUET_THROW_NOT_OK(dynamic_cast<arrow::DoubleBuilder*>(columns_[column_idx_["best_ask_qty"]].get())->Append(ask_qty));
    }
    if(write_kline) {
        PARQUET_THROW_NOT_OK(dynamic_cast<arrow::StringBuilder*>(columns_[column_idx_["kline_interval"]].get())->Append(ToString(kline.interval)));
        PARQUET_THROW_NOT_OK(dynamic_cast<arrow::Int64Builder*>(columns_[column_idx_["kline_start_ts"]].get())->Append(kline.start_ts));
        PARQUET_THROW_NOT_OK(dynamic_cast<arrow::Int64Builder*>(columns_[column_idx_["kline_end_ts"]].get())->Append(kline.end_ts));
        PARQUET_THROW_NOT_OK(dynamic_cast<arrow::Int16Builder*>(columns_[column_idx_["kline_closed"]].get())->Append(int16_t(kline.closed)));
        PARQUET_THROW_NOT_OK(dynamic_cast<arrow::DoubleBuilder*>(columns_[column_idx_["kline_open_price"]].get())->Append(kline.open_price));
        PARQUET_THROW_NOT_OK(dynamic_cast<arrow::DoubleBuilder*>(columns_[column_idx_["kline_close_price"]].get())->Append(kline.close_price));
        PARQUET_THROW_NOT_OK(dynamic_cast<arrow::DoubleBuilder*>(columns_[column_idx_["kline_high_price"]].get())->Append(kline.high_price));
        PARQUET_THROW_NOT_OK(dynamic_cast<arrow::DoubleBuilder*>(columns_[column_idx_["kline_low_price"]].get())->Append(kline.low_price));
        PARQUET_THROW_NOT_OK(dynamic_cast<arrow::DoubleBuilder*>(columns_[column_idx_["kline_volume"]].get())->Append(kline.volume));
        PARQUET_THROW_NOT_OK(dynamic_cast<arrow::DoubleBuilder*>(columns_[column_idx_["kline_quote_volume"]].get())->Append(kline.quote_volume));
        PARQUET_THROW_NOT_OK(dynamic_cast<arrow::Int32Builder*>(columns_[column_idx_["kline_num_trades"]].get())->Append(kline.num_trades));
        PARQUET_THROW_NOT_OK(dynamic_cast<arrow::DoubleBuilder*>(columns_[column_idx_["kline_taker_buy_volume"]].get())->Append(kline.taker_buy_volume));
        PARQUET_THROW_NOT_OK(dynamic_cast<arrow::DoubleBuilder*>(columns_[column_idx_["kline_taker_buy_quote_volume"]].get())->Append(kline.taker_buy_quote_volume));
    }

    if(demeter_data_manager_ != nullptr && write_demeter) {
        auto demeter_data = demeter_data_manager_->Get(sid);

        std::string side_str = "Buy";
        for(size_t n = 0; n < demeter::BookOrderType::NumBookOrderTypes; ++n) {
            append_list_values(side_str + "_" + demeter::ToString(static_cast<demeter::BookOrderType>(n)),
                                [&](int j) { return demeter_data->GetGobUpdate().get(Side::BUY, static_cast<demeter::BookOrderType>(n))[j]; },
                                demeter_data->GetGobUpdate().get(Side::BUY, static_cast<demeter::BookOrderType>(n)).size());

            std::string buy_sum_str = side_str + "_" + demeter::ToString(static_cast<demeter::BookOrderType>(n)) + "_sum";
            PARQUET_THROW_NOT_OK(dynamic_cast<arrow::DoubleBuilder*>(columns_[column_idx_[buy_sum_str]].get())->Append(demeter_data->GetGobUpdateSum(Side::BUY, static_cast<demeter::BookOrderType>(n))));
        }

        side_str = "Sell";
        for(size_t n = 0; n < demeter::BookOrderType::NumBookOrderTypes; ++n) {
            append_list_values(side_str + "_" + demeter::ToString(static_cast<demeter::BookOrderType>(n)),
            [&](int j) { return demeter_data->GetGobUpdate().get(Side::SELL, static_cast<demeter::BookOrderType>(n))[j]; },
            demeter_data->GetGobUpdate().get(Side::SELL, static_cast<demeter::BookOrderType>(n)).size());
            std::string sell_sum_str = side_str + "_" + demeter::ToString(static_cast<demeter::BookOrderType>(n)) + "_sum";
            PARQUET_THROW_NOT_OK(dynamic_cast<arrow::DoubleBuilder*>(columns_[column_idx_[sell_sum_str]].get())->Append(demeter_data->GetGobUpdateSum(Side::SELL, static_cast<demeter::BookOrderType>(n))));
        }

    }

    if(predictor_) {
        factors_.clear();
	    if(write_factors) {
            predictor_->getFactors(factors_);
            for(auto &factor : factors_) {
                PARQUET_THROW_NOT_OK(dynamic_cast<arrow::DoubleBuilder*>(columns_[column_idx_[factor.first]].get())->Append(factor.second));
            }
	    }
        PARQUET_THROW_NOT_OK(dynamic_cast<arrow::DoubleBuilder*>(columns_[column_idx_["predictor_value"]].get())->Append(strategy_fields_->signal.pred_value));
        PARQUET_THROW_NOT_OK(dynamic_cast<arrow::DoubleBuilder*>(columns_[column_idx_["main_predictor_value"]].get())->Append(predictor_->getState().signal.pred_value));
        PARQUET_THROW_NOT_OK(dynamic_cast<arrow::DoubleBuilder*>(columns_[column_idx_["assist_predictor_value"]].get())->Append(strategy_fields_->assist_signal.pred_value));

    }

    // Flush any buffered data to the file
    cur_row_size_++;
    if(cur_row_size_ >= batch_size_ || pool->bytes_allocated() > 4L * 1024L * 1024L * 1024L) {
        FlushRows();
    }
    //if (pool->bytes_allocated() > 4.5 * 1024 * 1024 * 1024)

}
