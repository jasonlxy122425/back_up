import yaml,datetime
from ServerInfo import *

class GenUtils:
    @classmethod
    def ConvertDictToContent(self,d, indent = 2):
        s = ""
        for k, v in d.items():
            s += " " * 2 + " " * indent + f"{k}: {str(v)}\n"

        return s

class FileBuilder:
    def __init__(self):
        pass

    def isGaia(self, config):
        if '_gaia' in config.acct_group:
            return True
        else:
            return False

    def generateConfigs(self, config):

        self.buildMdConfig(config)
        self.buildHedgerConfig(config)
        self.buildStrategyConfig(config)
        if config.mode != "SIM" and self.isGaia(config):
            self.buildTradeConfig(config)
            self.udp_config = ""
        elif config.mode == "SIM" and (config.simConfig.sim_engine == 'as' or config.simConfig.sim_engine == 'as_prod'):
            self.buildTradeConfig(config)
            self.udp_config = ""
        else:
            self.buildTsConfig(config)
            self.buildUdpConfig(config)
        self.buildWriter(config)


    def build(self, config):
        # print(config.reference_symbols)
        self.generateConfigs(config)


        backup_dir = ''
        if config.mode != "SIM" and self.isGaia(config) == False:
            backup_dir = 'backup_dir: ./secmaster_backup'

        secmaster_str = f"""
secmaster:
  base_url: https://prod-secmaster.timeresearch.biz
  exchanges: ["Binance", "Bybit", "Okex", "Phemex", "Gateio", "Kucoin", "Bitget", "Dydx", "WooX", "Deribit","Hyperliquid","HuobiGlobal"]
"""
        if config.mode != "SIM" and self.isGaia(config):
            secmaster_str = f"""
secmaster:
  files:
    - "/mnt/share/shared_files/config/secmaster_backup/Binance"
    - "/mnt/share/shared_files/config/secmaster_backup/Bitget"
    - "/mnt/share/shared_files/config/secmaster_backup/Bybit"
    - "/mnt/share/shared_files/config/secmaster_backup/Okex"
    - "/mnt/share/shared_files/config/secmaster_backup/Gateio"
    - "/mnt/share/shared_files/config/secmaster_backup/HuobiGlobal"
    - "/mnt/share/shared_files/config/secmaster_backup/Hyperliquid"
    - "/mnt/share/shared_files/config/secmaster_backup/Aster"
    - "/mnt/share/shared_files/config/secmaster_backup/Lighter"
"""

        if config.mode != "SIM" and self.isGaia(config):
            trading_str = f"""
cpu: {config.cpu}
trade_client_config_path: ./configs/exch/prod.yml
"""
        else:
            trading_str = f"""
order_manager:
  recon: true
  position_tracker: false  # change this to true to enable position tracker

trading_day_start_secs: 30

# event loop idle behavior, strategy can be BUSY_WAIT, YIELD or SLEEP
# see alphaless/base/idle_strategy.h
{self.idle_strategy}
engine_cpu: {config.cpu}
engine_thread_priority: -1

# max event batch size to process for each iteration
# md_read_batch_size: 32
# ts_read_batch_size: 32
# user_msg_read_batch_size: 32

# stop engine when received SIGINT/SIGTERM
stop_on_signaled: true
"""
        assist_reference_symbols_str = """
  assist_reference_symbols: []
"""
        if hasattr(config, "assist_reference_symbols"):
            assist_reference_symbols_str = f"""
  assist_reference_symbols: {config.assist_reference_symbols}
"""

        self.content = f"""
{secmaster_str} 
  {backup_dir}
  # auto reload secmaster on trading day start
  auto_reload: false

{self.ts_config}
{self.udp_config}

{self.md_config_str}

{trading_str}
# strategy config, this section will be passed to Strategy::OnInitialize
strategy:
{self.output_config}

  tag: {config.tag}
  sub_tag: {config.sub_tag}
  log_path: /opt/logs/realtime_logs/
  quoter_logic_acct_id: {config.logicAcctId}
  quoter_symbol: {config.quoter_symbol}
  quoter_machine_name: {config.machineName}
  leverage: {config.leverage}

  reference_symbols: {config.reference_symbols}
{assist_reference_symbols_str}
  {self.strategy_config}
"""
        if config.mode == 'SIM':
            self.buildSimConfig(config)
        return self.content

    def get_server_prefix(self, machineName):
        if "ali-hk" in machineName:
            return "ali-hk"
        elif "sgp" in machineName:
            return "sg"
        else:
            return machineName.split('-')[0]
    
    def get_microwave_info(self, machineName, hedgerMachineName):
        quoter_m = self.get_server_prefix(machineName)
        hedger_m = self.get_server_prefix(hedgerMachineName)
        for config in microwave_config:
            if quoter_m == config['from'] and hedger_m == config['to']:
                multi_link = False
                if config.__contains__('multi_link'):
                    multi_link = config['multi_link']

                return config['udp_tunnel_host'], config['udp_tunnel_port'],multi_link
        
    def buildWriter(self, config):
        self.output_config = ""
        if hasattr(config, "sim_output_engine") == False:
            return
        if config.sim_output_engine == "clickhouse":
            self.output_config += f"""
  data_writer:
    engine: clickhouse
    host: "prod-xy-clickhouse-tcp-c3abf903c2fce8cb.elb.ap-southeast-1.amazonaws.com"
    port: "9000"
    user: "default"
    passwd: "CS8tmty6Hkmv"
    data_base: "kronos_data"
    table_name: "{config.sim_output_target}"
    write_factors: {config.sim_output_factors}
    write_orderbook: {config.sim_output_orderbook}
    sample_count: {config.sim_output_sample_count}
    zone: "{config.target_server}"
"""
        elif config.sim_output_engine == "file" or config.sim_output_engine == "parquet":
            self.output_config += f"""
  data_writer:
    engine: {config.sim_output_engine}
    file_path: "{config.sim_output_target}"
    write_factors: {config.sim_output_factors}
    write_orderbook: {config.sim_output_orderbook}
    write_demeter: {config.sim_output_demeter}
    write_origin_quote: {config.sim_output_origin_quote}
    write_latency: {config.sim_output_latency}
    write_ob_l1: {config.sim_output_ob_l1}
    sample_count: {config.sim_output_sample_count}
    zone: "{config.target_server}"
"""

    def buildUdpConfig(self, config):
        self.udp_config = ""
        if hasattr(config, "hedgerConfig") == False:
            return

        if config.hedgerConfig.use_hedger == False:
            return

        udp_port = 36100
        if config.hedgerTs != -1:
            udp_port = udp_port + (config.hedgerTs - 1) * 100
        
        if config.use_microwave:
            ip, port, multi_link = self.get_microwave_info(config.machineName, config.hedgerMachineName)

            
            if multi_link == False:
                self.udp_config = f"""
      ### trade server's UDP listen port, check with trading support if UDP order entry is supported
      protocol: tcp
      udp_port: {udp_port} 
      ### if we want to let udp_tunnel to forward the request for us. Usually use together with micro wave
      udp_tunnel_host: {ip} 
      udp_tunnel_port: {port}
"""
            else:
                self.udp_config = f"""
      protocol: hybrid_tcp
      udp_port: {udp_port} 
      local_ip: 0.0.0.0
      udp_channels:
        - link_type: microwave
          channel: 0.0.0.0:{config.local_mw_port}-{config.remote_mw_ip}:{udp_port} # src_ip:src_port-dst_ip:dst_port
        - link_type: privatelink
          channel: 0.0.0.0:{config.local_avc_port}-{config.hedgerMachineIp}:{udp_port} # src_ip:src_port-dst_ip:dst_port
"""

        elif config.use_udp:
            self.udp_config = f"""
      protocol: tcp
      ### trade server's UDP listen port, check with trading support if UDP order entry is supported
      udp_port: {udp_port}
"""

    def buildMdConfig(self, config):
        batch_mode_str = ""
        #if hasattr(config.commonConfig, "use_batch_mode") and config.commonConfig.use_batch_mode:
        if config.commonConfig.use_batch_mode:
            batch_mode_str = """
  batch_mode: true
  batch_buf_bytes: 262144
"""
        if config.mode == "SIM":
            self.md_config_str = f"""
md:
  bybit_dmm_mode: hybrid
  subscription:
    orderbook: true
    orderbook_update: false
    kline_intervals: ["1m"]
    trade: true
    funding_rate: true
    best_quote: true
    liquidation: true
    stats_24h: false
    mark_price: true
    index_price: false
    settlement_price: false
    greeks: false
    prefer_use_transact_ts: true
    use_trade_history: true
    trade_arb_policy: prefer_complete
    num_book_levels: {config.num_of_book_levels}
"""
        else:
            self.md_config_str = f"""
md:
  # shm file path as configured in md_shm_publisher
  shm: ./tmp/md_shm
{batch_mode_str}
"""

    def buildStrategyConfig(self, config):
        commonConfigStr = GenUtils.ConvertDictToContent(config.commonConfig.__dict__)
        orderLogicConfigStr = GenUtils.ConvertDictToContent(config.orderLogicConfig.__dict__)
        orderLogicCommonConfigStr = GenUtils.ConvertDictToContent(config.orderLogicCommonConfig.__dict__, indent = 4)

        if hasattr(config.predictorConfig, "model_path"):
            if config.mode == "SIM":
                if config.predictorConfig.model_path != "":
                    model_file_name = config.predictorConfig.model_path.split("/")[-1]
                    config.predictorConfig.model_path = f"./{model_file_name}"
                else:
                    config.predictorConfig.model_path = '""'

        predictorConfigStr = GenUtils.ConvertDictToContent(config.predictorConfig.__dict__)
        assist_predictor_config_str = ""
        if hasattr(config, "assistPredictorConfig") and len(config.assistPredictorConfig.factors) > 0:
            assistPredictorConfigStr = GenUtils.ConvertDictToContent(config.assistPredictorConfig.__dict__)
            assist_predictor_config_str = f"""
  assist_predictor_config:
    shm: ./tmp/md_shm
    predictor_code: {config.assist_predictor}
{assistPredictorConfigStr}
"""
        self.strategy_config = f"""
{self.hedger_str}
  common_config:
{commonConfigStr}
  predictor_config:
    predictor_code: {config.predictor}
{predictorConfigStr}

{assist_predictor_config_str}
  order_logic_config:
    order_logic_code: {config.order_logic}
    common:
{orderLogicCommonConfigStr}

{orderLogicConfigStr}
"""


    def buildHedgerConfig(self, config):
        self.hedger_str = ""
        if hasattr(config, "hedgerConfig") and config.hedgerConfig.use_hedger:
            self.hedgerConfigStr = GenUtils.ConvertDictToContent(config.hedgerConfig.__dict__)
            self.hedger_str = f"""
  hedger:
{self.hedgerConfigStr}
"""

    def buildTradeConfig(self, config):
        self.idle_strategy = f"""
"""
        algo_2_str = ""
        if hasattr(config, "hedgerConfig") and config.hedgerConfig.use_hedger:
            tcp_port = 12110
            if config.hedgerTs != -1:
                tcp_port = 12110 + (config.hedgerTs - 1) * 100

            algo_2_str = f"""
    - algo_id: {config.algo_id_2}
      logic_acct_id: {config.hedgerLogicAcctId}
      use_48bits_order_id: {config.use_48bits_order_id}
      max_qry_order_count: {config.max_qry_order_count}
"""
        self.ts_config = f"""
# trade server client config
trade:
  log_path: /opt/logs/as/
  leverage: {config.leverage}
  clients:
    - algo_id: {config.algo_id}
      logic_acct_id: {config.logicAcctId}
      use_48bits_order_id: {config.use_48bits_order_id}
      max_qry_order_count: {config.max_qry_order_count}
{algo_2_str}
""" 

    def buildTsConfig(self, config):
        algo_2_str = ""
        self.idle_strategy = f"""
idle_strategy: BUSY_WAIT
idle_sleep_us: 10
"""
        if config.cpu == -1:
            self.idle_strategy = f"""
idle_strategy: YIELD 
idle_sleep_us: 1
"""
            
        if hasattr(config, "hedgerConfig") and config.hedgerConfig.use_hedger:
            tcp_port = 12110
            if config.hedgerTs != -1:
                tcp_port = 12110 + (config.hedgerTs - 1) * 100

            algo_2_str = f"""
    - algo_id: {config.algo_id_2}
      username: test
      password: test
      logic_accts:
        - id: {config.hedgerLogicAcctId}
          name: {config.hedgerLogicAcctStr}
      host: {config.hedgerMachineIp}
      port: {tcp_port} 
      cpu: -1
      thread_priority: -1
"""
        log_str = """
  log_dir: /opt/logs/alphaless/ts
""" 
        if config.mode == "SIM":
            if hasattr(config, "use_ts_log") and config.use_ts_log == True:
                log_str = """
  log_dir: ./
"""
            else:
                log_str = """
"""
        ts_path = 'ts_01'
        if config.ts != -1:
            ts_path = f"ts_0{config.ts}"
            
        self.ts_config = f"""
# trade server client config
ts:
{log_str}
  clients:
    - algo_id: {config.algo_id}
      username: test
      password: test
      logic_accts:
        - id: {config.logicAcctId}
          name: {config.logicAcctStr}
      protocol: shm
      path: /opt/data/{ts_path}/kungfu
      name: {config.algo_name} 
      cpu: -1
      thread_priority: -1
{algo_2_str}
""" 

    def buildSimConfig(self, config):

        yaml_data = yaml.load(self.content, Loader=yaml.FullLoader)
        yaml_data['mode'] = 'sim'
        yaml_data['sim_engine'] = config.simConfig.sim_engine
        yaml_data['sim_fee'] = config.simConfig.sim_fee
        yaml_data['sim_leverage'] = config.simConfig.sim_leverage
        yaml_data['sim_latency'] = config.simConfig.sim_latency
        yaml_data['sim_order'] = config.simConfig.sim_order

        yaml_data['sim_use_exch_ts'] = config.simConfig.sim_configs["sim_use_exch_ts"]
        yaml_data['sim_configs'] = config.simConfig.sim_configs

        yaml_data['start_date'] = int(config.start_date)

        end = datetime.date(int(config.end_date[0:4]), int(config.end_date[4:6]), int(config.end_date[-2:]))
        end += datetime.timedelta(days=1)
        yaml_data['end_date'] = int(end.strftime('%Y%m%d'))

        self.content = yaml.dump(yaml_data, sort_keys=False)
