#pragma once

#include "OrderLogic.h"

class OrderLogicFactory {
public:
    static OrderLogic* generateOrderLogic(const std::string& order_logic_code);
};