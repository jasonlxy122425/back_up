#pragma once
#include "Hedger.h"
#include "GOrderOp.h"

class ZeusHedger : public Hedger {
public:
    ZeusHedger(){}
    ~ZeusHedger(){}

    void InitConfig(const Config &conf) override {
        auto hedger_config = conf.Get<Config>("hedger");
        config.use_market_order = GaiaUtils::GetParam<bool>(hedger_config, "use_market_order_for_hedge");
        config.round_for_hyperliquid = GaiaUtils::GetParam<bool>(hedger_config, "round_for_hyperliquid");
        config.hedge_take_bp = GaiaUtils::GetParam<double>(hedger_config, "hedge_take_bp");
        config.mkt_timeout_ns = GaiaUtils::GetParam<int64_t>(hedger_config, "mkt_timeout_ns");
        config.quoter_hedger_mkt_recv_diff_ns = GaiaUtils::GetParam<int64_t>(hedger_config, "quoter_hedger_mkt_recv_diff_ns");

        config.net_pos_risk_ratio = GaiaUtils::GetParam<double>(hedger_config, "net_pos_risk_ratio");

        config.hedger_ref_quoter_price_ratio = GaiaUtils::GetParam<double>(hedger_config, "hedger_ref_quoter_price_ratio");

        config.custom_hedge_min_notional = GaiaUtils::GetParam<double>(hedger_config, "custom_hedge_min_notional");
        config.custom_hedge_max_notional = GaiaUtils::GetParam<double>(hedger_config, "custom_hedge_max_notional");
        config.custom_pos_hedge_max_notional = GaiaUtils::GetParam<double>(hedger_config, "custom_pos_hedge_max_notional");

        config.hedge_interval_ns_in_exit = ONE_SECOND_IN_NANOS * GaiaUtils::GetParam<int64_t>(hedger_config, "hedge_interval_second_in_exit");

        config.hedge_interval_ns_in_disconnect = GaiaUtils::GetParam<int64_t>(hedger_config, "hedge_interval_ns_in_disconnect");
        config.exit_ns_in_disconnect = GaiaUtils::GetParam<int64_t>(hedger_config, "exit_ns_in_disconnect");
    }

    bool isHedged() override {
        ContractInfo *contract_info = strategy_fields_->contract_info;
        double mid_price = GaiaUtils::GetMidPrice(strategy_fields_->contract_info);
        if (contract_info->is_reverse && quoter_strategy_fields_->contract_info->is_reverse) {
            double total_net_pos_usd = quoter_strategy_fields_->sym_risk.contract_usd_risk + strategy_fields_->sym_risk.contract_usd_risk;
            double hedge_min_usd = std::max(strategy_fields_->contract_info->symbol_info->min_qty * strategy_fields_->contract_info->symbol_info->multiplier,
                                config.custom_hedge_min_notional);
            if(total_net_pos_usd > hedge_min_usd ||
                total_net_pos_usd < -hedge_min_usd)
            {
                return false;
            }
        } else {
            double hedge_min_coin = std::max(strategy_fields_->contract_info->symbol_info->min_qty * strategy_fields_->contract_info->symbol_info->multiplier,
                                config.custom_hedge_min_notional / mid_price);
            if (contract_info->is_reverse) {
                hedge_min_coin = std::max(strategy_fields_->contract_info->symbol_info->min_qty * strategy_fields_->contract_info->symbol_info->multiplier / mid_price,
                                config.custom_hedge_min_notional / mid_price);
            }
            double total_net_pos_coin = quoter_strategy_fields_->sym_risk.symbol_risk / config.hedger_ref_quoter_price_ratio + strategy_fields_->sym_risk.symbol_risk;
            // std::cout << "total_net_pos_coin: " << total_net_pos_coin << ", hedge_min_coin: " << hedge_min_coin << std::endl;
            if(total_net_pos_coin > hedge_min_coin ||
                total_net_pos_coin < -hedge_min_coin)
            {
                return false;
            }
        }

        return true;
    }

    void RiskCheck() override {
        quoter_strategy_fields_->risk_check_result.reset();

        ContractInfo *contract_info = strategy_fields_->contract_info;

        bool allow_process_bid = true;
        bool allow_process_ask = true;

        int num_bid = GaiaUtils::BookGetNumBidLevels(contract_info);
        int num_ask = GaiaUtils::BookGetNumAskLevels(contract_info);

        if(num_bid < 1 || num_ask < 1)
        {
            std::cout << "Risk Check: Book is empty, num_bid: " << num_bid << ","
                    << "num_ask: " << num_ask << ","
                    << "recv_ts: " << contract_info->latency_record.mkt_data.mkt_recv_ts << std::endl;
            allow_process_bid = false;
            allow_process_ask = false;
        }

        // mkt bbo check
        if(GaiaUtils::BookGetBestBidPrice(contract_info) > GaiaUtils::BookGetBestAskPrice(contract_info))
        {
            std::cout << "Risk Check: mkt data bbo error, bid:" << GaiaUtils::BookGetBestBidPrice(contract_info)
                        << ", ask:" << GaiaUtils::BookGetBestAskPrice(contract_info)
                        << ", recv_ts:" << contract_info->latency_record.mkt_data.mkt_recv_ts
                        << ", exch_ts:" << contract_info->latency_record.mkt_data.mkt_exch_ts << std::endl;

            allow_process_bid = false;
            allow_process_ask = false;
        }

        // hedger mkt time check
        if(contract_info->latency_record.mkt_data.mkt_recv_ts - contract_info->latency_record.mkt_data.mkt_exch_ts > config.mkt_timeout_ns)
        {
            std::cout << "Risk Check: hedger latency: " << contract_info->latency_record.mkt_data.mkt_recv_ts - contract_info->latency_record.mkt_data.mkt_exch_ts
                      << " over than " << config.mkt_timeout_ns
                      << ", recv_ts: " << contract_info->latency_record.mkt_data.mkt_recv_ts
                      << ", exch_ts: " << contract_info->latency_record.mkt_data.mkt_exch_ts << std::endl;

            allow_process_bid = false;
            allow_process_ask = false;
        }

        // quoter hedger mkt recv_ts diff
        ContractInfo *quoter_contract_info = quoter_strategy_fields_->contract_info;
        if(std::abs(quoter_contract_info->latency_record.mkt_data.mkt_recv_ts - contract_info->latency_record.mkt_data.mkt_recv_ts) > config.quoter_hedger_mkt_recv_diff_ns)
        {
            std::cout << "Risk Check: recv_ts diff between quoter and hedger over than " << config.quoter_hedger_mkt_recv_diff_ns
                      << ",quoter recv_ts:" << quoter_contract_info->latency_record.mkt_data.mkt_recv_ts
                      << ",hedger recv_ts:" << contract_info->latency_record.mkt_data.mkt_recv_ts 
                      << std::endl;

            allow_process_bid = false;
            allow_process_ask = false;
        }

        double total_net_pos_coin = quoter_strategy_fields_->sym_risk.symbol_risk + strategy_fields_->sym_risk.symbol_risk * config.hedger_ref_quoter_price_ratio;

        // control risk of net pos(quoter + hedger)
        if(total_net_pos_coin > config.net_pos_risk_ratio * quoter_strategy_fields_->order_size_coin)
        {
            allow_process_bid = false;
            std::cout << "Risk Check : total_net_pos1: " << total_net_pos_coin << ", order_size_coin: " << quoter_strategy_fields_->order_size_coin  << std::endl;
        }
        else if(total_net_pos_coin < -config.net_pos_risk_ratio * quoter_strategy_fields_->order_size_coin)
        {
            allow_process_ask = false;
            std::cout << "Risk Check : total_net_pos2: " << total_net_pos_coin  << ", order_size_coin: " << quoter_strategy_fields_->order_size_coin<< std::endl;
        }

        double bid_in_flight_coin = 0, ask_in_flight_coin = 0;
        GaiaUtils::GetInFlightOrderCoin(*strategy_fields_, bid_in_flight_coin, ask_in_flight_coin);

        double unhedged_quote_trade_coin = bid_in_flight_coin + ask_in_flight_coin;
        // control risk of unhedged trade
        if(unhedged_quote_trade_coin > config.net_pos_risk_ratio * quoter_strategy_fields_->order_size_coin)
        {
            allow_process_bid = false;
            allow_process_ask = false;
            std::cout << "Risk Check: unhedged_quote_trade_coin : " << unhedged_quote_trade_coin << std::endl;
        }

        double quote_mid = GaiaUtils::GetMidPrice(quoter_contract_info);
        double hedge_mid = GaiaUtils::GetMidPrice(contract_info);
        // check price ratio
        if(std::abs(quote_mid * config.hedger_ref_quoter_price_ratio - hedge_mid) / hedge_mid > 0.5)
        {
            allow_process_bid = false;
            allow_process_ask = false;
            std::cout << "Risk Check: hedger_ref_quoter_price_ratio error, "
                      << "hedger_ref_quoter_price_ratio: " << config.hedger_ref_quoter_price_ratio << ","
                      << "hedge_mid: " << hedge_mid << ","
                      << "quote_mid: " << quote_mid << ","
                      << "hedge recv_ts: " << contract_info->latency_record.mkt_data.mkt_recv_ts << ","
                      << "quote recv_ts: " << quoter_contract_info->latency_record.mkt_data.mkt_recv_ts
                      << std::endl;
        }

        if(!allow_process_bid) quoter_strategy_fields_->risk_check_result.allow_process_bid = false;
        if(!allow_process_ask) quoter_strategy_fields_->risk_check_result.allow_process_ask = false;
    }

    // called in idle time
    void tryHedge() override {
        static std::string fakeTradeId = "";
        HedgingLogic(*quoter_strategy_fields_, nullptr, fakeTradeId, 0, 0, 0, 0);
    }

    // called when quoter order is filled
    void HedgingLogic(StrategyFields &quoter_strategy_fields, GOrderState *orderState,
                        const std::string &tradeId, const double &quoterFilledPrice,
                        const double &quoterFilledSize, const int8_t &quoterFilledSideInt,
                        const double &quoterFilledFees) override {
        OrderType hedge_type = OrderType::LIMIT;
        if(config.use_market_order) hedge_type = OrderType::MARKET;

        if(quoter_strategy_fields.current_mode == StrategyMode::RiskExitMode) {
            RiskExitModeLogic(quoter_strategy_fields, orderState, tradeId, quoterFilledPrice, quoterFilledSize, quoterFilledSideInt, quoterFilledFees, hedge_type);
            return;
        }

        if(quoter_strategy_fields.current_mode == StrategyMode::LiquidateRiskMode ||
            quoter_strategy_fields.current_mode == StrategyMode::FullLiquidationMode) {
                return;
        }
        
        auto now = GaiaUtils::GetSysTimestamp();
        if(quoter_strategy_fields.current_mode == StrategyMode::DisconnectMode) {
            if (now - last_hedge_ns > config.hedge_interval_ns_in_disconnect) {
                HedgingLogicImpl(quoter_strategy_fields, orderState, tradeId, quoterFilledPrice, quoterFilledSize, quoterFilledSideInt, quoterFilledFees, hedge_type);
                last_hedge_ns = now;
            }

            // if (now - last_disconnect_ns > config.exit_ns_in_disconnect) {
            //     quoter_strategy_fields.setStrategyMode(StrategyMode::ExitMode, "exit, over exit_ns_in_disconnect");
            // }

            if(isHedged() && !hasInFlightOrder()) {
                quoter_strategy_fields.setStrategyMode(StrategyMode::NormalMode, "Recovered from disconnect, due to hedger is hedged and no order outside");
            }

	        return;
        }

        HedgingLogicImpl(quoter_strategy_fields, orderState, tradeId, quoterFilledPrice, quoterFilledSize, quoterFilledSideInt, quoterFilledFees, hedge_type);
    }

    void RiskExitModeLogic(StrategyFields &quoter_strategy_fields, GOrderState *orderState,
                        const std::string &tradeId, const double &quoterFilledPrice,
                        const double &quoterFilledSize, const int8_t &quoterFilledSideInt,
                        const double &quoterFilledFees, const OrderType &hedge_type) {
        if(GaiaUtils::GetSysTimestamp() - last_hedge_ns < config.hedge_interval_ns_in_exit)
        {
            return;
        }

        HedgingLogicImpl(quoter_strategy_fields, orderState, tradeId, quoterFilledPrice, quoterFilledSize, quoterFilledSideInt, quoterFilledFees, hedge_type);
        last_hedge_ns = GaiaUtils::GetSysTimestamp();
    }

    void HedgingLogicImpl(StrategyFields &quoter_strategy_fields, GOrderState *orderState,
                        const std::string &tradeId, const double &quoterFilledPrice,
                        const double &quoterFilledSize, const int8_t &quoterFilledSideInt,
                        const double &quoterFilledFees, const OrderType &hedge_type) {
        TradeHedge(quoter_strategy_fields, orderState, tradeId, quoterFilledPrice, quoterFilledSize, quoterFilledSideInt, quoterFilledFees, hedge_type);
        PositionHedge(quoter_strategy_fields, hedge_type);
    }

    void TradeHedge(StrategyFields &quoter_strategy_fields, GOrderState *orderState, const std::string &tradeId,
                    const double &quoterFilledPrice, const double &quoterFilledSize, const int8_t &quoterFilledSideInt,
                    const double &quoterFilledFees, const OrderType &hedge_type) {
        ContractInfo* &quoter_contract = quoter_strategy_fields.contract_info;
        ContractInfo* &hedger_contract = strategy_fields_->contract_info;

        double hedge_best_bid = GaiaUtils::BookGetBestBidPrice(hedger_contract);
        double hedge_best_ask = GaiaUtils::BookGetBestAskPrice(hedger_contract);
        double hedge_mid = (hedge_best_bid + hedge_best_ask) / 2;

        double hedge_price_tick = hedger_contract->symbol_info->prc_tick_size;
        double hedge_qty_tick = hedger_contract->symbol_info->qty_tick_size;

        double hedge_min_qty = std::max(0.0, hedger_contract->symbol_info->min_qty);
        double hedge_min_notional = std::max(config.custom_hedge_min_notional, hedger_contract->symbol_info->min_notional);
        double hedge_max_notional = config.custom_hedge_max_notional;


        double exchange_max_size = hedger_contract->symbol_info->max_qty;
        if(config.use_market_order) {
            exchange_max_size = hedger_contract->max_mkt_qty;
        } 
        double exchange_min_size = hedger_contract->symbol_info->min_qty;

        // save trade for hedging
        if (orderState != nullptr && tradeId != "" && tradeId != "UnknownFill" && savedQuoterTradeMap.find(tradeId) == savedQuoterTradeMap.end() && quoterFilledSize > eps) {
            double filled_coin = 0;
            if(quoter_contract->is_reverse) {
                filled_coin = quoterFilledSize * quoter_contract->symbol_info->multiplier / quoterFilledPrice;
            } else {
                filled_coin = quoterFilledSize * quoter_contract->symbol_info->multiplier;
            }
            double need_hedge_size = 0;
            if(hedger_contract->is_reverse && quoter_contract->is_reverse) {
                need_hedge_size = GaiaUtils::roundSizeViaQtyTick(quoterFilledSize * quoter_contract->symbol_info->multiplier / hedger_contract->symbol_info->multiplier, hedger_contract);
            } else if(hedger_contract->is_reverse) {
                need_hedge_size = GaiaUtils::roundSizeViaQtyTick(filled_coin * hedge_mid / hedger_contract->symbol_info->multiplier, hedger_contract);
            } else {
                need_hedge_size = GaiaUtils::roundSizeViaQtyTick(filled_coin / hedger_contract->symbol_info->multiplier / config.hedger_ref_quoter_price_ratio, hedger_contract);
            }
            TradeWrapper trade_wrapper(quoterFilledPrice, quoterFilledSize, need_hedge_size, orderState->ts_order->client_order_id().value, orderState->ts_order->logic_acct_id(), quoterFilledSideInt, filled_coin, orderState->strategy_order_type);
            savedQuoterTradeMap.insert(std::pair(tradeId, trade_wrapper));
        }

        GOrderState *hedgerOrderState;
        double hedgePrice;
        TradeWrapperMapType::iterator iter = savedQuoterTradeMap.begin();
        while (iter != savedQuoterTradeMap.end()) {
            TradeWrapper &trade_wrapper = iter->second;

            int hedgeSideInt = -trade_wrapper.side_int;
            Side hedgeSide = trade_wrapper.side_int == 1 ? Side::SELL : Side::BUY;

	        if(hedgeSideInt == 1) {
                hedgePrice = hedge_best_ask;
                hedgePrice = hedgePrice * (1 + config.hedge_take_bp / ONE_BASE_POINT);
                hedgePrice = GaiaUtils::ceilPrice(hedgePrice, hedge_price_tick);
            }else {
                hedgePrice = hedge_best_bid;
                hedgePrice = hedgePrice * (1 - config.hedge_take_bp / ONE_BASE_POINT);
                hedgePrice = GaiaUtils::floorPrice(hedgePrice, hedge_price_tick);
            }

            double hedge_max_size = 0;
            double hedge_min_size = 0;
            if(hedger_contract->is_reverse) {
                hedge_max_size = std::min(exchange_max_size, hedge_max_notional / hedger_contract->symbol_info->multiplier);
                hedge_min_size = std::max(exchange_min_size, hedge_min_notional / hedger_contract->symbol_info->multiplier);
            } else {
                hedge_max_size = std::min(exchange_max_size, hedge_max_notional / hedgePrice / hedger_contract->symbol_info->multiplier);
                hedge_min_size = std::max(exchange_min_size, hedge_min_notional / hedgePrice / hedger_contract->symbol_info->multiplier);
            }
            hedge_max_size = GaiaUtils::roundSizeViaQtyTick(hedge_max_size, hedger_contract);
            hedge_min_size = GaiaUtils::ceilSizeViaQtyTick(hedge_min_size, hedger_contract);


            double &needHedgeQty = trade_wrapper.need_hedge_qty; // size of hedge contract
            if (needHedgeQty < hedge_min_size && trade_wrapper.hedger_order_num == 0) {
                iter = savedQuoterTradeMap.erase(iter);
                continue;
            }
            // quoter_strategy_fields->current_mode = StrategyMode::ReduceOnlyMode;
            if(quoter_strategy_fields.current_mode == StrategyMode::ReduceOnlyMode && trade_wrapper.hedger_order_num == 0) {

                double quoter_mid = (GaiaUtils::BookGetBestAskPrice(quoter_contract) + GaiaUtils::BookGetBestBidPrice(quoter_contract)) / 2;
                double quoter_min_notional = std::max(quoter_contract->symbol_info->min_notional, quoter_contract->custom_min_notional);
                double quoter_min_size = std::max(quoter_contract->symbol_info->min_qty, quoter_min_notional / quoter_mid / quoter_contract->symbol_info->multiplier);
                if(quoter_contract->is_reverse) {
                    quoter_min_size = std::max(quoter_contract->symbol_info->min_qty, quoter_min_notional / quoter_contract->symbol_info->multiplier);
                }
                // std::cout << "quoter sym_risk: " << quoter_strategy_fields->sym_risk.symbol_risk << std::endl;
                // std::cout << "quoter min size: " << quoter_min_size << std::endl;
                bool is_less_than_min_size = std::abs(quoter_strategy_fields.sym_risk.symbol_risk) / quoter_contract->symbol_info->multiplier < quoter_min_size;
                if (quoter_contract->is_reverse) {
                    is_less_than_min_size = std::abs(quoter_strategy_fields.sym_risk.symbol_risk * quoter_strategy_fields.sym_risk.symbol_risk_avg_price) / quoter_contract->symbol_info->multiplier < quoter_min_size;
                }
                if(is_less_than_min_size) {
                    double base_coin_sum = strategy_fields_->sym_risk.symbol_risk;

                    // find flying order of hedger
                    double bid_inflight_coin = 0;
                    double ask_inflight_coin = 0;
                    GaiaUtils::GetInFlightOrderCoin(*strategy_fields_, bid_inflight_coin, ask_inflight_coin);

                    double base_coin_sum_with_inflight = base_coin_sum + (bid_inflight_coin - ask_inflight_coin);
                    int pos_hedge_side = 0;
                    if(base_coin_sum_with_inflight < -eps) {
                        pos_hedge_side = 1;
                    }else if(base_coin_sum_with_inflight > eps) {
                        pos_hedge_side = -1;
                    }
                    base_coin_sum_with_inflight = std::abs(base_coin_sum_with_inflight);

                    double pos_hedge_qty = 0;
                    if (hedger_contract->is_reverse && quoter_contract->is_reverse) {
                        // usd based
                        double bid_inflight_usd = 0, ask_inflight_usd = 0;
                        GaiaUtils::GetInFlightOrderUsd(*strategy_fields_, bid_inflight_usd, ask_inflight_usd);
                        auto net_usd_with_inflight = std::abs(strategy_fields_->sym_risk.contract_usd_risk + (bid_inflight_usd - ask_inflight_usd));
                        pos_hedge_qty = net_usd_with_inflight / hedger_contract->symbol_info->multiplier;
                    } else if (hedger_contract->is_reverse) {
                        // coin based turn to usd based
                        pos_hedge_qty = base_coin_sum_with_inflight * hedgePrice / hedger_contract->symbol_info->multiplier;
                    } else {
                        // coin based
                        pos_hedge_qty = base_coin_sum_with_inflight / hedger_contract->symbol_info->multiplier;
                    }
                    /*
                    std::cout << "pos_hedge_qty :" << pos_hedge_qty << ","
                                << "needHedgeQty: " << needHedgeQty  << ","
                                << "" << std::endl;
                    */
                    if(hedgeSideInt == pos_hedge_side) {
                        if(std::abs(pos_hedge_qty - needHedgeQty) < hedge_min_size) {
                            needHedgeQty = pos_hedge_qty;
                        }
                    }  
                }
            }

            while (needHedgeQty > hedge_max_size) {
                hedgerOrderState = GOrderOp::InsertOrder(*strategy_fields_, hedgePrice, hedge_max_size, hedgeSide, hedge_type, TimeInForce::IOC, PositionOffset::UNKNOWN, trade_wrapper.strategy_order_type);
                if(hedgerOrderState == nullptr)
                    return;

                hedgerOrderIdToQuoterTradeMap[hedgerOrderState->ts_order->client_order_id().value] = iter->first;
                needHedgeQty -= hedge_max_size;

                trade_wrapper.hedger_order_num++;
                LOG_AUTO(TradeHedgingMessage, quoter_contract->symbol_info->mirana_ticker.c_str(),
                            hedger_contract->symbol_info->mirana_ticker.c_str(), trade_wrapper.logic_acct_id,
                            hedgerOrderState->ts_order->logic_acct_id(), trade_wrapper.fill_qty,
                            trade_wrapper.fill_price, trade_wrapper.side_int, iter->first.c_str(),
                            trade_wrapper.client_order_id, hedgerOrderState->ts_order->client_order_id().value,
                            hedgerOrderState->ts_order->qty(), hedgerOrderState->ts_order->price(),
                            hedgerOrderState->ts_order->side() == Side::BUY ? 1 : -1);
            }

            needHedgeQty = GaiaUtils::roundSizeViaQtyTick(needHedgeQty, hedger_contract);
            if (needHedgeQty < hedge_min_size) {
                ++iter;
                continue;
            }

            hedgerOrderState = GOrderOp::InsertOrder(*strategy_fields_, hedgePrice, needHedgeQty, hedgeSide, hedge_type, TimeInForce::IOC, PositionOffset::UNKNOWN, trade_wrapper.strategy_order_type);
            if(hedgerOrderState == nullptr)
                return;

            hedgerOrderIdToQuoterTradeMap[hedgerOrderState->ts_order->client_order_id().value] = iter->first;
            needHedgeQty = 0;
            trade_wrapper.hedger_order_num++;

            LOG_AUTO(TradeHedgingMessage, quoter_contract->symbol_info->mirana_ticker.c_str(),
                    hedger_contract->symbol_info->mirana_ticker.c_str(), trade_wrapper.logic_acct_id,
                    hedgerOrderState->ts_order->logic_acct_id(), trade_wrapper.fill_qty, trade_wrapper.fill_price, trade_wrapper.side_int, iter->first.c_str(), trade_wrapper.client_order_id, hedgerOrderState->ts_order->client_order_id().value, hedgerOrderState->ts_order->qty(), hedgerOrderState->ts_order->price(), hedgerOrderState->ts_order->side() == Side::BUY ? 1 : -1);

            ++iter;
        }
    }

    void PositionHedge(StrategyFields &quoter_strategy_fields, const OrderType &hedge_type) {
        ContractInfo* &quoter_contract = quoter_strategy_fields.contract_info;
        ContractInfo* &hedger_contract = strategy_fields_->contract_info;


        double hedge_best_bid = GaiaUtils::BookGetBestBidPrice(hedger_contract);
        double hedge_best_ask = GaiaUtils::BookGetBestAskPrice(hedger_contract);
        double hedge_mid = (hedge_best_bid + hedge_best_ask) / 2;

        double hedge_price_tick = hedger_contract->symbol_info->prc_tick_size;
        double hedge_qty_tick = hedger_contract->symbol_info->qty_tick_size;

        double hedge_min_qty = std::max(eps, hedger_contract->symbol_info->min_qty);
        double hedge_min_notional = std::max(config.custom_hedge_min_notional, hedger_contract->symbol_info->min_notional);
        double hedge_max_notional = std::min(config.custom_hedge_max_notional, config.custom_pos_hedge_max_notional);


        double exchange_max_size = hedger_contract->symbol_info->max_qty;
        if(config.use_market_order) {
            exchange_max_size = hedger_contract->max_mkt_qty;
        }
        double exchange_min_size = hedger_contract->symbol_info->min_qty;

        Side pos_hedge_side;
        int  pos_hedge_side_int;
        Price hedge_price;
        double pos_hedge_coin;

        double quoter_risk = 0, hedger_risk = 0;
        double total_risk = 0, total_risk_with_inflight = 0;
        double pos_hedge_qty = 0;


        double bid_inflight = 0;
        double ask_inflight = 0;
        // find flying order of hedger


        if(hedger_contract->is_reverse && quoter_contract->is_reverse) {
            quoter_risk = quoter_strategy_fields.sym_risk.contract_usd_risk;
            hedger_risk = strategy_fields_->sym_risk.contract_usd_risk;
            total_risk = quoter_risk + hedger_risk;

            GaiaUtils::GetInFlightOrderUsd(*strategy_fields_, bid_inflight, ask_inflight);
            total_risk_with_inflight = total_risk + (bid_inflight - ask_inflight);

            pos_hedge_qty = GaiaUtils::roundSizeViaQtyTick(total_risk_with_inflight / hedger_contract->symbol_info->multiplier, hedger_contract);
        } else {
            // coin based calculation

            quoter_risk = quoter_strategy_fields.sym_risk.symbol_risk / config.hedger_ref_quoter_price_ratio;
            hedger_risk = strategy_fields_->sym_risk.symbol_risk;

            total_risk = quoter_risk + hedger_risk;

            GaiaUtils::GetInFlightOrderCoin(*strategy_fields_, bid_inflight, ask_inflight);
            total_risk_with_inflight = total_risk + (bid_inflight - ask_inflight);

            if(hedger_contract->is_reverse) {
                // coin based turn to usd based
                pos_hedge_qty = GaiaUtils::roundSizeViaQtyTick(total_risk_with_inflight * hedge_mid / hedger_contract->symbol_info->multiplier, hedger_contract);
            } else {
                pos_hedge_qty = GaiaUtils::roundSizeViaQtyTick(total_risk_with_inflight / hedger_contract->symbol_info->multiplier, hedger_contract);
            }
        }

        if (bid_inflight > eps || ask_inflight > eps) {
            return;
        }

        if(total_risk_with_inflight > eps) {
            pos_hedge_side = Side::SELL;
            pos_hedge_side_int = -1;
        } else if(total_risk_with_inflight < -eps) {
            pos_hedge_side = Side::BUY;
            pos_hedge_side_int = 1;
            total_risk_with_inflight = -total_risk_with_inflight;
        } else {
            return;
        }

	    pos_hedge_qty = pos_hedge_qty < -eps ? -pos_hedge_qty : pos_hedge_qty;


        if(pos_hedge_qty < hedge_min_qty) return;

        // std::cout << "pos_hedge_qty: " << pos_hedge_qty << std::endl;

        if(pos_hedge_side_int == 1) {
            hedge_price = hedge_best_ask;
            hedge_price = hedge_price * (1 + config.hedge_take_bp / ONE_BASE_POINT);
            hedge_price = GaiaUtils::ceilPrice(hedge_price, hedge_price_tick);
        }else {
            hedge_price = hedge_best_bid;
            hedge_price = hedge_price * (1 - config.hedge_take_bp / ONE_BASE_POINT);
            hedge_price = GaiaUtils::floorPrice(hedge_price, hedge_price_tick);
        }

        double hedge_max_size = 0;
        double hedge_min_size = 0;
        if(hedger_contract->is_reverse) {
            hedge_max_size = std::min(exchange_max_size, hedge_max_notional / hedger_contract->symbol_info->multiplier);
            hedge_min_size = std::max(exchange_min_size, hedge_min_notional / hedger_contract->symbol_info->multiplier);
        } else {
            hedge_max_size = std::min(exchange_max_size, hedge_max_notional / hedge_price / hedger_contract->symbol_info->multiplier);
            hedge_min_size = std::max(exchange_min_size, hedge_min_notional / hedge_price / hedger_contract->symbol_info->multiplier);
        }

        hedge_max_size = GaiaUtils::roundSizeViaQtyTick(hedge_max_size, hedger_contract);
        hedge_min_size = GaiaUtils::ceilSizeViaQtyTick(hedge_min_size, hedger_contract);

        if (pos_hedge_qty < hedge_min_size) {
            return;
        }

        hedge_max_size = GaiaUtils::roundSizeViaQtyTick(hedge_max_size, hedger_contract);
        hedge_min_size = GaiaUtils::ceilSizeViaQtyTick(hedge_min_size, hedger_contract);

        if (hedge_max_size < hedge_min_size) {
            return;
        }

        if (pos_hedge_qty < hedge_min_size) {
            return;
        }


        GOrderState *hedgerOrderState;
        // only one order per call of PositionHedge
        if (pos_hedge_qty > hedge_max_size) {
            hedgerOrderState = GOrderOp::InsertOrder(*strategy_fields_, hedge_price, hedge_max_size, pos_hedge_side, hedge_type, TimeInForce::IOC, PositionOffset::UNKNOWN, 0);

            if(hedgerOrderState == nullptr)
                return;
            pos_hedge_qty = pos_hedge_qty - hedge_max_size;
            LOG_AUTO(PositionHedgingMessage, quoter_contract->symbol_info->mirana_ticker.c_str(), hedger_contract->symbol_info->mirana_ticker.c_str(),
                                                   quoter_contract->logic_acct_id, hedgerOrderState->ts_order->logic_acct_id(),
                                                   hedgerOrderState->ts_order->client_order_id().value, hedgerOrderState->ts_order->price(),
                                                   hedgerOrderState->ts_order->qty(), hedgerOrderState->ts_order->side() == Side::BUY ? 1 : -1,
                                                   total_risk, bid_inflight, ask_inflight);
        } else {
            pos_hedge_qty = GaiaUtils::roundSizeViaQtyTick(pos_hedge_qty, hedger_contract);
            if(pos_hedge_qty < hedge_min_size) {
                return;
            }

            hedgerOrderState = GOrderOp::InsertOrder(*strategy_fields_, hedge_price, pos_hedge_qty, pos_hedge_side, hedge_type, TimeInForce::IOC, PositionOffset::UNKNOWN, 0);
            if(hedgerOrderState == nullptr)
                return;
            LOG_AUTO(PositionHedgingMessage, quoter_contract->symbol_info->mirana_ticker.c_str(), hedger_contract->symbol_info->mirana_ticker.c_str(),
                                                quoter_contract->logic_acct_id, hedgerOrderState->ts_order->logic_acct_id(),
                                                hedgerOrderState->ts_order->client_order_id().value, hedgerOrderState->ts_order->price(),
                                                hedgerOrderState->ts_order->qty(), hedgerOrderState->ts_order->side() == Side::BUY ? 1 : -1,
                                                total_risk, bid_inflight, ask_inflight);
        }
    }

    // Order update (ts order)
    void OnOrder(Order *order, const OrderStatusUpdate &update) override {
        if (hedgerOrderIdToQuoterTradeMap.find(order->client_order_id().value) == hedgerOrderIdToQuoterTradeMap.end())
        {
            return;
        }

        // Usage: find hedger order state by ts order
        // GOrderState *hedgerOrderState = strategy_fields_->order_state_map[order->client_order_id().value];

        std::string quoterTradeId = hedgerOrderIdToQuoterTradeMap[order->client_order_id().value];

        if (savedQuoterTradeMap.find(quoterTradeId) == savedQuoterTradeMap.end())
        {
            return;
        }

        TradeWrapper &tradeWrapper = savedQuoterTradeMap[quoterTradeId];

        if (order->closed())
        {
            hedgerOrderIdToQuoterTradeMap.erase(order->client_order_id().value);
            tradeWrapper.hedger_order_num--;

            if (update.fill_qty < eps)
                tradeWrapper.need_hedge_qty += (order->qty() - order->cum_fill_qty());
        }
    }


};
