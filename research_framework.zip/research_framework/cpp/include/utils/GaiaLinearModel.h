#pragma once
#include "GaiaModelBase.h"
#include "GaiaUtils.h"
#include <vector>
// #include "immintrin.h"


class GaiaLinearModel : public GaiaModelBase {
public:
    void Init(std::string &model_path, int feature_num, const Config &config = {}) final {
        auto factors_conf = config.Get<std::vector<Config>>("factors");
        for(size_t i = 0; i < factors_conf.size(); ++i) {
            auto factor_conf = factors_conf[i];
            double weight = factor_conf.Get<double>("coef");
            sorted_weights_.push_back(weight);
        }
    }

    void Calculate(const std::vector<double> &input, std::vector<double> &output, int64_t &output_len) final {
        // output_len = 1;
        // if(output.size() < 1) output.resize(1);
        sum_ = 0.0;
        index_ = 0;
        for (; index_ + 4 <= input.size(); index_ += 4) {
            sum_ += input[index_] * sorted_weights_[index_];
            sum_ += input[index_ + 1] * sorted_weights_[index_ + 1];
            sum_ += input[index_ + 2] * sorted_weights_[index_ + 2];
            sum_ += input[index_ + 3] * sorted_weights_[index_ + 3];
        }

        for (; index_ < input.size(); ++index_) {
            sum_ += input[index_] * sorted_weights_[index_];
        }

        output[0] = sum_;
    }

private:
    double sum_ = 0.0;
    size_t index_ = 0;
    std::vector<double> sorted_weights_;
};
