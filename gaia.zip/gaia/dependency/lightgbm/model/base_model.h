//
// Created by Hongjian Han on 8/28/22.
//
# pragma once
# include <vector>
# include "../thirdparty/rapidjson/document.h"

class BaseModel
{
public:
    explicit BaseModel() = default;
    virtual ~BaseModel() = default;
    virtual void get_model_dir(const std::string & dir){};
    virtual bool init(const rapidjson::Document & d){return false;};
    virtual void calculate(const std::vector<double>& input, std::vector<double> & output){};
};
