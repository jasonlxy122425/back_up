#include "Factor.h"
#include "Ema.h"
#include <cmath>
#include "GaiaCircularBuffer.h"

class TradeTQtyImbaFactor : public FactorInterface
{
public:
    TradeTQtyImbaFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
        ema_int = config.Get<int64_t>("ema_int");
        lookback = config.Get<int64_t>("lookback");
        ema.init(ema_int);
        qty_buffer.setSize(lookback, 0.0);

    };

    virtual std::string gen_name() {;
        return std::string("TradeTQtyImbaFactor") + '@' + std::to_string(lookback) + '@' + std::to_string(ema_int);
    }

    virtual void calculate(const FactorInput& input_data) {
        factor_value = 0.0;
        auto &trade = input_data.cur_contract->trade;
        if (trade.side == Side::BUY){
            qty_buffer.push(trade.qty);
        }
        else if (trade.side == Side::SELL){
            qty_buffer.push(-trade.qty);
        }
    
        if(qty_buffer.isFull() != false){
            double buys = qty_buffer.pos_sum();
            double sells = qty_buffer.neg_sum();  
            if (buys + sells > MinErr){
                factor_value = (buys - sells)/(buys + sells);
            }
        }
        ema.update(factor_value);
        factor_value = ema.get();
        
    };

private:
    int64_t ema_int;
    Ema ema;
    int64_t lookback;
    GaiaCircularBuffer<double> qty_buffer;
    
};
                              
