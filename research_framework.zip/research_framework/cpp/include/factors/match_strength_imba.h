#include "Factor.h"
#include "Ema.h"
#include <cmath>

class MatchStrengthImbaFactor : public FactorInterface
{
public:
    MatchStrengthImbaFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
        lookback = config.Get<int16_t>("lookback");
        imba_buffer.setSize(lookback, 0.0);
    };

    virtual std::string gen_name() {;
        return std::string("MatchStrengthImbaFactor") + '@' + std::to_string(lookback);
    }

    virtual void calculate(const FactorInput& input_data) {
        factor_value = 0.0;
        auto &gob = input_data.cur_contract->alphaBook;
        auto &demeter_data = input_data.cur_contract->demeter_data;
        double imba = demeter_data->GetGobUpdateSum(Side::BUY, demeter::BookOrderType::Match) - demeter_data->GetGobUpdateSum(Side::SELL, demeter::BookOrderType::Match);
        imba_buffer.push(imba);
        if(imba_buffer.isFull() != false){
            double imba_std = imba_buffer.std();
            if (imba_std > MinErr){
                factor_value = imba_buffer.mean()/imba_std;
            }
        }
    };

private:
    int64_t lookback;
    GaiaCircularBuffer<double> imba_buffer;
};
                              
