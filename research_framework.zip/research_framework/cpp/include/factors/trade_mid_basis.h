#include "Factor.h"
#include "Ema.h"
#include <cmath>

class TradeMidBasisFactor : public FactorInterface
{
public:
   TradeMidBasisFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
        asst_symbol = config.Get<std::string>("asst_symbol");
        asst_sid = SecMaster::instance().FindSid(asst_symbol);

    };

    virtual std::string gen_name() {;
        return std::string("TradeMidBasisFactor") + "@asst_symbol=" + asst_symbol;
    }

    virtual void calculate(const FactorInput& input_data) {
        factor_value = 0.0;
        int16_t current_sid = input_data.cur_contract->symbol_info->sid;
        auto &trade = input_data.cur_contract->trade;
        if (std::fabs(asst_sid - current_sid) < MinErr){
            if (trade.side == Side::BUY){
                asst_ask_price = trade.price;
            }
            else if (trade.side == Side::SELL){
                asst_bid_price = trade.price;
            }
        }
        else {
            if (trade.side == Side::BUY){
                target_ask_price = trade.price;
            }
            else if (trade.side == Side::SELL){
                target_bid_price = trade.price;
            }
        }
        if (target_bid_price > MinErr && asst_bid_price > MinErr  && target_ask_price > MinErr && asst_ask_price > MinErr ){
            double target_mid = (target_bid_price + target_ask_price)/2.0;
            double asst_mid = (asst_bid_price + asst_ask_price)/2.0;
            double basis = target_mid -  asst_mid;
            factor_value = basis - prev_basis;
            prev_basis = basis;
        }
    };


private:
    std::string asst_symbol;
    int64_t asst_sid;
    double target_bid_price = 0.0;
    double asst_bid_price = 0.0;
    double target_ask_price = 0.0;
    double asst_ask_price = 0.0;
    double prev_basis = 0.0;
};
                              
