import irbabel
from clickhouse_driver import Client
import pandas as pd
import os,sys
import yaml
import alphaless as al
from alphaless.secmaster import SecMaster, SymbolInfo, SecMasterLoader

home_path = '/home/syq/gitlab'
os.environ['LD_LIBRARY_PATH'] = f'{home_path}/alphaless-cpp/lib:/usr/local/lib64'

sys.path.append(f'{home_path}/gaia/python/orderbook')
import gaia_orderbook
connect = {
   "host":"prod-xy-clickhouse-tcp-c3abf903c2fce8cb.elb.ap-southeast-1.amazonaws.com", # xy
    "user": "default",
    "password": "CS8tmty6Hkmv",
    "port": 9000
}
client = Client(**connect)
# alter table ts_info delete where toDateTime(timestamp) < '2030-03-07 00:00:00'
loader = SecMasterLoader()
config=None
with open('/mnt/share/syq/secmaster.yml') as f_yml:
    config = yaml.load(f_yml, Loader=yaml.FullLoader)
    loader.load(al.to_config(config["secmaster"]))
rs,cols = client.execute(f"""
    select toUnixTimestamp64Nano(recv_ts) as recv_ts_ns,* from kronos_public.any_any_trade
    where
    zone = 'sg-kronos-prod-md-1a-01'
    and (sid == 12550)
    and toDate(exch_ts) == '2024-10-01'
    order by recv_ts
    limit 10000
 """, with_column_types=True)
new_cols = []
for c in cols:
    new_cols.append(c[0])

df_trade = pd.DataFrame(rs, columns=new_cols)
df_trade['type'] = 'trade'

rs,cols = client.execute(f"""
    select toUnixTimestamp64Nano(recv_ts) as recv_ts_ns,* from kronos_public.any_any_orderbook
    where
    zone = 'sg-kronos-prod-md-1a-01'
    and (sid == 12550)
    and toDate(exch_ts) == '2024-10-01'
    order by recv_ts
    limit 10000
 """, with_column_types=True)
new_cols = []
for c in cols:
    new_cols.append(c[0])

df_ob = pd.DataFrame(rs, columns=new_cols)
df_ob['type'] = 'ob'

rs,cols = client.execute(f"""
    select toUnixTimestamp64Nano(recv_ts) as recv_ts_ns,* from kronos_public.any_any_bestquote
    where
    zone = 'sg-kronos-prod-md-1a-01'
    and (sid == 12550)
    and toDate(exch_ts) == '2024-10-01'
    order by recv_ts
    limit 10000
 """, with_column_types=True)
new_cols = []
for c in cols:
    new_cols.append(c[0])

df_bq = pd.DataFrame(rs, columns=new_cols)
df_bq['type'] = 'bq'

df_data_set = pd.concat([df_trade, df_bq, df_ob])
df_data_set.sort_values('recv_ts_ns', inplace=True)
df_data_set['recv_ts'] = df_data_set['recv_ts_ns'].astype(int)
df_data_set['exch_ts'] = df_data_set['exch_ts'].astype(int)
df_data_set['qs_send_ts'] = df_data_set['qs_send_ts'].astype(int)
df_data_set.to_csv("data_set.csv")

class orderbook_manager:
    def __init__(self):
        self.om = gaia_orderbook.GaiaOrderbookManager()
        self.trade = gaia_orderbook.md.Trade()
        self.ob = gaia_orderbook.md.FlatOrderbookData()
        self.bq = gaia_orderbook.md.BestQuote()

    def get_src(self, src):
        if src == 'EXCHANGE':
            return gaia_orderbook.md.Source.EXCHANGE
        elif src == 'DMM':
            return gaia_orderbook.md.Source.DMM
        else:
            return gaia_orderbook.md.Source.UNKNOWN

    def trans_orderbook(self, orderbook, data):
        ob_line = []
        ob_line.append(orderbook.exch_ts())
        ob_line.append(data.recv_ts)
        ob_line.append(data.qs_send_ts)
        ob_line.append(data.sid)
        ob_line.append(self.get_src(data.src))
        ob_line.append(orderbook.seq_id())
        ob_line.append([ask.price for ask in orderbook.asks()])
        ob_line.append([ask.qty for ask in orderbook.asks()])
        ob_line.append([bid.price for bid in orderbook.bids()])
        ob_line.append([bid.qty for bid in orderbook.bids()])
        ob_line.append(data.zone)
        ob_line.append(data.type)
        return ob_line

    def on_orderbook(self, data):
        self.ob.sid = data.sid
        self.ob.num_bids = len(data.bid_price)
        self.ob.num_asks = len(data.ask_price)
        for idx in range(len(data.ask_price)):
            self.ob.ask_data()[idx][0] = data.ask_price[idx]
            self.ob.ask_data()[idx][1] = data.ask_qty[idx]
            
        for idx in range(len(data.bid_price)):
            self.ob.bid_data()[idx][0] = data.bid_price[idx]
            self.ob.bid_data()[idx][1] = data.bid_qty[idx]
        self.ob.exch_ts = data.exch_ts
        self.ob.recv_ts = data.recv_ts
        self.ob.seq_id = int(data.seq_id)

        self.ob.src = self.get_src(data.src)
        gaia_ob_ = self.om.OnOrderbook(self.ob.get_view())

        return self.trans_orderbook(gaia_ob_, data)

    def on_trade(self, data):
        self.trade.sid = data.sid
        self.trade.price = data.price
        self.trade.qty = data.qty
        self.trade.side = gaia_orderbook.md.Side.BUY
        if data.side == 'Sell':
            self.trade.side = gaia_orderbook.md.Side.SELL
        self.trade.exch_ts = data.exch_ts
        self.trade.recv_ts = data.recv_ts
        self.trade.set_trade_id(data.trade_id)
        self.trade.src = self.get_src(data.src)
        gaia_ob_ = self.om.OnTrade(self.trade)
        return self.trans_orderbook(gaia_ob_, data)

    def on_bestquote(self, data):

        self.bq.sid = data.sid
        self.bq.best_bid.price = data.best_bid_price
        self.bq.best_bid.qty = data.best_bid_qty
        self.bq.best_ask.price = data.best_ask_price
        self.bq.best_ask.qty = data.best_ask_qty
        self.bq.seq_id = int(data.seq_id)
        self.bq.exch_ts = data.exch_ts
        self.bq.recv_ts = data.recv_ts
        self.bq.src = self.get_src(data.src)
        gaia_ob_ = self.om.OnBestQuote(self.bq)

        return self.trans_orderbook(gaia_ob_, data)

    def get_orderbook(self, data_set):
        orderbook_df = []
        for idx, data in data_set.iterrows():
            ret = None
            if data['type'] == 'trade':
                ret = self.on_trade(data)
            elif data['type'] == 'ob':
                ret = self.on_orderbook(data)
            elif data['type'] == 'bq':
                ret = self.on_bestquote(data)
            if ret is not None:
                orderbook_df.append(ret)
        return pd.DataFrame(orderbook_df)
o_m = orderbook_manager()
ob = o_m.get_orderbook(df_data_set)

#print(ob)

ob.to_csv("./gaia_ob_py.csv", header=None)
