#include "Factor.h"
#include "Ema.h"
#include <cmath>

class MidBasisPhilFactor : public FactorInterface
{
public:
    MidBasisPhilFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
        asst_symbol = config.Get<std::string>("asst_symbol");
        ema_int = config.Get<int64_t>("ema_int");
        mid_ema_int = config.Get<int64_t>("mid_ema_int");
        asst_sid = SecMaster::instance().FindSid(asst_symbol);
        ema.init(ema_int);
        ema_mid_target.init(mid_ema_int);
        ema_mid_asst.init(mid_ema_int);

    };

    virtual std::string gen_name() {;
        return std::string("MidBasisPhilFactor") + '@' + std::to_string(mid_ema_int) + '@' + std::to_string(ema_int) + '@' + asst_symbol;
    }

    virtual void calculate(const FactorInput& input_data) {
        factor_value = 0.0;
        int16_t this_sid = input_data.cur_contract->symbol_info->sid;
        auto &gob = input_data.cur_contract->alphaBook;
        double mid_price = (gob->bid(0).price + gob->ask(0).price)/2.0;
        if (std::fabs(asst_sid - this_sid) < MinErr){
            asst_mid_price = mid_price;
        }
        else {
            target_mid_price = mid_price;
        }
        if (target_mid_price > MinErr && asst_mid_price > MinErr){
            ema_mid_target.update(target_mid_price);
            ema_mid_asst.update(asst_mid_price);
            factor_value = std::log(ema_mid_target.get()/target_mid_price) - std::log(ema_mid_asst.get()/asst_mid_price);
        }
        ema.update(factor_value);
        factor_value = ema.get();
    };


private:
    int64_t ema_int;
    int64_t mid_ema_int;
    Ema ema;
    Ema ema_mid_target;
    Ema ema_mid_asst;
    std::string asst_symbol;
    int64_t asst_sid;
    double target_mid_price = 0.0;
    double asst_mid_price = 0.0;
};
                              
