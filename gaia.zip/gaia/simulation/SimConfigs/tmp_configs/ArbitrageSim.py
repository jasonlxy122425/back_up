from Default.ArbConfig import *
from Default.DefaultCommonConfig import *

@config_interface
class TagConfig():
    def __init__(self):
        self.configs = []
        self.tag = 'sim_test'

    def generateParams(self, base_min_edge_bp):
        step = 1
        configs = []
        for idx in [1]:
            arb_config = ArbConfig()
            #arb_config.commonConfig.only_log_exec = False
            arb_config.orderLogicConfig.min_edge_bp = base_min_edge_bp + step * idx
            arb_config.orderLogicConfig.edge_range_bp = base_min_edge_bp + step * idx
            arb_config.orderLogicConfig.use_log_factor = 0
            arb_config.orderLogicConfig.vol_max_cap = 0
            arb_config.orderLogicConfig.vol_min_cap = 0
            arb_config.orderLogicConfig.custom_max_notional = 25000

            arb_config.hedgerConfig.mkt_timeout_ns = 5000000000
            arb_config.hedgerConfig.quoter_hedger_mkt_recv_diff_ns = 5000000000
            
            arb_config.predictorConfig.hedger_ref_quoter_price_ratio = 1
            arb_config.predictorConfig.demeter_sample_num = 100
            arb_config.predictorConfig.demeter_sample_type = "fixed_interval"

            arb_config.hedgerConfig.hedger_ref_quoter_price_ratio = 1
            arb_config.hedgerConfig.custom_hedge_max_notional = 10000
            arb_config.hedgerConfig.use_market_order_for_hedge = True
            arb_config.tag = self.tag
            arb_config.sub_tag = f"{self.tag}_{idx}"


            arb_config.predictorConfig.exp_base_num_notional = 1
            arb_config.hedgerConfig.use_market_order_for_hedge = True
            arb_config.num_of_book_levels = 20
            
            arb_config.orderLogicCommonConfig.set_values(notional_size = 10000,
                                                        stop_loss = -5000000,
                                                        use_market_order_for_liq = True,
                                                        max_pos_in_clips = 3,
                                                        mkt_timeout_ns = 5000000000,
                                                        use_balance_limit_mode = False
                                                        )
            arb_config.orderLogicCommonConfig.rate_limit_duration_ms=0
            arb_config.hedgerConfig.custom_pos_hedge_max_notional = arb_config.orderLogicCommonConfig.notional_size

            arb_config.set_sim(mode = 'SIM'
                                ,start_date = '20250201'
                                ,end_date = '20250201'
                                , sign_str = f"{idx}"
                                , sign = {"idx": idx}
                                ,target_server = 'sgp-kronos-prod-md-az2-01'
                                ,sim_output_engine = 'parquet'
                                ,sim_output_target = './gaia_orderbook.parquet'
                               )

            configs.append(arb_config)
        return configs
    
    def getSymbolConfig(self):
        symbol_name = ["ADA"]
        for symbol in symbol_name:
            for param_config in self.generateParams(20):
                param_config.setSymbol(f"Bybit_LinearSwap_{symbol}USDT",f"Binance_LinearSwap_{symbol}USDT")
                self.configs.append(param_config)


    def getConfig(self):
        self.getSymbolConfig()

        return self.configs
