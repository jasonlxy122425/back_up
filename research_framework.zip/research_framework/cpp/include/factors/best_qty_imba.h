#include "Factor.h"
#include "Ema.h"
#include <cmath>

class BestQtyImbaFactor : public FactorInterface
{
public:
    BestQtyImbaFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
    };

    virtual std::string gen_name() {
        return std::string("BestQtyImbaFactor");
    }

    virtual void calculate(const FactorInput& input_data) {
        auto &ob = input_data.cur_contract->alphaBook;
        double tmp_bid = std::log(ob->bid(0).qty + 1.0);
        double tmp_ask = std::log(ob->ask(0).qty + 1.0);
        factor_value = tmp_bid - tmp_ask;
    };

};
                              
