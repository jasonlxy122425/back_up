#include "OrderLogicDef.h"
#include "ApolloImpl.h"

STANDARD_ORDER_LOGIC_DEFINITION(Apollo, ApolloImpl)
