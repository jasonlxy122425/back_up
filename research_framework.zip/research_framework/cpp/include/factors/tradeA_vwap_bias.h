#include "Factor.h"
#include "Ema.h"
#include <cmath>
#include "GaiaCircularBuffer.h"

class TradeAVwapBiasFactor : public FactorInterface
{
public:
    TradeAVwapBiasFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
        lookback = config.Get<int64_t>("lookback");
        amt_buffer.setSize(lookback, 0.0);
        qty_buffer.setSize(lookback, 0.0);

    };

    virtual std::string gen_name() {;
        return std::string("TradeAVwapBiasFactor") + "@lookback=" + std::to_string(lookback);
    }

    virtual void calculate(const FactorInput& input_data) {
        factor_value = 0.0;
        auto &trade = input_data.cur_contract->trade;
        int64_t exch_ts = trade.exch_ts;
        if (trade.side == Side::BUY){
            last_ask = trade.price;
        } else if (trade.side == Side::SELL){
            last_bid = trade.price;
        }

        double amt = trade.price * trade.qty;
        
        if (exch_ts != prev_exch_ts) {
            if (amt_buffer.isFull()) {
                double oldest_amt = amt_buffer[0];
                double oldest_qty = qty_buffer[0];

                amt_sum -= oldest_amt;
                qty_sum -= oldest_qty;
            }

            amt_sum += amt;
            qty_sum += trade.qty;

            qty_buffer.push(trade.qty);
            amt_buffer.push(amt);
        } else {
            amt_sum += amt;
            qty_sum += trade.qty;

            qty_buffer[-1] += trade.qty;
            amt_buffer[-1] += amt;
        }
        
        if (qty_buffer.isFull()) {
            double vwap = (amt_sum / qty_sum);
            if (last_bid > MinErr && last_ask > MinErr) {
                double mid_price = (last_bid + last_ask) / 2.0;
                factor_value = vwap - mid_price;
            }
        }
        
        prev_exch_ts = exch_ts;
    };

    // virtual void calculate(const FactorInput& input_data) {

    //     factor_value = 0.0;
    //     auto &trade = input_data.cur_contract->trade;
    //     int64_t exch_ts = trade.exch_ts;
    //     if (trade.side == Side::BUY){
    //         last_ask = trade.price;
    //     }
    //     else if (trade.side == Side::SELL){
    //         last_bid = trade.price;
    //     }
    //     if (std::abs(exch_ts - prev_exch_ts) > MinErr){
    //         qty_buffer.push(trade.qty);
    //         amt_buffer.push(trade.price*trade.qty);
    //     }
    //     else {
    //         qty_buffer[-1] += trade.qty;
    //         amt_buffer[-1] += trade.price*trade.qty;
    //     }
    
    //     if(qty_buffer.isFull() != false){
    //         double vwap = amt_buffer.sum()/qty_buffer.sum();
    //         if (last_bid > MinErr && last_ask > MinErr){
    //             double mid_price = (last_bid + last_ask)/2.0;
    //             factor_value = vwap - mid_price;
    //         }
    //         ;
    //     }
    //     prev_exch_ts = exch_ts;
    // };

private:
    int64_t lookback;
    GaiaCircularBuffer<double> qty_buffer;
    GaiaCircularBuffer<double> amt_buffer;
    double last_bid = 0.0;
    double last_ask = 0.0;
    int64_t prev_exch_ts = 0;

    double amt_sum = 0, qty_sum = 0;
};
                              
