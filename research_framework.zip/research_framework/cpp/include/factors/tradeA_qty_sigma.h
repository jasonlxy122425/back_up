#include "Factor.h"
#include "Ema.h"
#include <cmath>
#include "GaiaCircularBuffer.h"

class TradeAQtySigmaFactor : public FactorInterface
{
public:
    TradeAQtySigmaFactor(){};
    virtual void Init(Config &config) {
        symbol = config.Get<std::string>("symbol");
        lookback = config.Get<int64_t>("lookback");
        qty_buffer.setSize(lookback, 0.0);
    };

    virtual std::string gen_name() {;
        return std::string("TradeAQtySigmaFactor") + "@lookback=" + std::to_string(lookback);
    }

    virtual void calculate(const FactorInput& input_data) {
        factor_value = 0.0;
        auto &trade = input_data.cur_contract->trade;
        int64_t exch_ts = trade.exch_ts;
        if (std::abs(exch_ts - prev_exch_ts) > MinErr){
            qty_buffer.push(trade.qty);
        }
        else {
            qty_buffer[-1] += trade.qty;
        }

        if(qty_buffer.isFull() != false){
            factor_value = qty_buffer.std();
        }
        prev_exch_ts = exch_ts;
    };

private:
    int64_t lookback;
    GaiaCircularBuffer<double> qty_buffer;
    int64_t prev_exch_ts = 0;

};
                              
                      
