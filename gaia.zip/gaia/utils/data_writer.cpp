#include "data_writer.h"
#include "parquet_writer.h"

std::shared_ptr<DataWriter> DataWriter::CreateDataWriter(const Config &config, StrategyFields *st, Predictor *predictor, std::shared_ptr<demeter::DemeterDataManager> demeter_data_manager) {
    std::string engine = config.Get<std::string>("engine");
    std::shared_ptr<DataWriter> ptr;
    if (engine == "parquet") {
        ptr =  std::make_shared<ParquetWriter>();
    } else {
        throw std::runtime_error("Unsupported engine: " + engine);
    }

    if(demeter_data_manager != nullptr) ptr->setDemeterDatas(demeter_data_manager);
    ptr->Initialize(config, st, predictor);
    return ptr;
}